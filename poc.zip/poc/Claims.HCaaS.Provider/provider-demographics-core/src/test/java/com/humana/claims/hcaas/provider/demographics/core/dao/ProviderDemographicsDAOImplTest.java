package com.humana.claims.hcaas.provider.demographics.core.dao;

import static com.humana.claims.hcaas.provider.demographics.core.dao.ProviderDemographicsMongoConstants.COLLECTION_PROVIDER_DEMOGRAPHICS;
import static com.humana.claims.hcaas.provider.demographics.core.util.ProviderDemographicsTestData.createDemographics;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.humana.claims.hcaas.common.test.spring.mongodb.ConfigureInMemoryMongoTestServer;
import com.humana.claims.hcaas.provider.demographics.core.exception.ProviderDemographicsNotFoundException;
import com.humana.claims.hcaas.provider.demographics.core.model.DemographicsDBResponse;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.demographics.core.model.db.DemographicsKey;
import com.humana.claims.hcaas.provider.demographics.core.model.db.NpiInfos;
import com.humana.claims.hcaas.provider.demographics.core.model.db.ProviderInfo;
import com.humana.claims.hcaas.provider.demographics.core.util.ProviderDemographicsPatchUtil;

import lombok.SneakyThrows;

@SpringBootTest(classes = {ProviderDemographicsDAOImpl.class, ProviderDemographicsPatchUtil.class, ProviderDemographicsDataEncryptionTestImpl.class})
@ConfigureInMemoryMongoTestServer
public class ProviderDemographicsDAOImplTest {

	@Autowired
	private MongoTemplate mongoTemplate;

	@Autowired
	private ProviderDemographicsDAOImpl providerDemographicsDAOImpl;

	@AfterEach
	public void dropCollection() {
		mongoTemplate.dropCollection(COLLECTION_PROVIDER_DEMOGRAPHICS);
	}

	@SneakyThrows
	@Test
	public void testUpsertDemographicsInsert() {
		Demographics testDemographicsData = createDemographics();
		providerDemographicsDAOImpl.upsertProviderDemographicsProv1(testDemographicsData);

		List<Demographics> actual = mongoTemplate.findAll(Demographics.class, COLLECTION_PROVIDER_DEMOGRAPHICS);

		assertThat(actual).isNotNull();
		assertThat(actual.size()).isEqualTo(1);
		assertThat(actual).usingElementComparatorIgnoringFields("id").contains(testDemographicsData);

	}

	@SneakyThrows
	@Test
	public void testUpsertDemographicsUpdateExisting() {
		Demographics testDemographicsData1 = createDemographics();
		Demographics testDemographicsData2 = createDemographics();
		testDemographicsData2.setIrsNo("999999988");
		mongoTemplate.save(testDemographicsData1, COLLECTION_PROVIDER_DEMOGRAPHICS);

		providerDemographicsDAOImpl.upsertProviderDemographicsProv1(testDemographicsData2);

		List<Demographics> actual = mongoTemplate.findAll(Demographics.class, COLLECTION_PROVIDER_DEMOGRAPHICS);

		assertThat(actual).isNotNull();
		assertThat(actual.size()).isEqualTo(1);
		assertThat(actual.get(0).getIrsNo()).isEqualTo("999999988");
	}

	@Test
	public void testPostDemographicsSuccess() {
		Demographics testDemographics = createDemographics();

		providerDemographicsDAOImpl.postProviderDemographics(testDemographics);

		List<Demographics> actual = mongoTemplate.findAll(Demographics.class, COLLECTION_PROVIDER_DEMOGRAPHICS);

		assertThat(actual.size()).isEqualTo(1);
		assertThat(actual).usingElementComparatorIgnoringFields("id").contains(testDemographics);
	}

	@SneakyThrows
	@Test
	public void testUpdateDemographicsWhenRecordExistsInDatabase() {
		Demographics testDemographics1 = createDemographics();
		Demographics testDemographics2 = createDemographics();
		testDemographics2.setIrsNo("999999988");
		mongoTemplate.save(testDemographics1, COLLECTION_PROVIDER_DEMOGRAPHICS);

		providerDemographicsDAOImpl.updateProviderDemographics(testDemographics2, "542", " ", "H");

		List<Demographics> actual = mongoTemplate.findAll(Demographics.class, COLLECTION_PROVIDER_DEMOGRAPHICS);

		assertThat(actual.size()).isEqualTo(1);
		assertThat(actual.get(0).getIrsNo()).isNotEqualTo(testDemographics1.getIrsNo());
		assertThat(actual.get(0).getIrsNo()).isEqualTo(testDemographics2.getIrsNo());
	}

	@SneakyThrows
	@Test
	public void testUpdateDemographicsWhenNoRecordExistsInDatabase() {
		Demographics testDemographics = createDemographics();
		testDemographics.setIrsNo("999999988");
		
		Demographics actual = providerDemographicsDAOImpl.updateProviderDemographics(testDemographics, "542", " ", "H");
	
		assertThat(actual).isNull();	
	}
	

	@SneakyThrows
	@Test
	public void testUpdateDemographicsProv2WhenRecordExistsInDatabase() {
		Demographics testDemographics1 = createDemographics();
		Demographics testDemographics2 = createDemographics();
		List<NpiInfos> npiIds = new ArrayList<>();
		NpiInfos npiInfos = new NpiInfos();
		npiInfos.setNpiId("0123456789");
		npiIds.add(npiInfos);
		testDemographics2.getProviderInfo().setNpiIds(npiIds);

		mongoTemplate.save(testDemographics1, COLLECTION_PROVIDER_DEMOGRAPHICS);

		providerDemographicsDAOImpl.updateProviderDemographicsProv2(testDemographics2);

		List<Demographics> actual = mongoTemplate.findAll(Demographics.class, COLLECTION_PROVIDER_DEMOGRAPHICS);

		assertThat(actual.size()).isEqualTo(1);
		assertThat(actual.get(0).getProviderInfo().getNpiIds())
				.isEqualTo(testDemographics2.getProviderInfo().getNpiIds());

	}

	@SneakyThrows
	@Test
	public void testUpdateDemographicsProv2WhenNoRecordExistsInDatabase() {

		Throwable actualThrown = catchThrowable(
				() -> providerDemographicsDAOImpl.updateProviderDemographicsProv2(createDemographics()));

		assertThat(actualThrown).isInstanceOf(ProviderDemographicsNotFoundException.class);
	}
	
	
    @SneakyThrows
	@Test
	public void testGetDemographicsByProviderTaxIdWhenSingleRecordExistsInDatabase() {
		Demographics testDemographics = createDemographics();
		testDemographics.setIrsNo("999999988");
		testDemographics.setAlphaKey("ALPHA KEY TEST");
		mongoTemplate.save(testDemographics, COLLECTION_PROVIDER_DEMOGRAPHICS);
		
		Map<String, String> queryMap = new LinkedHashMap<>();
		queryMap.put("irsNo", "999999988");
		
		DemographicsDBResponse actual = providerDemographicsDAOImpl.getDemographicsByProviderTaxId(queryMap,1000,0,true);
		
		assertThat(actual).isNotNull();
		assertThat(actual.getDemographics().size()).isEqualTo(1);
		assertEquals("999999988",actual.getDemographics().get(0).getIrsNo());
		assertEquals("1",actual.getTotalCount());
		assertEquals("ALPHA KEY TEST", actual.getDemographics().get(0).getAlphaKey());
	}
    
    /**
     * When we query the provider api by Tax ID, we have a specific requirement -
     * If the number of provider document found using the TaxId is Zero, then api should be searching the provider database again using the incoming tax id as the provider id.
     * If the incoming tax id found any match in the provider database against the provider Id field, then return those documents.
     * 
     */
    @SneakyThrows
   	@Test
   	public void testGetDemographicsByProviderTaxIdWhenIncomingValueMatchesProvideIDButNotTaxid() {
   		Demographics testDemographics = createDemographics();
   		testDemographics.setIrsNo("999999999");
   		testDemographics.setAlphaKey("ALPHA KEY TEST");
   		testDemographics.getKey().setProv("229999922");
   		
   		mongoTemplate.save(testDemographics, COLLECTION_PROVIDER_DEMOGRAPHICS);
   		
   		Map<String, String> queryMap = new LinkedHashMap<>();
   		queryMap.put("irsNo", "229999922");
   		queryMap.put("alphaKey", "Alpha Key Test");
   		
   		DemographicsDBResponse actual = providerDemographicsDAOImpl.getDemographicsByProviderTaxId(queryMap,1000,0,true);
   		
   		assertThat(actual).isNotNull();
   		assertThat(actual.getDemographics().size()).isEqualTo(1);
   		assertEquals("999999999",actual.getDemographics().get(0).getIrsNo());
   		assertEquals("229999922",actual.getDemographics().get(0).getKey().getProv());
   		assertEquals("1",actual.getTotalCount());
   		assertEquals("ALPHA KEY TEST", actual.getDemographics().get(0).getAlphaKey());
   	}

    @SneakyThrows
   	@Test
   	public void testGetDemographicsByProviderTaxIdWhenIncomingValueMatchesProvideIDButNotTaxidWithPvdStatus1() {
   		Demographics testDemographics = createDemographics();
   		testDemographics.setIrsNo("999999999");
   		testDemographics.getKey().setProv("229999922");
		testDemographics.setPvdStatus("1");
   		
   		mongoTemplate.save(testDemographics, COLLECTION_PROVIDER_DEMOGRAPHICS);
   		
   		Map<String, String> queryMap = new LinkedHashMap<>();
   		queryMap.put("irsNo", "229999922");
   		queryMap.put("pvdStatus", "1");
   		
   		DemographicsDBResponse actual = providerDemographicsDAOImpl.getDemographicsByProviderTaxId(queryMap,1000,0,true);
   		
   		assertThat(actual).isNotNull();
   		assertThat(actual.getDemographics().size()).isEqualTo(1);
   		assertEquals("999999999",actual.getDemographics().get(0).getIrsNo());
   		assertEquals("229999922",actual.getDemographics().get(0).getKey().getProv());
   		assertEquals("1",actual.getTotalCount());
   	}
    
    @SneakyThrows
   	@Test
   	public void testGetDemographicsByProviderTaxIdWhenIncomingValueMatchesProvideIDButNotTaxidWithPvdStatusAsNull() {
   		Demographics testDemographics = createDemographics();
   		testDemographics.setIrsNo("999999999");
   		testDemographics.getKey().setProv("229999922");
   		
   		mongoTemplate.save(testDemographics, COLLECTION_PROVIDER_DEMOGRAPHICS);
   		
   		Map<String, String> queryMap = new LinkedHashMap<>();
   		queryMap.put("irsNo", "229999922");
   		queryMap.put("pvdStatus", null);
   		
   		DemographicsDBResponse actual = providerDemographicsDAOImpl.getDemographicsByProviderTaxId(queryMap,1000,0,true);
   		
   		assertThat(actual).isNotNull();
   		assertThat(actual.getDemographics().size()).isEqualTo(1);
   		assertEquals("999999999",actual.getDemographics().get(0).getIrsNo());
   		assertEquals("0",actual.getDemographics().get(0).getPvdStatus());
   		assertEquals("229999922",actual.getDemographics().get(0).getKey().getProv());
   		assertEquals("1",actual.getTotalCount());
   	}
    
    @SneakyThrows
   	@Test
   	public void testGetDemographicsByProviderTaxIdWhenPvdStatusAs2WithIncomingPvdStatusAsNullAndNoRecordReturned() {
   		Demographics testDemographics = createDemographics();
   		testDemographics.setIrsNo("999999999");
   		testDemographics.getKey().setProv("229999922");
		testDemographics.setPvdStatus("2");
   		
   		mongoTemplate.save(testDemographics, COLLECTION_PROVIDER_DEMOGRAPHICS);
   		
   		Map<String, String> queryMap = new LinkedHashMap<>();
   		queryMap.put("irsNo", "229999922");
   		queryMap.put("pvdStatus", null);
   		
   		DemographicsDBResponse actual = providerDemographicsDAOImpl.getDemographicsByProviderTaxId(queryMap,1000,0,true);
   		
   		assertThat(actual.getDemographics().size()).isEqualTo(0);
   	}
    
    @SneakyThrows
   	@Test
   	public void testGetDemographicsByProviderTaxIdWhenPvdStatusAs0WithIncomingPvdStatusAsNull() {
   		Demographics testDemographics = createDemographics();
   		testDemographics.setIrsNo("999999999");
   		testDemographics.getKey().setProv("229999922");
		testDemographics.setPvdStatus("0");
   		
   		mongoTemplate.save(testDemographics, COLLECTION_PROVIDER_DEMOGRAPHICS);
   		
   		Map<String, String> queryMap = new LinkedHashMap<>();
   		queryMap.put("irsNo", "229999922");
   		queryMap.put("pvdStatus", null);
   		
   		DemographicsDBResponse actual = providerDemographicsDAOImpl.getDemographicsByProviderTaxId(queryMap,1000,0,true);
   		
   		assertThat(actual).isNotNull();
   		assertThat(actual.getDemographics().size()).isEqualTo(1);
   	}
    
    @Test
   	public void testGetDemographicsByProviderTaxIdWhenIncomingPvdStatusAsNullAndProviderRecordReasonCodeWith1E() {
   		Demographics testDemographics =createDemographics();
   		testDemographics.setIrsNo("999999999");
   		testDemographics.getKey().setProv("229999922");
   		ProviderInfo providerInfo = new ProviderInfo();
		providerInfo.setPvdStRc("1E");
		testDemographics.setProviderInfo(providerInfo);
		testDemographics.setPvdStatus("1");
   		
   		mongoTemplate.save(testDemographics, COLLECTION_PROVIDER_DEMOGRAPHICS);
   		
   		Map<String, String> queryMap = new LinkedHashMap<>();
   		queryMap.put("irsNo", "229999922");
   		queryMap.put("pvdStatus", null);
   		
   		DemographicsDBResponse actual = providerDemographicsDAOImpl.getDemographicsByProviderTaxId(queryMap,1000,0,true);
   		
   		assertThat(actual).isNotNull();
   		assertThat(actual.getDemographics().size()).isEqualTo(1);
   		assertEquals("999999999",actual.getDemographics().get(0).getIrsNo());
   		assertEquals("229999922",actual.getDemographics().get(0).getKey().getProv());
   		assertEquals("1",actual.getTotalCount());
   	}
    
	@SneakyThrows
	@Test
	public void testGetDemographicsByProviderIdWhenSingleRecordExistsInDatabase() {
		Demographics testDemographics = createDemographics();
		DemographicsKey key= new DemographicsKey();
		key.setProv("499999994");
		key.setClient("58");
		testDemographics.setAlphaKey("ALPHA KEY TEST");
		testDemographics.setKey(key);
		mongoTemplate.save(testDemographics, COLLECTION_PROVIDER_DEMOGRAPHICS);
		
		Map<String, String> queryMap = new LinkedHashMap<>();
		queryMap.put("key.prov", "499999994");
		queryMap.put("alphaKey", "Alpha Key Test");
		
		DemographicsDBResponse actual = providerDemographicsDAOImpl.getDemographicsByProviderId(queryMap,1000,0,false);
		
		assertThat(actual).isNotNull();
		assertThat(actual.getDemographics().size()).isEqualTo(1);
		assertEquals("499999994",actual.getDemographics().get(0).getKey().getProv());
		assertThat(actual.getTotalCount()).isEmpty();
		assertEquals("ALPHA KEY TEST" ,actual.getDemographics().get(0).getAlphaKey());
	}
	
	@SneakyThrows
	@Test
	public void testGetDemographicsByNpiIdWhenSingleRecordExistsInDatabase() {
		Demographics testDemographics = createDemographics();
		ProviderInfo providerInfo = new ProviderInfo();
		NpiInfos npiInfos= new NpiInfos();
		npiInfos.setNpiId("123456799");
		NpiInfos npiId2= new NpiInfos();
		npiId2.setNpiId("423456794");
		providerInfo.setNpiIds(Arrays.asList(npiInfos,npiId2));
		testDemographics.setProviderInfo(providerInfo);
		testDemographics.setAlphaKey("ALPHA KEY TEST");
		
		mongoTemplate.save(testDemographics, COLLECTION_PROVIDER_DEMOGRAPHICS);
		
		Map<String, String> queryMap = new LinkedHashMap<>();
		queryMap.put("providerInfo.npiIds.npiId", "123456799");
		queryMap.put("alphaKey", "Alpha Key Test");
		
		DemographicsDBResponse actual = providerDemographicsDAOImpl.getDemographicsByNpiId(queryMap,1000,0,true);
		
		assertThat(actual).isNotNull();
		assertThat(actual.getDemographics().size()).isEqualTo(1);
		assertEquals("123456799",actual.getDemographics().get(0).getProviderInfo().getNpiIds().get(0).getNpiId());
		assertEquals("423456794",actual.getDemographics().get(0).getProviderInfo().getNpiIds().get(1).getNpiId());
		assertEquals("1",actual.getTotalCount());
		assertEquals("ALPHA KEY TEST", actual.getDemographics().get(0).getAlphaKey());
	}
	
	@SneakyThrows
	@Test
	public void testGetDemographicsByNpiIdWhenNpiIdPassedAsNull() {
		Demographics testDemographics = createDemographics();
		ProviderInfo providerInfo = new ProviderInfo();
		NpiInfos npiInfos= new NpiInfos();
		npiInfos.setNpiId("123456799");
		NpiInfos npiId2= new NpiInfos();
		npiId2.setNpiId("423456794");
		providerInfo.setNpiIds(Arrays.asList(npiInfos,npiId2));
		testDemographics.setProviderInfo(providerInfo);
		
		mongoTemplate.save(testDemographics, COLLECTION_PROVIDER_DEMOGRAPHICS);
		
		Map<String, String> queryMap = new LinkedHashMap<>();
		queryMap.put("providerInfo.npiInfos.npiId", null);
		
		DemographicsDBResponse actual = providerDemographicsDAOImpl.getDemographicsByNpiId(queryMap,1000,0,true);
		
		assertThat(actual.getDemographics().size()).isEqualTo(0);
		assertEquals("0",actual.getTotalCount());
	}
	
	@SneakyThrows
	@Test
	public void testGetDemographicsByNpiIdWhenSingleRecordExistsInDatabaseWithPvdStatusAs0() {
		Demographics testDemographics = createDemographics();
		ProviderInfo providerInfo = new ProviderInfo();
		NpiInfos npiInfos= new NpiInfos();
		npiInfos.setNpiId("123456799");
		NpiInfos npiId2= new NpiInfos();
		npiId2.setNpiId("423456794");
		providerInfo.setNpiIds(Arrays.asList(npiInfos,npiId2));
		testDemographics.setProviderInfo(providerInfo);
		testDemographics.setPvdStatus("0");
		
		mongoTemplate.save(testDemographics, COLLECTION_PROVIDER_DEMOGRAPHICS);
		
		Map<String, String> queryMap = new LinkedHashMap<>();
		queryMap.put("providerInfo.npiIds.npiId", "123456799");
		queryMap.put("pvdStatus", "0");
		
		DemographicsDBResponse actual = providerDemographicsDAOImpl.getDemographicsByNpiId(queryMap,1000,0,true);
		
		assertThat(actual).isNotNull();
		assertThat(actual.getDemographics().size()).isEqualTo(1);
		assertEquals("123456799",actual.getDemographics().get(0).getProviderInfo().getNpiIds().get(0).getNpiId());
		assertEquals("423456794",actual.getDemographics().get(0).getProviderInfo().getNpiIds().get(1).getNpiId());
		assertEquals("1",actual.getTotalCount());
	}
	
	@SneakyThrows
	@Test
	public void testGetDemographicsByNpiIdWhenMultipleRecordsExistsInDatabase() {
		Demographics testDemographics = createDemographics();
		ProviderInfo providerInfo = new ProviderInfo();
		NpiInfos npiInfos= new NpiInfos();
		npiInfos.setNpiId("123456799");
		providerInfo.setNpiIds(Arrays.asList(npiInfos));
		testDemographics.setProviderInfo(providerInfo);
		Demographics testDemographics1 = createDemographics();
		ProviderInfo providerInfo1 = new ProviderInfo();
		NpiInfos npiId1= new NpiInfos();
		npiInfos.setNpiId("123456799");
		providerInfo1.setNpiIds(Arrays.asList(npiId1));
		testDemographics1.setProviderInfo(providerInfo);
		
		mongoTemplate.save(testDemographics, COLLECTION_PROVIDER_DEMOGRAPHICS);
		mongoTemplate.save(testDemographics1, COLLECTION_PROVIDER_DEMOGRAPHICS);
		
		Map<String, String> queryMap = new LinkedHashMap<>();
		queryMap.put("providerInfo.npiIds.npiId", "123456799");
		
		DemographicsDBResponse actual = providerDemographicsDAOImpl.getDemographicsByNpiId(queryMap,1000,0,true);
		
		assertThat(actual).isNotNull();
		assertThat(actual.getDemographics().size()).isEqualTo(2);
		assertEquals("123456799",actual.getDemographics().get(0).getProviderInfo().getNpiIds().get(0).getNpiId());
		assertEquals("123456799",actual.getDemographics().get(1).getProviderInfo().getNpiIds().get(0).getNpiId());
		assertEquals("2",actual.getTotalCount());
	}
	
	@SneakyThrows
	@Test
	public void testGetDemographicsByProvNameWhenSingleRecordExistsInDatabase() {
		Demographics testDemographics = createDemographics();
		testDemographics.setAlphaKey("NORTHERN HOSP");
		
		mongoTemplate.save(testDemographics, COLLECTION_PROVIDER_DEMOGRAPHICS);
		
		Map<String, String> queryMap = new LinkedHashMap<>();
		queryMap.put("alphaKey", "Northern HOSP");
		
		DemographicsDBResponse actual = providerDemographicsDAOImpl.getDemographicsByProvName(queryMap,1000,0,false);
		
		assertThat(actual).isNotNull();
		assertThat(actual.getDemographics().size()).isEqualTo(1);
		assertEquals("NORTHERN HOSP", actual.getDemographics().get(0).getAlphaKey());
		assertThat(actual.getTotalCount()).isEmpty();
	}

	@SneakyThrows
	@Test
	public void testGetDemographicsByProvNameWhenSingleRecordExistsInDatabaseWithPvdStatus1() {
		Demographics testDemographics = createDemographics();
		testDemographics.setAlphaKey("NORTHERN HOSP");
		testDemographics.setPvdStatus("ONE");
			
		mongoTemplate.save(testDemographics, COLLECTION_PROVIDER_DEMOGRAPHICS);
		
		Map<String, String> queryMap = new LinkedHashMap<>();
		queryMap.put("alphaKey", "Northern HOSP");
		queryMap.put("pvdStatus", "ONE");
		
		DemographicsDBResponse actual = providerDemographicsDAOImpl.getDemographicsByProvName(queryMap,1000,0,false);
		
		assertThat(actual).isNotNull();
		assertThat(actual.getDemographics().size()).isEqualTo(1);
		assertEquals("NORTHERN HOSP",actual.getDemographics().get(0).getAlphaKey());
		assertThat(actual.getTotalCount()).isEmpty();
	}
	
	@SneakyThrows
	@Test
	public void testGetDemographicsByProvNameWhenMultipleRecordExistsInDatabaseAndReturnsMultipleDocuments() {
		Demographics testDemographics = createDemographics();
		testDemographics.setAlphaKey("SPRING UNIVERSITY HOSPITAL");
		Demographics testDemographics1 = createDemographics();
		testDemographics1.setAlphaKey("SPRING UNIVERSITY HOSPITAL");
		
		mongoTemplate.save(testDemographics, COLLECTION_PROVIDER_DEMOGRAPHICS);
		mongoTemplate.save(testDemographics1, COLLECTION_PROVIDER_DEMOGRAPHICS);
		
		Map<String, String> queryMap = new LinkedHashMap<>();
		queryMap.put("alphaKey", "Spring University Hospital");
		
		DemographicsDBResponse actual = providerDemographicsDAOImpl.getDemographicsByProvName(queryMap,1000,0,false);
		
		assertThat(actual).isNotNull();
		assertThat(actual.getDemographics().size()).isEqualTo(2);
		assertEquals("SPRING UNIVERSITY HOSPITAL", actual.getDemographics().get(0).getAlphaKey());
		assertThat(actual.getTotalCount()).isEmpty();
	}
	
	@SneakyThrows
	@Test
	public void testGetDemographicsByProvNameWithPartialSearch() {
		Demographics testDemographics = createDemographics();
		testDemographics.setAlphaKey("JONATHAN");
		
		mongoTemplate.save(testDemographics, COLLECTION_PROVIDER_DEMOGRAPHICS);
		
		Map<String, String> queryMap = new LinkedHashMap<>();
		queryMap.put("alphaKey", "jon");
		
		DemographicsDBResponse actual = providerDemographicsDAOImpl.getDemographicsByProvName(queryMap,1000,0,false);
		
		assertThat(actual).isNotNull();
		assertThat(actual.getDemographics().size()).isEqualTo(1);
		assertEquals("JONATHAN", actual.getDemographics().get(0).getAlphaKey());
		assertThat(actual.getTotalCount()).isEmpty();
	}
	
	@SneakyThrows
	@Test
	public void testGetDemographicsByProvNameWithPartialSearchWithMixOfCapitalAndSmallCase() {
		Demographics testDemographics = createDemographics();
		testDemographics.setAlphaKey("JONATHAN");
		
		mongoTemplate.save(testDemographics, COLLECTION_PROVIDER_DEMOGRAPHICS);
		
		Map<String, String> queryMap = new LinkedHashMap<>();
		queryMap.put("alphaKey", "Jona");
		
		DemographicsDBResponse actual = providerDemographicsDAOImpl.getDemographicsByProvName(queryMap,1000,0,false);
		
		assertThat(actual).isNotNull();
		assertThat(actual.getDemographics().size()).isEqualTo(1);
		assertEquals("JONATHAN", actual.getDemographics().get(0).getAlphaKey());
		assertThat(actual.getTotalCount()).isEmpty();
	}
	
	@SneakyThrows
	@Test
	public void testGetDemographicsByProvNameWithPartialSearchWithAllCharsInSmallCase() {
		Demographics testDemographics = createDemographics();
		testDemographics.setAlphaKey("JONATHAN");
		
		mongoTemplate.save(testDemographics, COLLECTION_PROVIDER_DEMOGRAPHICS);
		
		Map<String, String> queryMap = new LinkedHashMap<>();
		queryMap.put("alphaKey", "jonathan");
		
		DemographicsDBResponse actual = providerDemographicsDAOImpl.getDemographicsByProvName(queryMap,1000,0,false);
		
		assertThat(actual).isNotNull();
		assertThat(actual.getDemographics().size()).isEqualTo(1);
		assertEquals("JONATHAN", actual.getDemographics().get(0).getAlphaKey());
		assertThat(actual.getTotalCount()).isEmpty();
	}
	
	@SneakyThrows
	@Test
	public void testGetDemographicsByProvNameShouldDOPartialSearchFromStartOnly() {
		Demographics testDemographics = createDemographics();
		testDemographics.setAlphaKey("ABCJONATHAN");
		
		mongoTemplate.save(testDemographics, COLLECTION_PROVIDER_DEMOGRAPHICS);
		
		Map<String, String> queryMap = new LinkedHashMap<>();
		queryMap.put("alphaKey", "Jonathan");
		
		DemographicsDBResponse actual = providerDemographicsDAOImpl.getDemographicsByProvName(queryMap,1000,0,false);
		
		assertThat(actual).isNotNull();
		assertThat(actual.getDemographics().size()).isEqualTo(0);
	}
	
	@SneakyThrows
	@Test
	public void testGetDemographicsByProvNameWithPartialSearchWithNonAlphaNumericChars() {
		Demographics testDemographics = createDemographics();
		testDemographics.setAlphaKey("JONATHAN ANDERSON");
		
		mongoTemplate.save(testDemographics, COLLECTION_PROVIDER_DEMOGRAPHICS);
		
		Map<String, String> queryMap = new LinkedHashMap<>();
		queryMap.put("alphaKey", "jona$~!@#$%^&*()-_=+\\/<>*+|than ");
		
		DemographicsDBResponse actual = providerDemographicsDAOImpl.getDemographicsByProvName(queryMap,1000,0,false);
		
		assertThat(actual).isNotNull();
		assertThat(actual.getDemographics().size()).isEqualTo(1);
		assertEquals("JONATHAN ANDERSON", actual.getDemographics().get(0).getAlphaKey());
		assertThat(actual.getTotalCount()).isEmpty();
	}
	
	@SneakyThrows
	@Test
	public void testGetDemographicsByProvNameWithPartialSearchWithSpaceAtEnd() {
		Demographics testDemographics = createDemographics();
		testDemographics.setAlphaKey("JONATHAN ANDERSON");
		
		mongoTemplate.save(testDemographics, COLLECTION_PROVIDER_DEMOGRAPHICS);
		
		Map<String, String> queryMap = new LinkedHashMap<>();
		queryMap.put("alphaKey", "jonathan ");
		
		DemographicsDBResponse actual = providerDemographicsDAOImpl.getDemographicsByProvName(queryMap,1000,0,false);
		
		assertThat(actual).isNotNull();
		assertThat(actual.getDemographics().size()).isEqualTo(1);
		assertEquals("JONATHAN ANDERSON", actual.getDemographics().get(0).getAlphaKey());
		assertThat(actual.getTotalCount()).isEmpty();
	}
	
	@SneakyThrows
	@Test
	public void testGetDemographicsByProvNameWithPartialSearchWithAllowedSpecialCharactersAndSearchStringLengthGreterThan20() {
		Demographics testDemographics = createDemographics();
		testDemographics.setAlphaKey("JONATHA9.\":';, ANDERSON");
		
		mongoTemplate.save(testDemographics, COLLECTION_PROVIDER_DEMOGRAPHICS);
		
		Map<String, String> queryMap = new LinkedHashMap<>();
		queryMap.put("alphaKey", "jonatha9.\":';, ANDE$~!@#$%^&*()-_=+\\/<>*+|RSON");
		
		DemographicsDBResponse actual = providerDemographicsDAOImpl.getDemographicsByProvName(queryMap,1000,0,false);
		
		assertThat(actual).isNotNull();
		assertThat(actual.getDemographics().size()).isEqualTo(1);
		assertEquals("JONATHA9.\":';, ANDERSON", actual.getDemographics().get(0).getAlphaKey());
		assertThat(actual.getTotalCount()).isEmpty();
	}
	
	@SneakyThrows
	@Test
	public void testGetDemographicsByProvNameWithNullAlphaKey() {
		Map<String, String> queryMap = new LinkedHashMap<>();
		queryMap.put("alphaKey", null);
		
		assertThatExceptionOfType(NullPointerException.class).isThrownBy(() -> 
			providerDemographicsDAOImpl.getDemographicsByProvName(queryMap,1000,0,false)
		);
	}

	@SneakyThrows
	@Test
	public void testGetDemographicsByProvNameWithPartialSearchTreatsPeriodAsStringAndNotRegexWildcard() {
		insertDemographicsIntoDB(d -> d.setAlphaKey("CDB"));
		insertDemographicsIntoDB(d -> d.setAlphaKey("C.B"));

		Map<String, String> query = alphaKeyQuery("C.B");
		DemographicsDBResponse actual = providerDemographicsDAOImpl.getDemographicsByProvName(query,1000,0,false);
		
		assertThat(actual).isNotNull();
		assertThat(actual.getDemographics().size()).isEqualTo(1);
		assertThat(actual.getDemographics().get(0).getAlphaKey()).isEqualTo("C.B");
	}

	private void insertDemographicsIntoDB(Consumer<Demographics> demographicsCustomizer) {
		Demographics testDemographics = createDemographics();
		demographicsCustomizer.accept(testDemographics);
		mongoTemplate.save(testDemographics, COLLECTION_PROVIDER_DEMOGRAPHICS);
	}

	private Map<String, String> alphaKeyQuery(String alphaKeySearchValue) {
		Map<String, String> queryMap = new LinkedHashMap<>();
		queryMap.put("alphaKey", alphaKeySearchValue);
		return queryMap;
	}
}
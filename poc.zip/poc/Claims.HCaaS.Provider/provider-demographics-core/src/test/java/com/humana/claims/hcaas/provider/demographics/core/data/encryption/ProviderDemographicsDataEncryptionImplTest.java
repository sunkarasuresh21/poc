package com.humana.claims.hcaas.provider.demographics.core.data.encryption;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.bson.BsonBinary;
import org.bson.Document;
import org.bson.types.Binary;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.humana.claims.hcaas.common.spring.boot.starter.mongodb.MongoDBFieldEncryptor;
import com.humana.claims.hcaas.provider.demographics.core.model.db.NpiInfos;
import com.mongodb.client.vault.ClientEncryption;

@ExtendWith(MockitoExtension.class)
public class ProviderDemographicsDataEncryptionImplTest {

	@InjectMocks
	private ProviderDemographicsDataEncryptionImpl dataEnrcyptionImpl;

	private static final String DETERMINISTIC_ENCRYPTION_TYPE = "AEAD_AES_256_CBC_HMAC_SHA_512-Deterministic";

	@Mock
	private MongoDBFieldEncryptor dbFieldEncryptor;

	ClientEncryption clientEncryption = Mockito.mock(ClientEncryption.class);

	@Test
	public void testEncryptionShouldHappenWhenFieldValueIsNotNull() {
		BsonBinary bsonVal = new BsonBinary("123456789".getBytes());
		BsonBinary bsonIrsVal = new BsonBinary("564321789".getBytes());
		BsonBinary bsonAddress = new BsonBinary("1501 PASADENA SOUTH".getBytes());
		BsonBinary bsonProvName = new BsonBinary("THE PALMS OF PASADENA HOSPITAL".getBytes());

		Document doc = createDocumentForEncryption();

		Mockito.when(dbFieldEncryptor.encrypt("123456789", DETERMINISTIC_ENCRYPTION_TYPE)).thenReturn(bsonVal);
		Mockito.when(dbFieldEncryptor.encrypt("564321789", DETERMINISTIC_ENCRYPTION_TYPE)).thenReturn(bsonIrsVal);
		Mockito.when(dbFieldEncryptor.encrypt("1501 PASADENA SOUTH", DETERMINISTIC_ENCRYPTION_TYPE))
				.thenReturn(bsonAddress);
		Mockito.when(dbFieldEncryptor.encrypt("THE PALMS OF PASADENA HOSPITAL", DETERMINISTIC_ENCRYPTION_TYPE))
				.thenReturn(bsonProvName);

		Document docReturned = dataEnrcyptionImpl.encryptProviderDemoData(doc);
		assertEquals(bsonIrsVal, docReturned.get("irsNo"));
		assertEquals(bsonVal, ((Document) docReturned.get("key")).get("prov"));
		assertEquals(bsonProvName, ((Document) docReturned.get("providerInfo")).get("provName"));
		assertEquals(bsonAddress,
				((Document) ((Document) docReturned.get("providerInfo")).get("address")).get("addr1"));
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testEncryptionShouldHappenWhenNpiIdFieldValueIsNotNull() {
		BsonBinary bsonVal = new BsonBinary("0123456789".getBytes());
		
		Document npiId = new Document();
		npiId.put("npiId", "0123456789");
		List<Document> npiIds = new ArrayList<>();
		npiIds.add(npiId);
		Document providerInfo = new Document();
		providerInfo.put("npiIds", npiIds);
		Document document = new Document();
		document.put("providerInfo", providerInfo);

		Mockito.when(dbFieldEncryptor.encrypt("0123456789", DETERMINISTIC_ENCRYPTION_TYPE)).thenReturn(bsonVal);

		Document docReturned = dataEnrcyptionImpl.encryptProviderDemoData(document);
		Document providerInfoDoc = (Document) docReturned.get("providerInfo");
		List<Document> listNpiIds = (List<Document>) providerInfoDoc.get("npiIds");
		Document npiIdDoc = (Document) listNpiIds.get(0);
		BsonBinary encryptedNpiId = (BsonBinary) npiIdDoc.get("npiId");
		assertEquals(bsonVal, encryptedNpiId);
	}

	@Test
	public void testDecryptionShouldHappenWhenFieldValueIsNotNull() {
		String providerId = "765432189";
		String irsNumber = "876543219";
		Binary bsonVal = new Binary(providerId.getBytes());
		Binary bsonIrs = new Binary(irsNumber.getBytes());

		Document doc = new Document();
		doc.put("prov", bsonVal);
		Document decDoc = new Document();
		decDoc.put("key", doc);
		decDoc.put("irsNo", bsonIrs);

		Mockito.when(dbFieldEncryptor.decrypt(new BsonBinary(bsonVal.getData()), DETERMINISTIC_ENCRYPTION_TYPE))
				.thenReturn(providerId);
		Mockito.when(dbFieldEncryptor.decrypt(new BsonBinary(bsonIrs.getData()), DETERMINISTIC_ENCRYPTION_TYPE))
				.thenReturn(irsNumber);

		Document docReturned = dataEnrcyptionImpl.decryptProviderDemoData(decDoc);
		assertEquals(providerId, docReturned.get("doc", doc.get("prov")));
		assertEquals(irsNumber, docReturned.get("irsNo"));
	}

	@Test
	public void testDecryptionShouldHappenWhenAddressFieldValueIsNotNull() {
		String addr1 = "TestingAddr1";
		Binary bsonVal = new Binary(addr1.getBytes());

		Document address = new Document();
		address.put("addr1", bsonVal);
		Document providerInfo = new Document();
		providerInfo.put("address", address);
		Document document = new Document();
		document.put("providerInfo", providerInfo);

		Mockito.when(dbFieldEncryptor.decrypt(new BsonBinary(bsonVal.getData()), DETERMINISTIC_ENCRYPTION_TYPE))
				.thenReturn(addr1);

		Document docReturned = dataEnrcyptionImpl.decryptProviderDemoData(document);
		assertEquals(addr1, ((Document) ((Document) docReturned.get("providerInfo")).get("address")).get("addr1"));
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testDecryptionShouldHappenWhenFieldValueIsNotNullForNpiId() {
		String npiId = "9876543210";
		Binary bsonVal = new Binary(npiId.getBytes());

		Document npiIdDoc = new Document();
		npiIdDoc.put("npiId", bsonVal);
		List<Document> npiIds = new ArrayList<>();
		npiIds.add(npiIdDoc);
		Document providerInfo = new Document();
		providerInfo.put("npiIds", npiIds);
		Document document = new Document();
		document.put("providerInfo", providerInfo);

		Mockito.when(dbFieldEncryptor.decrypt(new BsonBinary(bsonVal.getData()), DETERMINISTIC_ENCRYPTION_TYPE))
				.thenReturn(npiId);

		Document docReturned = dataEnrcyptionImpl.decryptProviderDemoData(document);
		Document providerInfoDoc = (Document) docReturned.get("providerInfo");
		List<Document> listNpiIds = (List<Document>) providerInfoDoc.get("npiIds");
		Document npiIdDocument = (Document) listNpiIds.get(0);
		String decryptedNpiId = (String) npiIdDocument.get("npiId");
		assertEquals(npiId, decryptedNpiId);
	}

	@Test
	public void testEncryptionShouldNotHappenWhenFieldValueIsNull() {
		Document address = new Document();
		address.put("addr1", null);
		address.put("addr2", null);
		Document providerInfo = new Document();
		providerInfo.put("provName", null);
		providerInfo.put("address", address);
		Document key = new Document();
		key.put("prov", null);
		Document document = new Document();
		document.put("key", key);
		document.put("irsNo", null);
		document.put("providerInfo", providerInfo);

		Document docReturned = dataEnrcyptionImpl.encryptProviderDemoData(document);
		assertNull(((Document) docReturned.get("key")).get("prov"));
		assertNull(((Document) docReturned.get("providerInfo")).get("provName"));
		assertNull(((Document) ((Document) docReturned.get("providerInfo")).get("address")).get("addr1"));
		assertNull(((Document) docReturned.get("key")).get("prov"));
	}

	@Test
	public void testDecryptionShouldNotHappenWhenFieldValueIsNull() {
		Document address = new Document();
		address.put("addr1", null);
		address.put("addr2", null);
		Document providerInfo = new Document();
		providerInfo.put("provName", null);
		providerInfo.put("address", address);
		Document key = new Document();
		key.put("prov", null);
		Document document = new Document();
		document.put("key", key);
		document.put("irsNo", null);
		document.put("providerInfo", providerInfo);

		Document docReturned = dataEnrcyptionImpl.decryptProviderDemoData(document);
		assertNull(((Document) docReturned.get("key")).get("prov"));
		assertNull(((Document) docReturned.get("providerInfo")).get("provName"));
		assertNull(((Document) ((Document) docReturned.get("providerInfo")).get("address")).get("addr1"));
		assertNull(((Document) docReturned.get("key")).get("prov"));
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testEncryptionShouldHappenWhenPatchFieldValueIsNotNull() {
		BsonBinary bsonVal = new BsonBinary("provName".getBytes());
		BsonBinary bsonIrsNo = new BsonBinary("323456789".getBytes());
		BsonBinary bsonNpiId = new BsonBinary("823456789".getBytes());
		BsonBinary bsonAddress = new BsonBinary("testAddress1".getBytes());
		
		List<NpiInfos> npiIds = new ArrayList<>();
		NpiInfos npiInfos = new NpiInfos();
		npiInfos.setNpiId("823456789");
		npiIds.add(npiInfos);
		Document document = new Document();
		document.put("irsNo", "323456789");
		document.put("providerInfo.provName", "provName");
		document.put("providerInfo.address.addr1", "testAddress1");
		document.put("providerInfo.npiIds", npiIds);

		Mockito.when(dbFieldEncryptor.encrypt("provName", DETERMINISTIC_ENCRYPTION_TYPE)).thenReturn(bsonVal);
		Mockito.when(dbFieldEncryptor.encrypt("323456789", DETERMINISTIC_ENCRYPTION_TYPE)).thenReturn(bsonIrsNo);
		Mockito.when(dbFieldEncryptor.encrypt("823456789", DETERMINISTIC_ENCRYPTION_TYPE)).thenReturn(bsonNpiId);
		Mockito.when(dbFieldEncryptor.encrypt("testAddress1", DETERMINISTIC_ENCRYPTION_TYPE)).thenReturn(bsonAddress);
		
		Document docReturned = dataEnrcyptionImpl.encryptProviderPatchData(document);
		List<NpiInfos> encNpiId = (List<NpiInfos>) docReturned.get("providerInfo.npiIds");
		Map<String, BsonBinary> encryptedNpiIdDoc = (Map<String, BsonBinary>) encNpiId.get(0);
		BsonBinary encryptedNpiId = encryptedNpiIdDoc.get("npiId");
		assertEquals(bsonIrsNo, docReturned.get("irsNo"));
		assertEquals(bsonVal, docReturned.get("providerInfo.provName"));
		assertEquals(bsonAddress, docReturned.get("providerInfo.address.addr1"));
		assertEquals(bsonNpiId, encryptedNpiId);
	}

	@Test
	public void testProvIdEncryptionShouldHappenWhenFieldValueIsNotNull() {
		BsonBinary bsonVal = new BsonBinary("456742134".getBytes());
		String provId = "456742134";

		Mockito.when(dbFieldEncryptor.encrypt(provId, DETERMINISTIC_ENCRYPTION_TYPE)).thenReturn(bsonVal);

		BsonBinary actual = dataEnrcyptionImpl.encryptProviderId(provId);
		assertEquals(bsonVal, actual);
	}

	private Document createDocumentForEncryption() {
		Document npiId = new Document();
		npiId.put("npiId", "0123456789");
		List<Document> npiIds = new ArrayList<>();
		npiIds.add(npiId);
		Document address = new Document();
		address.put("addr1", "1501 PASADENA SOUTH");
		address.put("addr2", "US");
		Document providerInfo = new Document();
		providerInfo.put("provName", "THE PALMS OF PASADENA HOSPITAL");
		providerInfo.put("address", address);
		providerInfo.put("npiIds", npiIds);
		Document key = new Document();
		key.put("prov", "123456789");
		Document document = new Document();
		document.put("key", key);
		document.put("irsNo", "564321789");
		document.put("providerInfo", providerInfo);
		return document;
	}
}

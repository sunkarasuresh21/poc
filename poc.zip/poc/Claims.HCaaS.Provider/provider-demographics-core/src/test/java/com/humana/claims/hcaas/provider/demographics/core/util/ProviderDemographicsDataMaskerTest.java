package com.humana.claims.hcaas.provider.demographics.core.util;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.function.Supplier;

import org.junit.jupiter.api.Test;

import com.humana.claims.hcaas.provider.demographics.core.masker.ProviderDemographicsDataMasker;

public class ProviderDemographicsDataMaskerTest {
	
	private ProviderDemographicsDataMasker classUnderTest = new ProviderDemographicsDataMasker();
	
	@Test
	public void maskProviderIdTest() {
		String provId = "123456789";
		
		Supplier<String> maskProviderId = classUnderTest.maskProviderId(provId);
		
		assertThat(maskProviderId.get()).isEqualTo("12***89");
	}
	
	@Test
	public void maskIrsNoTest() {
		String irsNo = "123456789";
		
		Supplier<String> maskIrsNo = classUnderTest.maskIrsNo(irsNo);
		
		assertThat(maskIrsNo.get()).isEqualTo("12***89");
	}
	
	@Test
	public void maskNpiIdTest() {
		String npiId = "123456789";
		
		Supplier<String> maskNpiId = classUnderTest.maskNpiId(npiId);
		
		assertThat(maskNpiId.get()).isEqualTo("12***89");
	}
	
	@Test
	public void maskProvNameTest() {
		String provName = "123456789";
		
		Supplier<String> maskProvName = classUnderTest.maskProvName(provName);
		
		assertThat(maskProvName.get()).isEqualTo("12***89");
	}
}	
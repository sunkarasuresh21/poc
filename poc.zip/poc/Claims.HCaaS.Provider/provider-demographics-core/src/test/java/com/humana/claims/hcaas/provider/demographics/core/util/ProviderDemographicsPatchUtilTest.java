package com.humana.claims.hcaas.provider.demographics.core.util;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.query.Update;

import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
public class ProviderDemographicsPatchUtilTest {

	@InjectMocks
	private ProviderDemographicsPatchUtil classUnderTest;

	@Test
	public void test_classUnderTest_initialized() {
		assertNotNull(classUnderTest);
	}

	@Test
	@SneakyThrows
	public void testGetMongoUpdateObjForDemographicsWithUpdateSysAsNull() {
		Demographics demographics = ProviderDemographicsTestData.createDemographics();
		demographics.setUpdateSys(null);

		Update actual = classUnderTest.getMongoUpdateObjForDemographics(demographics);

		Document updateObjectSet = (Document)actual.getUpdateObject().get("$set");
		assertThat(updateObjectSet.keySet()).doesNotContain("updateSys");
	}

	@Test
	@SneakyThrows
	public void testGetMongoUpdateObjForDemographicsWithValidInput() {
		Demographics demographics = ProviderDemographicsTestData.createDemographics();

		Update actual = classUnderTest.getMongoUpdateObjForDemographics(demographics);

		Document updateObjectSet = (Document)actual.getUpdateObject().get("$set");
		assertThat(updateObjectSet.keySet()).isNotNull();
	}

	@Test
	@SneakyThrows
	public void testGetMongoUpdateObjForDemographicsWithProviderInfoCityAsNull() {
		Demographics demographics = ProviderDemographicsTestData.createDemographics();
		demographics.getProviderInfo().setCity(null);

		Update actual = classUnderTest.getMongoUpdateObjForDemographics(demographics);

		Document updateObjectSet = (Document)actual.getUpdateObject().get("$set");
		assertThat(updateObjectSet.keySet()).doesNotContain("providerInfo.city");
	}
	
	@Test
	@SneakyThrows
	public void testGetMongoUpdateObjForDemographicsWithKeyAsNull() {
		Demographics demographics = ProviderDemographicsTestData.createDemographics();
		demographics.setKey(null);

		Update actual = classUnderTest.getMongoUpdateObjForDemographics(demographics);

		Document updateObjectSet = (Document)actual.getUpdateObject().get("$set");
		assertThat(updateObjectSet.keySet()).doesNotContain("key");
	}
	
	@Test
	@SneakyThrows
	public void testGetMongoUpdateObjForDemographicsWithAddressFieldsAsNull() {
		Demographics demographics = ProviderDemographicsTestData.createDemographics();
		demographics.getProviderInfo().getAddress().setAddr1(null);
		demographics.getProviderInfo().getAddress().setAddr2(null);
		demographics.getProviderInfo().getAddress().setAddr3(null);
		demographics.getProviderInfo().getAddress().setAddr4(null);

		Update actual = classUnderTest.getMongoUpdateObjForDemographics(demographics);

		Document updateObjectSet = (Document)actual.getUpdateObject().get("$set");
		assertThat(updateObjectSet.keySet()).doesNotContain("providerInfo.address.addr1");
		assertThat(updateObjectSet.keySet()).doesNotContain("providerInfo.address.addr2");
		assertThat(updateObjectSet.keySet()).doesNotContain("providerInfo.address.addr3");
		assertThat(updateObjectSet.keySet()).doesNotContain("providerInfo.address.addr4");
	}
	
	@Test
	@SneakyThrows
	public void testGetMongoUpdateObjForDemographicsWithSpecCodesListFieldAsNull() {
		Demographics demographics = ProviderDemographicsTestData.createDemographics();
		demographics.getProviderInfo().getSpecCodes().get(0).setSpecCd(null);

		Update actual = classUnderTest.getMongoUpdateObjForDemographics(demographics);

		Document updateObjectSet = (Document)actual.getUpdateObject().get("$set");
		assertThat(updateObjectSet.keySet()).doesNotContain("providerInfo.specCodes.specCd");
	}
	
	@Test
	@SneakyThrows
	public void testGetMongoUpdateObjForDemographicsWithNpiIdsListFieldAsNull() {
		Demographics demographics = ProviderDemographicsTestData.createDemographics();
		demographics.getProviderInfo().getNpiIds().get(0).setNpiId(null);

		Update actual = classUnderTest.getMongoUpdateObjForDemographics(demographics);

		Document updateObjectSet = (Document)actual.getUpdateObject().get("$set");
		assertThat(updateObjectSet.keySet()).doesNotContain("providerInfo.npiIds.npiId");
	}
	
	@Test
	@SneakyThrows
	public void testGetMongoUpdateObjForDemographicsWithTaxonomyCodesListFieldAsNull() {
		Demographics demographics = ProviderDemographicsTestData.createDemographics();
		demographics.getProviderInfo().getTaxonomyCodes().get(0).setTaxonomyCd(null);

		Update actual = classUnderTest.getMongoUpdateObjForDemographics(demographics);

		Document updateObjectSet = (Document)actual.getUpdateObject().get("$set");
		assertThat(updateObjectSet.keySet()).doesNotContain("providerInfo.taxonomyCodes.taxonomyCd");
	}

}
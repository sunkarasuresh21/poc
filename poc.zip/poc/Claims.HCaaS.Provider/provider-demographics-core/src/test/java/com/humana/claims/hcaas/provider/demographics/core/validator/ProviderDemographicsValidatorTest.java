package com.humana.claims.hcaas.provider.demographics.core.validator;

import static com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsErrorConstants.INVALID_MAJOR_CLASSCODE;
import static com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsErrorConstants.INVALID_NPI_ID;
import static com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsErrorConstants.INVALID_PROVIDER_ID;
import static com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsErrorConstants.INVALID_PROVIDER_IND;
import static com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsErrorConstants.INVALID_PROVIDER_MULTI_ADDRESS_KEY;
import static com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsErrorConstants.INVALID_PROV_NAME;
import static com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsErrorConstants.INVALID_STATE_CODE;
import static com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsErrorConstants.INVALID_STATUS_OR_REASONCODE;
import static com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsErrorConstants.INVALID_TAX_ID;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Map;
import java.util.Set;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.humana.claims.hcaas.provider.demographics.core.dao.ProviderDemographicsMongoConstants;
import com.humana.claims.hcaas.provider.demographics.core.exception.InvalidRequestException;
import com.humana.claims.hcaas.provider.demographics.core.model.ProviderDemoGetRequest;

@ExtendWith(MockitoExtension.class)
public class ProviderDemographicsValidatorTest {

	@InjectMocks
	ProviderDemographicsValidator providerValidator;

	@Test
	public void testValidateByProviderIdParametersWithAllValidValues() {
		try {
			ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().providerId("000000011")
					.providerIndicator("D").providerMultiAddressKey("S").statusOrReasonCode("1").majorClassCode("G")
					.provName("Shilpa").stateCode("FL").includeCount(true).build();
			providerValidator.validateByProviderId(provDemoGetReq);
		} catch (InvalidRequestException e) {
			Assertions.fail("Exception Not Expected");
		}
	}

	@Test
	public void testValidProviderIdPassedShouldNotThrowError() {
		try {
			ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().providerId("000000011").build();
			providerValidator.validateByProviderId(provDemoGetReq);
		} catch (InvalidRequestException e) {
			Assertions.fail("Exception Not Expected");
		}
	}

	@Test
	public void testValidateByProviderIDAllInvalidBlankValues() {
		try {
			ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().providerId("")
					.providerIndicator("").providerMultiAddressKey("").npiId("").statusOrReasonCode("")
					.majorClassCode("").provName("").stateCode("").includeCount(true).build();
			providerValidator.validateByProviderId(provDemoGetReq);
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(INVALID_PROV_NAME));
			assertTrue(errors.contains(INVALID_STATE_CODE));
			assertTrue(errors.contains(INVALID_MAJOR_CLASSCODE));
			assertTrue(errors.contains(INVALID_PROVIDER_ID));
			assertTrue(errors.contains(INVALID_PROVIDER_IND));
			assertTrue(errors.contains(INVALID_PROVIDER_MULTI_ADDRESS_KEY));
		}
	}

	@Test
	public void testValidateByProviderIDAAllInvalidNonBlankValues() {
		try {
			ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().providerId("123")
					.providerIndicator("C").providerMultiAddressKey("ER").statusOrReasonCode("QAF").majorClassCode("1e")
					.provName("test-test-test-test").stateCode("ERG").includeCount(true).build();
			providerValidator.validateByProviderId(provDemoGetReq);
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(INVALID_PROV_NAME));
			assertTrue(errors.contains(INVALID_STATE_CODE));
			assertTrue(errors.contains(INVALID_MAJOR_CLASSCODE));
			assertTrue(errors.contains(INVALID_PROVIDER_ID));
			assertTrue(errors.contains(INVALID_PROVIDER_IND));
			assertTrue(errors.contains(INVALID_PROVIDER_MULTI_ADDRESS_KEY));
		}
	}

	@Test
	public void validateGetProviderDemographicsByProviderTaxIdParametersWithAllValidValues() {
		try {
			ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().providerTaxId("000000011").providerIndicator("D")
					.statusOrReasonCode("1").majorClassCode("G").provName("Shilpa").stateCode("FL").includeCount(true)
					.build();
			providerValidator.validateByProviderTaxId(provDemoGetReq);
		} catch (InvalidRequestException e) {
			Assertions.fail("Exception Not Expected");
		}
	}

	@Test
	public void testValidProviderTaxIdNotPassedShouldNotThrowError() {
		try {
			ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().providerTaxId("000000011").build();
			providerValidator.validateByProviderTaxId(provDemoGetReq);
		} catch (InvalidRequestException e) {
			Assertions.fail("Exception Not Expected");
		}
	}

	@Test
	public void testValidateByProviderTaxIDAllInvalidBlankValues() {
		try {
			ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().providerTaxId("").providerIndicator("")
					.statusOrReasonCode("").majorClassCode("").provName("").stateCode("").includeCount(true).build();
			providerValidator.validateByProviderTaxId(provDemoGetReq);
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(INVALID_PROV_NAME));
			assertTrue(errors.contains(INVALID_STATE_CODE));
			assertTrue(errors.contains(INVALID_STATUS_OR_REASONCODE));
			assertTrue(errors.contains(INVALID_MAJOR_CLASSCODE));
			assertTrue(errors.contains(INVALID_TAX_ID));
			assertTrue(errors.contains(INVALID_PROVIDER_IND));
		}
	}

	@Test
	public void testValidateByProviderTaxIDAAllInvalidNonBlankValues() {
		try {
			ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().providerTaxId("1234567891").providerIndicator("G")
					.statusOrReasonCode("SDC").majorClassCode("ty").provName("test-test-test-test").stateCode("tgg")
					.includeCount(true).build();
			providerValidator.validateByProviderTaxId(provDemoGetReq);
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(INVALID_PROV_NAME));
			assertTrue(errors.contains(INVALID_STATE_CODE));
			assertTrue(errors.contains(INVALID_STATUS_OR_REASONCODE));
			assertTrue(errors.contains(INVALID_MAJOR_CLASSCODE));
			assertTrue(errors.contains(INVALID_TAX_ID));
			assertTrue(errors.contains(INVALID_PROVIDER_IND));
		}
	}

	@Test
	public void testValidateGetProviderDemographicsByProviderNpiIdParametersWithAllValidValues() {
		try {
			ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().npiId("0000000111")
					.statusOrReasonCode("1").majorClassCode("G").provName("Shilpa").stateCode("FL").includeCount(true)
					.build();
			providerValidator.validateByNpiId(provDemoGetReq);
		} catch (InvalidRequestException e) {
			Assertions.fail("Exception Not Expected");
		}
	}

	@Test
	public void testValidateByNpiIdNotPassedShouldNotThrowError() {
		try {
			ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().npiId("0000000111").build();
			providerValidator.validateByNpiId(provDemoGetReq);
		} catch (InvalidRequestException e) {
			Assertions.fail("Exception Not Expected");
		}
	}

	@Test
	public void testValidateByNpiIdAllInvalidBlankValues() {
		try {
			ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().npiId("").statusOrReasonCode("").providerIndicator("")
					.majorClassCode("").provName("").stateCode("").includeCount(true).build();
			providerValidator.validateByNpiId(provDemoGetReq);
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(INVALID_PROV_NAME));
			assertTrue(errors.contains(INVALID_STATE_CODE));
			assertTrue(errors.contains(INVALID_STATUS_OR_REASONCODE));
			assertTrue(errors.contains(INVALID_MAJOR_CLASSCODE));
			assertTrue(errors.contains(INVALID_NPI_ID));
			assertTrue(errors.contains(INVALID_PROVIDER_IND));
		}
	}

	@Test
	public void testValidateByNpiIdAllInvalidNonBlankValues() {
		try {
			ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().npiId("123456789").statusOrReasonCode("ERT").providerIndicator("X")
					.majorClassCode("ty").provName("test-test-test-test").stateCode("tgg")
					.includeCount(true).build();
			providerValidator.validateByNpiId(provDemoGetReq);
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(INVALID_PROV_NAME));
			assertTrue(errors.contains(INVALID_STATE_CODE));
			assertTrue(errors.contains(INVALID_STATUS_OR_REASONCODE));
			assertTrue(errors.contains(INVALID_MAJOR_CLASSCODE));
			assertTrue(errors.contains(INVALID_NPI_ID));
			assertTrue(errors.contains(INVALID_PROVIDER_IND));
		}
	}

	@Test
	public void testValidateByProvNameWithAllValidValues() {
		try {
			ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().npiId("0000000111").providerIndicator("H")
					.statusOrReasonCode("1").majorClassCode("G").provName("Shilpa").stateCode("FL").includeCount(true)
					.build();
			providerValidator.validateByProvName(provDemoGetReq);
		} catch (InvalidRequestException e) {
			Assertions.fail("Exception Not Expected");
		}
	}

	@Test
	public void testValidateByProvNameNotPassedShouldNotThrowError() {
		try {
			ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().provName("Shilpa").build();
			providerValidator.validateByProvName(provDemoGetReq);
		} catch (InvalidRequestException e) {
			Assertions.fail("Exception Not Expected");
		}
	}

	@Test
	public void testValidateByProvNameAllInvalidBlankValues() {
		try {
			ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().providerId("")
					.providerIndicator("").providerMultiAddressKey("").npiId("").statusOrReasonCode("")
					.majorClassCode("").provName("").stateCode("").includeCount(true).build();
			providerValidator.validateByProvName(provDemoGetReq);
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(INVALID_PROV_NAME));
			assertTrue(errors.contains(INVALID_STATE_CODE));
			assertTrue(errors.contains(INVALID_STATUS_OR_REASONCODE));
			assertTrue(errors.contains(INVALID_MAJOR_CLASSCODE));
			assertTrue(errors.contains(INVALID_PROVIDER_IND));
		}
	}

	@Test
	public void testValidateByProvNameAllInvalidNonBlankValues() {
		try {
			ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().statusOrReasonCode("SDG").providerIndicator("X")
					.majorClassCode("ty").provName("test-test-test-test").stateCode("tgg").includeCount(true).build();
			providerValidator.validateByProvName(provDemoGetReq);
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(INVALID_PROV_NAME));
			assertTrue(errors.contains(INVALID_STATE_CODE));
			assertTrue(errors.contains(INVALID_STATUS_OR_REASONCODE));
			assertTrue(errors.contains(INVALID_MAJOR_CLASSCODE));
			assertTrue(errors.contains(INVALID_PROVIDER_IND));
		}
	}
	
	
	/**
	 * If pvdStatusOrReasonCode is 0/1/2/null/any-valid-value it should be added to Map, mean filter is applied
	 * If pvdStatusOrReasonCode is A it should not be added to Map, mean filter is not applied
	 * @throws InvalidRequestException 
	 */
	@Test
	public void testValidProvStatusOrReasonCode() throws InvalidRequestException {
			Map<String, String> queryMap = providerValidator.validateByProvName(ProviderDemoGetRequest.builder().statusOrReasonCode("0").build());
			assertTrue(queryMap.containsKey(ProviderDemographicsMongoConstants.PROVIDER_STATUS));

			Map<String, String> queryMap2 = providerValidator.validateByProvName(ProviderDemoGetRequest.builder().statusOrReasonCode("1").build());
			assertTrue(queryMap2.containsKey(ProviderDemographicsMongoConstants.PROVIDER_STATUS));

			Map<String, String> queryMap3 = providerValidator.validateByProvName(ProviderDemoGetRequest.builder().statusOrReasonCode("2").build());
			assertTrue(queryMap3.containsKey(ProviderDemographicsMongoConstants.PROVIDER_STATUS));
			
			Map<String, String> queryMap4 = providerValidator.validateByProvName(ProviderDemoGetRequest.builder().statusOrReasonCode("A").build());
			assertFalse(queryMap4.containsKey(ProviderDemographicsMongoConstants.PROVIDER_STATUS));
			
			Map<String, String> queryMap5 = providerValidator.validateByProvName(ProviderDemoGetRequest.builder().statusOrReasonCode("A1").build());
			assertTrue(queryMap5.containsKey(ProviderDemographicsMongoConstants.PROVIDER_STATUS));
			
			Map<String, String> queryMap6 = providerValidator.validateByProvName(ProviderDemoGetRequest.builder().statusOrReasonCode("3").build());
			assertTrue(queryMap6.containsKey(ProviderDemographicsMongoConstants.PROVIDER_STATUS));
			
			Map<String, String> queryMap7 = providerValidator.validateByProvName(ProviderDemoGetRequest.builder().build());
			assertTrue(queryMap7.containsKey(ProviderDemographicsMongoConstants.PROVIDER_STATUS));
	}


}

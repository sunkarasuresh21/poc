package com.humana.claims.hcaas.provider.demographics.core.dao;

import org.bson.Document;

import com.humana.claims.hcaas.provider.demographics.core.data.encryption.ProviderDemographicsDataEncryption;

public class ProviderDemographicsDataEncryptionTestImpl implements  ProviderDemographicsDataEncryption{
	
	public  Document encryptProviderDemoData(Document  doc) {
		return doc;
	}

	public Document encryptProviderPatchData(Document doc) {
		return doc;
	}
	
	public Document decryptProviderDemoData(Document doc) {
		return doc;
	}
	
	public String encryptProviderTaxId(String irsNo) {
		return irsNo;
	}
	
	public String encryptProviderId(String providerId) {
		return providerId;
	}
	
	public String encryptNpiId(String npiId) {
		return npiId;
	}

	@Override
	public Object encryptProvName(String provName) {
		return provName;
	}
}

package com.humana.claims.hcaas.provider.demographics.core.data.encryption;

import org.bson.Document;

public interface ProviderDemographicsDataEncryption {
	
	 Document encryptProviderDemoData(Document  doc);
	 
	 Document encryptProviderPatchData(Document doc);
	 
	 Document decryptProviderDemoData(Document doc);
	 
	 Object encryptProviderId(String provId);
	 
	 Object encryptProviderTaxId(String irsNo);
	 
	 Object encryptNpiId(String npiId);
	 
	 Object encryptProvName(String provName);
}

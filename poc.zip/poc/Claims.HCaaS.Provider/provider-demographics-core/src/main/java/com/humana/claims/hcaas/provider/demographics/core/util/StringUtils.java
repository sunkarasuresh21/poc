package com.humana.claims.hcaas.provider.demographics.core.util;

public class StringUtils {
	
	private StringUtils() {
		
	}

	public static String replaceBlankStringToSingleWhiteSpace(String str) {
		if(null != str) {
			return "".equals(str.trim())? " ": str; 
		}
		return str;
	}
}

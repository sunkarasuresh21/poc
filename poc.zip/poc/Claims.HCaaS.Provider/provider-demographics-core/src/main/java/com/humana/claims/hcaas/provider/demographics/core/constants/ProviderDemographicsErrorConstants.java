package com.humana.claims.hcaas.provider.demographics.core.constants;

public class ProviderDemographicsErrorConstants {
	
	private ProviderDemographicsErrorConstants() {
		
	}

	public static final String INVALID_PROVIDER_IND = "Invalid Provider-Ind, Provider-Ind should contain [D, H]";
	
	public static final String INVALID_PROVIDER_MULTI_ADDRESS_KEY = "Invalid Provider-Multi-Address-Key, length should be 1";
	
	public static final String INVALID_PROVIDER_ID = "Invalid provId, provId should be 9 digit numeric value.";
	
	public static final String INVALID_NPI_ID = "Invalid npiId, npiId should be 10 digit numeric value.";
	
	public static final String INVALID_TAX_ID = "Invalid provTaxId, provTaxId should be 9 digit numeric value.";

	public static final String NO_RECORD_FOUND = "Provider Demographics not found using request input";
	
	public static final String INVALID_HEADER_COMBINATION = "Invalid input combination";

	public static final String INVALID_MAJOR_CLASSCODE = "Invalid majorClassCode, length should be 1";
	
	public static final String INVALID_STATE_CODE = "Invalid stateCode, length should be 1 or 2";
	
	public static final String INVALID_PROV_NAME = "Invalid provName, length should be <=20";
	
	public static final String INVALID_STATUS_OR_REASONCODE = "Invalid statusOrReasonCode, length should be 1 or 2";

}
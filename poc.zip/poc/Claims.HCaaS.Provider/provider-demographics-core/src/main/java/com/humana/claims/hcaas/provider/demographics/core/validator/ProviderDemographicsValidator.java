package com.humana.claims.hcaas.provider.demographics.core.validator;

import static com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsConstants.*;
import static com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsErrorConstants.*;
import static com.humana.claims.hcaas.provider.demographics.core.dao.ProviderDemographicsMongoConstants.*;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

import com.humana.claims.hcaas.provider.demographics.core.exception.InvalidRequestException;
import com.humana.claims.hcaas.provider.demographics.core.model.ProviderDemoGetRequest;

@Component
public class ProviderDemographicsValidator {
	
	private static final Pattern PROV_IND_REGEX = Pattern.compile("D|H");

	public Map<String, String> validateByProviderId(ProviderDemoGetRequest provDemoGetReq) throws InvalidRequestException {

		Set<String> errorMessages = new HashSet<>();
		Map<String, String> queryMap = new LinkedHashMap<>();

		String providerId = provDemoGetReq.getProviderId();
		String multiAddrKey = provDemoGetReq.getProviderMultiAddressKey();
		String providerInd = provDemoGetReq.getProviderIndicator();
		String provName = provDemoGetReq.getProvName();
		String stateCode = provDemoGetReq.getStateCode();
		String majorClsCode = provDemoGetReq.getMajorClassCode();

		if (!Pattern.matches(PROVIDER_ID_PATTERN, providerId)) {
			errorMessages.add(INVALID_PROVIDER_ID);
		} else {
			queryMap.put(KEY_PROVIDER_ID, providerId);
		}

		validateOptionalFields(provName, stateCode, majorClsCode, providerInd, multiAddrKey, errorMessages, queryMap);
		
		if (!errorMessages.isEmpty()) {
			throw new InvalidRequestException(errorMessages);
		}
		
		return queryMap;
	}
	
	public Map<String, String> validateByProviderTaxId(ProviderDemoGetRequest provDemoGetReq) throws InvalidRequestException {

		Set<String> errorMessages = new HashSet<>();
		Map<String, String> queryMap = new LinkedHashMap<>();

		String providerTaxId = provDemoGetReq.getProviderTaxId();
		String provName = provDemoGetReq.getProvName();
		String stateCode = provDemoGetReq.getStateCode();
		String majorClsCode = provDemoGetReq.getMajorClassCode();
		String statusOrReasonCode = provDemoGetReq.getStatusOrReasonCode();
		String providerInd = provDemoGetReq.getProviderIndicator();

		if (!Pattern.matches(PROVIDER_TAX_ID_PATTERN, providerTaxId)) {
			errorMessages.add(INVALID_TAX_ID);
		} else {
			queryMap.put(KEY_PROVIDER_TAX_ID, providerTaxId);
		}

		validateOptionalFields(provName, stateCode, majorClsCode, providerInd, null, errorMessages, queryMap);
		validateProviderStatusOrReasonCode(statusOrReasonCode, errorMessages, queryMap);
		
		if (!errorMessages.isEmpty()) {
			throw new InvalidRequestException(errorMessages);
		}
		
		return queryMap;
	}
	
	public Map<String, String> validateByNpiId(ProviderDemoGetRequest provDemoGetReq) throws InvalidRequestException {

		Set<String> errorMessages = new HashSet<>();
		Map<String, String> queryMap = new LinkedHashMap<>();

		String npiId = provDemoGetReq.getNpiId();
		String provName = provDemoGetReq.getProvName();
		String stateCode = provDemoGetReq.getStateCode();
		String majorClsCode = provDemoGetReq.getMajorClassCode();
		String statusOrReasonCode = provDemoGetReq.getStatusOrReasonCode();
		String providerInd = provDemoGetReq.getProviderIndicator();

		if (!Pattern.matches(NPI_ID_PATTERN, npiId)) {
			errorMessages.add(INVALID_NPI_ID);
		} else {
			queryMap.put(KEY_NPI_ID, npiId);
		}

		validateOptionalFields(provName, stateCode, majorClsCode, providerInd, null, errorMessages, queryMap);
		validateProviderStatusOrReasonCode(statusOrReasonCode, errorMessages, queryMap);
		
		if (!errorMessages.isEmpty()) {
			throw new InvalidRequestException(errorMessages);
		}
		
		return queryMap;
	}
	
	public Map<String, String> validateByProvName(ProviderDemoGetRequest provDemoGetReq) throws InvalidRequestException {

		Set<String> errorMessages = new HashSet<>();
		Map<String, String> queryMap = new LinkedHashMap<>();

		String provName = provDemoGetReq.getProvName();
		String stateCode = provDemoGetReq.getStateCode();
		String majorClsCode = provDemoGetReq.getMajorClassCode();
		String statusOrReasonCode = provDemoGetReq.getStatusOrReasonCode();
		String providerInd = provDemoGetReq.getProviderIndicator();

		validateOptionalFields(provName, stateCode, majorClsCode, providerInd, null, errorMessages, queryMap);
		validateProviderStatusOrReasonCode(statusOrReasonCode, errorMessages, queryMap);
		
		if (!errorMessages.isEmpty()) {
			throw new InvalidRequestException(errorMessages);
		}
		
		return queryMap;
	}

	private void validateOptionalFields(String provName, String stateCode, String majorClsCode,
			String providerInd,String  multiAddrKey, Set<String> errorMessages, Map<String, String> queryMap) {
		
		if (null != providerInd) {
			if (!PROV_IND_REGEX.matcher(providerInd).matches()) {
				errorMessages.add(INVALID_PROVIDER_IND);
			} else {
				queryMap.put(KEY_PROVIDER_INDICATOR, providerInd);
			}
		}
		
		if (null != multiAddrKey) {
			if (multiAddrKey.length() != 1) {
				errorMessages.add(INVALID_PROVIDER_MULTI_ADDRESS_KEY);
			} else {
				queryMap.put(KEY_PROVIDER_SUFFIX, multiAddrKey);
			}
		}
		
		if (null != provName) {
			if (!Pattern.matches(PROV_NAME_PATTERN, provName)) {
				errorMessages.add(INVALID_PROV_NAME);
			} else {
				queryMap.put(ALPHA_KEY, provName);
			}
		}

		validateMajorClassCodeAndStatecode(stateCode, majorClsCode, errorMessages, queryMap);
	}
	
	private void validateProviderStatusOrReasonCode(String statusOrReasonCode, Set<String> errorMessages, Map<String, String> queryMap) {
		if ((null != statusOrReasonCode) && !(statusOrReasonCode.length() == STATUS_REASON_CODE_MIN_LENGTH || statusOrReasonCode.length() == STATUS_REASON_CODE_MAX_LENGTH)) {
			errorMessages.add(INVALID_STATUS_OR_REASONCODE);
		} 
		if (statusOrReasonCode == null || !statusOrReasonCode.equalsIgnoreCase("A")) {
			queryMap.put(PROVIDER_STATUS, statusOrReasonCode);
		}
	}
	
	private void validateMajorClassCodeAndStatecode(String stateCode, String majorClsCode, Set<String> errorMessages,
			Map<String, String> queryMap) {
		if (null != majorClsCode) {
			if (!Pattern.matches(MAJOR_CLASS_CODE_PATTERN, majorClsCode)) {
				errorMessages.add(INVALID_MAJOR_CLASSCODE);
			} else {
				queryMap.put(MAJOR_CLASSCODE, majorClsCode);
			}
		}

		if (null != stateCode) {
			if (!Pattern.matches(STATE_CODE_PATTERN, stateCode)) {
				errorMessages.add(INVALID_STATE_CODE);
			} else {
				queryMap.put(STATE_CODE, stateCode);
			}
		}
	}

}
package com.humana.claims.hcaas.provider.demographics.core.model.db;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class Address {

    @JsonProperty("ADDR-1")
    private String addr1;

    @JsonProperty("ADDR-2")
    private String addr2;

    @JsonProperty("ADDR-3")
    private String addr3;

    @JsonProperty("ADDR-4")
    private String addr4;

}

package com.humana.claims.hcaas.provider.demographics.core.data.encryption;

import static com.humana.claims.hcaas.provider.demographics.core.dao.ProviderDemographicsMongoConstants.DETERMINISTIC_ENCRYPTION_TYPE;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.bson.BsonBinary;
import org.bson.Document;
import org.bson.types.Binary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.humana.claims.hcaas.common.spring.boot.starter.mongodb.MongoDBFieldEncryptor;
import com.humana.claims.hcaas.provider.demographics.core.model.db.NpiInfos;

@Component
public class ProviderDemographicsDataEncryptionImpl implements ProviderDemographicsDataEncryption {

	@Autowired
	private MongoDBFieldEncryptor dbFieldEncryptor;
	
	private static final String NPIDS = "npiIds";
	
	private static final String PROVIDERINFO_NPIDS = "providerInfo.npiIds";
	
	private static final String IRSNO = "irsNo";

	private static final List<String> FIELDS_FLE_TO_BE_APPLIED = Arrays.asList(IRSNO, "providerInfo.provName",
			"providerInfo.address.addr1", "providerInfo.address.addr2", "providerInfo.address.addr3",
			"providerInfo.address.addr4");

	public Document encryptProviderDemoData(Document doc) {

		for (Entry<String, Object> key : doc.entrySet()) {
			if ((key.getKey()).equalsIgnoreCase("key") || (key.getKey()).equalsIgnoreCase("providerInfo")) {
				Document innerDocument = (Document) doc.get(key.getKey());
				processInnerDocument(innerDocument);
			}
			if ((key.getKey()).equalsIgnoreCase(IRSNO)) {
				encryptData(doc, key.getKey());
			}
		}
		return doc;
	}

	private Document processInnerDocument(Document innerDocument) {
		for (Entry<String, Object> key : innerDocument.entrySet()) {
			if ((key.getKey()).equalsIgnoreCase("prov")||(key.getKey()).equalsIgnoreCase("provName")) {
				encryptData(innerDocument, key.getKey());
			}
			
			encryptAddress(key, innerDocument);
			
			encryptNpi(key, innerDocument);
			
		}
		return innerDocument;
	}
	
	private void encryptAddress(Entry<String, Object> key,Document innerDocument) {
		if ((key.getKey()).equalsIgnoreCase("address")) {
			Document addressDoc = (Document) innerDocument.get(key.getKey());
			for (String addressKey : addressDoc.keySet()) {
				encryptData(addressDoc, addressKey);
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	private void encryptNpi(Entry<String, Object> key,Document innerDocument) {
		if ((key.getKey()).equalsIgnoreCase(NPIDS)) {
			List<Document> listDocNpiIds = (List<Document>) innerDocument.get(NPIDS);
			for (Document docNpiIds : listDocNpiIds) {
				for (String npiId : docNpiIds.keySet()) {
					encryptData(docNpiIds, npiId);
				}
			}
		}
	}
	
	private BsonBinary encryptData(Document doc, String key) {
		return (BsonBinary) doc.computeIfPresent(key, (ky, value) -> 
			(BsonBinary) dbFieldEncryptor.encrypt((String) value, DETERMINISTIC_ENCRYPTION_TYPE));
	}

	public Document decryptProviderDemoData(Document doc) {

		for (Entry<String, Object> key : doc.entrySet()) {
			if ((key.getKey()).equalsIgnoreCase("key") || (key.getKey()).equalsIgnoreCase("providerInfo")) {
				Document innerDocument = (Document) doc.get(key.getKey());
				processInnerDocumentForDecryption(innerDocument);
			}
			if ((key.getKey()).equalsIgnoreCase(IRSNO)) {
				decryptData(doc, key.getKey());
			}
		}
		return doc;
	}

	private Document processInnerDocumentForDecryption(Document innerDocument) {
		for (Entry<String, Object> key : innerDocument.entrySet()) {
			if ((key.getKey()).equalsIgnoreCase("prov") || (key.getKey()).equalsIgnoreCase("provName")) {
				decryptData(innerDocument, key.getKey());
			}
			
			decryptAddress(key, innerDocument);
			
			decryptNpi(key, innerDocument);
		}
		return innerDocument;
	}
	
	
	private void decryptAddress(Entry<String, Object> key,Document innerDocument) {
		if ((key.getKey()).equalsIgnoreCase("address")) {
			Document addressDoc = (Document) innerDocument.get(key.getKey());
			for (String addressKey : addressDoc.keySet()) {
				decryptData(addressDoc, addressKey);
			}
		}
	}
	
	@SuppressWarnings("unchecked")
	private void decryptNpi(Entry<String, Object> key,Document innerDocument) {
		if ((key.getKey()).equalsIgnoreCase(NPIDS)) {
			List<Document> listDocNpiIds = (List<Document>) innerDocument.get(NPIDS);
			for (Document docNpiIds : listDocNpiIds) {
				for (String npiId : docNpiIds.keySet()) {
					decryptData(docNpiIds, npiId);
				}
			}
		}
	}

	private String decryptData(Document doc, String key) {
		doc.computeIfPresent(key, (ky, value) -> {
			Binary binVal = (Binary) value;
			return (String) dbFieldEncryptor.decrypt(new BsonBinary(binVal.getData()), DETERMINISTIC_ENCRYPTION_TYPE);
		});
		return null;
	}

	@SuppressWarnings("unchecked")
	public Document encryptProviderPatchData(Document doc) {
		List<Map<String, BsonBinary>> listEncryptedNpiId = new ArrayList<>();
		for (String key : doc.keySet()) {
			if (key.equalsIgnoreCase(PROVIDERINFO_NPIDS)) {
				List<NpiInfos> listDocNpiIds = (List<NpiInfos>) doc.get(PROVIDERINFO_NPIDS);
				for (NpiInfos npiIdsDoc : listDocNpiIds) {
					Map<String, BsonBinary> map = new HashMap<>();
					map.put("npiId",
							(BsonBinary) dbFieldEncryptor.encrypt(npiIdsDoc.getNpiId(), DETERMINISTIC_ENCRYPTION_TYPE));
							listEncryptedNpiId.add(map);
				}
			}
		}
		doc.put(PROVIDERINFO_NPIDS, listEncryptedNpiId);
		for (String field : FIELDS_FLE_TO_BE_APPLIED) {
			encryptData(doc, field);
		}
		return doc;
	}

	public BsonBinary encryptProviderId(String provId) {
		return dbFieldEncryptor.encrypt(provId, DETERMINISTIC_ENCRYPTION_TYPE);
	}

	public BsonBinary encryptProviderTaxId(String irsNo) {
		return dbFieldEncryptor.encrypt(irsNo, DETERMINISTIC_ENCRYPTION_TYPE);
	}

	public BsonBinary encryptNpiId(String npiId) {
		return  dbFieldEncryptor.encrypt(npiId, DETERMINISTIC_ENCRYPTION_TYPE);
	}
	
	public BsonBinary encryptProvName(String provName) {
		return  dbFieldEncryptor.encrypt(provName, DETERMINISTIC_ENCRYPTION_TYPE);
	}
}


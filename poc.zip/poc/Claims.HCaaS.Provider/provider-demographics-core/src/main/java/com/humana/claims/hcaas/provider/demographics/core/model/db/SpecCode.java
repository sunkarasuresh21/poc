package com.humana.claims.hcaas.provider.demographics.core.model.db;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class SpecCode {

    @JsonProperty("SPEC-CD")
    private String specCd;

}

package com.humana.claims.hcaas.provider.demographics.core.dao;

import static com.humana.claims.hcaas.provider.demographics.core.dao.ProviderDemographicsMongoConstants.COLLECTION_PROVIDER_DEMOGRAPHICS;
import static com.humana.claims.hcaas.provider.demographics.core.dao.ProviderDemographicsMongoConstants.CREATE_DEMOGRAPHICS_SUCCESS;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsConstants;
import com.humana.claims.hcaas.provider.demographics.core.data.encryption.ProviderDemographicsDataEncryption;
import com.humana.claims.hcaas.provider.demographics.core.exception.ProviderDemographicsNotFoundException;
import com.humana.claims.hcaas.provider.demographics.core.model.DemographicsDBResponse;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.demographics.core.util.ProviderDemographicsPatchUtil;
import com.mongodb.client.result.UpdateResult;

import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class ProviderDemographicsDAOImpl implements ProviderDemographicsDAO {

	private MongoTemplate mongoTemplate;

	private ProviderDemographicsPatchUtil providerDemographicsPatchUtil;

	private ProviderDemographicsDataEncryption providerDemographicsDataEncryption;

	@Autowired
	public ProviderDemographicsDAOImpl(MongoTemplate mongoTemplate, ProviderDemographicsPatchUtil providerDemographicsPatchUtil, ProviderDemographicsDataEncryption providerDemographicsDataEncryption) {
		this.mongoTemplate = mongoTemplate;
		this.providerDemographicsDataEncryption = providerDemographicsDataEncryption;
		this.providerDemographicsPatchUtil = providerDemographicsPatchUtil;
	}

	private static final String CLIENT_VALUE = "58";
	private static final List<String> REASON_CODE = Arrays.asList("1C","1E","1F","1G","1J","1L","1M","1N","1P","1Q","1R","1S","1T","1U","IM");
	private static final String ZERO = "0";
	private static final String SINGLE_SPACE = " ";
	private static final String ONE = "1";
	private static final int ALPHA_KEY_MAX_LENGTH = 20;
	private static final Pattern INVALID_ALPHA_KEY_CHAR_PATTERN = Pattern.compile("[^a-zA-Z0-9\\.\":';, ]");
	private static final Pattern PERIOD_CHAR_PATTERN = Pattern.compile("\\.");
	
	@Override
	public void upsertProviderDemographicsProv1(Demographics providerDemographicsFromQueue) {
		setAlphaKeyToUpperCase(providerDemographicsFromQueue);
		Query query = new Query();
		query.addCriteria(buildProviderCriteria(providerDemographicsFromQueue));
		
		Document demographicsFromDb = mongoTemplate.findOne(query, Document.class,
				ProviderDemographicsMongoConstants.COLLECTION_PROVIDER_DEMOGRAPHICS);

		Document doc = new Document();
		mongoTemplate.getConverter().write(providerDemographicsFromQueue, doc);
		doc = providerDemographicsDataEncryption.encryptProviderDemoData(doc);

		if (null != demographicsFromDb) {
			demographicsFromDb = providerDemographicsDataEncryption.decryptProviderDemoData(demographicsFromDb);
			Demographics demographics = mongoTemplate.getConverter().read(Demographics.class, demographicsFromDb);
			updateProviderDemographics(mapDemographicsFromMQDataProv1(providerDemographicsFromQueue, demographics),
					query);
			log.debug("Provider Demographics updated successfully for ProvKey");
		} else {
			mongoTemplate.save(doc, ProviderDemographicsMongoConstants.COLLECTION_PROVIDER_DEMOGRAPHICS);
			log.debug("Provider Demographics inserted successfully for ProvKey");
		}
	}
	
	private Criteria buildProviderCriteria(Demographics providerDemographicsFromQueue) {
		return Criteria.where(ProviderDemographicsMongoConstants.KEY_PROVIDER_ID)
				.is(providerDemographicsDataEncryption
				.encryptProviderId(providerDemographicsFromQueue.getKey().getProv()))
		.and(ProviderDemographicsMongoConstants.KEY_PROVIDER_SUFFIX)
		.is(providerDemographicsFromQueue.getKey().getMultAddressKey())
		.and(ProviderDemographicsMongoConstants.KEY_PROVIDER_INDICATOR)
		.is(providerDemographicsFromQueue.getKey().getPvdInd())
		.and(ProviderDemographicsMongoConstants.KEY_CLIENT).is(CLIENT_VALUE);
	}

	@Override
	public void updateProviderDemographicsProv2(Demographics providerDemographicsFromQueue)
			throws ProviderDemographicsNotFoundException {
		setAlphaKeyToUpperCase(providerDemographicsFromQueue);
		Query query = new Query();
		query.addCriteria(buildProviderCriteria(providerDemographicsFromQueue));
		Document demographicsFromDb = mongoTemplate.findOne(query, Document.class,
				ProviderDemographicsMongoConstants.COLLECTION_PROVIDER_DEMOGRAPHICS);
		if (null != demographicsFromDb) {
			demographicsFromDb = providerDemographicsDataEncryption.decryptProviderDemoData(demographicsFromDb);
			Demographics demographics = mongoTemplate.getConverter().read(Demographics.class, demographicsFromDb);
			updateProviderDemographics(mapDemographicsFromMQDataProv2(providerDemographicsFromQueue, demographics),
					query);
			log.debug(ProviderDemographicsMongoConstants.COLLECTION_PROVIDER_DEMOGRAPHICS);
		} else {
			log.debug(ProviderDemographicsConstants.PROVIDER_DEMOGRAPHICS_NOT_FOUND);
			throw new ProviderDemographicsNotFoundException();
		}
	}

	private Document mapDemographicsFromMQDataProv2(Demographics providerDemographicsFromQueue,
			Demographics providerDemographicsFromDb) {
		Document doc = new Document();
		providerDemographicsFromDb.getProviderInfo()
				.setNpiIds(providerDemographicsFromQueue.getProviderInfo().getNpiIds());
		providerDemographicsFromDb.getProviderInfo()
				.setTaxonomyCodes(providerDemographicsFromQueue.getProviderInfo().getTaxonomyCodes());
		mongoTemplate.getConverter().write(providerDemographicsFromDb, doc);
		return doc;
	}

	private long updateProviderDemographics(Document doc, Query query) {
		Document document = providerDemographicsDataEncryption.encryptProviderDemoData(doc);
		UpdateResult updateResult = mongoTemplate.updateFirst(query, Update.fromDocument(document),
				ProviderDemographicsMongoConstants.COLLECTION_PROVIDER_DEMOGRAPHICS);
		return updateResult.getModifiedCount();
	}
	
	@Override
	public String postProviderDemographics(Demographics demographics) {
		setAlphaKeyToUpperCase(demographics);
		demographics.getKey().setClient(CLIENT_VALUE);
		Document doc = new Document();
		mongoTemplate.getConverter().write(demographics, doc);
		doc = providerDemographicsDataEncryption.encryptProviderDemoData(doc);
		mongoTemplate.save(doc, COLLECTION_PROVIDER_DEMOGRAPHICS);
		return CREATE_DEMOGRAPHICS_SUCCESS;
	}

	private void setAlphaKeyToUpperCase(Demographics demographics) {
		if(null != demographics.getAlphaKey()) {
			demographics.setAlphaKey(demographics.getAlphaKey().toUpperCase());
		}
	}
	
	@Override
	public Demographics updateProviderDemographics(Demographics demographics, String providerId,
			String providerMultiAddressKey, String providerIndicator) throws IllegalAccessException {
		setAlphaKeyToUpperCase(demographics);
		demographics.getKey().setClient(CLIENT_VALUE);
		Query query = new Query();
		query.addCriteria(Criteria.where(ProviderDemographicsMongoConstants.KEY_PROVIDER_ID)
				.is(providerDemographicsDataEncryption.encryptProviderId(providerId))
				.and(ProviderDemographicsMongoConstants.KEY_PROVIDER_SUFFIX).is(providerMultiAddressKey)
				.and(ProviderDemographicsMongoConstants.KEY_PROVIDER_INDICATOR).is(providerIndicator));
		
		Update update = providerDemographicsPatchUtil.getMongoUpdateObjForDemographics(demographics);
		Document document = providerDemographicsDataEncryption
				.encryptProviderPatchData((Document) update.getUpdateObject().get("$set"));
		update.getUpdateObject().put("$set", document);
		Document providerDemographics = mongoTemplate.findAndModify(query, update, new FindAndModifyOptions().returnNew(true).upsert(false),
				Document.class,COLLECTION_PROVIDER_DEMOGRAPHICS);
		if (providerDemographics == null) {
			return null;
		}
		providerDemographics = providerDemographicsDataEncryption.decryptProviderDemoData(providerDemographics);
		return mongoTemplate.getConverter().read(Demographics.class, providerDemographics);	
	}

	private Document mapDemographicsFromMQDataProv1(Demographics providerDemographicsFromQueue,
			Demographics providerDemographicsFromDb) {
		Document doc = new Document();
		providerDemographicsFromDb.setKey(providerDemographicsFromQueue.getKey());
		providerDemographicsFromDb.setIrsNo(providerDemographicsFromQueue.getIrsNo());
		providerDemographicsFromDb.setAlphaKey(providerDemographicsFromQueue.getAlphaKey());
		providerDemographicsFromDb.setTinEffDt(providerDemographicsFromQueue.getTinEffDt());
		providerDemographicsFromDb.setUpdateSys(providerDemographicsFromQueue.getUpdateSys());
		providerDemographicsFromDb.setPvdStatus(providerDemographicsFromQueue.getPvdStatus());
		providerDemographicsFromDb.getProviderInfo()
				.setProvName(providerDemographicsFromQueue.getProviderInfo().getProvName());
		providerDemographicsFromDb.getProviderInfo()
				.setAddress(providerDemographicsFromQueue.getProviderInfo().getAddress());
		providerDemographicsFromDb.getProviderInfo().setCity(providerDemographicsFromQueue.getProviderInfo().getCity());
		providerDemographicsFromDb.getProviderInfo().setSt(providerDemographicsFromQueue.getProviderInfo().getSt());
		providerDemographicsFromDb.getProviderInfo().setZip(providerDemographicsFromQueue.getProviderInfo().getZip());
		providerDemographicsFromDb.getProviderInfo().setLatitude(providerDemographicsFromQueue.getProviderInfo().getLatitude());
		providerDemographicsFromDb.getProviderInfo().setLongitude(providerDemographicsFromQueue.getProviderInfo().getLongitude());
		providerDemographicsFromDb.getProviderInfo()
				.setProvType(providerDemographicsFromQueue.getProviderInfo().getProvType());
		providerDemographicsFromDb.getProviderInfo()
				.setMajClsCd(providerDemographicsFromQueue.getProviderInfo().getMajClsCd());
		providerDemographicsFromDb.getProviderInfo()
				.setGroupFlag(providerDemographicsFromQueue.getProviderInfo().getGroupFlag());
		providerDemographicsFromDb.getProviderInfo()
				.setSpecCodes(providerDemographicsFromQueue.getProviderInfo().getSpecCodes());
		providerDemographicsFromDb.getProviderInfo()
				.setPhone(providerDemographicsFromQueue.getProviderInfo().getPhone());
		providerDemographicsFromDb.getProviderInfo()
				.setAdjNo(providerDemographicsFromQueue.getProviderInfo().getAdjNo());
		providerDemographicsFromDb.getProviderInfo()
				.setChgDt(providerDemographicsFromQueue.getProviderInfo().getChgDt());
		providerDemographicsFromDb.getProviderInfo()
				.setPrvNoPay(providerDemographicsFromQueue.getProviderInfo().getPrvNoPay());
		providerDemographicsFromDb.getProviderInfo()
				.setPrvNoPayDt(providerDemographicsFromQueue.getProviderInfo().getPrvNoPayDt());
		providerDemographicsFromDb.getProviderInfo()
				.setPvdStRc(providerDemographicsFromQueue.getProviderInfo().getPvdStRc());
		providerDemographicsFromDb.getProviderInfo()
				.setActive(providerDemographicsFromQueue.getProviderInfo().getActive());
		providerDemographicsFromDb.getProviderInfo()
				.setArchived(providerDemographicsFromQueue.getProviderInfo().getArchived());
		mongoTemplate.getConverter().write(providerDemographicsFromDb, doc);
		return doc;
	}

	@Override
	public DemographicsDBResponse getDemographicsByProviderId(Map<String, String> queryMap, int limit, int offset,
			boolean includeCount) {
		Query query = new Query();
		
		Criteria criteria = Criteria.where(ProviderDemographicsMongoConstants.KEY_PROVIDER_ID)
				.is(providerDemographicsDataEncryption.encryptProviderId(queryMap.get(ProviderDemographicsMongoConstants.KEY_PROVIDER_ID)));
		
		queryMap.remove(ProviderDemographicsMongoConstants.KEY_PROVIDER_ID);
		
		if (queryMap.containsKey(ProviderDemographicsMongoConstants.ALPHA_KEY)) {
			addProvNameToCriteriaObj(queryMap, criteria);
			queryMap.remove(ProviderDemographicsMongoConstants.ALPHA_KEY);
		}
		
		if (queryMap.containsKey(ProviderDemographicsMongoConstants.PROVIDER_STATUS)) {
			addPvdStatusOrReasonCodeToCriteriaObj(queryMap, criteria);
		}
		
		query.addCriteria(generateCreteriaObjForOptionalParams(queryMap, criteria));
		query.skip(offset).limit(limit);
		
		return queryDBandBuildResponse(query, includeCount);
	}
	
	@Override
	public DemographicsDBResponse getDemographicsByProviderTaxId(Map<String, String> queryMap, int limit,
			int offset, boolean includeCount) {
		Query query = new Query();
		
		Map<String, String> queryMapByProviderId = new HashMap<>(queryMap); 
		String provtaxId = queryMap.get(ProviderDemographicsMongoConstants.KEY_PROVIDER_TAX_ID);
		
		Criteria criteria = Criteria.where(ProviderDemographicsMongoConstants.KEY_PROVIDER_TAX_ID)
				.is(providerDemographicsDataEncryption.encryptProviderTaxId(provtaxId));
		
		queryMap.remove(ProviderDemographicsMongoConstants.KEY_PROVIDER_TAX_ID);
		
		if (queryMap.containsKey(ProviderDemographicsMongoConstants.ALPHA_KEY)) {
			addProvNameToCriteriaObj(queryMap, criteria);
			queryMap.remove(ProviderDemographicsMongoConstants.ALPHA_KEY);
		}
		
		if (queryMap.containsKey(ProviderDemographicsMongoConstants.PROVIDER_STATUS)) {
			addPvdStatusOrReasonCodeToCriteriaObj(queryMap, criteria);
		}
		
		query.addCriteria(generateCreteriaObjForOptionalParams(queryMap, criteria));
		query.skip(offset).limit(limit);
		
		DemographicsDBResponse demographicsDBResponse = queryDBandBuildResponse(query, includeCount);
		
		if(CollectionUtils.isEmpty(demographicsDBResponse.getDemographics())) {
			queryMapByProviderId.remove(ProviderDemographicsMongoConstants.KEY_PROVIDER_TAX_ID);
			queryMapByProviderId.put(ProviderDemographicsMongoConstants.KEY_PROVIDER_ID, provtaxId);
			return getDemographicsByProviderId(queryMapByProviderId, limit, offset, includeCount);
		}
		
		return demographicsDBResponse;
	}
	
	@Override
	public DemographicsDBResponse getDemographicsByNpiId(Map<String, String> queryMap, int limit, int offset, boolean includeCount) {
		Query query = new Query();
		
		Criteria criteria = Criteria.where(ProviderDemographicsMongoConstants.KEY_NPI_ID)
				.is(providerDemographicsDataEncryption
						.encryptProviderTaxId(queryMap.get(ProviderDemographicsMongoConstants.KEY_NPI_ID)));
		queryMap.remove(ProviderDemographicsMongoConstants.KEY_NPI_ID);
		
		if (queryMap.containsKey(ProviderDemographicsMongoConstants.ALPHA_KEY)) {
			addProvNameToCriteriaObj(queryMap, criteria);
			queryMap.remove(ProviderDemographicsMongoConstants.ALPHA_KEY);
		}
		
		if (queryMap.containsKey(ProviderDemographicsMongoConstants.PROVIDER_STATUS)) {
			addPvdStatusOrReasonCodeToCriteriaObj(queryMap, criteria);
		}
		
		query.addCriteria(generateCreteriaObjForOptionalParams(queryMap, criteria));
		query.skip(offset).limit(limit);
		
		return queryDBandBuildResponse(query, includeCount);
	}
	
	@Override
	public DemographicsDBResponse getDemographicsByProvName(Map<String, String> queryMap, int limit, int offset,
			boolean includeCount) {
		Query query = new Query();
		
		@NonNull String alphaKey = queryMap.get(ProviderDemographicsMongoConstants.ALPHA_KEY);
		alphaKey = alphaKey.toUpperCase();
		alphaKey = toAnchoredRegex(alphaKey);
		Criteria criteria = Criteria.where(ProviderDemographicsMongoConstants.ALPHA_KEY).regex(alphaKey);
		queryMap.remove(ProviderDemographicsMongoConstants.ALPHA_KEY);
		
		if (queryMap.containsKey(ProviderDemographicsMongoConstants.PROVIDER_STATUS)) {
			addPvdStatusOrReasonCodeToCriteriaObj(queryMap, criteria);
		}
		
		query.addCriteria(generateCreteriaObjForOptionalParams(queryMap, criteria));
		query.skip(offset).limit(limit);
		
		return queryDBandBuildResponse(query, includeCount);
	}
	
	private String toAnchoredRegex(String str) {
		str = removeInvalidCharsAndRestrictLengthTo20Chars(str);
		return "^" + str;
	}
	
	private String removeInvalidCharsAndRestrictLengthTo20Chars(String str) {
		if (str != null) {
			str = INVALID_ALPHA_KEY_CHAR_PATTERN.matcher(str).replaceAll("");
			str = PERIOD_CHAR_PATTERN.matcher(str).replaceAll("\\\\.");
			StringUtils.substring(str, 0, ALPHA_KEY_MAX_LENGTH);
		}
		return str;
	}
	
	private Criteria generateCreteriaObjForOptionalParams(Map<String, String> queryMap,Criteria criteria) {
		queryMap.entrySet().stream().forEach(e -> criteria.and(e.getKey()).is(e.getValue()));
		criteria.and(ProviderDemographicsMongoConstants.KEY_CLIENT).is(CLIENT_VALUE);
		return criteria;
	}
	
	private String getDemographicsTotalDocumentsByProviderId(Query query) {
		long totDocs = mongoTemplate.count(query, Demographics.class,
				ProviderDemographicsMongoConstants.COLLECTION_PROVIDER_DEMOGRAPHICS);
		return String.valueOf(totDocs);
	}

	private void addProvNameToCriteriaObj(Map<String, String> queryMap, Criteria criteria) {
		String alphaKey = queryMap.get(ProviderDemographicsMongoConstants.ALPHA_KEY);
		alphaKey = alphaKey.toUpperCase();
		alphaKey = toAnchoredRegex(alphaKey);
		criteria.and(ProviderDemographicsMongoConstants.ALPHA_KEY).regex(alphaKey); 
	}
	
	private void addPvdStatusOrReasonCodeToCriteriaObj(Map<String, String> queryMap, Criteria criteria) {
		String value = queryMap.get(ProviderDemographicsMongoConstants.PROVIDER_STATUS);
		if (value != null) {
			criteria.orOperator(Criteria.where(ProviderDemographicsMongoConstants.PROVIDER_STATUS).is(value),
					Criteria.where(ProviderDemographicsMongoConstants.REASON_CODE).is(value));
		} else {
			Criteria criteria2 = new Criteria();
			criteria.orOperator(Criteria.where(ProviderDemographicsMongoConstants.PROVIDER_STATUS).is(ZERO),
					Criteria.where(ProviderDemographicsMongoConstants.PROVIDER_STATUS).is(SINGLE_SPACE),
					criteria2.andOperator(Criteria.where(ProviderDemographicsMongoConstants.PROVIDER_STATUS).is(ONE),
							Criteria.where(ProviderDemographicsMongoConstants.REASON_CODE).in(REASON_CODE)));
		}
		queryMap.remove(ProviderDemographicsMongoConstants.PROVIDER_STATUS);
	}
	
	private DemographicsDBResponse queryDBandBuildResponse(Query query,boolean includeCount) {
		String count = "";
		
		List<Document> doc = mongoTemplate.find(query, Document.class,
				ProviderDemographicsMongoConstants.COLLECTION_PROVIDER_DEMOGRAPHICS);
		List<Demographics> demographicsList = new ArrayList<>();
		for (Document demographicsDoc : doc) {
			demographicsDoc = providerDemographicsDataEncryption.decryptProviderDemoData(demographicsDoc);
			Demographics demographics = mongoTemplate.getConverter().read(Demographics.class, demographicsDoc);
			demographicsList.add(demographics);
		}
		
		if(includeCount) {
			query.skip(0).limit(0);
			count = getDemographicsTotalDocumentsByProviderId(query);
		}
		
		return DemographicsDBResponse.builder().demographics(demographicsList).totalCount(count).build();
	}

}

package com.humana.claims.hcaas.provider.demographics.core.constants;

import static java.util.Arrays.asList;
import static java.util.Collections.unmodifiableSet;

import java.util.HashSet;
import java.util.Set;

public class ProviderDemographicsConstants {

	private ProviderDemographicsConstants() {}
	
	public static final String SUCCESS = "Success";
	
	public static final String NOT_FOUND = "Provider not found for update";
	
	public static final String PROVIDER_DEMOGRAPHICS_NOT_FOUND = "Provider Demographics Data Not Found will retry later - ";
	
	public static final Set<String> listOfReasonCodes = unmodifiableSet(new HashSet<>(
			asList("SF", "1E", "1F", "1G", "1J", "1K", "1S", "1T", "1U", "IM", "1L", "1M", "1N", "1P", "1Q", "1R")));

	public static final String ARCHIVED_REASON_CODE = "AR";
	
	public static final String ARCHIVED_STATUS_CODE = "1";
	
	public static final String TOTAL_DOCS = "Total-Documents";
	
	public static final String PROVIDER_ID_PATTERN = "^[0-9]{9}$";
	
	public static final String NPI_ID_PATTERN = "^[0-9]{10}$";
	
	public static final String PROVIDER_TAX_ID_PATTERN = "^[0-9]{9}$";
	
	public static final String STATE_CODE_PATTERN = "^[a-zA-Z]{2}$";
	
	public static final String PROV_NAME_PATTERN = "^[a-zA-Z ]{1,20}$";
	
	public static final String MAJOR_CLASS_CODE_PATTERN = "^[a-zA-Z]{1}$";
	
	public static final int STATUS_REASON_CODE_MIN_LENGTH = 1;
	
	public static final int STATUS_REASON_CODE_MAX_LENGTH = 2;
}
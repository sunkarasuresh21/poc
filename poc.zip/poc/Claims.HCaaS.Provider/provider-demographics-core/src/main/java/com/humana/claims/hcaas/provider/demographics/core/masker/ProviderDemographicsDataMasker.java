package com.humana.claims.hcaas.provider.demographics.core.masker;

import java.util.function.Supplier;

import org.springframework.stereotype.Component;

import com.humana.claims.hcaas.common.utils.datamasking.StringMasker;

@Component
public class ProviderDemographicsDataMasker {
	
	private final StringMasker providerIdMasker = StringMasker.stringMasker(2, 2);
	
	private final StringMasker irsNoMasker = StringMasker.stringMasker(2, 2);
	
	private final StringMasker npiIdMasker = StringMasker.stringMasker(2, 2);
	
	private final StringMasker provNameMasker = StringMasker.stringMasker(2, 2);
	
	public Supplier<String> maskProviderId(String providerId) {
		return providerIdMasker.maskSupplier(providerId);
	}
	
	public Supplier<String> maskIrsNo(String irsNo) {
		return irsNoMasker.maskSupplier(irsNo);
	}
	
	public Supplier<String> maskNpiId(String npiId) {
		return npiIdMasker.maskSupplier(npiId);
	}
	
	public Supplier<String> maskProvName(String provName) {
		return provNameMasker.maskSupplier(provName);
	}
	
}

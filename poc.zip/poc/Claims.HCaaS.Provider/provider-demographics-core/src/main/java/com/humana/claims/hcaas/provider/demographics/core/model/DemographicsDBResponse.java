package com.humana.claims.hcaas.provider.demographics.core.model;

import java.util.List;

import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Getter
@Setter
@ToString
public class DemographicsDBResponse {
	private List<Demographics> demographics;
	private String  totalCount;
}


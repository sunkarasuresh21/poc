package com.humana.claims.hcaas.provider.demographics.core.dao;

public class ProviderDemographicsMongoConstants {

	private ProviderDemographicsMongoConstants() {}
	
	public static final String COLLECTION_PROVIDER_DEMOGRAPHICS = "ProviderDemographics"; 
	
	public static final String CREATE_DEMOGRAPHICS_SUCCESS = "Demographics data added successfully";
	
	public static final String DEMOGRAPHICS_ALREADY_EXISTS = "Demographics already exists";

	public static final String KEY = "key";
	
	public static final String KEY_PROVIDER_TAX_ID = "irsNo";

	public static final String KEY_PROVIDER_ID = "key.prov";

	public static final String KEY_CLIENT = "key.client";
	
	public static final String KEY_PROVIDER_SUFFIX = "key.multAddressKey";
	
	public static final String KEY_PROVIDER_INDICATOR = "key.pvdInd";

	public static final String KEY_NPI_ID = "providerInfo.npiIds.npiId";
	
	public static final String DETERMINISTIC_ENCRYPTION_TYPE = "AEAD_AES_256_CBC_HMAC_SHA_512-Deterministic";
	
	public static final String MAJOR_CLASSCODE = "providerInfo.majClsCd";
	
	public static final String ALPHA_KEY = "alphaKey";
	
	public static final String PROVIDER_STATUS= "pvdStatus";
	
	public static final String REASON_CODE="providerInfo.pvdStRc";
	
	public static final String STATE_CODE = "providerInfo.st";
	
	public static final String LIMIT = "providerInfo.st";
	
	public static final String OFFSET = "providerInfo.st";

}
package com.humana.claims.hcaas.provider.demographics.core.model.db;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class Demographics {

	@JsonProperty("KEY")
	private DemographicsKey key;

	@JsonProperty("TIN-EFF-DT")
	private LocalDate tinEffDt;

	@JsonProperty("IRS-NO")
	private String irsNo;
	
	private String alphaKey;

	@JsonProperty("UPDATE-SYS")
	private String updateSys;

	@JsonProperty("PVD-STATUS")
	private String pvdStatus;

	@JsonProperty("PROVIDER-INFO")
	private ProviderInfo providerInfo;
	
}

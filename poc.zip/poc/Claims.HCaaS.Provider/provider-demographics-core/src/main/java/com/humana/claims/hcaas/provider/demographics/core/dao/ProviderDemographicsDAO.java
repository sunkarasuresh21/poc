package com.humana.claims.hcaas.provider.demographics.core.dao;

import java.util.Map;

import com.humana.claims.hcaas.provider.demographics.core.exception.ProviderDemographicsNotFoundException;
import com.humana.claims.hcaas.provider.demographics.core.model.DemographicsDBResponse;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;

public interface ProviderDemographicsDAO {

	void upsertProviderDemographicsProv1(Demographics providerDemographics);

	void updateProviderDemographicsProv2(Demographics providerDemographics) throws ProviderDemographicsNotFoundException;

	DemographicsDBResponse getDemographicsByProviderId(Map<String, String> queryMap,int limit,int offset,boolean includeCount);
	
	DemographicsDBResponse getDemographicsByProviderTaxId(Map<String, String> queryMap,int limit,int offset,boolean includeCount);
	
	DemographicsDBResponse getDemographicsByNpiId(Map<String, String> queryMap,int limit,int offset,boolean includeCount);
	
	DemographicsDBResponse getDemographicsByProvName(Map<String, String> queryMap,int limit,int offset,boolean includeCount);

	String postProviderDemographics(Demographics demographics);

	Demographics updateProviderDemographics(Demographics demographics, String providerId,
			String providerMultiAddressKey, String providerIndicator) throws IllegalAccessException;
	

}

package com.humana.claims.hcaas.provider.demographics.core.exception;

@SuppressWarnings("serial")
public class ProviderDemographicsNotFoundException extends Exception {

	public ProviderDemographicsNotFoundException() {
		super();
	}

}

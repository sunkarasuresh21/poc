package com.humana.claims.hcaas.provider.demographics.core.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Getter
@Setter
@ToString
public class ProviderDemoGetRequest {
	private String providerId;
	private String providerIndicator;
	private String providerMultiAddressKey;
	private String providerTaxId;
	private String npiId;
	private Integer limit;
	private Integer offset; 
	private String statusOrReasonCode;
	private Boolean includeCount;
	private String majorClassCode;
	private String provName;
	private String stateCode;
	private Boolean checkContract;
}


package com.humana.claims.hcaas.provider.demographics.core.util;

import java.lang.reflect.Field;
import java.time.LocalDate;
import java.util.Collection;

import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import com.humana.claims.hcaas.provider.demographics.core.model.db.Address;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.demographics.core.model.db.DemographicsKey;
import com.humana.claims.hcaas.provider.demographics.core.model.db.ProviderInfo;

@Component
public class ProviderDemographicsPatchUtil {

	public Update getMongoUpdateObjForDemographics(Demographics demographics) throws IllegalAccessException {
		demographics.getProviderInfo().setChgDt(LocalDate.now());
		Update update = new Update();

		for (Field field : Demographics.class.getDeclaredFields()) {
			field.setAccessible(true);
			if (!field.isSynthetic()) {

				if (field.get(demographics) != null && field.getType() != ProviderInfo.class
						&& field.getType() != DemographicsKey.class) {
					update.set(field.getName(), field.get(demographics));
				}

				getMongoUpdateObjForProviderInfo(update, field, demographics);
			}
		}
		return update;
	}

	private Update getMongoUpdateObjForProviderInfo(Update update, Field field, Demographics demographics)
			throws IllegalAccessException {
		if (field.getType() == ProviderInfo.class) {
			ProviderInfo providerInfo = demographics.getProviderInfo();
			for (Field providerInfoField : ProviderInfo.class.getDeclaredFields()) {
				providerInfoField.setAccessible(true);
				if (!providerInfoField.isSynthetic()) {
					getMongoUpdateObj(update, providerInfoField, providerInfo, demographics);
				}
			}
		}
		return update;
	}

	private void getMongoUpdateObj(Update update, Field providerInfoField, ProviderInfo providerInfo, Demographics demographics) throws IllegalAccessException {
		if (providerInfoField.get(providerInfo) != null
				&& (!Collection.class.isAssignableFrom(providerInfoField.getType()))
				&& providerInfoField.getType() != Address.class) {
			update.set("providerInfo." + providerInfoField.getName(), providerInfoField.get(providerInfo));
		}
		getMongoUpdateObjForProviderInfoFieldsOfTypeList(update, providerInfoField, providerInfo);
		getMongoUpdateObjForAddress(update, providerInfoField, demographics);
	}

	@SuppressWarnings("rawtypes")
	private Update getMongoUpdateObjForProviderInfoFieldsOfTypeList(Update update, Field providerInfoField,
			ProviderInfo providerInfo) throws IllegalAccessException {
		if (Collection.class.isAssignableFrom(providerInfoField.getType())
				&& !((Collection) providerInfoField.get(providerInfo)).isEmpty()) {
			update.set("providerInfo." + providerInfoField.getName(), providerInfoField.get(providerInfo));
		}
		return update;
	}

	private Update getMongoUpdateObjForAddress(Update update, Field providerInfoField, Demographics demographics)
			throws IllegalAccessException {
		if (providerInfoField.getType() == Address.class) {
			Address address = demographics.getProviderInfo().getAddress();
			for (Field addressField : Address.class.getDeclaredFields()) {
				addressField.setAccessible(true);
				if (!addressField.isSynthetic() && addressField.get(address) != null) {

					update.set("providerInfo.address." + addressField.getName(), addressField.get(address));
				}
			}
		}
		return update;
	}

}
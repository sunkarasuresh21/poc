package com.humana.claims.hcaas.provider.demographics.core.model.db;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class DemographicsKey {

    @JsonProperty("CLIENT")
    private String client;

    @JsonProperty("PVD-IND")
    private String pvdInd;

    @JsonProperty("PROV")
    private String prov;

    @JsonProperty("MULT-ADDRESS-KEY")
    private String multAddressKey;

}

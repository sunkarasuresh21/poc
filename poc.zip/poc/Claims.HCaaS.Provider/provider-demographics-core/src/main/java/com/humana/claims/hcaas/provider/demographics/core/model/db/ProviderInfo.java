package com.humana.claims.hcaas.provider.demographics.core.model.db;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ProviderInfo {

	@JsonProperty("PROV-NAME")
	private String provName;

	@JsonProperty("ADDRESS")
	private Address address;

	@JsonProperty("CITY")
	private String city;

	@JsonProperty("ST")
	private String st;

	@JsonProperty("ZIP")
	private String zip;
	
	@JsonProperty("LATITUDE")
	private Double latitude;
	
	@JsonProperty("LONGITUDE")
	private Double longitude;
	
	@JsonProperty("PROV-TYPE")
	private String provType;

	@JsonProperty("MAJ-CLS-CD")
	private String majClsCd;

	@JsonProperty("GROUP-FLAG")
	private String groupFlag;

	@JsonProperty("SPEC-CODES")
	private List<SpecCode> specCodes = new ArrayList<>();

	@JsonProperty("PHONE")
	private String phone;

	@JsonProperty("ADJ-NO")
	private String adjNo;

	@JsonProperty("CHG-DT")
	private LocalDate chgDt;

	@JsonProperty("NO-PAY")
	private String prvNoPay;

	@JsonProperty("NO-PAY-DT")
	private LocalDate prvNoPayDt;

	@JsonProperty("PVD-ST-RC")
	private String pvdStRc;
	
	@JsonProperty("ACTIVE")
	private Boolean active;
	
	@JsonProperty("ARCHIVED")
	private Boolean archived;

	@JsonProperty("NPI-IDS")
	private List<NpiInfos> npiIds = new ArrayList<>();

	@JsonProperty("TAXONOMY-CODES")
	private List<TaxonomyCode> taxonomyCodes = new ArrayList<>();

}

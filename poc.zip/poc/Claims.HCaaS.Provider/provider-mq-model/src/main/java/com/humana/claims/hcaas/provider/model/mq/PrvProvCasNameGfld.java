package com.humana.claims.hcaas.provider.model.mq;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class PrvProvCasNameGfld {

    @JsonProperty("PRV-PROV-CAS-FST-NAME")
    private String prvProvCasFstName;

    @JsonProperty("PRV-PROV-CAS-LAST-NAME")
    private String prvProvCasLastName;

}

package com.humana.claims.hcaas.provider.model.mq;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class Prv3ProvWthldCurrent {

	@JsonProperty("PRV3-WTHLD-PER-C")
	private String prv3WthldPerC;

	@JsonProperty("PRV3-WTHLD-EFF-DATE-C")
	private String prv3WthldEffDateC;

}

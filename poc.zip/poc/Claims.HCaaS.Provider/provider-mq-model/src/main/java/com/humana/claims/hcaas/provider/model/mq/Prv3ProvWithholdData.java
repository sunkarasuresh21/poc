package com.humana.claims.hcaas.provider.model.mq;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class Prv3ProvWithholdData {

	@JsonProperty("PRV3-PROV-WTHLD-CURRENT")
	private Prv3ProvWthldCurrent prv3ProvWthldCurrent;

	@JsonProperty("PRV3-PROV-WTHLD-PRIOR")
	private Prv3ProvWthldPrior prv3ProvWthldPrior;

	@JsonProperty("PRV3-PROV-PR-TAXFREE-AMT")
	private String prv3ProvPrTaxfreeAmt;

}

package com.humana.claims.hcaas.provider.model.mq;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class PrvProviderInfo {

    @JsonProperty("PRV-PROV-NAME")
    private String prvProvName;

    @JsonProperty("PRV-ADDRESS")
    private PrvAddress prvAddress;

    @JsonProperty("PRV-CITY")
    private String prvCity;

    @JsonProperty("PRV-ST")
    private String prvSt;

    @JsonProperty("PRV-ZIP")
    private String prvZip;
    
    @JsonProperty("PRV-LATITUDE")
    private String prvLatitiude;
    
    @JsonProperty("PRV-LONGITUDE")
    private String prvLongitude;

    @JsonProperty("PRV-PROV-TYPE")
    private String prvProvType;

    @JsonProperty("PRV-VCH")
    private String prvVch;

    @JsonProperty("PRV-MAJ-CLS-CD")
    private String prvMajClsCd;

    @JsonProperty("PRV-TAX-TYPE")
    private String prvTaxType;

    @JsonProperty("PRV-GROUP-FLAG")
    private String prvGroupFlag;

    @JsonProperty("PRV-SPEC1-CD")
    private String prvSpec1Cd;

    @JsonProperty("PRV-SPEC2-CD")
    private String prvSpec2Cd;

    @JsonProperty("PRV-SPEC3-CD")
    private String prvSpec3Cd;

    @JsonProperty("PRV-SEND-1099-IND")
    private String prvSend1099Ind;

    @JsonProperty("PRV-PEND-ESC")
    private String prvPendEsc;

    @JsonProperty("PRV-AUTO-CHECK-PULL-IND")
    private String prvAutoCheckPullInd;

    @JsonProperty("PRV-IRS-WITHHOLD-IND")
    private String prvIrsWithholdInd;

    @JsonProperty("PRV-PAY-CYCLE")
    private String prvPayCycle;

    @JsonProperty("PRV-CROSS-REF")
    private String prvCrossRef;

    @JsonProperty("PRV-SPEC-CD")
    private String prvSpecCd;

    @JsonProperty("PRV-MARKET-ID")
    private String prvMarketId;

    @JsonProperty("PRV-PHONE")
    private String prvPhone;

    @JsonProperty("PRV-DG")
    private String prvDg;

    @JsonProperty("PRV-ADJ-NO")
    private String prvAdjNo;

    @JsonProperty("PRV-CHG-DT")
    private String prvChgDt;

    @JsonProperty("PRV-ALPHA-KEY")
    private String prvAlphaKey;

    @JsonProperty("PRV-PROV-CAS-NAME-GFLD")
    private PrvProvCasNameGfld prvProvCasNameGfld;

    @JsonProperty("PRV-MED-SUPP-WAIVE-IND")
    private String prvMedSuppWaiveInd;

    @JsonProperty("PRV-PRIOR-INFO")
    private PrvPriorInfo prvPriorInfo;

    @JsonProperty("PRV-COMMENT")
    private String prvComment;
    
    @JsonProperty("PRV-PVD-ST-RC")
    private String prvPvdStRc;

    @JsonProperty("PRV-NOTIFY-IND")
    private String prvNotifyInd;

    @JsonProperty("PRV-FOCUS-FROM-DATE")
    private String prvFocusFromDate;

    @JsonProperty("PRV-CLPTH-IND")
    private String prvClpthInd;

    @JsonProperty("PRV-CLM-CHK-IND")
    private String prvClmChkInd;

    @JsonProperty("PRV-UC-ZIP")
    private String prvUcZip;

    @JsonProperty("PRV-FOCUS-TO-DATE")
    private String prvFocusToDate;

    @JsonProperty("PRV-AUTO-LOAD-IND")
    private String prvAutoLoadInd;

    @JsonProperty("PRV-CHECK-TO-AIX-KEY")
    private PrvCheckToAixKey prvCheckToAixKey;

}

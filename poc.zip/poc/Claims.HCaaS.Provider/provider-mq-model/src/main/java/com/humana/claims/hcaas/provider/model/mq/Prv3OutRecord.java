package com.humana.claims.hcaas.provider.model.mq;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@JsonRootName(value = "PRV3-OUT-RECORD")
public class Prv3OutRecord {

	@JsonProperty("PRV3-KEY")
	private Prv3Key prv3Key;

	@JsonProperty("PRV3-PROV-WITHHOLD-DATA")
	private Prv3ProvWithholdData prv3ProvWithholdData;

}

package com.humana.claims.hcaas.provider.model.mq;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class Prv2Provider2Info {

	@JsonProperty("PRV2-APPLY-TAX-IND")
	private String prv2ApplyTaxInd;

	@JsonProperty("PRV2-W9-IND")
	private String prv2W9Ind;

	@JsonProperty("PRV2-SEND-480-IND")
	private String prv2Send480Ind;

	@JsonProperty("PRV2-COMMENT-2")
	private String prv2Comment2;

	@JsonProperty("PRV2-COMMENT-3")
	private String prv2Comment3;

	@JsonProperty("PRV2-VENDOR-ID")
	private String prv2VendorId;

	@JsonProperty("PRV2-UPDT-ADJ-NO")
	private String prv2UpdtAdjNo;

	@JsonProperty("PRV2-UPDT-DT")
	private String prv2UpdtDt;

	@JsonProperty("PRV2-RAD-SITE-CURR-IND")
	private String prv2RadSiteCurrInd;

	@JsonProperty("PRV2-RAD-SITE-CURR-DT")
	private String prv2RadSiteCurrDt;

	@JsonProperty("PRV2-RAD-SITE-P1-IND")
	private String prv2RadSiteP1Ind;

	@JsonProperty("PRV2-RAD-SITE-P1-DT")
	private String prv2RadSiteP1Dt;

	@JsonProperty("PRV2-RAD-SITE-P2-IND")
	private String prv2RadSiteP2Ind;

	@JsonProperty("PRV2-RAD-SITE-P2-DT")
	private String prv2RadSiteP2Dt;

	@JsonProperty("PRV2-RAD-SCOPE-CURR-IND")
	private String prv2RadScopeCurrInd;

	@JsonProperty("PRV2-RAD-SCOPE-CURR-DT")
	private String prv2RadScopeCurrDt;

	@JsonProperty("PRV2-RAD-SCOPE-P1-IND")
	private String prv2RadScopeP1Ind;

	@JsonProperty("PRV2-RAD-SCOPE-P1-DT")
	private String prv2RadScopeP1Dt;

	@JsonProperty("PRV2-NPI")
	private String prv2Npi;

	@JsonProperty("PRV2-TAXONOMY-CODE")
	private String prv2TaxonomyCode;

	@JsonProperty("PRV2-FAC-UC-ZIP")
	private String prv2FacUcZip;

	@JsonProperty("PRV2-TAXONOMY-CODE-2")
	private String prv2TaxonomyCode2;

	@JsonProperty("PRV2-TAXONOMY-CODE-3")
	private String prv2TaxonomyCode3;

	@JsonProperty("PRV2-TAXONOMY-CODE-4")
	private String prv2TaxonomyCode4;

	@JsonProperty("PRV2-TAXONOMY-CODE-5")
	private String prv2TaxonomyCode5;

	@JsonProperty("PRV2-TAXONOMY-CODE-6")
	private String prv2TaxonomyCode6;

	@JsonProperty("PRV2-TAXONOMY-CODE-7")
	private String prv2TaxonomyCode7;

	@JsonProperty("PRV2-TAXONOMY-CODE-8")
	private String prv2TaxonomyCode8;

	@JsonProperty("PRV2-TAXONOMY-CODE-9")
	private String prv2TaxonomyCode9;

	@JsonProperty("PRV2-TAXONOMY-CODE-10")
	private String prv2TaxonomyCode10;

	@JsonProperty("PRV2-PXI-UPDT-ADJ-NO")
	private String prv2PxiUpdtAdjNo;

	@JsonProperty("PRV2-PXI-UPDT-DT")
	private String prv2PxiUpdtDt;

	@JsonProperty("PRV2-NPI-2")
	private String prv2Npi2;

	@JsonProperty("PRV2-NPI-3")
	private String prv2Npi3;

	@JsonProperty("PRV2-NPI-4")
	private String prv2Npi4;

	@JsonProperty("PRV2-NPI-5")
	private String prv2Npi5;

	@JsonProperty("PRV2-NPI-6")
	private String prv2Npi6;

	@JsonProperty("PRV2-NPI-7")
	private String prv2Npi7;

	@JsonProperty("PRV2-NPI-8")
	private String prv2Npi8;
	
	@JsonProperty("PRV2-NPI-9")
	private String prv2Npi9;
	
	@JsonProperty("PRV2-CLM-CHK-IND")
	private String prv2ClmChkInd;

	@JsonProperty("PRV2-SEND-LTR-IND")
	private String prv2SendLtrInd;

	@JsonProperty("PRV2-FINALST-IND")
	private String prv2FinalstInd;

	@JsonProperty("PRV2-PXI-ZIP-1")
	private String prv2PxiZip1;

	@JsonProperty("PRV2-PXI-ZIP-2")
	private String prv2PxiZip2;

	@JsonProperty("PRV2-PXI-ZIP-3")
	private String prv2PxiZip3;

	@JsonProperty("PRV2-PXI-ZIP-4")
	private String prv2PxiZip4;

	@JsonProperty("PRV2-PXI-ZIP-5")
	private String prv2PxiZip5;

	@JsonProperty("PRV2-PXI-ZIP-6")
	private String prv2PxiZip6;

	@JsonProperty("PRV2-PXI-ZIP-7")
	private String prv2PxiZip7;

	@JsonProperty("PRV2-PXI-ZIP-8")
	private String prv2PxiZip8;

	@JsonProperty("PRV2-PXI-ZIP-9")
	private String prv2PxiZip9;

	@JsonProperty("PRV2-PXI-ZIP-10")
	private String prv2PxiZip10;

	@JsonProperty("PRV2-PXI-ZIP-11")
	private String prv2PxiZip11;

	@JsonProperty("PRV2-PXI-ZIP-12")
	private String prv2PxiZip12;

	@JsonProperty("PRV2-PXI-ZIP-13")
	private String prv2PxiZip13;

	@JsonProperty("PRV2-PXI-ZIP-14")
	private String prv2PxiZip14;

	@JsonProperty("PRV2-PXI-ZIP-15")
	private String prv2PxiZip15;

	@JsonProperty("PRV2-PXI-ZIP-16")
	private String prv2PxiZip16;

	@JsonProperty("PRV2-PXI-ZIP-17")
	private String prv2PxiZip17;

	@JsonProperty("PRV2-PXI-ZIP-18")
	private String prv2PxiZip18;

	@JsonProperty("PRV2-PXI-ZIP-19")
	private String prv2PxiZip19;

	@JsonProperty("PRV2-PXI-ZIP-20")
	private String prv2PxiZip20;

	@JsonProperty("PRV2-PXI-ZIP-IND-1")
	private String prv2PxiZipInd1;

	@JsonProperty("PRV2-PXI-ZIP-IND-2")
	private String prv2PxiZipInd2;

	@JsonProperty("PRV2-PXI-ZIP-IND-3")
	private String prv2PxiZipInd3;

	@JsonProperty("PRV2-PXI-ZIP-IND-4")
	private String prv2PxiZipInd4;

	@JsonProperty("PRV2-PXI-ZIP-IND-5")
	private String prv2PxiZipInd5;

	@JsonProperty("PRV2-PXI-ZIP-IND-6")
	private String prv2PxiZipInd6;

	@JsonProperty("PRV2-PXI-ZIP-IND-7")
	private String prv2PxiZipInd7;

	@JsonProperty("PRV2-PXI-ZIP-IND-8")
	private String prv2PxiZipInd8;

	@JsonProperty("PRV2-PXI-ZIP-IND-9")
	private String prv2PxiZipInd9;

	@JsonProperty("PRV2-PXI-ZIP-IND-10")
	private String prv2PxiZipInd10;

	@JsonProperty("PRV2-PXI-ZIP-IND-11")
	private String prv2PxiZipInd11;

	@JsonProperty("PRV2-PXI-ZIP-IND-12")
	private String prv2PxiZipInd12;

	@JsonProperty("PRV2-PXI-ZIP-IND-13")
	private String prv2PxiZipInd13;

	@JsonProperty("PRV2-PXI-ZIP-IND-14")
	private String prv2PxiZipInd14;

	@JsonProperty("PRV2-PXI-ZIP-IND-15")
	private String prv2PxiZipInd15;

	@JsonProperty("PRV2-PXI-ZIP-IND-16")
	private String prv2PxiZipInd16;

	@JsonProperty("PRV2-PXI-ZIP-IND-17")
	private String prv2PxiZipInd17;

	@JsonProperty("PRV2-PXI-ZIP-IND-18")
	private String prv2PxiZipInd18;

	@JsonProperty("PRV2-PXI-ZIP-IND-19")
	private String prv2PxiZipInd19;

	@JsonProperty("PRV2-PXI-ZIP-IND-20")
	private String prv2PxiZipInd20;

	@JsonProperty("PRV2-COMPBID-IND")
	private String prv2CompbidInd;

	@JsonProperty("PRV2-COMPBID-EFF-DT")
	private String prv2CompbidEffDt;

	@JsonProperty("PRV2-COMPBID-TRM-DT")
	private String prv2CompbidTrmDt;

	@JsonProperty("PRV2-PXI-PTS-LOB-AREA")
	private Prv2PxiPtsLobArea prv2PxiPtsLobArea;

}

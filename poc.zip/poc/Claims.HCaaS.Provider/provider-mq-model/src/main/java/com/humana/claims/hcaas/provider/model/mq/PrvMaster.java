package com.humana.claims.hcaas.provider.model.mq;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@JsonRootName(value = "PRV-MASTER")
public class PrvMaster {

	@JsonProperty("PRV-KEY")
	private PrvKey prvKey;

	@JsonProperty("PRV-IRS-NO")
	private String prvIrsNo;

	@JsonProperty("PRV-PVD-STATUS")
	private String prvPvdStatus;

	@JsonProperty("PRV-TIN-EFF-DT")
	private String prvTinEffDt;

	@JsonProperty("PRV-UPDATE-SYS")
	private String prvUpdateSys;

	@JsonProperty("PRV-PROVIDER-INFO")
	private PrvProviderInfo prvProviderInfo;

}

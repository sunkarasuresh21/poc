package com.humana.claims.hcaas.provider.model.mq;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class PrvPriorInfo {

    @JsonProperty("PRV-NO-PAY")
    private String prvNoPay;

    @JsonProperty("PRV-NO-PAY-DT")
    private String prvNoPayDt;

}

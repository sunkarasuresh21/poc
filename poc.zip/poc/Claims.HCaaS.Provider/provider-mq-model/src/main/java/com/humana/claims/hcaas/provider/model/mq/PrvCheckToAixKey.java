package com.humana.claims.hcaas.provider.model.mq;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class PrvCheckToAixKey {

    @JsonProperty("PRV-CHECK-TO")
    private String prvCheckTo;

    @JsonProperty("PRV-SUFFIX-TO")
    private String prvSuffixTo;

}

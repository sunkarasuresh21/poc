package com.humana.claims.hcaas.provider.model.mq;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class PrvKey {

    @JsonProperty("PRV-CLIENT")
    private String prvClient;

    @JsonProperty("PRV-PVD-IND")
    private String prvPvdInd;

    @JsonProperty("PRV-PROV")
    private String prvProv;

    @JsonProperty("PRV-MULT-ADDRESS-KEY")
    private String prvMultAddressKey;

}

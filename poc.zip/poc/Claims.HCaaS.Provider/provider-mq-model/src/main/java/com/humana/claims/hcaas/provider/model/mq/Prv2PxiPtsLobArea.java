package com.humana.claims.hcaas.provider.model.mq;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class Prv2PxiPtsLobArea {

    @JsonProperty("PRV2-PXI-PTS-LOB1")
    private String prv2PxiPtsLob1;

    @JsonProperty("PRV2-PXI-PTS-LOB2")
    private String prv2PxiPtsLob2;

    @JsonProperty("PRV2-PXI-PTS-LOB3")
    private String prv2PxiPtsLob3;

    @JsonProperty("PRV2-PXI-PTS-LOB4")
    private String prv2PxiPtsLob4;

    @JsonProperty("PRV2-PXI-PTS-LOB5")
    private String prv2PxiPtsLob5;

    @JsonProperty("PRV2-PXI-PTS-LOB6")
    private String prv2PxiPtsLob6;

    @JsonProperty("PRV2-PXI-PTS-LOB7")
    private String prv2PxiPtsLob7;

    @JsonProperty("PRV2-PXI-PTS-LOB8")
    private String prv2PxiPtsLob8;

    @JsonProperty("PRV2-PXI-PTS-LOB9")
    private String prv2PxiPtsLob9;

}

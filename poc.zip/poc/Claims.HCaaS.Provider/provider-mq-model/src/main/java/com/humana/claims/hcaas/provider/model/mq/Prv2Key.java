package com.humana.claims.hcaas.provider.model.mq;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class Prv2Key {

	@JsonProperty("PRV2-CLIENT")
	private String prv2Client;

	@JsonProperty("PRV2-PVD-IND")
	private String prv2PvdInd;

	@JsonProperty("PRV2-PROV")
	private String prv2Prov;

	@JsonProperty("PRV2-MULT-ADDRESS-KEY")
	private String prv2MultAddressKey;

}

package com.humana.claims.hcaas.provider.model.mq;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@JsonRootName(value = "PRV2-OUT-RECORD")
public class Prv2OutRecord {

	@JsonProperty("PRV2-KEY")
	private Prv2Key prv2Key;

	@JsonProperty("PRV2-PROVIDER2-INFO")
	private Prv2Provider2Info prv2Provider2Info;

}

package com.humana.claims.hcaas.provider.model.mq;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class PrvAddress {

    @JsonProperty("PRV-ADDR-1")
    private String prvAddr1;

    @JsonProperty("PRV-ADDR-2")
    private String prvAddr2;

    @JsonProperty("PRV-ADDR-3")
    private String prvAddr3;

    @JsonProperty("PRV-ADDR-4")
    private String prvAddr4;

}

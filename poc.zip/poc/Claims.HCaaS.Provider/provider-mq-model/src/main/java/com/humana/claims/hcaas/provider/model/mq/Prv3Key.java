package com.humana.claims.hcaas.provider.model.mq;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class Prv3Key {

	@JsonProperty("PRV3-CLIENT")
	private String prv3Client;

	@JsonProperty("PRV3-PVD-IND")
	private String prv3PvdInd;

	@JsonProperty("PRV3-PROV")
	private String prv3Prov;

	@JsonProperty("PRV3-MULT-ADDRESS-KEY")
	private String prv3MultAddressKey;

}

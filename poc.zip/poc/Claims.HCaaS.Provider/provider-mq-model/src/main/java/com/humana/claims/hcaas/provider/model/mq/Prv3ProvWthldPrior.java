package com.humana.claims.hcaas.provider.model.mq;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class Prv3ProvWthldPrior {

	@JsonProperty("PRV3-WTHLD-PER-P")
	private String prv3WthldPerP;

	@JsonProperty("PRV3-WTHLD-EFF-DATE-P")
	private String prv3WthldEffDateP;

}

package com.humana.claims.hcaas.provider.attributes.core.model;

import lombok.Data;

@Data
public class RequestKey {

	private String client;

	private String pvdInd;

	private Object prov;

	private String multAddressKey;
}

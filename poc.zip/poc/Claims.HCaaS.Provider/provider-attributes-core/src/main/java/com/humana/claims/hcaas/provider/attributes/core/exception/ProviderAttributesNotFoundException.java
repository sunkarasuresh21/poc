package com.humana.claims.hcaas.provider.attributes.core.exception;

@SuppressWarnings("serial")
public class ProviderAttributesNotFoundException extends Exception {

	public ProviderAttributesNotFoundException() {
		super();
	}

}

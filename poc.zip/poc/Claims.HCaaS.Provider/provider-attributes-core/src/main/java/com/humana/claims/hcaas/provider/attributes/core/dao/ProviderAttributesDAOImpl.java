package com.humana.claims.hcaas.provider.attributes.core.dao;

import static com.humana.claims.hcaas.provider.attributes.core.dao.ProviderAttributesMongoConstants.ATTRIBUTES_ALREADY_EXISTS;
import static com.humana.claims.hcaas.provider.attributes.core.dao.ProviderAttributesMongoConstants.COLLECTION_PROVIDER_ATTRIBUTES;
import static com.humana.claims.hcaas.provider.attributes.core.dao.ProviderAttributesMongoConstants.CREATE_ATTRIBUTES_SUCCESS;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.humana.claims.hcaas.provider.attributes.core.constants.ProviderAttributesConstants;
import com.humana.claims.hcaas.provider.attributes.core.data.encrypt.ProviderAttributesDataEncryption;
import com.humana.claims.hcaas.provider.attributes.core.exception.ProviderAttributesNotFoundException;
import com.humana.claims.hcaas.provider.attributes.core.mapper.ProviderAttrGetRequest;
import com.humana.claims.hcaas.provider.attributes.core.model.RequestKey;
import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.attributes.core.util.ProviderAttributesPatchUtil;
import com.mongodb.client.result.UpdateResult;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
@AllArgsConstructor
public class ProviderAttributesDAOImpl implements ProviderAttributesDAO {

	private MongoTemplate mongoTemplate;

	private ProviderAttributesPatchUtil providerAttributesPatchUtil;

	private ProviderAttributesDataEncryption providerAttributesDataEncrypt;

	private static final String CLIENT_VALUE = "58";

	@Override
	public void upsertProviderAttributesProv1(Attributes providerAttributesFromQueue) {
		Document doc = new Document();
		Query query = new Query();
		query.addCriteria(buildProviderCriteria(providerAttributesFromQueue));

		mongoTemplate.getConverter().write(providerAttributesFromQueue, doc);
		doc = providerAttributesDataEncrypt.encryptProviderData(doc);

		Document attributesFromDb = mongoTemplate.findOne(query, Document.class,
				ProviderAttributesMongoConstants.COLLECTION_PROVIDER_ATTRIBUTES);
		
		if (null != attributesFromDb) {
			attributesFromDb = providerAttributesDataEncrypt.decryptProviderData(attributesFromDb);
			Attributes attributes = mongoTemplate.getConverter().read(Attributes.class, attributesFromDb);
			updateProviderAttributes(mapAttributesFromMQDataProv1(providerAttributesFromQueue, attributes),
					query);
			log.debug("Provider Attributes updated successfully for ProvKey");
		} else {
			mongoTemplate.save(doc, ProviderAttributesMongoConstants.COLLECTION_PROVIDER_ATTRIBUTES);
			log.debug("Provider Attributes inserted successfully for ProvKey");
		}
	}
	
	private Criteria buildProviderCriteria(Attributes providerAttributesFromQueue) {
		return Criteria.where(ProviderAttributesMongoConstants.KEY_PROVIDER_ID)
				.is(providerAttributesDataEncrypt.encryptProviderId(providerAttributesFromQueue.getKey().getProv()))
				.and(ProviderAttributesMongoConstants.KEY_PROVIDER_SUFFIX)
				.is(providerAttributesFromQueue.getKey().getMultAddressKey())
				.and(ProviderAttributesMongoConstants.KEY_PROVIDER_INDICATOR)
				.is(providerAttributesFromQueue.getKey().getPvdInd()).and(ProviderAttributesMongoConstants.KEY_CLIENT)
				.is(CLIENT_VALUE);
	}

	private long updateProviderAttributes(Document doc, Query query) {
		Document document = providerAttributesDataEncrypt.encryptProviderData(doc);
		UpdateResult updateResult = mongoTemplate.updateFirst(query, Update.fromDocument(document),
				ProviderAttributesMongoConstants.COLLECTION_PROVIDER_ATTRIBUTES);
		return updateResult.getModifiedCount();
	}

	@Override
	public Collection<Attributes> getAttributesByProviderTaxId(ProviderAttrGetRequest provAttrGetReq) {
		Query query = new Query();
		query.addCriteria(Criteria.where(ProviderAttributesMongoConstants.KEY_PROVIDER_TAX_ID)
				.is(providerAttributesDataEncrypt.encryptProviderTaxId(provAttrGetReq.getProviderTaxId()))
				.and(ProviderAttributesMongoConstants.KEY_CLIENT).is(CLIENT_VALUE));
		query.addCriteria(validateFirstName(provAttrGetReq));
		query.skip(provAttrGetReq.getOffset()).limit(provAttrGetReq.getLimit());
		return fetchAttributes(query);
	}

	@Override
	public Collection<Attributes> getAttributesByProviderId(ProviderAttrGetRequest provAttrGetReq) {
		Query query = new Query();
		query.addCriteria(Criteria.where(ProviderAttributesMongoConstants.KEY_PROVIDER_ID)
				.is(providerAttributesDataEncrypt.encryptProviderId(provAttrGetReq.getProviderId()))
				.and(ProviderAttributesMongoConstants.KEY_CLIENT).is(CLIENT_VALUE));
		query.addCriteria(validateFirstName(provAttrGetReq));
		query.skip(provAttrGetReq.getOffset()).limit(provAttrGetReq.getLimit());
		return fetchAttributes(query);
	}

	@Override
	public Collection<Attributes> getAttributesByProviderIdMultiAddressKeyAndIndicator(ProviderAttrGetRequest provAttrGetReq) {
		Query query = new Query();
		query.addCriteria(Criteria.where(ProviderAttributesMongoConstants.KEY_PROVIDER_ID)
				.is(providerAttributesDataEncrypt.encryptProviderId(provAttrGetReq.getProviderId()))
				.and(ProviderAttributesMongoConstants.KEY_PROVIDER_SUFFIX).is(provAttrGetReq.getProviderMultiAddressKey())
				.and(ProviderAttributesMongoConstants.KEY_PROVIDER_INDICATOR).is(provAttrGetReq.getProviderIndicator())
				.and(ProviderAttributesMongoConstants.KEY_CLIENT).is(CLIENT_VALUE));
		query.addCriteria(validateFirstName(provAttrGetReq));
		query.skip(provAttrGetReq.getOffset()).limit(provAttrGetReq.getLimit());
		return fetchAttributes(query);
	}

	@Override
	public Collection<Attributes> getAttributesByProviderIdAndIndicator(ProviderAttrGetRequest provAttrGetReq) {
		Query query = new Query();
		query.addCriteria(Criteria.where(ProviderAttributesMongoConstants.KEY_PROVIDER_ID)
				.is(providerAttributesDataEncrypt.encryptProviderId(provAttrGetReq.getProviderId()))
				.and(ProviderAttributesMongoConstants.KEY_PROVIDER_INDICATOR).is(provAttrGetReq.getProviderIndicator())
				.and(ProviderAttributesMongoConstants.KEY_CLIENT).is(CLIENT_VALUE));
		query.addCriteria(validateFirstName(provAttrGetReq));
		query.skip(provAttrGetReq.getOffset()).limit(provAttrGetReq.getLimit());
		return fetchAttributes(query);
	}

	@Override
	public String postProviderAttributes(Attributes attributes) {
		attributes.getKey().setClient(CLIENT_VALUE);
		Query query = new Query();
		query.addCriteria(Criteria.where(ProviderAttributesMongoConstants.KEY_PROVIDER_ID)
				.is(providerAttributesDataEncrypt.encryptProviderId(attributes.getKey().getProv()))
				.and(ProviderAttributesMongoConstants.KEY_PROVIDER_SUFFIX).is(attributes.getKey().getMultAddressKey())
				.and(ProviderAttributesMongoConstants.KEY_PROVIDER_INDICATOR).is(attributes.getKey().getPvdInd()));
		Document attriButes = mongoTemplate.findOne(query, Document.class,
				ProviderAttributesMongoConstants.COLLECTION_PROVIDER_ATTRIBUTES);
		if (null != attriButes) {
			return ATTRIBUTES_ALREADY_EXISTS;
		}
		Document doc = new Document();
		mongoTemplate.getConverter().write(attributes, doc);
		doc = providerAttributesDataEncrypt.encryptProviderData(doc);
		mongoTemplate.save(doc, COLLECTION_PROVIDER_ATTRIBUTES);
		return CREATE_ATTRIBUTES_SUCCESS;
	}

	@Override
	public Attributes updateProviderAttributes(Attributes attributes, String providerId, String providerMultiAddressKey,
			String providerIndicator) throws IllegalAccessException {
		attributes.getKey().setClient(CLIENT_VALUE);
		Query query = new Query();
		query.addCriteria(Criteria.where(ProviderAttributesMongoConstants.KEY_PROVIDER_ID)
				.is(providerAttributesDataEncrypt.encryptProviderId(providerId))
				.and(ProviderAttributesMongoConstants.KEY_PROVIDER_SUFFIX).is(providerMultiAddressKey)
				.and(ProviderAttributesMongoConstants.KEY_PROVIDER_INDICATOR).is(providerIndicator));
		Update update = providerAttributesPatchUtil.getMongoUpdateObjForAttributes(attributes);
		Document document = providerAttributesDataEncrypt.encryptProviderData( (Document)update.getUpdateObject().get("$set"));
		update.getUpdateObject().put("$set", document);
		Document providerAttributes = mongoTemplate.findAndModify(query, update, new FindAndModifyOptions().returnNew(true).upsert(false),
				Document.class,COLLECTION_PROVIDER_ATTRIBUTES);
		if (providerAttributes == null) {
			return null;
		}
		providerAttributes = providerAttributesDataEncrypt.decryptProviderData(providerAttributes);
		return mongoTemplate.getConverter().read(Attributes.class, providerAttributes);	
	}
	
	private Document mapAttributesFromMQDataProv1(Attributes providerAttributesForUpdate,
			Attributes providerAttributesFromDb) {
		Document doc = new Document();
		providerAttributesFromDb.setIrsNo(providerAttributesForUpdate.getIrsNo());
		providerAttributesFromDb.setVch(providerAttributesForUpdate.getVch());
		providerAttributesFromDb.setTaxType(providerAttributesForUpdate.getTaxType());
		providerAttributesFromDb.setSend1099Ind(providerAttributesForUpdate.getSend1099Ind());
		providerAttributesFromDb.setPendEsc(providerAttributesForUpdate.getPendEsc());
		providerAttributesFromDb.setAutoCheckPullInd(providerAttributesForUpdate.getAutoCheckPullInd());
		providerAttributesFromDb.setIrsWithholdInd(providerAttributesForUpdate.getIrsWithholdInd());
		providerAttributesFromDb.setPayCycle(providerAttributesForUpdate.getPayCycle());
		providerAttributesFromDb.setCrossRef(providerAttributesForUpdate.getCrossRef());
		providerAttributesFromDb.setMarketId(providerAttributesForUpdate.getMarketId());
		providerAttributesFromDb.setDg(providerAttributesForUpdate.getDg());
		providerAttributesFromDb.setAlphaKey(providerAttributesForUpdate.getAlphaKey());
		providerAttributesFromDb.setCasName(providerAttributesForUpdate.getCasName());
		providerAttributesFromDb.setMedSuppWaiveInd(providerAttributesForUpdate.getMedSuppWaiveInd());
		providerAttributesFromDb.setComment1(providerAttributesForUpdate.getComment1());
		providerAttributesFromDb.setNotifyInd(providerAttributesForUpdate.getNotifyInd());
		providerAttributesFromDb.setFocusFromDate(providerAttributesForUpdate.getFocusFromDate());
		providerAttributesFromDb.setClpthInd(providerAttributesForUpdate.getClpthInd());
		providerAttributesFromDb.setClmChkInd(providerAttributesForUpdate.getClmChkInd());
		providerAttributesFromDb.setUcZip(providerAttributesForUpdate.getUcZip());
		providerAttributesFromDb.setFocusToDate(providerAttributesForUpdate.getFocusToDate());
		providerAttributesFromDb.setAutoLoadInd(providerAttributesForUpdate.getAutoLoadInd());
		providerAttributesFromDb.setCheckTo(providerAttributesForUpdate.getCheckTo());
		providerAttributesFromDb.setSuffixTo(providerAttributesForUpdate.getSuffixTo());
		mongoTemplate.getConverter().write(providerAttributesFromDb, doc);
		return doc;
	}

	private Document mapAttributesFromMQDataProv2(Attributes providerAttributesForUpdate,
			Attributes providerAttributesFromDb) {
		Document doc = new Document();
		providerAttributesFromDb.setApplyTaxInd(providerAttributesForUpdate.getApplyTaxInd());
		providerAttributesFromDb.setW9Ind(providerAttributesForUpdate.getW9Ind());
		providerAttributesFromDb.setSend480Ind(providerAttributesForUpdate.getSend480Ind());
		providerAttributesFromDb.setComment2(providerAttributesForUpdate.getComment2());
		providerAttributesFromDb.setComment3(providerAttributesForUpdate.getComment3());
		providerAttributesFromDb.setVendorId(providerAttributesForUpdate.getVendorId());
		providerAttributesFromDb.setUpdtAdjNo(providerAttributesForUpdate.getUpdtAdjNo());
		providerAttributesFromDb.setUpdtDt((providerAttributesForUpdate.getUpdtDt()));
		providerAttributesFromDb.setRadSiteCurrInd(providerAttributesForUpdate.getRadSiteCurrInd());
		providerAttributesFromDb.setRadSiteCurrDt(providerAttributesForUpdate.getRadSiteCurrDt());
		providerAttributesFromDb.setRadSiteP1Ind(providerAttributesForUpdate.getRadSiteP1Ind());
		providerAttributesFromDb.setRadSiteP1Dt(providerAttributesForUpdate.getRadSiteP1Dt());
		providerAttributesFromDb.setRadSiteP2Ind(providerAttributesForUpdate.getRadSiteP2Ind());
		providerAttributesFromDb.setRadSiteP2Dt(providerAttributesForUpdate.getRadSiteP2Dt());
		providerAttributesFromDb.setRadScopeCurrInd(providerAttributesForUpdate.getRadScopeCurrInd());
		providerAttributesFromDb.setRadScopeCurrDt(providerAttributesForUpdate.getRadScopeCurrDt());
		providerAttributesFromDb.setRadScopeP1Ind(providerAttributesForUpdate.getRadScopeP1Ind());
		providerAttributesFromDb.setRadScopeP1Dt(providerAttributesForUpdate.getRadScopeP1Dt());
		providerAttributesFromDb.setFacUcZip(providerAttributesForUpdate.getFacUcZip());
		providerAttributesFromDb.setPxiUpdtAdjNo(providerAttributesForUpdate.getPxiUpdtAdjNo());
		providerAttributesFromDb.setPxiUpdtDt(providerAttributesForUpdate.getPxiUpdtDt());
		providerAttributesFromDb.setClmChkInd(providerAttributesForUpdate.getClmChkInd());
		providerAttributesFromDb.setSendLtrInd(providerAttributesForUpdate.getSendLtrInd());
		providerAttributesFromDb.setFinalstInd(providerAttributesForUpdate.getFinalstInd());
		providerAttributesFromDb.setCompbidInd(providerAttributesForUpdate.getCompbidInd());
		providerAttributesFromDb.setCompbidEffDt(providerAttributesForUpdate.getCompbidEffDt());
		providerAttributesFromDb.setCompbidTrmDt(providerAttributesForUpdate.getCompbidTrmDt());
		providerAttributesFromDb.setContractPointEnable(providerAttributesForUpdate.getContractPointEnable());
		providerAttributesFromDb.setPxiZip(providerAttributesForUpdate.getPxiZip());
		providerAttributesFromDb.setFacUcZip(providerAttributesForUpdate.getFacUcZip());
		mongoTemplate.getConverter().write(providerAttributesFromDb, doc);
		return doc;
	}
	
	private Document mapAttributesFromMQDataProv3(Attributes providerAttributesForUpdate,
			Attributes providerAttributesFromDb) {
		Document doc = new Document();
		providerAttributesFromDb.setWithholdData(providerAttributesForUpdate.getWithholdData());
		mongoTemplate.getConverter().write(providerAttributesFromDb, doc);
		return doc;
	}
	
	@Override
	public void updateProviderAttributesProv2(Attributes providerAttributesFromQueue)
			throws ProviderAttributesNotFoundException {
		Query query = new Query();
		query.addCriteria(buildProviderCriteria(providerAttributesFromQueue));
		Document attributesFromDb = mongoTemplate.findOne(query, Document.class,
				ProviderAttributesMongoConstants.COLLECTION_PROVIDER_ATTRIBUTES);
		if (null != attributesFromDb) {
			attributesFromDb = providerAttributesDataEncrypt.decryptProviderData(attributesFromDb);
			Attributes attributes = mongoTemplate.getConverter().read(Attributes.class, attributesFromDb);
			updateProviderAttributes(mapAttributesFromMQDataProv2(providerAttributesFromQueue, attributes),
					query);
			log.debug(ProviderAttributesMongoConstants.COLLECTION_PROVIDER_ATTRIBUTES);
		} else {
			log.debug(ProviderAttributesConstants.PROVIDER_ATTRIBUTES_NOT_FOUND);
			throw new ProviderAttributesNotFoundException();
		}

	}

	@Override
	public void updateProviderAttributesProv3(Attributes providerAttributesFromQueue)
			throws ProviderAttributesNotFoundException {
		Query query = new Query();
		query.addCriteria(buildProviderCriteria(providerAttributesFromQueue));
		Document attributesFromDb = mongoTemplate.findOne(query, Document.class,
				ProviderAttributesMongoConstants.COLLECTION_PROVIDER_ATTRIBUTES);
		if (null != attributesFromDb) {
			attributesFromDb = providerAttributesDataEncrypt.decryptProviderData(attributesFromDb);
			Attributes attributes = mongoTemplate.getConverter().read(Attributes.class, attributesFromDb);
			updateProviderAttributes(mapAttributesFromMQDataProv3(providerAttributesFromQueue, attributes),
					query);
			log.debug(ProviderAttributesMongoConstants.COLLECTION_PROVIDER_ATTRIBUTES);
		} else {
			log.debug(ProviderAttributesConstants.PROVIDER_ATTRIBUTES_NOT_FOUND);
			throw new ProviderAttributesNotFoundException();
		}

	}

	@Override
	public String getAttributesTotalDocumentsByProviderIdMultiAddressKeyAndIndicator(ProviderAttrGetRequest provAttrGetReq) {
		Query query = new Query();
		query.addCriteria(Criteria.where(ProviderAttributesMongoConstants.KEY_PROVIDER_ID)
				.is(providerAttributesDataEncrypt.encryptProviderId(provAttrGetReq.getProviderId()))
				.and(ProviderAttributesMongoConstants.KEY_PROVIDER_INDICATOR).is(provAttrGetReq.getProviderIndicator())
				.and(ProviderAttributesMongoConstants.KEY_PROVIDER_SUFFIX).is(provAttrGetReq.getProviderMultiAddressKey())
				.and(ProviderAttributesMongoConstants.KEY_CLIENT).is(CLIENT_VALUE));
		query.addCriteria(validateFirstName(provAttrGetReq));
		query.skip(0).limit(0);
		long totDocs = mongoTemplate.count(query, Attributes.class,
				ProviderAttributesMongoConstants.COLLECTION_PROVIDER_ATTRIBUTES);
		return Integer.toString(Math.toIntExact(totDocs));
	}

	@Override
	public String getAttributesTotalDocumentsByProviderIdTaxId(ProviderAttrGetRequest provAttrGetReq) {
		Query query = new Query();
		query.addCriteria(Criteria.where(ProviderAttributesMongoConstants.KEY_PROVIDER_TAX_ID)
				.is(providerAttributesDataEncrypt.encryptProviderTaxId(provAttrGetReq.getProviderTaxId()))
				.and(ProviderAttributesMongoConstants.KEY_CLIENT).is(CLIENT_VALUE));		
		query.addCriteria(validateFirstName(provAttrGetReq));
		query.skip(0).limit(0);
		long totDocs = mongoTemplate.count(query, Attributes.class,
				ProviderAttributesMongoConstants.COLLECTION_PROVIDER_ATTRIBUTES);
		return Integer.toString(Math.toIntExact(totDocs));
	}

	@Override
	public String getAttributesTotalDocumentsByProviderId(ProviderAttrGetRequest provAttrGetReq) {
		Query query = new Query();
		query.addCriteria(Criteria.where(ProviderAttributesMongoConstants.KEY_PROVIDER_ID)
				.is(providerAttributesDataEncrypt.encryptProviderId(provAttrGetReq.getProviderId()))
				.and(ProviderAttributesMongoConstants.KEY_CLIENT).is(CLIENT_VALUE));
		query.addCriteria(validateFirstName(provAttrGetReq));
		query.skip(0).limit(0);
		long totDocs = mongoTemplate.count(query, Attributes.class,
				ProviderAttributesMongoConstants.COLLECTION_PROVIDER_ATTRIBUTES);
		return Integer.toString(Math.toIntExact(totDocs));
	}

	@Override
	public String getAttributesTotalDocumentsByProviderIdAndIndicator(ProviderAttrGetRequest provAttrGetReq) {
		Query query = new Query();
		query.addCriteria(Criteria.where(ProviderAttributesMongoConstants.KEY_PROVIDER_ID)
				.is(providerAttributesDataEncrypt.encryptProviderId(provAttrGetReq.getProviderId()))
				.and(ProviderAttributesMongoConstants.KEY_PROVIDER_INDICATOR).is(provAttrGetReq.getProviderIndicator())
				.and(ProviderAttributesMongoConstants.KEY_CLIENT).is(CLIENT_VALUE));
		query.addCriteria(validateFirstName(provAttrGetReq));
		query.skip(0).limit(0);
		long totDocs = mongoTemplate.count(query, Attributes.class,
				ProviderAttributesMongoConstants.COLLECTION_PROVIDER_ATTRIBUTES);
		return Integer.toString(Math.toIntExact(totDocs));
	}
	
	private Criteria validateFirstName(ProviderAttrGetRequest provAttrGetReq) {
		Criteria criteria = new Criteria();
		if(StringUtils.isNotBlank(provAttrGetReq.getFirstName())) {
			criteria = Criteria.where(ProviderAttributesMongoConstants.FIRST_NAME).regex(provAttrGetReq.getFirstName());
		}
		return criteria;
	}
	
	private Collection<Attributes> fetchAttributes(Query query){
		List<Document> doc = mongoTemplate.find(query, Document.class,
				ProviderAttributesMongoConstants.COLLECTION_PROVIDER_ATTRIBUTES);
		List<Attributes> attributesList = new ArrayList<>();
		for (Document attibuteDoc : doc) {
			attibuteDoc = providerAttributesDataEncrypt.decryptProviderData(attibuteDoc);
			Attributes attributes = mongoTemplate.getConverter().read(Attributes.class, attibuteDoc);
			attributesList.add(attributes);
		}
		return attributesList;
	}

	@Override
	public List<Attributes> getAttributesByKey(List<RequestKey> attributeKeyList) {
		Query query = new Query();
		Criteria criteria = Criteria.where(ProviderAttributesMongoConstants.KEY)
				.in(encryptProviderId(attributeKeyList));
		query.addCriteria(criteria);
		return (List<Attributes>) fetchAttributes(query);
	}
	
	private List<RequestKey> encryptProviderId(List<RequestKey> keyRequestList) {
		keyRequestList.forEach(e->e.setProv(providerAttributesDataEncrypt.encryptProviderId((String)e.getProv())));
		return keyRequestList;
	}
	
	
}
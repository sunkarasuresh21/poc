package com.humana.claims.hcaas.provider.attributes.core.model.db;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;


@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class Attributes {

	@JsonProperty("KEY")
	private AttributesKey key;

	@JsonProperty("IRS-NO")
	private String irsNo;

	@JsonProperty("VCH")
	private String vch;

	@JsonProperty("TAX-TYPE")
	private String taxType;

	@JsonProperty("SEND-1099-IND")
	private String send1099Ind;

	@JsonProperty("PEND-ESC")
	private String pendEsc;

	@JsonProperty("AUTO-CHECK-PULL-IND")
	private String autoCheckPullInd;

	@JsonProperty("IRS-WITHHOLD-IND")
	private String irsWithholdInd;

	@JsonProperty("PAY-CYCLE")
	private String payCycle;

	@JsonProperty("CROSS-REF")
	private String crossRef;

	@JsonProperty("MARKET-ID")
	private String marketId;

	@JsonProperty("DG")
	private String dg;

	@JsonProperty("ALPHA-KEY")
	private String alphaKey;

	@JsonProperty("PROV-CAS-NAME-GFLD")
	private CasName casName;

	@JsonProperty("MED-SUPP-WAIVE-IND")
	private String medSuppWaiveInd;

	@JsonProperty("COMMENT")
	private String comment1;

	@JsonProperty("NOTIFY-IND")
	private String notifyInd;

	@JsonProperty("FOCUS-FROM-DATE")
	private LocalDate focusFromDate;

	@JsonProperty("CLPTH-IND")
	private String clpthInd;

	@JsonProperty("CLM-CHK-IND")
	private String clmChkInd;

	@JsonProperty("UC-ZIP")
	private String ucZip;

	@JsonProperty("FOCUS-TO-DATE")
	private LocalDate focusToDate;

	@JsonProperty("AUTO-LOAD-IND")
	private String autoLoadInd;

	@JsonProperty("CHECK-TO")
	private String checkTo;

	@JsonProperty("SUFFIX-TO")
	private String suffixTo;

	@JsonProperty("APPLY-TAX-IND")
	private String applyTaxInd;

	@JsonProperty("W9-IND")
	private String w9Ind;

	@JsonProperty("SEND-480-IND")
	private String send480Ind;

	@JsonProperty("WITHHOLD-DATA")
	private WithholdData withholdData;
	
	@JsonProperty("COMMENTS")
	private String comment2;

	@JsonProperty("UPDT-ADJ-NO")
	private String updtAdjNo;

	@JsonProperty("UPDT-DT")
	private LocalDate updtDt;

	@JsonProperty("RAD-SITE-CURR-IND")
	private String radSiteCurrInd;

	@JsonProperty("RAD-SITE-CURR-DT")
	private LocalDate radSiteCurrDt;

	@JsonProperty("RAD-SITE-P1-IND")
	private String radSiteP1Ind;

	@JsonProperty("RAD-SITE-P1-DT")
	private LocalDate radSiteP1Dt;

	@JsonProperty("RAD-SITE-P2-IND")
	private String radSiteP2Ind;

	@JsonProperty("RAD-SITE-P2-DT")
	private LocalDate radSiteP2Dt;

	@JsonProperty("RAD-SCOPE-CURR-IND")
	private String radScopeCurrInd;

	@JsonProperty("RAD-SCOPE-CURR-DT")
	private LocalDate radScopeCurrDt;

	@JsonProperty("RAD-SCOPE-P1-IND")
	private String radScopeP1Ind;

	@JsonProperty("RAD-SCOPE-P1-DT")
	private LocalDate radScopeP1Dt;

	@JsonProperty("FAC-UC-ZIP")
	private String facUcZip;

	@JsonProperty("PXI-UPDT-ADJ-NO")
	private String pxiUpdtAdjNo;

	@JsonProperty("PXI-UPDT-DT")
	private LocalDate pxiUpdtDt;

	@JsonProperty("SEND-LTR-IND")
	private String sendLtrInd;

	@JsonProperty("FINALST-IND")
	private String finalstInd;

	@JsonProperty("PXI-ZIP")
	private List<PxiZip> pxiZip = new ArrayList<>();

	@JsonProperty("COMPBID-IND")
	private String compbidInd;

	@JsonProperty("PROV-VENDOR-ID")
	private String vendorId;

	@JsonProperty("COMPBID-EFF-DT")
	private LocalDate compbidEffDt;

	@JsonProperty("COMPBID-TRM-DT")
	private LocalDate compbidTrmDt;

	@JsonProperty("PXI-PTS-LOB-AREA")
	private Map<String, Boolean> contractPointEnable = new HashMap<>();
	
	private String comment3;

}

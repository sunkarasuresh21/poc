package com.humana.claims.hcaas.provider.attributes.core.util;

import java.lang.reflect.Field;
import java.time.LocalDate;
import java.util.Collection;

import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.attributes.core.model.db.CasName;
import com.humana.claims.hcaas.provider.attributes.core.model.db.AttributesKey;
import com.humana.claims.hcaas.provider.attributes.core.model.db.WithholdData;
import com.humana.claims.hcaas.provider.attributes.core.model.db.WthldCurrent;
import com.humana.claims.hcaas.provider.attributes.core.model.db.WthldPrior;

@Component
public class ProviderAttributesPatchUtil {

	public Update getMongoUpdateObjForAttributes(Attributes attributes) throws IllegalAccessException {
		attributes.setUpdtDt(LocalDate.now());
		Update update = new Update();

		for (Field field : Attributes.class.getDeclaredFields()) {
			field.setAccessible(true);

			if (!field.isSynthetic()) {
				if (field.get(attributes) != null && !isSpecialFieldType(field)) {
					update.set(field.getName(), field.get(attributes));
				}

				getMongoUpdateObjForAttributesFieldsOfTypeList(update, field, attributes);

				getMongoUpdateObjForCasName(update, field, attributes);

				getMongoUpdateObjForWithholdData(update, field, attributes);
			}
		}

		return update;
	}

	private boolean isSpecialFieldType(Field field) {
		return (Collection.class.isAssignableFrom(field.getType()) || field.getType() == CasName.class
				|| field.getType() == WithholdData.class || field.getType() == AttributesKey.class);
	}

	@SuppressWarnings("rawtypes")
	private Update getMongoUpdateObjForAttributesFieldsOfTypeList(Update update, Field field, Attributes attributes)
			throws IllegalAccessException {
		if (Collection.class.isAssignableFrom(field.getType()) && !((Collection) field.get(attributes)).isEmpty()) {
			update.set(field.getName(), field.get(attributes));
		}

		return update;
	}

	private Update getMongoUpdateObjForCasName(Update update, Field field, Attributes attributes)
			throws IllegalAccessException {
		if (field.getType() == CasName.class) {
			CasName casName = attributes.getCasName();
			for (Field casNameField : CasName.class.getDeclaredFields()) {
				casNameField.setAccessible(true);
				if (!casNameField.isSynthetic() && casNameField.get(casName) != null) {
					update.set("casName." + casNameField.getName(), casNameField.get(casName));
				}

			}
		}
		return update;
	}

	private Update getMongoUpdateObjForWithholdData(Update update, Field field, Attributes attributes)
			throws IllegalAccessException {
		if (field.getType() == WithholdData.class) {
			for (Field withholdDataField : WithholdData.class.getDeclaredFields()) {
				withholdDataField.setAccessible(true);
				if (!withholdDataField.isSynthetic()) {
					getMongoUpdateObj(withholdDataField, update, attributes);
				}
			}
		}
		return update;
	}

	private Update getMongoUpdateObj(Field withholdDataField, Update update, Attributes attributes) throws IllegalAccessException  {
		if (withholdDataField.get(attributes.getWithholdData()) != null && withholdDataField.getType() != WthldCurrent.class
				&& withholdDataField.getType() != WthldPrior.class) {
			update.set("withholdData." + withholdDataField.getName(), withholdDataField.get(attributes.getWithholdData()));
		}
		getMongoUpdateObjForWthldCurrent(update, withholdDataField, attributes);
		getMongoUpdateObjForWthldPrior(update, withholdDataField, attributes);
		return update;
	}

	private Update getMongoUpdateObjForWthldCurrent(Update update, Field withholdDataField, Attributes attributes)
			throws IllegalAccessException {
		if (withholdDataField.getType() == WthldCurrent.class) {
			WthldCurrent wthldCurrent = attributes.getWithholdData().getWthldCurrent();
			for (Field wthldCurrentField : WthldCurrent.class.getDeclaredFields()) {
				wthldCurrentField.setAccessible(true);
				if (!wthldCurrentField.isSynthetic() && wthldCurrentField.get(wthldCurrent) != null) {
					update.set("withholdData.wthldCurrent." + wthldCurrentField.getName(),
							wthldCurrentField.get(wthldCurrent));
				}
			}
		}
		return update;
	}

	private Update getMongoUpdateObjForWthldPrior(Update update, Field withholdDataField, Attributes attributes)
			throws IllegalAccessException {
		if (withholdDataField.getType() == WthldPrior.class) {
			WthldPrior wthldPrior = attributes.getWithholdData().getWthldPrior();
			for (Field wthldPriorField : WthldPrior.class.getDeclaredFields()) {
				wthldPriorField.setAccessible(true);
				if (!wthldPriorField.isSynthetic() && wthldPriorField.get(wthldPrior) != null) {
					update.set("withholdData.wthldPrior." + wthldPriorField.getName(), wthldPriorField.get(wthldPrior));

				}
			}
		}
		return update;
	}

}
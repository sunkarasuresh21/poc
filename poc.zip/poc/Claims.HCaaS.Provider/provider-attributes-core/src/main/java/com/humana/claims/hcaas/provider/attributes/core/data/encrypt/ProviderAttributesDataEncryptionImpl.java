package com.humana.claims.hcaas.provider.attributes.core.data.encrypt;

import static com.humana.claims.hcaas.provider.attributes.core.constants.ProviderAttributesConstants.DETERMINISTIC_ENCRYPTION_TYPE;

import java.util.Map.Entry;

import org.bson.BsonBinary;
import org.bson.Document;
import org.bson.types.Binary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.humana.claims.hcaas.common.spring.boot.starter.mongodb.MongoDBFieldEncryptor;

@Component
public class ProviderAttributesDataEncryptionImpl implements ProviderAttributesDataEncryption {

	@Autowired
	private MongoDBFieldEncryptor dbFieldEncryptor;

	public Document encryptProviderData(Document doc) {
		for (Entry<String, Object> key : doc.entrySet()) {
			if ((key.getKey()).equalsIgnoreCase("key")) {
				Document innerDocument = (Document) doc.get(key.getKey());
				encryptInnerDocumentData(innerDocument);
			}
			if ((key.getKey()).equalsIgnoreCase("irsNo")) {
				encryptData(doc, key.getKey());
			}
		}
		return doc;
	}

	private void encryptInnerDocumentData(Document innerDocument) {
		for (String prov : innerDocument.keySet()) {
			if (prov.equalsIgnoreCase("prov")) {
				encryptData(innerDocument, prov);
			}
		}
	}

	private BsonBinary encryptData(Document doc, String key) {
		return (BsonBinary) doc.computeIfPresent(key, (ky, value) -> 
		(BsonBinary) dbFieldEncryptor.encrypt((String) value, DETERMINISTIC_ENCRYPTION_TYPE));
	}

	public Document decryptProviderData(Document doc) {

		for (Entry<String, Object> key : doc.entrySet()) {
			if ((key.getKey()).equalsIgnoreCase("key")) {
				Document innerDocument = (Document) doc.get(key.getKey());
				decryptInnerDocumentData(innerDocument);
			}	
			if ((key.getKey()).equalsIgnoreCase("irsNo")) {
				decryptData(doc, key.getKey());
			}
		}
		return doc;
	}

	private void decryptInnerDocumentData(Document innerDocument) {
		for (String prov : innerDocument.keySet()) {
			if (prov.equalsIgnoreCase("prov")) {
				decryptData(innerDocument, prov);
			}
		}
	}

	private String decryptData(Document doc, String key) {
		doc.computeIfPresent(key, (ky, value) -> {
			Binary binVal = (Binary) value;
			return (String) dbFieldEncryptor.decrypt(new BsonBinary(binVal.getData()), DETERMINISTIC_ENCRYPTION_TYPE);
		});
		return null;
	}

	public BsonBinary encryptProviderId(String provId) {
		return dbFieldEncryptor.encrypt(provId, DETERMINISTIC_ENCRYPTION_TYPE);
	}

	public BsonBinary encryptProviderTaxId(String irsNo) {
		return dbFieldEncryptor.encrypt(irsNo, DETERMINISTIC_ENCRYPTION_TYPE);
	}
}

package com.humana.claims.hcaas.provider.attributes.core.model.db;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class WthldCurrent {

    @JsonProperty("WTHLD-PER-CURRENT")
    private String wthldPerCurrent;

    @JsonProperty("WTHLD-EFF-DATE-CURRENT")
    private LocalDate wthldEffDateCurrent;

}

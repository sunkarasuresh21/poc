package com.humana.claims.hcaas.provider.attributes.core.model.db;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class PxiZip {

    @JsonProperty("PXI-ZIP")
    private String pxiZipCode;

    
    @JsonProperty("PXI-ZIP-IND")
    private String pxiZipInd;

}

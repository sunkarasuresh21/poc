package com.humana.claims.hcaas.provider.attributes.core.model.db;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class CasName {

    @JsonProperty("CAS-FST-NAME")
    private String fstName;

    @JsonProperty("CAS-LAST-NAME")
    private String lastName;

}

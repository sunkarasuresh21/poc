package com.humana.claims.hcaas.provider.attributes.core.constants;

public class ProviderAttributesConstants {

	private ProviderAttributesConstants() {}
	
	public static final String SUCCESS = "Success";

	public static final String NOT_FOUND = "Provider not found for update";

	public static final String PROVIDER_ATTRIBUTES_NOT_FOUND = "Provider Attributes Data Not Found will retry later - ";
	
	public static final String TOTAL_DOCS = "Total-Documents";
	
	public static final String DETERMINISTIC_ENCRYPTION_TYPE = "AEAD_AES_256_CBC_HMAC_SHA_512-Deterministic";
	
}


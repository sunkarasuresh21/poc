package com.humana.claims.hcaas.provider.attributes.core.dao;

import java.util.Collection;
import java.util.List;

import com.humana.claims.hcaas.provider.attributes.core.exception.ProviderAttributesNotFoundException;
import com.humana.claims.hcaas.provider.attributes.core.mapper.ProviderAttrGetRequest;
import com.humana.claims.hcaas.provider.attributes.core.model.RequestKey;
import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;

public interface ProviderAttributesDAO {

	void upsertProviderAttributesProv1(Attributes providerAttributes);

	void updateProviderAttributesProv2(Attributes providerAttributes) throws ProviderAttributesNotFoundException;

	void updateProviderAttributesProv3(Attributes providerAttributes) throws ProviderAttributesNotFoundException;

	Collection<Attributes> getAttributesByProviderTaxId(ProviderAttrGetRequest provAttrGetReq);

	Collection<Attributes> getAttributesByProviderId(ProviderAttrGetRequest provAttrGetReq);
	
	Collection<Attributes> getAttributesByProviderIdAndIndicator(ProviderAttrGetRequest provAttrGetReq);

	Collection<Attributes> getAttributesByProviderIdMultiAddressKeyAndIndicator(ProviderAttrGetRequest provAttrGetReq);

	String postProviderAttributes(Attributes attributes);

	
	Attributes updateProviderAttributes(Attributes attributes, String providerId, String providerMultiAddressKey, 
			String providerIndicator) throws IllegalAccessException;

	String getAttributesTotalDocumentsByProviderIdMultiAddressKeyAndIndicator(ProviderAttrGetRequest provAttrGetReq);

	String getAttributesTotalDocumentsByProviderIdTaxId(ProviderAttrGetRequest provAttrGetReq);

	String getAttributesTotalDocumentsByProviderId(ProviderAttrGetRequest provAttrGetReq);

	String getAttributesTotalDocumentsByProviderIdAndIndicator(ProviderAttrGetRequest provAttrGetReq);
	
	List<Attributes> getAttributesByKey(List<RequestKey> keyRequestList);

}

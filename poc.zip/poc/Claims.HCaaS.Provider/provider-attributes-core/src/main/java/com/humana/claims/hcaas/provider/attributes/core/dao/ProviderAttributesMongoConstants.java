package com.humana.claims.hcaas.provider.attributes.core.dao;

public class ProviderAttributesMongoConstants {

	private ProviderAttributesMongoConstants() {}
	
	public static final String COLLECTION_PROVIDER_ATTRIBUTES = "ProviderAttributes"; 
	
	public static final String CREATE_ATTRIBUTES_SUCCESS = "Attributes data added successfully";
	
	public static final String ATTRIBUTES_ALREADY_EXISTS = "Attributes already exists";

	public static final String KEY = "key";
	
	public static final String KEY_PROVIDER_TAX_ID = "irsNo";

	public static final String KEY_PROVIDER_ID = "key.prov";
	
	public static final String KEY_CLIENT = "key.client";

	public static final String KEY_PROVIDER_SUFFIX = "key.multAddressKey";
	
	public static final String KEY_PROVIDER_INDICATOR = "key.pvdInd";
	
	public static final String FIRST_NAME = "alphaKey";

}
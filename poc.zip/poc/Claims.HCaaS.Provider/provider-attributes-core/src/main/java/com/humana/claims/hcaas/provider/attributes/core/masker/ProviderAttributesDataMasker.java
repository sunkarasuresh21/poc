package com.humana.claims.hcaas.provider.attributes.core.masker;

import static com.humana.claims.hcaas.common.utils.datamasking.JsonMaskerConfiguration.jsonMaskerConfig;
import static com.humana.claims.hcaas.common.utils.datamasking.StringMasker.stringMasker;

import java.util.function.Supplier;

import org.springframework.stereotype.Component;

import com.humana.claims.hcaas.common.utils.datamasking.JsonMasker;
import com.humana.claims.hcaas.common.utils.datamasking.StringMasker;

@Component
public class ProviderAttributesDataMasker {
	
	private final StringMasker providerIdMasker = StringMasker.stringMasker(2, 2);
	
	private final StringMasker irsNoMasker = StringMasker.stringMasker(2, 2);
	
	private final JsonMasker prov1JsonDataMasker = new JsonMasker(jsonMaskerConfig(stringMasker(2,2), "PRV-PROV"), 
			jsonMaskerConfig(stringMasker(2,2), "PRV-IRS-NO"), 
			jsonMaskerConfig(stringMasker(0,0), "PRV-PROV-NAME"), 
			jsonMaskerConfig(stringMasker(0,0), "PRV-ADDR-1"), 
			jsonMaskerConfig(stringMasker(0,0), "PRV-ADDR-2"), 
			jsonMaskerConfig(stringMasker(0,0), "PRV-ADDR-3"), 
			jsonMaskerConfig(stringMasker(0,0), "PRV-ADDR-4"));
	
	private final JsonMasker prov2JsonDataMasker = new JsonMasker(jsonMaskerConfig(stringMasker(2,2), "PRV2-PROV"), 
			jsonMaskerConfig(stringMasker(2,2), "PRV2-NPI"), 
			jsonMaskerConfig(stringMasker(2,2), "PRV2-NPI-2"), 
			jsonMaskerConfig(stringMasker(2,2), "PRV2-NPI-3"),
			jsonMaskerConfig(stringMasker(2,2), "PRV2-NPI-4"),
			jsonMaskerConfig(stringMasker(2,2), "PRV2-NPI-5"),
			jsonMaskerConfig(stringMasker(2,2), "PRV2-NPI-6"),
			jsonMaskerConfig(stringMasker(2,2), "PRV2-NPI-7"),
			jsonMaskerConfig(stringMasker(2,2), "PRV2-NPI-8"),
			jsonMaskerConfig(stringMasker(2,2), "PRV2-NPI-9"));
	
	private final JsonMasker prov3JsonDataMasker = new JsonMasker(jsonMaskerConfig(stringMasker(2,2), "PRV3-PROV"));
	
	public Supplier<String> maskProviderId(String providerId) {
		return providerIdMasker.maskSupplier(providerId);
	}
	
	public Supplier<String> maskIrsNo(String irsNo) {
		return irsNoMasker.maskSupplier(irsNo);
	}
	
	public JsonMasker getProv1JsonDataMasker() {
		return prov1JsonDataMasker;
	}
	
	public JsonMasker getProv2JsonDataMasker() {
		return prov2JsonDataMasker;
	}
	
	public JsonMasker getProv3JsonDataMasker() {
		return prov3JsonDataMasker;
	}

}

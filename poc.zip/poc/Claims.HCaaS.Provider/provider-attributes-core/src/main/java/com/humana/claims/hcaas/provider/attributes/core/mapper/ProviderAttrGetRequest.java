package com.humana.claims.hcaas.provider.attributes.core.mapper;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Getter
@Setter
@ToString
public class ProviderAttrGetRequest {
	private String providerId;
	private String providerIndicator;
	private String providerMultiAddressKey;
	private String providerTaxId;
	private String firstName;
	private Integer limit;
	private Integer offset; 	
	private Boolean includeCount;
}


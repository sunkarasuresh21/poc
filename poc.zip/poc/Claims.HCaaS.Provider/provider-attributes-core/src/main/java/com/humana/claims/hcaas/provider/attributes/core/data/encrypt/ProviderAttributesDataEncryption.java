package com.humana.claims.hcaas.provider.attributes.core.data.encrypt;

import org.bson.Document;

public interface ProviderAttributesDataEncryption {
	 Document encryptProviderData(Document  doc);
	 
	 Document decryptProviderData(Document doc);
	 
	 Object encryptProviderId(String provId);
	 
	 Object encryptProviderTaxId(String irsNo);
}

package com.humana.claims.hcaas.provider.attributes.core.dao;

import org.bson.Document;

import com.humana.claims.hcaas.provider.attributes.core.data.encrypt.ProviderAttributesDataEncryption;

public class ProviderAttributesDataEncryptionTestImpl implements ProviderAttributesDataEncryption{
	
	public  Document encryptProviderData(Document  doc) {
		return doc;
	}
	
	public Document decryptProviderData(Document doc) {
		return doc;
	}
	
	public String encryptProviderTaxId(String irsNo) {
		return irsNo;
	}
	
	public String encryptProviderId(String providerId) {
		return providerId;
	}

}

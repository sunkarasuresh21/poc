package com.humana.claims.hcaas.provider.attributes.core.masker;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

import java.util.function.Supplier;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.humana.claims.hcaas.common.utils.datamasking.JsonMasker;
import com.humana.claims.hcaas.common.utils.datamasking.StringMasker;

public class ProviderAttributesDataMaskerTest {
	
	private ProviderAttributesDataMasker classUnderTest;
	
	StringMasker mockStringMasker;

	JsonMasker mockJsonMasker;
	
	@BeforeEach
	public void setup() {
		mockStringMasker = mock(StringMasker.class);
		mockJsonMasker = mock(JsonMasker.class);
		classUnderTest = new ProviderAttributesDataMasker();
	}
	
	@Test
	public void maskProviderIdTest() {
		String providerId = "123456789";
		
		Supplier<String> maskProviderId = classUnderTest.maskProviderId(providerId);
		
		assertEquals("12***89", maskProviderId.get());
	}
	
	@Test
	public void maskIrsNoTest() {
		String irsNo = "123456789";
		
		Supplier<String> maskIrsNo = classUnderTest.maskIrsNo(irsNo);
		
		assertEquals("12***89", maskIrsNo.get());
	}

	@Test
	public void testProv1JsonDataMasker(){
		
		JsonMasker actual = classUnderTest.getProv1JsonDataMasker();
		
		assertThat(actual).isInstanceOf(JsonMasker.class);
	}
	
	@Test
	public void testProv2JsonDataMasker(){
		
		JsonMasker actual = classUnderTest.getProv2JsonDataMasker();
		
		assertThat(actual).isInstanceOf(JsonMasker.class);
	}
	
	@Test
	public void testProv3JsonDataMasker(){
		
		JsonMasker actual = classUnderTest.getProv3JsonDataMasker();
		
		assertThat(actual).isInstanceOf(JsonMasker.class);
	}

}

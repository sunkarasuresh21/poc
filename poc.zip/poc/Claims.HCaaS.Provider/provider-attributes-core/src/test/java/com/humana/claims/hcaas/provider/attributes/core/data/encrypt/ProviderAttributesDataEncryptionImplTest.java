package com.humana.claims.hcaas.provider.attributes.core.data.encrypt;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.bson.BsonBinary;
import org.bson.Document;
import org.bson.types.Binary;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.humana.claims.hcaas.common.spring.boot.starter.mongodb.MongoDBFieldEncryptor;
import com.mongodb.client.vault.ClientEncryption;

@ExtendWith(MockitoExtension.class)
public class ProviderAttributesDataEncryptionImplTest {

	@InjectMocks
	private ProviderAttributesDataEncryptionImpl dataEnrcyptionImpl;

	private static final String DETERMINISTIC_ENCRYPTION_TYPE = "AEAD_AES_256_CBC_HMAC_SHA_512-Deterministic";

	@Mock
	private MongoDBFieldEncryptor dbFieldEncryptor;

	ClientEncryption clientEncryption = Mockito.mock(ClientEncryption.class);

	@Test
	public void testEncryptionShouldHappenWhenFieldValueIsNotNull() {
		BsonBinary bsonVal = new BsonBinary("123456789".getBytes());
		BsonBinary bsonIrsVal = new BsonBinary("5432178996".getBytes());

		Document doc = new Document();
		doc.put("prov", "123456789");
		Document encDoc = new Document();
		encDoc.put("key", doc);
		encDoc.put("irsNo", "5432178996");
		Mockito.when(dbFieldEncryptor.encrypt("123456789", DETERMINISTIC_ENCRYPTION_TYPE)).thenReturn(bsonVal);
		Mockito.when(dbFieldEncryptor.encrypt("5432178996", DETERMINISTIC_ENCRYPTION_TYPE)).thenReturn(bsonIrsVal);
		
		Document docReturned = dataEnrcyptionImpl.encryptProviderData(encDoc);
		assertEquals(bsonVal, ((Document) docReturned.get("key")).get("prov"));
		assertEquals(bsonIrsVal, docReturned.get("irsNo"));
	}

	@Test
	public void testDecryptionShouldHappenWhenFieldValueIsNotNull() {
		String providerId = "123456789";
		String irsNumber = "5432178996";
		Binary bsonVal = new Binary(providerId.getBytes());
		Binary bsonIrs = new Binary(irsNumber.getBytes());

		Document doc = new Document();
		doc.put("prov", bsonVal);
		Document decDoc = new Document();
		decDoc.put("key", doc);
		decDoc.put("irsNo", bsonIrs);

		Mockito.when(dbFieldEncryptor.decrypt(new BsonBinary(bsonVal.getData()), DETERMINISTIC_ENCRYPTION_TYPE))
				.thenReturn(providerId);
		Mockito.when(dbFieldEncryptor.decrypt(new BsonBinary(bsonIrs.getData()), DETERMINISTIC_ENCRYPTION_TYPE))
		.thenReturn(irsNumber);

		Document docReturned = dataEnrcyptionImpl.decryptProviderData(decDoc);
		assertEquals(providerId, docReturned.get("doc", doc.get("prov")));
		assertEquals(irsNumber, docReturned.get("irsNo"));
	}

	@Test
	public void testEncryptionShouldNotHappenWhenFieldValueIsNull() {
		Document doc = new Document();
		doc.put("prov", null);
		Document encDoc = new Document();
		encDoc.put("key", doc);
		encDoc.put("irsNo", null);

		Document docReturned = dataEnrcyptionImpl.encryptProviderData(encDoc);
		assertNull(((Document) docReturned.get("key")).get("prov"));
		assertNull(docReturned.get("irsNo"));
	}

	@Test
	public void testDecryptionShouldNotHappenWhenFieldValueIsNull() {

		Document doc = new Document();
		doc.put("prov", null);
		Document decDoc = new Document();
		decDoc.put("key", doc);
		decDoc.put("irsNo", null);

		Document docReturned = dataEnrcyptionImpl.decryptProviderData(decDoc);
		assertNull(((Document) docReturned.get("key")).get("prov"));
		assertNull(docReturned.get("irsNo"));
	}

}

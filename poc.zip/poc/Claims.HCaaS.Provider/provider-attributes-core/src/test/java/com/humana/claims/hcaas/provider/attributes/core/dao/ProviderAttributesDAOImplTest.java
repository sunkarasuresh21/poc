	package com.humana.claims.hcaas.provider.attributes.core.dao;

import static com.humana.claims.hcaas.provider.attributes.core.dao.ProviderAttributesMongoConstants.COLLECTION_PROVIDER_ATTRIBUTES;
import static com.humana.claims.hcaas.provider.attributes.core.util.ProviderAttributesTestData.getAttributes;
import static com.humana.claims.hcaas.provider.attributes.core.util.ProviderAttributesTestData.getAttributesData;
import static com.humana.claims.hcaas.provider.attributes.core.util.ProviderAttributesTestData.getRequestKey;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.humana.claims.hcaas.common.test.spring.mongodb.ConfigureInMemoryMongoTestServer;
import com.humana.claims.hcaas.provider.attributes.core.exception.ProviderAttributesNotFoundException;
import com.humana.claims.hcaas.provider.attributes.core.mapper.ProviderAttrGetRequest;
import com.humana.claims.hcaas.provider.attributes.core.model.RequestKey;
import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.attributes.core.model.db.WithholdData;
import com.humana.claims.hcaas.provider.attributes.core.util.ProviderAttributesPatchUtil;

import lombok.SneakyThrows;

@SpringBootTest(classes= {ProviderAttributesDAOImpl.class, ProviderAttributesPatchUtil.class, ProviderAttributesDataEncryptionTestImpl.class})
@ConfigureInMemoryMongoTestServer
public class ProviderAttributesDAOImplTest {
	
	@Autowired
	private MongoTemplate mongoTemplate;

	@Autowired
	private ProviderAttributesDAOImpl providerAttributesDAOImpl;
	
	@AfterEach public void dropCollection() {
	mongoTemplate.dropCollection(COLLECTION_PROVIDER_ATTRIBUTES); }

	@SneakyThrows
	@Test
	public void testUpsertAttributesInsert() {
		Attributes testAttributesData = getAttributesData();
		providerAttributesDAOImpl.upsertProviderAttributesProv1(testAttributesData);
		
		List<Attributes> actual = mongoTemplate.findAll(Attributes.class, COLLECTION_PROVIDER_ATTRIBUTES);
		
		assertThat(actual).isNotNull();
		assertThat(actual.size()).isEqualTo(1);
		assertThat(actual).usingElementComparatorIgnoringFields("id").contains(testAttributesData);

	}
	
	@SneakyThrows
	@Test
	public void testUpsertAttributesUpdateExisting() {
		Attributes testAttributesData1 = getAttributesData();
		Attributes testAttributesData2 = getAttributesData();
		testAttributesData2.setComment1("update comment1");
		mongoTemplate.save(testAttributesData1, COLLECTION_PROVIDER_ATTRIBUTES);
	
		providerAttributesDAOImpl.upsertProviderAttributesProv1(testAttributesData2);
		
		List<Attributes> actual = mongoTemplate.findAll(Attributes.class, COLLECTION_PROVIDER_ATTRIBUTES);
		
		assertThat(actual).isNotNull();
		assertThat(actual.size()).isEqualTo(1);
		assertThat(actual.get(0).getComment1()).isEqualTo("update comment1");
	}

	@Test
	public void testPostAttributesSuccess() {
		Attributes testAttributes = getAttributesData();

		providerAttributesDAOImpl.postProviderAttributes(testAttributes);

		List<Attributes> actual = mongoTemplate.findAll(Attributes.class,COLLECTION_PROVIDER_ATTRIBUTES);

		assertThat(actual.size()).isEqualTo(1);
		assertThat(actual).usingElementComparatorIgnoringFields("id").contains(testAttributes);
	}
	
	@Test
	public void testPostAttributesReturnsNullWhenDataIsAlreadySavedInDatabase() {
		Attributes testAttributesData = getAttributesData();
		mongoTemplate.save(testAttributesData, COLLECTION_PROVIDER_ATTRIBUTES);
		
		String actual = providerAttributesDAOImpl.postProviderAttributes(testAttributesData);

		assertThat(actual).isEqualTo("Attributes already exists");
	}
	
	@SneakyThrows
	@Test
	public void testUpdateAttributesWhenRecordExistsInDatabase() {
		Attributes testAttributes1 = getAttributesData();
		Attributes testAttributes2 = getAttributesData();
		testAttributes2.setComment1("update comment1");
		mongoTemplate.save(testAttributes1, COLLECTION_PROVIDER_ATTRIBUTES);
	
		providerAttributesDAOImpl.updateProviderAttributes(testAttributes2, "542", " ", "H");
		
		List<Attributes> actual = mongoTemplate.findAll(Attributes.class, COLLECTION_PROVIDER_ATTRIBUTES);
		
		assertThat(actual.size()).isEqualTo(1);
		assertThat(actual.get(0).getComment1()).isNotEqualTo(testAttributes1.getComment1());
		assertThat(actual.get(0).getComment1()).isEqualTo(testAttributes2.getComment1());
	}
	
	@SneakyThrows
	@Test
	public void testUpdateAttributesWhenNoRecordExistsInDatabase() {
		Attributes testAttributes1 = getAttributesData();
		
		Attributes actual = providerAttributesDAOImpl.updateProviderAttributes(testAttributes1, "542", " ", "H");

		assertThat(actual).isNull();
	}
	
	@SneakyThrows
	@Test
	public void testGetAttributesByProviderIdWhenSingleRecordExistsInDatabase() {
		Attributes testAttributes = getAttributesData();
		mongoTemplate.save(testAttributes, COLLECTION_PROVIDER_ATTRIBUTES);
		
		Collection<Attributes> actual = providerAttributesDAOImpl.getAttributesByProviderId(createProvAttrGetReqObj());
		
		assertThat(actual).isNotEmpty();
		assertThat(actual.size()).isEqualTo(1);
		assertThat(actual.stream().findFirst().get()).usingRecursiveComparison().ignoringFields("id").isEqualTo(testAttributes);
	}
	
	@SneakyThrows
	@Test
	public void testGetAttributesByProviderIdWhenMultipleRecordsExistsInDatabase() {
		Attributes testAttributesData1 = getAttributesData();
		Attributes testAttributesData2 = getAttributesData();
		mongoTemplate.save(testAttributesData1, COLLECTION_PROVIDER_ATTRIBUTES);
		mongoTemplate.save(testAttributesData2, COLLECTION_PROVIDER_ATTRIBUTES);

		Collection<Attributes> actual = providerAttributesDAOImpl.getAttributesByProviderId(createProvAttrGetReqObj());

		assertThat(actual).isNotEmpty();
		assertThat(actual.size()).isEqualTo(2);
		assertThat(actual.stream().findFirst().get()).usingRecursiveComparison().ignoringFields("id").isEqualTo(testAttributesData1);
		assertThat(actual.stream().skip(1).findFirst().get()).usingRecursiveComparison().ignoringFields("id").isEqualTo(testAttributesData2);
	}
	
	@SneakyThrows
	@Test
	public void testGetAttributesWhenFirstNameIsNotNullAndMultipleRecordsExistsInDatabaseReturnsOnlyThatAreMatchingTheInputFirstName() {
		Attributes testAttributesData1 = getAttributesData();
		Attributes testAttributesData2 = getAttributesData();
		testAttributesData2.setAlphaKey("FIRST NAME");
		mongoTemplate.save(testAttributesData1, COLLECTION_PROVIDER_ATTRIBUTES);
		mongoTemplate.save(testAttributesData2, COLLECTION_PROVIDER_ATTRIBUTES);

		Collection<Attributes> actual = providerAttributesDAOImpl.getAttributesByProviderId(createProvAttrGetReqObj());

		assertThat(actual).isNotEmpty();
		assertThat(actual.size()).isEqualTo(1);
	}
	
	@SneakyThrows
	@Test
	public void testGetAttributesByProviderIdWhenItReturnsTotalDocs() {
		Attributes testAttributesData1 = getAttributesData();
		Attributes testAttributesData2 = getAttributesData();
		mongoTemplate.save(testAttributesData1, COLLECTION_PROVIDER_ATTRIBUTES);
		mongoTemplate.save(testAttributesData2, COLLECTION_PROVIDER_ATTRIBUTES);

		String actual = providerAttributesDAOImpl.getAttributesTotalDocumentsByProviderId(createProvAttrGetReqObj());

		assertThat(actual).isNotEmpty();
		assertThat(actual).isEqualTo("2");
	}
	
	@SneakyThrows
	@Test
	public void testGetAttributesByProviderIdWhenNoRecordExistsInDatabase() {
		
		Collection<Attributes> actual = providerAttributesDAOImpl.getAttributesByProviderId(createProvAttrGetReqObj());

		assertThat(actual).isEmpty();
		assertThat(actual.size()).isEqualTo(0);
	}
	
	@SneakyThrows
	@Test
	public void testGetAttributesByProviderIdAndIndicatorWhenSingleRecordExistsInDatabase() {
		Attributes attributesData = getAttributesData();
		mongoTemplate.save(attributesData, COLLECTION_PROVIDER_ATTRIBUTES);
		
		Collection<Attributes> actual = providerAttributesDAOImpl.getAttributesByProviderIdAndIndicator(createProvAttrGetReqObj());
		
		assertThat(actual).isNotEmpty();
		assertThat(actual.size()).isEqualTo(1);
		assertThat(actual.stream().findFirst().get()).usingRecursiveComparison().ignoringFields("id").isEqualTo(attributesData);
	}
	
	@SneakyThrows
	@Test
	public void testGetAttributesByProviderIdAndIndicatrorWhenMultipleRecordsExistsInDatabase() {
		Attributes testAttributesData1 = getAttributesData();
		Attributes testAttributesData2 = getAttributesData();
		mongoTemplate.save(testAttributesData1, COLLECTION_PROVIDER_ATTRIBUTES);
		mongoTemplate.save(testAttributesData2, COLLECTION_PROVIDER_ATTRIBUTES);

		Collection<Attributes> actual = providerAttributesDAOImpl.getAttributesByProviderIdAndIndicator(createProvAttrGetReqObj());

		assertThat(actual).isNotEmpty();
		assertThat(actual.size()).isEqualTo(2);
		assertThat(actual.stream().findFirst().get()).usingRecursiveComparison().ignoringFields("id").isEqualTo(testAttributesData1);
		assertThat(actual.stream().skip(1).findFirst().get()).usingRecursiveComparison().ignoringFields("id").isEqualTo(testAttributesData2);
	}
	
	@SneakyThrows
	@Test
	public void testGetAttributesByProviderIdAndIndicatorWhenItReturnsTotalDocs() {
		Attributes testAttributesData1 = getAttributesData();
		Attributes testAttributesData2 = getAttributesData();
		mongoTemplate.save(testAttributesData1, COLLECTION_PROVIDER_ATTRIBUTES);
		mongoTemplate.save(testAttributesData2, COLLECTION_PROVIDER_ATTRIBUTES);

		String actual = providerAttributesDAOImpl.getAttributesTotalDocumentsByProviderIdAndIndicator(createProvAttrGetReqObj());

		assertThat(actual).isNotEmpty();
		assertThat(actual).isEqualTo("2");
	}
	
	@SneakyThrows
	@Test
	public void testGetAttributesByProviderIdAndIndicatorWhenNoRecordExistsInDatabase() {
		
		Collection<Attributes> actual = providerAttributesDAOImpl.getAttributesByProviderIdAndIndicator(createProvAttrGetReqObj());

		assertThat(actual).isEmpty();
		assertThat(actual.size()).isEqualTo(0);
	}
	
	@SneakyThrows
	@Test
	public void testGetAttributesByProviderIdMultiAddressKeyAndIndicatorWhenSingleRecordExistsInDatabase() {
		Attributes attributesData = getAttributesData();
		mongoTemplate.save(attributesData, COLLECTION_PROVIDER_ATTRIBUTES);
		
		Collection<Attributes> actual = providerAttributesDAOImpl.getAttributesByProviderIdMultiAddressKeyAndIndicator(createProvAttrGetReqObj());
		
		assertThat(actual).isNotEmpty();
		assertThat(actual.size()).isEqualTo(1);
		assertThat(actual.stream().findFirst().get()).usingRecursiveComparison().ignoringFields("id").isEqualTo(attributesData);
	}
	
	@SneakyThrows
	@Test
	public void testGetAttributesByProviderIdMultiAddressKeyAndIndicatrorWhenMultipleRecordsExistsInDatabase() {
		Attributes testAttributesData1 = getAttributesData();
		Attributes testAttributesData2 = getAttributesData();
		mongoTemplate.save(testAttributesData1, COLLECTION_PROVIDER_ATTRIBUTES);
		mongoTemplate.save(testAttributesData2, COLLECTION_PROVIDER_ATTRIBUTES);

		Collection<Attributes> actual = providerAttributesDAOImpl.getAttributesByProviderIdMultiAddressKeyAndIndicator(createProvAttrGetReqObj());

		assertThat(actual).isNotEmpty();
		assertThat(actual.size()).isEqualTo(2);
		assertThat(actual.stream().findFirst().get()).usingRecursiveComparison().ignoringFields("id").isEqualTo(testAttributesData1);
		assertThat(actual.stream().skip(1).findFirst().get()).usingRecursiveComparison().ignoringFields("id").isEqualTo(testAttributesData2);
	}
	
	@SneakyThrows
	@Test
	public void testGetAttributesByProviderIdMultiAddressKeyAndIndicatorWhenItReturnsTotalDocs() {
		Attributes testAttributesData1 = getAttributesData();
		Attributes testAttributesData2 = getAttributesData();
		mongoTemplate.save(testAttributesData1, COLLECTION_PROVIDER_ATTRIBUTES);
		mongoTemplate.save(testAttributesData2, COLLECTION_PROVIDER_ATTRIBUTES);

		String actual = providerAttributesDAOImpl.getAttributesTotalDocumentsByProviderIdMultiAddressKeyAndIndicator(createProvAttrGetReqObj());

		assertThat(actual).isNotEmpty();
		assertThat(actual).isEqualTo("2");
	}
	
	@SneakyThrows
	@Test
	public void testGetAttributesByProviderIdMultiAddressKeyAndIndicatorWhenNoRecordExistsInDatabase() {
		
		Collection<Attributes> actual = providerAttributesDAOImpl.getAttributesByProviderIdMultiAddressKeyAndIndicator(createProvAttrGetReqObj());

		assertThat(actual).isEmpty();
		assertThat(actual.size()).isEqualTo(0);
	}
	
	@SneakyThrows
	@Test
	public void testGetAttributesByProviderTaxIdWhenSingleRecordExistsInDatabase() {
		Attributes testAttributes = getAttributesData();
		testAttributes.setIrsNo("999999988");
		mongoTemplate.save(testAttributes, COLLECTION_PROVIDER_ATTRIBUTES);
		
		Collection<Attributes> actual = providerAttributesDAOImpl.getAttributesByProviderTaxId(createProvAttrGetReqObj());
		
		assertThat(actual).isNotEmpty();
		assertThat(actual.size()).isEqualTo(1);
		assertThat(actual.stream().findFirst().get()).usingRecursiveComparison().ignoringFields("id").isEqualTo(testAttributes);
	}
	
	@SneakyThrows
	@Test
	public void testGetAttributesByProviderTaxIdWhenFirstNameNotMatched() {
		Attributes testAttributes = getAttributesData();
		testAttributes.setIrsNo("999999988");
		mongoTemplate.save(testAttributes, COLLECTION_PROVIDER_ATTRIBUTES);
		ProviderAttrGetRequest provAttrGetReq = createProvAttrGetReqObj();
		provAttrGetReq.setFirstName("NOT ALPHAKEY");
		
		Collection<Attributes> actual = providerAttributesDAOImpl.getAttributesByProviderTaxId(provAttrGetReq);
		
		assertThat(actual).isEmpty();
		assertThat(actual.size()).isEqualTo(0);
	}
	
	@SneakyThrows
	@Test
	public void testGetAttributesByProviderTaxIdWhenMultipleRecordsExistsInDatabase() {
		Attributes testAttributesData1 = getAttributesData();
		testAttributesData1.setIrsNo("999999988");
		Attributes testAttributesData2 = getAttributesData();
		testAttributesData2.setIrsNo("999999988");
		mongoTemplate.save(testAttributesData1, COLLECTION_PROVIDER_ATTRIBUTES);
		mongoTemplate.save(testAttributesData2, COLLECTION_PROVIDER_ATTRIBUTES);

		Collection<Attributes> actual = providerAttributesDAOImpl.getAttributesByProviderTaxId(createProvAttrGetReqObj());

		assertThat(actual).isNotEmpty();
		assertThat(actual.size()).isEqualTo(2);
		assertThat(actual.stream().findFirst().get()).usingRecursiveComparison().ignoringFields("id").isEqualTo(testAttributesData1);
		assertThat(actual.stream().skip(1).findFirst().get()).usingRecursiveComparison().ignoringFields("id").isEqualTo(testAttributesData2);
	}
	
	@SneakyThrows
	@Test
	public void testGetAttributesByProviderTaxIdWhenItReturnsTotalDocs() {
		Attributes testAttributesData1 = getAttributesData();
		testAttributesData1.setIrsNo("999999988");
		Attributes testAttributesData2 = getAttributesData();
		testAttributesData2.setIrsNo("999999988");
		mongoTemplate.save(testAttributesData1, COLLECTION_PROVIDER_ATTRIBUTES);
		mongoTemplate.save(testAttributesData2, COLLECTION_PROVIDER_ATTRIBUTES);

		String actual = providerAttributesDAOImpl.getAttributesTotalDocumentsByProviderIdTaxId(createProvAttrGetReqObj());

		assertThat(actual).isNotEmpty();
		assertThat(actual).isEqualTo("2");
	}
	
	@SneakyThrows
	@Test
	public void testGetAttributesByProviderTaxIdWhenNoRecordExistsInDatabase() {
		
		Collection<Attributes> actual = providerAttributesDAOImpl.getAttributesByProviderTaxId(createProvAttrGetReqObj());

		assertThat(actual).isEmpty();
		assertThat(actual.size()).isEqualTo(0);
	}
	
	@SneakyThrows
	@Test
	public void testUpdateAttributesProv2WhenRecordExistsInDatabase() {
		Attributes testAttributes1 = getAttributesData();
		Attributes testAttributes2 = getAttributesData();
		testAttributes2.setComment2("update-prov2-comment2");
		testAttributes2.setComment3("update-prov2-comment3");

		mongoTemplate.save(testAttributes1, COLLECTION_PROVIDER_ATTRIBUTES);
	
		providerAttributesDAOImpl.updateProviderAttributesProv2(testAttributes2);
		
		List<Attributes> actual = mongoTemplate.findAll(Attributes.class, COLLECTION_PROVIDER_ATTRIBUTES);
		
		assertThat(actual.size()).isEqualTo(1);
		assertThat(actual.get(0).getComment2()).isNotEqualTo(testAttributes1.getComment2());
		assertThat(actual.get(0).getComment2()).isEqualTo(testAttributes2.getComment2());
		assertThat(actual.get(0).getComment3()).isNotEqualTo(testAttributes1.getComment3());
		assertThat(actual.get(0).getComment3()).isEqualTo(testAttributes2.getComment3());
		assertThat(actual.get(0).getComment1()).isEqualTo(testAttributes1.getComment1());
	}
	
	@SneakyThrows
	@Test
	public void testUpdateAttributesProv2WhenNoRecordExistsInDatabase() {
		
		Throwable actualThrown = catchThrowable(() -> providerAttributesDAOImpl.updateProviderAttributesProv2(getAttributesData()));
		
		assertThat(actualThrown)
				.isInstanceOf(ProviderAttributesNotFoundException.class);
	}
	
	@SneakyThrows
	@Test
	public void testUpdateAttributesProv3WhenRecordExistsInDatabase() {
		Attributes testAttributes1 = getAttributesData();
		Attributes testAttributes2 = getAttributesData();
		
		WithholdData testWithHoldData = new WithholdData();
		testWithHoldData.setPrTaxfreeAmt("updated-prTaxfreeAmt");
		testAttributes2.setWithholdData(testWithHoldData);
		
		mongoTemplate.save(testAttributes1, COLLECTION_PROVIDER_ATTRIBUTES);
	
		providerAttributesDAOImpl.updateProviderAttributesProv3(testAttributes2);
		
		List<Attributes> actual = mongoTemplate.findAll(Attributes.class, COLLECTION_PROVIDER_ATTRIBUTES);
		
		assertThat(actual.size()).isEqualTo(1);
		assertThat(actual.get(0).getWithholdData()).isNotEqualTo(testAttributes1.getWithholdData());
		assertThat(actual.get(0).getWithholdData()).isEqualTo(testAttributes2.getWithholdData());
			}
	
	@SneakyThrows
	@Test
	public void testUpdateAttributesProv3WhenNoRecordExistsInDatabase() {
		
		Throwable actualThrown = catchThrowable(() -> providerAttributesDAOImpl.updateProviderAttributesProv3(getAttributesData()));
		
		assertThat(actualThrown)
				.isInstanceOf(ProviderAttributesNotFoundException.class);
	}
	
	@SneakyThrows
	@Test
	public void testGetAttributesByUsingKeyDocumentWhenRecordExistsInDatabase() {
		Attributes testAttributes1 = getAttributes("123456789", "D", "5", "Alpha-Test-1");
		Attributes testAttributes2 = getAttributes("993456789", "D", "e", "Alpha-Test-2");
		RequestKey requestKey1 = getRequestKey("123456789", "D", "5");
		RequestKey requestKey2 = getRequestKey("993456789", "D", "e");
		
		mongoTemplate.save(testAttributes1, COLLECTION_PROVIDER_ATTRIBUTES);
		mongoTemplate.save(testAttributes2, COLLECTION_PROVIDER_ATTRIBUTES);
	
		List<Attributes> actual = providerAttributesDAOImpl.getAttributesByKey(Arrays.asList(requestKey1,requestKey2));
		
		assertThat(actual.size()).isEqualTo(2);
		assertThat(actual.get(0).getAlphaKey()).isEqualTo("Alpha-Test-1");
		assertThat(actual.get(1).getAlphaKey()).isEqualTo("Alpha-Test-2");
	}
	
	@SneakyThrows
	@Test
	public void testGetAttributesByUsingKeyDocumentWhenRecordDoesntExistsInDatabase() {
		RequestKey requestKey1 = getRequestKey("123456789", "D", "5");
		RequestKey requestKey2 = getRequestKey("993456789", "D", "e");
	
		List<Attributes> actual = providerAttributesDAOImpl.getAttributesByKey(Arrays.asList(requestKey1,requestKey2));
		
		assertThat(actual).isEmpty();
	}
	
	private ProviderAttrGetRequest createProvAttrGetReqObj() {
		return ProviderAttrGetRequest.builder().providerId("542").providerIndicator("H").providerMultiAddressKey(" ").providerTaxId("999999988")
				.firstName("ALPHAKEY").limit(2).offset(0).includeCount(true).build();
	}
	

}
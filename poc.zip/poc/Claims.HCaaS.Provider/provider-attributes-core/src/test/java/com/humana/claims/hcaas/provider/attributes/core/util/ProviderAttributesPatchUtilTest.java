package com.humana.claims.hcaas.provider.attributes.core.util;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.HashMap;
import java.util.Map;

import org.bson.Document;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.query.Update;

import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
public class ProviderAttributesPatchUtilTest {

	@InjectMocks
	private ProviderAttributesPatchUtil classUnderTest;

	@Test
	public void test_classUnderTest_initialized() {
		assertNotNull(classUnderTest);
	}

	@Test
	@SneakyThrows
	public void testGetMongoUpdateObjForAttributesWithAlphaKeyAsNull() {
		Attributes attributes = ProviderAttributesTestData.getAttributesData();
		attributes.setAlphaKey(null);

		Update actual = classUnderTest.getMongoUpdateObjForAttributes(attributes);

		Document updateObjectSet = (Document)actual.getUpdateObject().get("$set");
		assertThat(updateObjectSet.keySet()).doesNotContain("alphaKey");
	}

	@Test
	@SneakyThrows
	public void testGetMongoUpdateObjForAttributesWithValidInput() {
		Attributes attributes = ProviderAttributesTestData.getAttributesData();

		Update actual = classUnderTest.getMongoUpdateObjForAttributes(attributes);

		Document updateObjectSet = (Document)actual.getUpdateObject().get("$set");
		assertThat(updateObjectSet.keySet()).isNotNull();
	}

	@Test
	@SneakyThrows
	public void testGetMongoUpdateObjForAttributesWithWithholdDataPrTaxfreeAmtAsNull() {
		Attributes attributes = ProviderAttributesTestData.getAttributesData();
		attributes.getWithholdData().setPrTaxfreeAmt(null);

		Update actual = classUnderTest.getMongoUpdateObjForAttributes(attributes);

		Document updateObjectSet = (Document)actual.getUpdateObject().get("$set");
		assertThat(updateObjectSet.keySet()).doesNotContain("withholdData.prTaxfreeAmt");
	}
	
	@Test
	@SneakyThrows
	public void testGetMongoUpdateObjForAttributesWithKeyAsNull() {
		Attributes attributes = ProviderAttributesTestData.getAttributesData();
		attributes.setKey(null);

		Update actual = classUnderTest.getMongoUpdateObjForAttributes(attributes);

		Document updateObjectSet = (Document)actual.getUpdateObject().get("$set");
		assertThat(updateObjectSet.keySet()).doesNotContain("key");
	}
	
	@Test
	@SneakyThrows
	public void testGetMongoUpdateObjForAttributesWithCasFstNameAndLastNameAsNull() {
		Attributes attributes = ProviderAttributesTestData.getAttributesData();
		attributes.getCasName().setFstName(null);
		attributes.getCasName().setLastName(null);

		Update actual = classUnderTest.getMongoUpdateObjForAttributes(attributes);

		Document updateObjectSet = (Document)actual.getUpdateObject().get("$set");
		assertThat(updateObjectSet.keySet()).doesNotContain("casName.fstName");
		assertThat(updateObjectSet.keySet()).doesNotContain("casName.lastName");
	}
	
	@Test
	@SneakyThrows
	public void testGetMongoUpdateObjForAttributesWithPxiZipListFieldsAsNull() {
		Attributes attributes = ProviderAttributesTestData.getAttributesData();
		attributes.getPxiZip().get(0).setPxiZipCode(null);
		attributes.getPxiZip().get(0).setPxiZipInd(null);

		Update actual = classUnderTest.getMongoUpdateObjForAttributes(attributes);

		Document updateObjectSet = (Document)actual.getUpdateObject().get("$set");
		assertThat(updateObjectSet.keySet()).doesNotContain("pxiZip.pxiZipCode");
		assertThat(updateObjectSet.keySet()).doesNotContain("pxiZip.pxiZipInd");
	}
	
	@Test
	@SneakyThrows
	public void testGetMongoUpdateObjForAttributesWithContractPointEnableMapUpdate() {
		Attributes attributes = ProviderAttributesTestData.getAttributesData();
		attributes.setContractPointEnable(buildContractPointEnableMap());
		
		Update actual = classUnderTest.getMongoUpdateObjForAttributes(attributes);
		
		Document updateObjectSet = (Document)actual.getUpdateObject().get("$set");
		assertThat(updateObjectSet.keySet()).isNotNull();
	}
	private static Map<String, Boolean> buildContractPointEnableMap() {
		Map<String, Boolean> contractPointEnableMap = new HashMap<>();
		contractPointEnableMap.put("1", true);
		contractPointEnableMap.put("2", false);
		return contractPointEnableMap;
	}
	
	@Test
	@SneakyThrows
	public void testGetMongoUpdateObjForAttributesWithContractPointEnableMapAsNull() {
		Attributes attributes = ProviderAttributesTestData.getAttributesData();
		attributes.setContractPointEnable(null);

		Update actual = classUnderTest.getMongoUpdateObjForAttributes(attributes);

		Document updateObjectSet = (Document)actual.getUpdateObject().get("$set");
		assertThat(updateObjectSet.keySet()).doesNotContain("contractPointEnable");
	}
	
}
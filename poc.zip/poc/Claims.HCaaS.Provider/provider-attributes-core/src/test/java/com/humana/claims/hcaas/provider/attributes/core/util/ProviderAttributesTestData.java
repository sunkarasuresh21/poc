package com.humana.claims.hcaas.provider.attributes.core.util;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.humana.claims.hcaas.provider.attributes.core.model.RequestKey;
import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.attributes.core.model.db.CasName;
import com.humana.claims.hcaas.provider.attributes.core.model.db.AttributesKey;
import com.humana.claims.hcaas.provider.attributes.core.model.db.PxiZip;
import com.humana.claims.hcaas.provider.attributes.core.model.db.WithholdData;
import com.humana.claims.hcaas.provider.attributes.core.model.db.WthldCurrent;
import com.humana.claims.hcaas.provider.attributes.core.model.db.WthldPrior;

public class ProviderAttributesTestData {
	
	private ProviderAttributesTestData() {}
	
	public static final String IRSNO_VALUE = "IRSNO";
	public static final String VCH_VALUE = "VCH";
	public static final String TAXTYPE_VALUE = "TAXTYPE";
	public static final String SEND1099IND_VALUE = "SEND1099IND";
	public static final String PENDESC_VALUE = "PENDESC";
	public static final String AUTOCHECKPULLIND_VALUE = "AUTOCHECKPULLIND";
	public static final String IRSWITHHOLDIND_VALUE = "IRSWITHHOLDIND";
	public static final String PAYCYCLE_VALUE = "PAYCYCLE";
	public static final String CROSSREF_VALUE = "CROSSREF";
	public static final String MARKETID_VALUE = "MARKETID";
	public static final String DG_VALUE = "DG";
	public static final String ALPHAKEY_VALUE = "ALPHAKEY";
	public static final String CASFSTNAME_VALUE = "CASNAME.CASFSTNAME";
	public static final String CASLASTNAME_VALUE = "CASNAME.CASLASTNAME";
	public static final String MEDSUPPWAIVEIND_VALUE = "MEDSUPPWAIVEIND";
	public static final String COMMENT_VALUE = "COMMENT";
	public static final String NOTIFYIND_VALUE = "NOTIFYIND";
	public static final String CLPTHIND_VALUE = "CLPTHIND";
	public static final String CLMCHKIND_VALUE = "CLMCHKIND";
	public static final String UCZIP_VALUE = "UCZIP";
	public static final String AUTOLOADIND_VALUE = "AUTOLOADIND";
	public static final String CHECKTO_VALUE = "CHECKTO";
	public static final String SUFFIXTO_VALUE = "SUFFIXTO";
	public static final String APPLYTAXIND_VALUE = "APPLYTAXIND";
	public static final String W9IND_VALUE = "W9IND";
	public static final String SEND480IND_VALUE = "SEND480IND";
	public static final String WTHLDPERCURRENT_VALUE = "WITHHOLDDATA.WTHLDPERCURRENT";
	public static final String WTHLDEFFDATECURRENT_VALUE = "WITHHOLDDATA.WTHLDEFFDATECURRENT";
	public static final String WTHLDPERPRIOR_VALUE = "WITHHOLDDATA.WTHLDPERPRIOR";
	public static final String WTHLDEFFDATEPRIOR_VALUE = "WITHHOLDDATA.WTHLDEFFDATEPRIOR";
	public static final String PRTAXFREEAMT_VALUE = "WITHHOLDDATA.PRTAXFREEAMT";
	public static final String UPDTADJNO_VALUE = "UPDTADJNO";
	public static final String RADSITECURRIND_VALUE = "RADSITECURRIND";
	public static final String RADSITEP1IND_VALUE = "RADSITEP1IND";
	public static final String RADSITEP2IND_VALUE = "RADSITEP2IND";
	public static final String RADSCOPECURRIND_VALUE = "RADSCOPECURRIND";
	public static final String RADSCOPEP1IND_VALUE = "RADSCOPEP1IND";
	public static final String FACUCZIP_VALUE = "FACUCZIP";
	public static final String PXIUPDTADJNO_VALUE = "PXIUPDTADJNO";
	public static final String SENDLTRIND_VALUE = "SENDLTRIND";
	public static final String FINALSTIND_VALUE = "FINALSTIND";
	public static final String PXIZIPCODE_VALUE = "PXIZIP.PXIZIPCODE";
	public static final String PXIZIPIND_VALUE = "PXIZIP.PXIZIPIND";
	public static final String COMPBIDIND_VALUE = "COMPBIDIND";
	public static final String VENDORID_VALUE = "VENDORID";
	public static final String COMMENT1_VALUE = "COMMENT1";
	public static final String COMMENT2_VALUE = "COMMENT2";
	public static final String COMMENT3_VALUE = "COMMENT3";
	public static final String CLIENT = "58";

	
	public static Attributes getAttributesData() {
		Attributes attributes = new Attributes();
		attributes.setKey(getKey());
		attributes.setIrsNo(IRSNO_VALUE);
		attributes.setVch(VCH_VALUE);
		attributes.setTaxType(TAXTYPE_VALUE);
		attributes.setSend1099Ind(SEND1099IND_VALUE);
		attributes.setPendEsc(PENDESC_VALUE);
		attributes.setAutoCheckPullInd(AUTOCHECKPULLIND_VALUE);
		attributes.setIrsWithholdInd(IRSWITHHOLDIND_VALUE);
		attributes.setPayCycle(PAYCYCLE_VALUE);
		attributes.setCrossRef(CROSSREF_VALUE);
		attributes.setMarketId(MARKETID_VALUE);
		attributes.setDg(DG_VALUE);
		attributes.setAlphaKey(ALPHAKEY_VALUE);
		attributes.setCasName(getCasName());
		attributes.setMedSuppWaiveInd(MEDSUPPWAIVEIND_VALUE);
		attributes.setComment1(COMMENT1_VALUE);
		attributes.setNotifyInd(NOTIFYIND_VALUE);
		attributes.setFocusFromDate(LocalDate.of(2020, 01, 01));
		attributes.setClpthInd(CLPTHIND_VALUE);
		attributes.setClmChkInd(CLMCHKIND_VALUE);
		attributes.setUcZip(UCZIP_VALUE);
		attributes.setFocusToDate(LocalDate.of(2020, 01, 01));
		attributes.setAutoLoadInd(AUTOLOADIND_VALUE);
		attributes.setCheckTo(CHECKTO_VALUE);
		attributes.setSuffixTo(SUFFIXTO_VALUE);
		attributes.setApplyTaxInd(APPLYTAXIND_VALUE);
		attributes.setW9Ind(W9IND_VALUE);
		attributes.setSend480Ind(SEND480IND_VALUE);
		attributes.setWithholdData(getWithholdData());
		attributes.setComment2(COMMENT2_VALUE);
		attributes.setComment3(COMMENT3_VALUE);
		attributes.setUpdtAdjNo(UPDTADJNO_VALUE);
		attributes.setUpdtDt(LocalDate.of(2020, 01, 01));
		attributes.setRadSiteCurrInd(RADSITECURRIND_VALUE);
		attributes.setRadSiteCurrDt(LocalDate.of(2020, 01, 01));
		attributes.setRadSiteP1Ind(RADSITEP1IND_VALUE);
		attributes.setRadSiteP1Dt(LocalDate.of(2020, 01, 01));
		attributes.setRadSiteP2Ind(RADSITEP2IND_VALUE);
		attributes.setRadSiteP2Dt(LocalDate.of(2020, 01, 01));
		attributes.setRadScopeCurrInd(RADSCOPECURRIND_VALUE);
		attributes.setRadScopeCurrDt(LocalDate.of(2020, 01, 01));
		attributes.setRadScopeP1Ind(RADSCOPEP1IND_VALUE);
		attributes.setRadScopeP1Dt(LocalDate.of(2020, 01, 01));
		attributes.setFacUcZip(FACUCZIP_VALUE);
		attributes.setPxiUpdtAdjNo(PXIUPDTADJNO_VALUE);
		attributes.setPxiUpdtDt(LocalDate.of(2020, 01, 01));
		attributes.setSendLtrInd(SENDLTRIND_VALUE);
		attributes.setFinalstInd(FINALSTIND_VALUE);
		attributes.setPxiZip(getPxiZip());
		attributes.setCompbidInd(COMPBIDIND_VALUE);
		attributes.setVendorId(VENDORID_VALUE);
		attributes.setCompbidEffDt(LocalDate.of(2019, 01, 01));
		attributes.setCompbidTrmDt(LocalDate.of(2020, 01, 01));
		attributes.setContractPointEnable(buildContractPointEnableMap());

		return attributes;					
	}
	
	public static Attributes getAttributes(String provId,String provInd,String MultiAddressKey,String AlphaKey) {
		Attributes attributes = new Attributes();
		AttributesKey attributesKey = new AttributesKey();
		attributesKey.setClient(CLIENT);
		attributesKey.setProv(provId);
		attributesKey.setPvdInd(provInd);
		attributesKey.setMultAddressKey(MultiAddressKey);
		attributes.setKey(attributesKey);
		attributes.setAlphaKey(AlphaKey);
		return attributes;
	}
	
	public static RequestKey getRequestKey(String provId,String provInd,String MultiAddressKey) {
		RequestKey requestKey = new RequestKey();
		requestKey.setClient(CLIENT);
		requestKey.setProv(provId);
		requestKey.setPvdInd(provInd);
		requestKey.setMultAddressKey(MultiAddressKey);
		return requestKey;
	}
	
	private static CasName getCasName() {
		CasName casNameDto = new CasName();
		casNameDto.setFstName(CASFSTNAME_VALUE);
		casNameDto.setLastName(CASLASTNAME_VALUE);
		return casNameDto;
	}
	private static WithholdData getWithholdData() {
		WithholdData withHldDataDto = new WithholdData();
		withHldDataDto.setWthldCurrent(getWthldCurrent());
		withHldDataDto.setWthldPrior(getWthldPrior());
		withHldDataDto.setPrTaxfreeAmt(PRTAXFREEAMT_VALUE);
		return withHldDataDto;
	}
	private static WthldCurrent getWthldCurrent() {
		WthldCurrent withHldCurrentDto = new WthldCurrent();
		withHldCurrentDto.setWthldPerCurrent(WTHLDPERCURRENT_VALUE);
		withHldCurrentDto.setWthldEffDateCurrent(LocalDate.of(2020, 01, 01));
		return withHldCurrentDto;
	}
	private static WthldPrior getWthldPrior() {
		WthldPrior withHldPriorDto = new WthldPrior();
		withHldPriorDto.setWthldPerPrior(WTHLDPERPRIOR_VALUE);
		withHldPriorDto.setWthldEffDatePrior(LocalDate.of(2020, 01, 01));
		return withHldPriorDto;
	}
	private static List<PxiZip> getPxiZip() {
		List<PxiZip> pxiZipDtos = new ArrayList<>();
		PxiZip pxiZipDto = new PxiZip();
		pxiZipDto.setPxiZipCode(PXIZIPCODE_VALUE);
		pxiZipDto.setPxiZipInd(PXIZIPIND_VALUE);
		pxiZipDtos.add(pxiZipDto);
		return pxiZipDtos;
	}
	private static Map<String, Boolean> buildContractPointEnableMap() {
		Map<String, Boolean> contractPointEnableMap = new HashMap<>();
		contractPointEnableMap.put("1", true);
		contractPointEnableMap.put("2", false);
		return contractPointEnableMap;
	}
	private static AttributesKey getKey() {
		AttributesKey keyDto = new AttributesKey();
		keyDto.setClient(CLIENT);
		keyDto.setPvdInd("H");
		keyDto.setProv("542");
		keyDto.setMultAddressKey(" ");		
		return keyDto;
	}

}
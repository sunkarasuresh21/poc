# Provider

This repo contains the code for the Provider Demographics and Provider Attributes microservices.

## Background

The data for these microservices originally comes from multiple VSAM files, and has been classified as either Provider Demographics or Provider Attributes.

These microservices are separated in order to define and maintain the different domains.  However, there are some modules that currently need to span both domains.

### Provider Demographics

Provider Demographics is the details about a Provider.  This data is truly the domain of the Provider group, but historically was maintained in CAS for convenience.  

### Provider Attributes

Provider Attributes are specific to Claims Adjudication.  This data will remain owned by Claims Adjudication.

## Components

![Component Diagram](./diagrams/provider-components.png)

The OpenAPI spec can be found [here](provider-rest-api-spec/src/main/resources)

The provider-data-capture module spans both domains because the data is intertwined in the mainframe VSAM files.  Once these microservices become the source of truth for this data, this module can be split into each microservice

Likewise, the provider-rest-api spans both domains to represent the current PDI service.  However, work is underway to move this functionality to the API Gateway.  Once completed, this module can be removed.

## Build

This is a multi-module Maven project.  Build the root/parent project will build all the modules.  

package com.humana.claims.hcaas.provider.demographics.restapi.mapper;

import static com.humana.claims.hcaas.provider.demographics.restapi.util.ProviderDemographicsTestData.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.demographics.restapi.gen.openapi.model.ProviderDemoDTO;

@ExtendWith(MockitoExtension.class)
public class ProviderDemographicsDataMapperTest {
	
	@InjectMocks
	private ProviderDemographicsDataMapper classUnderTest;

	@Test
	public void test_classUnderTest_initialized() {
		assertNotNull(classUnderTest);
	}
	
	@Test
	public void testMapProviderDemoDtoWithValidInput() {
		Demographics demographics = createDemographics();
		
		ProviderDemoDTO actual = ProviderDemographicsDataMapper.mapProviderDemoDTO(demographics);
		
		assertProviderDemoDtoData(actual);
	}
	
	@Test
	public void testMapProviderDemoDtoWithNullValue() {
		Demographics demographics = createDemographics();
		demographics.setProviderInfo(null);
		
		ProviderDemoDTO actual = ProviderDemographicsDataMapper.mapProviderDemoDTO(demographics);
		
		assertThat(actual.getProviderInfo().getCity()).isNull();
	}
	
	@Test
	public void testMapDemograhicsWithNullValue() {
		Demographics demographics = null;
		
		ProviderDemoDTO actual = ProviderDemographicsDataMapper.mapProviderDemoDTO(demographics);
		
		assertThat(actual.getKey()).isNull();
		assertThat(actual.getIrsNo()).isNull();
		assertThat(actual.getTinEffDt()).isNull();
		assertThat(actual.getUpdateSys()).isNull();
		assertThat(actual.getProviderInfo()).isNull();
	}
	
	@Test
	public void testMapProviderDemoKeyDtoWithNullValue() {
		Demographics demographics = createDemographics();
		demographics.setKey(null);
		
		ProviderDemoDTO actual = ProviderDemographicsDataMapper.mapProviderDemoDTO(demographics);
		
		assertThat(actual.getKey().getClient()).isNull();
		assertThat(actual.getKey().getMultAddressKey()).isNull();
		assertThat(actual.getKey().getProv()).isNull();
		assertThat(actual.getKey().getPvdInd()).isNull();
	}
	
	@Test
	public void testMapProviderInfoWithNullValue() {
		Demographics demographics = createDemographics();
		demographics.setProviderInfo(null);
		
		ProviderDemoDTO actual = ProviderDemographicsDataMapper.mapProviderDemoDTO(demographics);
		
		assertThat(actual.getProviderInfo().getNoPayCode()).isNull();
		assertThat(actual.getProviderInfo().getNoPayDt()).isNull();
	}
	
	@Test
	public void testMapProviderDemoInfoAddressDtoWithNullValue() {
		Demographics demographics = createDemographics();
		demographics.getProviderInfo().setAddress(null);
		
		ProviderDemoDTO actual = ProviderDemographicsDataMapper.mapProviderDemoDTO(demographics);
		
		assertThat(actual.getProviderInfo().getAddress().getAddr1()).isNull();
		assertThat(actual.getProviderInfo().getAddress().getAddr2()).isNull();
		assertThat(actual.getProviderInfo().getAddress().getAddr3()).isNull();
		assertThat(actual.getProviderInfo().getAddress().getAddr4()).isNull();
	}
	
	@Test
	public void testMapProviderDemoInfoProviderInfoWithNullValue() {
		Demographics demographics = createDemographics();
		demographics.setProviderInfo(null);
		
		ProviderDemoDTO actual = ProviderDemographicsDataMapper.mapProviderDemoDTO(demographics);
		
		assertThat(actual.getProviderInfo().getAddress()).isNull();
	}
	
	@Test
	public void testMapProviderDemoDtoWithInvalidInput() {
		Demographics demographics = createDemographics();
		demographics.getProviderInfo().setGroupFlag(null);
		
		ProviderDemoDTO actual = ProviderDemographicsDataMapper.mapProviderDemoDTO(demographics);
		
		assertNotNull(actual);
		assertThat(actual.getProviderInfo().getGroupFlag()).isNull();
	}
	
	private void assertProviderDemoDtoData(ProviderDemoDTO providerDemoDTO) {

		assertThat(providerDemoDTO.getKey().getClient()).isEqualTo("30");
		assertThat(providerDemoDTO.getKey().getPvdInd()).isEqualTo("H");
		assertThat(providerDemoDTO.getKey().getProv()).isEqualTo("542");
		assertThat(providerDemoDTO.getKey().getMultAddressKey()).isEqualTo("");
		assertThat(providerDemoDTO.getTinEffDt()).isEqualTo(TINEFFDT_VALUE);
		assertThat(providerDemoDTO.getIrsNo()).isEqualTo(IRSNO_VALUE);
		assertThat(providerDemoDTO.getAlphaKey()).isEqualTo(ALPHAKEY_VALUE);
		assertThat(providerDemoDTO.getUpdateSys()).isEqualTo(UPDATESYS_VALUE);
		assertThat(providerDemoDTO.getProviderInfo().getProvName()).isEqualTo(PROVNAME_VALUE);
		assertThat(providerDemoDTO.getProviderInfo().getAddress().getAddr1()).isEqualTo(ADDRESS1_VALUE);
		assertThat(providerDemoDTO.getProviderInfo().getAddress().getAddr2()).isEqualTo(ADDRESS2_VALUE);
		assertThat(providerDemoDTO.getProviderInfo().getAddress().getAddr3()).isEqualTo(ADDRESS3_VALUE);
		assertThat(providerDemoDTO.getProviderInfo().getAddress().getAddr4()).isEqualTo(ADDRESS4_VALUE);
		assertThat(providerDemoDTO.getProviderInfo().getCity()).isEqualTo(CITY_VALUE);
		assertThat(providerDemoDTO.getProviderInfo().getSt()).isEqualTo(ST_VALUE);
		assertThat(providerDemoDTO.getProviderInfo().getZip()).isEqualTo(ZIP_VALUE);
		assertThat(providerDemoDTO.getProviderInfo().getLatitude()).isEqualTo(LATITUDE);
		assertThat(providerDemoDTO.getProviderInfo().getLongitude()).isEqualTo(LONGITUDE);
		assertThat(providerDemoDTO.getProviderInfo().getProvType()).isEqualTo(PROVTYPE_VALUE);
		assertThat(providerDemoDTO.getProviderInfo().getMajClsCd()).isEqualTo(MAJCLSCD_VALUE);
		assertThat(providerDemoDTO.getProviderInfo().getGroupFlag()).isEqualTo(GROUPFLAG_VALUE);
		assertThat(providerDemoDTO.getProviderInfo().getSpecCodes().get(0).getSpecCd()).isEqualTo(SPECCD_VALUE);
		assertThat(providerDemoDTO.getProviderInfo().getPhone()).isEqualTo(PHONE_VALUE);
		assertThat(providerDemoDTO.getProviderInfo().getAdjNo()).isEqualTo(ADJNO_VALUE);
		assertThat(providerDemoDTO.getProviderInfo().getPvdStatus()).isEqualTo(PVDSTATUS_VALUE);
		assertThat(providerDemoDTO.getProviderInfo().getPvdStRc()).isEqualTo(PVDSTRC_VALUE);
		assertThat(providerDemoDTO.getProviderInfo().getActive()).isEqualTo(ACTIVE_VALUE);
		assertThat(providerDemoDTO.getProviderInfo().getArchived()).isEqualTo(ARCHIVED_VALUE);
		assertThat(providerDemoDTO.getProviderInfo().getNoPayCode()).isEqualTo(NOPAYCODE_VALUE);
		assertThat(providerDemoDTO.getProviderInfo().getNoPayDt()).isEqualTo(NOPAYDT_VALUE);
		assertThat(providerDemoDTO.getProviderInfo().getNpiIds().get(0).getNpiId()).isEqualTo(NPIID_VALUE);
		assertThat(providerDemoDTO.getProviderInfo().getTaxonomyCodes().get(0).getTaxonomyCd()).isEqualTo(TAXONOMYCD_VALUE);
	}

}
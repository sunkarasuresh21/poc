
package com.humana.claims.hcaas.provider.demographics.restapi.controller;

import static com.humana.claims.hcaas.provider.demographics.restapi.util.ProviderDemographicsTestData.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.mockito.ArgumentMatchers.any;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsConstants;
import com.humana.claims.hcaas.provider.demographics.core.masker.ProviderDemographicsDataMasker;
import com.humana.claims.hcaas.provider.demographics.restapi.exception.InvalidHeaderCombinationException;
import com.humana.claims.hcaas.provider.demographics.restapi.gen.openapi.model.ProviderDemoDTO;
import com.humana.claims.hcaas.provider.demographics.restapi.model.ProviderDemoGetResponse;
import com.humana.claims.hcaas.provider.demographics.restapi.service.ProviderDemographicsService;
import com.humana.claims.hcaas.provider.demographics.core.model.ProviderDemoGetRequest;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
public class ProviderDemographicsControllerTest {

	@InjectMocks
	private ProviderDemographicsController classUnderTest;

	@Mock
	private ProviderDemographicsService providerDemograhicsService;

	@Mock
	private ProviderDemographicsDataMasker dataMasker;

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdMultiAddressKeyAndProviderIndicatorShouldReturnResponseIncludeCountTrue200() {
		ProviderDemoDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = "H";
		String npiId = null;
		String providerMultiAddressKey = "";
		String providerTaxId = null;
		Boolean includeCount = true;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Mockito.when(providerDemograhicsService.getDemographicsByProviderId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderDemoGetResponse.builder().demographicsDtos(providerDemographicsDtos).totalCount("1").build());
		ResponseEntity<List<ProviderDemoDTO>> actual = classUnderTest.getProviderDemographics(providerId,
				providerIndicator, providerMultiAddressKey, providerTaxId, npiId, limit, offset, statusOrReasonCode,
				majorClassCode, provName, stateCode, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(true);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdMultiAddressKeyAndProviderIndicatorShouldReturnResponseIncludeCountFalse200() {
		ProviderDemoDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = "H";
		String npiId = null;
		String providerMultiAddressKey = "";
		String providerTaxId = null;
		Boolean includeCount = false;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Mockito.when(providerDemograhicsService.getDemographicsByProviderId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderDemoGetResponse.builder().demographicsDtos(providerDemographicsDtos).build());
		ResponseEntity<List<ProviderDemoDTO>> actual = classUnderTest.getProviderDemographics(providerId,
				providerIndicator, providerMultiAddressKey, providerTaxId, npiId, limit, offset, statusOrReasonCode,
				majorClassCode, provName, stateCode, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdMultiAddressKeyAndProviderIndicatorShouldReturnResponseIncludeCountWithNullValue200() {
		ProviderDemoDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = "H";
		String npiId = null;
		String providerMultiAddressKey = "";
		String providerTaxId = null;
		Boolean includeCount = null;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Mockito.when(providerDemograhicsService.getDemographicsByProviderId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderDemoGetResponse.builder().demographicsDtos(providerDemographicsDtos).build());
		ResponseEntity<List<ProviderDemoDTO>> actual = classUnderTest.getProviderDemographics(providerId,
				providerIndicator, providerMultiAddressKey, providerTaxId, npiId, limit, offset, statusOrReasonCode,
				majorClassCode, provName, stateCode, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderTaxIdShouldReturnResponseIncludeCountTrue200() {
		ProviderDemoDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String npiId = null;
		String providerTaxId = "999999999";
		Boolean includeCount = true;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Mockito.when(providerDemograhicsService.getDemographicsByProviderTaxId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderDemoGetResponse.builder().demographicsDtos(providerDemographicsDtos).build());

		ResponseEntity<List<ProviderDemoDTO>> actual = classUnderTest.getProviderDemographics(providerId,
				providerIndicator, providerMultiAddressKey, providerTaxId, npiId, limit, offset, statusOrReasonCode,
				majorClassCode, provName, stateCode, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(true);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderTaxIdShouldReturnResponseIncludeCountFalse200() {
		ProviderDemoDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String npiId = null;
		String providerTaxId = "999999999";
		Boolean includeCount = false;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Mockito.when(providerDemograhicsService.getDemographicsByProviderTaxId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderDemoGetResponse.builder().demographicsDtos(providerDemographicsDtos).build());

		ResponseEntity<List<ProviderDemoDTO>> actual = classUnderTest.getProviderDemographics(providerId,
				providerIndicator, providerMultiAddressKey, providerTaxId, npiId, limit, offset, statusOrReasonCode,
				majorClassCode, provName, stateCode, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderTaxIdShouldReturnResponseIncludeCountWithNullValue200() {
		ProviderDemoDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String npiId = null;
		String providerTaxId = "999999999";
		Boolean includeCount = null;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Mockito.when(providerDemograhicsService.getDemographicsByProviderTaxId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderDemoGetResponse.builder().demographicsDtos(providerDemographicsDtos).build());

		ResponseEntity<List<ProviderDemoDTO>> actual = classUnderTest.getProviderDemographics(providerId,
				providerIndicator, providerMultiAddressKey, providerTaxId, npiId, limit, offset, statusOrReasonCode,
				majorClassCode, provName, stateCode, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdShouldReturnResponseIncludeCountTrue200() {
		ProviderDemoDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = null;
		String npiId = null;
		String providerMultiAddressKey = null;
		String providerTaxId = null;
		Boolean includeCount = true;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Mockito.when(providerDemograhicsService.getDemographicsByProviderId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderDemoGetResponse.builder().demographicsDtos(providerDemographicsDtos).build());

		ResponseEntity<List<ProviderDemoDTO>> actual = classUnderTest.getProviderDemographics(providerId,
				providerIndicator, providerMultiAddressKey, providerTaxId, npiId, limit, offset, statusOrReasonCode,
				majorClassCode, provName, stateCode, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(true);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdShouldReturnResponseIncludeCountFalse200() {
		ProviderDemoDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = null;
		String npiId = null;
		String providerMultiAddressKey = null;
		String providerTaxId = null;
		Boolean includeCount = false;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Mockito.when(providerDemograhicsService.getDemographicsByProviderId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderDemoGetResponse.builder().demographicsDtos(providerDemographicsDtos).build());

		ResponseEntity<List<ProviderDemoDTO>> actual = classUnderTest.getProviderDemographics(providerId,
				providerIndicator, providerMultiAddressKey, providerTaxId, npiId, limit, offset, statusOrReasonCode,
				majorClassCode, provName, stateCode, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdShouldReturnResponseIncludeCountDefault200() {
		ProviderDemoDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = null;
		String npiId = null;
		String providerMultiAddressKey = null;
		String providerTaxId = null;
		Boolean includeCount = null;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Mockito.when(providerDemograhicsService.getDemographicsByProviderId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderDemoGetResponse.builder().demographicsDtos(providerDemographicsDtos).build());

		ResponseEntity<List<ProviderDemoDTO>> actual = classUnderTest.getProviderDemographics(providerId,
				providerIndicator, providerMultiAddressKey, providerTaxId, npiId, limit, offset, statusOrReasonCode,
				majorClassCode, provName, stateCode, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdAndIndicatorShouldReturnResponseIncludeCountTrue200() {
		ProviderDemoDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = "H";
		String providerMultiAddressKey = null;
		String providerTaxId = null;
		String npiId = null;
		Boolean includeCount = true;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Mockito.when(providerDemograhicsService.getDemographicsByProviderId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderDemoGetResponse.builder().demographicsDtos(providerDemographicsDtos).build());

		ResponseEntity<List<ProviderDemoDTO>> actual = classUnderTest.getProviderDemographics(providerId,
				providerIndicator, providerMultiAddressKey, providerTaxId, npiId, limit, offset, statusOrReasonCode,
				majorClassCode, provName, stateCode, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(true);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdAndIndicatorShouldReturnResponseIncludeCountFalse200() {
		ProviderDemoDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = "H";
		String providerMultiAddressKey = null;
		String providerTaxId = null;
		String npiId = null;
		Boolean includeCount = false;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Mockito.when(providerDemograhicsService.getDemographicsByProviderId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderDemoGetResponse.builder().demographicsDtos(providerDemographicsDtos).build());

		ResponseEntity<List<ProviderDemoDTO>> actual = classUnderTest.getProviderDemographics(providerId,
				providerIndicator, providerMultiAddressKey, providerTaxId, npiId, limit, offset, statusOrReasonCode,
				majorClassCode, provName, stateCode, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdAndIndicatorShouldReturnResponseIncludeCountWithNullValue200() {
		ProviderDemoDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = "H";
		String providerMultiAddressKey = null;
		String providerTaxId = null;
		String npiId = null;
		Boolean includeCount = null;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Mockito.when(providerDemograhicsService.getDemographicsByProviderId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderDemoGetResponse.builder().demographicsDtos(providerDemographicsDtos).demographicsDtos(providerDemographicsDtos).build());

		ResponseEntity<List<ProviderDemoDTO>> actual = classUnderTest.getProviderDemographics(providerId,
				providerIndicator, providerMultiAddressKey, providerTaxId, npiId, limit, offset, statusOrReasonCode,
				majorClassCode, provName, stateCode, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingNpiIdShouldReturnResponseIncludeCountFalse200() {
		ProviderDemoDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String npiId = "999999999";
		String providerTaxId = null;
		Boolean includeCount = false;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Mockito.when(providerDemograhicsService.getDemographicsByProviderNpiId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderDemoGetResponse.builder().demographicsDtos(providerDemographicsDtos).build());

		ResponseEntity<List<ProviderDemoDTO>> actual = classUnderTest.getProviderDemographics(providerId,
				providerIndicator, providerMultiAddressKey, providerTaxId, npiId, limit, offset, statusOrReasonCode,
				majorClassCode, provName, stateCode, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingNpiIdShouldReturnResponseIncludeCountWithNullValue200() {
		ProviderDemoDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String npiId = "999999999";
		String providerTaxId = null;
		Boolean includeCount = null;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Mockito.when(providerDemograhicsService.getDemographicsByProviderNpiId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderDemoGetResponse.builder().demographicsDtos(providerDemographicsDtos).build());

		ResponseEntity<List<ProviderDemoDTO>> actual = classUnderTest.getProviderDemographics(providerId,
				providerIndicator, providerMultiAddressKey, providerTaxId, npiId, limit, offset, statusOrReasonCode,
				majorClassCode, provName, stateCode, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingNpiIdShouldReturnResponseIncludeCountTrue200() {
		ProviderDemoDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String npiId = "999999999";
		String providerTaxId = null;
		Boolean includeCount = true;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Mockito.when(providerDemograhicsService.getDemographicsByProviderNpiId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderDemoGetResponse.builder().demographicsDtos(providerDemographicsDtos).totalCount("1").build());

		ResponseEntity<List<ProviderDemoDTO>> actual = classUnderTest.getProviderDemographics(providerId,
				providerIndicator, providerMultiAddressKey, providerTaxId, npiId, limit, offset, statusOrReasonCode,
				majorClassCode, provName, stateCode, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(true);
	}
	
	@Test
	@SneakyThrows
	public void validCombinationHavingProvNameShouldReturnResponseIncludeCountWithNullValue200() {
		ProviderDemoDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String npiId = null;
		String providerTaxId = null;
		Boolean includeCount = null;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Mockito.when(providerDemograhicsService.getDemographicsByProvName(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderDemoGetResponse.builder().demographicsDtos(providerDemographicsDtos).build());

		ResponseEntity<List<ProviderDemoDTO>> actual = classUnderTest.getProviderDemographics(providerId,
				providerIndicator, providerMultiAddressKey, providerTaxId, npiId, limit, offset, statusOrReasonCode,
				majorClassCode, provName, stateCode, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProvNameShouldReturnResponseIncludeCountTrue200() {
		ProviderDemoDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String npiId = null;
		String providerTaxId = null;
		Boolean includeCount = true;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Mockito.when(providerDemograhicsService.getDemographicsByProvName(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderDemoGetResponse.builder().demographicsDtos(providerDemographicsDtos).totalCount("1").build());

		ResponseEntity<List<ProviderDemoDTO>> actual = classUnderTest.getProviderDemographics(providerId,
				providerIndicator, providerMultiAddressKey, providerTaxId, npiId, limit, offset, statusOrReasonCode,
				majorClassCode, provName, stateCode, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(true);
	}

	@Test
	@SneakyThrows
	public void invalidCombinationHavingOnlyOptionalFiltersShouldReturnBadRequest() {
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = "H";
		String providerMultiAddressKey = "S";
		String npiId = null;
		String providerTaxId = null;
		Boolean includeCount = false;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = null;
		String stateCode = "A";
		Throwable actualThrown = catchThrowable(() -> classUnderTest.getProviderDemographics(providerId,
				providerIndicator, providerMultiAddressKey, providerTaxId, npiId, limit, offset, statusOrReasonCode,
				majorClassCode, provName, stateCode, includeCount));
		assertThat(actualThrown).isInstanceOf(InvalidHeaderCombinationException.class);
	}



}

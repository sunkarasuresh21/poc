
package com.humana.claims.hcaas.provider.demographics.restapi.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.humana.claims.hcaas.provider.demographics.core.dao.ProviderDemographicsDAO;
import com.humana.claims.hcaas.provider.demographics.core.model.DemographicsDBResponse;
import com.humana.claims.hcaas.provider.demographics.core.model.ProviderDemoGetRequest;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.demographics.core.model.db.DemographicsKey;
import com.humana.claims.hcaas.provider.demographics.core.model.db.NpiInfos;
import com.humana.claims.hcaas.provider.demographics.core.model.db.ProviderInfo;
import com.humana.claims.hcaas.provider.demographics.core.validator.ProviderDemographicsValidator;
import com.humana.claims.hcaas.provider.demographics.restapi.exception.NotFoundException;
import com.humana.claims.hcaas.provider.demographics.restapi.model.ProviderDemoGetResponse;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
public class ProviderDemographicsServiceImplTest {

	@InjectMocks
	private ProviderDemographicsServiceImpl classUnderTest;

	@Mock
	private ProviderDemographicsDAO providerDemographicsDAO;

	@Mock
	private ProviderDemographicsValidator providerDemographicsValidator;

	@Test
	@SneakyThrows
	public void testNotFoundExceptionForGetDemographicsByProviderIdAndOptionalFields() {

		ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().providerId("999999999")
				.providerIndicator("H").providerMultiAddressKey(" ").majorClassCode("A").limit(1000).offset(1).build();

		Map<String, String> queryMap = new LinkedHashMap<String, String>();

		Mockito.when((providerDemographicsValidator.validateByProviderId(provDemoGetReq))).thenReturn(queryMap);
		Mockito.when((providerDemographicsDAO.getDemographicsByProviderId(queryMap, 1000, 1, false)))
				.thenReturn(DemographicsDBResponse.builder().build());

		Throwable actualThrown = catchThrowable(() -> classUnderTest.getDemographicsByProviderId(provDemoGetReq));

		assertThat(actualThrown).isInstanceOf(NotFoundException.class);
	}

	@Test
	@SneakyThrows
	public void testGetDemographicsByProviderIdAndOptionalFieldsSuccessScenario() {

		ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().providerId("999999999")
				.providerIndicator("H").providerMultiAddressKey(" ").majorClassCode("A").limit(1000).offset(1).build();

		Map<String, String> queryMap = new LinkedHashMap<String, String>();
		Demographics demographics = new Demographics();
		DemographicsKey demographicsKey = new DemographicsKey();
		demographicsKey.setProv("123456789");
		demographics.setKey(demographicsKey);

		Mockito.when((providerDemographicsValidator.validateByProviderId(provDemoGetReq))).thenReturn(queryMap);
		Mockito.when((providerDemographicsDAO.getDemographicsByProviderId(queryMap, 1000, 1, false))).thenReturn(
				DemographicsDBResponse.builder().demographics(Arrays.asList(demographics)).totalCount("1").build());

		ProviderDemoGetResponse demographicResponseObj = classUnderTest.getDemographicsByProviderId(provDemoGetReq);

		assertEquals(demographicResponseObj.getDemographicsDtos().size(), 1);
		assertEquals(demographicResponseObj.getDemographicsDtos().get(0).getKey().getProv(), "123456789");
		assertEquals(demographicResponseObj.getTotalCount(), "1");
	}

	@Test
	@SneakyThrows
	public void testNotFoundExceptionForGetDemographicsByProviderTaxIdAndOptionalFields() {

		ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().providerTaxId("000000011").limit(1000)
				.offset(1).build();

		Map<String, String> queryMap = new LinkedHashMap<String, String>();

		Mockito.when((providerDemographicsValidator.validateByProviderTaxId(provDemoGetReq))).thenReturn(queryMap);
		Mockito.when((providerDemographicsDAO.getDemographicsByProviderTaxId(queryMap, 1000, 1, false)))
				.thenReturn(DemographicsDBResponse.builder().build());

		Throwable actualThrown = catchThrowable(() -> classUnderTest.getDemographicsByProviderTaxId(provDemoGetReq));

		assertThat(actualThrown).isInstanceOf(NotFoundException.class);
	}

	@Test
	@SneakyThrows
	public void testGetDemographicsByProviderTaxIdAndOptionalFieldsSuccessScenario() {

		ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().providerTaxId("000000011").limit(1000)
				.offset(1).build();

		Map<String, String> queryMap = new LinkedHashMap<String, String>();
		Demographics demographics = new Demographics();
		demographics.setIrsNo("000000011");

		Mockito.when((providerDemographicsValidator.validateByProviderTaxId(provDemoGetReq))).thenReturn(queryMap);
		Mockito.when((providerDemographicsDAO.getDemographicsByProviderTaxId(queryMap, 1000, 1, false))).thenReturn(
				DemographicsDBResponse.builder().demographics(Arrays.asList(demographics)).totalCount("1").build());

		ProviderDemoGetResponse demographicResponseObj = classUnderTest.getDemographicsByProviderTaxId(provDemoGetReq);

		assertEquals(demographicResponseObj.getDemographicsDtos().size(), 1);
		assertEquals(demographicResponseObj.getDemographicsDtos().get(0).getIrsNo(), "000000011");
		assertEquals(demographicResponseObj.getTotalCount(), "1");
	}

	@Test
	@SneakyThrows
	public void testNotFoundExceptionForGetDemographicsByProviderNpiIdAndOptionalFields() {

		ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().npiId("0000000111").limit(1000)
				.offset(1).build();

		Map<String, String> queryMap = new LinkedHashMap<String, String>();

		Mockito.when((providerDemographicsValidator.validateByNpiId(provDemoGetReq))).thenReturn(queryMap);
		Mockito.when((providerDemographicsDAO.getDemographicsByNpiId(queryMap, 1000, 1, false)))
				.thenReturn(DemographicsDBResponse.builder().build());

		Throwable actualThrown = catchThrowable(() -> classUnderTest.getDemographicsByProviderNpiId(provDemoGetReq));

		assertThat(actualThrown).isInstanceOf(NotFoundException.class);
	}

	@Test
	@SneakyThrows
	public void testGetDemographicsByNpiIdAndOptionalFieldsSuccessScenario() {

		ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().npiId("0000000111").limit(1000)
				.offset(1).build();

		Map<String, String> queryMap = new LinkedHashMap<String, String>();
		Demographics demographics = new Demographics();
		ProviderInfo providerInfo = new ProviderInfo();
		NpiInfos npiInfos = new NpiInfos();
		npiInfos.setNpiId("1234567890");
		providerInfo.setNpiIds(Arrays.asList(npiInfos));
		demographics.setProviderInfo((providerInfo));

		Mockito.when((providerDemographicsValidator.validateByNpiId(provDemoGetReq))).thenReturn(queryMap);
		Mockito.when((providerDemographicsDAO.getDemographicsByNpiId(queryMap, 1000, 1, false))).thenReturn(
				DemographicsDBResponse.builder().demographics(Arrays.asList(demographics)).totalCount("1").build());

		ProviderDemoGetResponse demographicResponseObj = classUnderTest.getDemographicsByProviderNpiId(provDemoGetReq);

		assertEquals(demographicResponseObj.getDemographicsDtos().size(), 1);
		assertEquals(demographicResponseObj.getDemographicsDtos().get(0).getProviderInfo().getNpiIds().get(0).getNpiId(), "1234567890");
		assertEquals(demographicResponseObj.getTotalCount(), "1");
	}

	@Test
	@SneakyThrows
	public void testNotFoundExceptionForGetDemographicsByProvNameAndOptionalFields() {

		ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().provName("NORTHERN HOSPITAL")
				.limit(1000).offset(1).build();

		Map<String, String> queryMap = new LinkedHashMap<String, String>();

		Mockito.when((providerDemographicsValidator.validateByProvName(provDemoGetReq))).thenReturn(queryMap);
		Mockito.when((providerDemographicsDAO.getDemographicsByProvName(queryMap, 1000, 1, false)))
				.thenReturn(DemographicsDBResponse.builder().build());

		Throwable actualThrown = catchThrowable(() -> classUnderTest.getDemographicsByProvName(provDemoGetReq));

		assertThat(actualThrown).isInstanceOf(NotFoundException.class);
	}

	@Test
	@SneakyThrows
	public void testGetDemographicsByProvNameAndOptionalFieldsSuccessScenario() {

		ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().provName("NORTHERN HOSPITAL")
				.limit(1000).offset(1).build();

		Map<String, String> queryMap = new LinkedHashMap<String, String>();
		Demographics demographics = new Demographics();
		ProviderInfo providerInfo = new ProviderInfo();
		providerInfo.setProvName("NORTHERN HOSPITAL");
		demographics.setProviderInfo((providerInfo));

		Mockito.when((providerDemographicsValidator.validateByProvName(provDemoGetReq))).thenReturn(queryMap);
		Mockito.when((providerDemographicsDAO.getDemographicsByProvName(queryMap, 1000, 1, false))).thenReturn(
				DemographicsDBResponse.builder().demographics(Arrays.asList(demographics)).totalCount("1").build());

		ProviderDemoGetResponse demographicResponseObj = classUnderTest.getDemographicsByProvName(provDemoGetReq);

		assertEquals(demographicResponseObj.getDemographicsDtos().size(), 1);
		assertEquals(demographicResponseObj.getDemographicsDtos().get(0).getProviderInfo().getProvName(), "NORTHERN HOSPITAL");
		assertEquals(demographicResponseObj.getTotalCount(), "1");
	}

}

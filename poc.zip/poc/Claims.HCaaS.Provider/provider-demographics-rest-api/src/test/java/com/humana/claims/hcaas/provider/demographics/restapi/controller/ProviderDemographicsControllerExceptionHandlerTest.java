
package com.humana.claims.hcaas.provider.demographics.restapi.controller;

import static com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsErrorConstants.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.humana.claims.hcaas.common.rest.api.starter.enumerrorcode.ErrorCode;
import com.humana.claims.hcaas.provider.demographics.core.exception.InvalidRequestException;
import com.humana.claims.hcaas.provider.demographics.core.masker.ProviderDemographicsDataMasker;
import com.humana.claims.hcaas.provider.demographics.core.model.ProviderDemoGetRequest;
import com.humana.claims.hcaas.provider.demographics.core.validator.ProviderDemographicsValidator;
import com.humana.claims.hcaas.provider.demographics.restapi.exception.NotFoundException;
import com.humana.claims.hcaas.provider.demographics.restapi.service.ProviderDemographicsService;

import lombok.SneakyThrows;

@ExtendWith(SpringExtension.class)
@WebMvcTest(ProviderDemographicsController.class)

@TestPropertySource("classpath:test-application.properties")
public class ProviderDemographicsControllerExceptionHandlerTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private ProviderDemographicsService providerDemographicsService;

	@MockBean
	private ProviderDemographicsValidator providerValidator;

	@MockBean
	private ProviderDemographicsDataMasker dataMasker;

	@Test

	@SneakyThrows
	public void test_v1BetaProviderDemographicsWhenInvalidHeaderExceptionPassed() {
		this.mockMvc.perform(get("/v1/providers/demographics")).andDo(print()).andExpect(status().isBadRequest())
		.andExpect(MockMvcResultMatchers.jsonPath("$.errorCode").value(ErrorCode.BAD_REQUEST.toString()));
	}

	@Test
	@SneakyThrows
	public void test_v1BetaProviderDemographicsWhenInvalidHeaderPassed() {
		Set<String> errorMessagesSet = new HashSet<>();
		errorMessagesSet.add(NO_RECORD_FOUND);

		when(providerDemographicsService.getDemographicsByProviderId(any(ProviderDemoGetRequest.class)))
				.thenThrow(new NotFoundException(errorMessagesSet));

		this.mockMvc.perform(
				get("/v1/providers/demographics").header("provider-id", "999999999").header("majorClassCode", "A"))
				.andDo(print()).andExpect(status().isBadRequest())
				.andExpect(MockMvcResultMatchers.jsonPath("$.errorCode").value(ErrorCode.NOT_FOUND.toString()));
	}

	@Test
	@SneakyThrows
	public void test_v1BetaProviderDemographicsWhenInvalidRequestPassed() {
		Set<String> errorMessagesSet = new HashSet<>();
		errorMessagesSet.add(INVALID_PROVIDER_ID);

		when(providerDemographicsService.getDemographicsByProviderId(any(ProviderDemoGetRequest.class)))
				.thenThrow(new InvalidRequestException(errorMessagesSet));

		this.mockMvc.perform(
				get("/v1/providers/demographics").header("provider-id", "123").header("majorClassCode", "A"))
				.andDo(print()).andExpect(status().isBadRequest())
				.andExpect(MockMvcResultMatchers.jsonPath("$.errorCode").value(ErrorCode.BAD_REQUEST.toString()));
	}

	@Test
	@SneakyThrows
	public void test_v1BetaProviderDemographicsWhenItThrowsInternalServerError() {
		Set<String> errorMessagesSet = new HashSet<>();
		errorMessagesSet.add(INVALID_MAJOR_CLASSCODE);
		when(providerDemographicsService.getDemographicsByProviderId(any(ProviderDemoGetRequest.class)))
				.thenThrow(new InvalidRequestException(errorMessagesSet));

		this.mockMvc.perform(
				get("/v1/providers/demographics").header("provider-id", "123").header("majorClassCode", "A"))
				.andDo(print()).andExpect(status().isBadRequest())
				.andExpect(MockMvcResultMatchers.jsonPath("$.errorCode").value(ErrorCode.BAD_REQUEST.toString()));
	}
}

package com.humana.claims.hcaas.provider.demographics.restapi.util;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.humana.claims.hcaas.provider.demographics.core.model.db.Address;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.demographics.core.model.db.DemographicsKey;
import com.humana.claims.hcaas.provider.demographics.core.model.db.NpiInfos;
import com.humana.claims.hcaas.provider.demographics.core.model.db.ProviderInfo;
import com.humana.claims.hcaas.provider.demographics.core.model.db.SpecCode;
import com.humana.claims.hcaas.provider.demographics.core.model.db.TaxonomyCode;
import com.humana.claims.hcaas.provider.demographics.restapi.gen.openapi.model.ProviderDemoDTO;
import com.humana.claims.hcaas.provider.demographics.restapi.gen.openapi.model.ProviderDemoKeyDTO;
import com.humana.claims.hcaas.provider.demographics.restapi.gen.openapi.model.ProviderDemoProviderInfoAddressDTO;
import com.humana.claims.hcaas.provider.demographics.restapi.gen.openapi.model.ProviderDemoProviderInfoDTO;
import com.humana.claims.hcaas.provider.demographics.restapi.gen.openapi.model.ProviderDemoProviderInfoNpiIdsDTO;
import com.humana.claims.hcaas.provider.demographics.restapi.gen.openapi.model.ProviderDemoProviderInfoSpecCodesDTO;
import com.humana.claims.hcaas.provider.demographics.restapi.gen.openapi.model.ProviderDemoProviderInfoTaxonomyCodesDTO;

public class ProviderDemographicsTestData {
	
	private ProviderDemographicsTestData() {

	}
	
	public static final String CLIENT_VALUE = "30";
	public static final String PVDIND_VALUE = "H"; 	
	public static final String PROV_VALUE = "542";
	public static final String MULTADDRESSKEY_VALUE = ""; 
	
	public static final LocalDate TINEFFDT_VALUE = LocalDate.of(2020, 4, 21);
	public static final String IRSNO_VALUE = "999999999";
	public static final String ALPHAKEY_VALUE = "alpha key test";
	public static final String UPDATESYS_VALUE = "N";
	public static final String PROVNAME_VALUE = "PALMS OF PASADENA HOSPITAL";
	public static final String ADDRESS1_VALUE = "1501 PASADENA SOUTH";
	public static final String ADDRESS2_VALUE = "addr2";
	public static final String ADDRESS3_VALUE = "addr3";
	public static final String ADDRESS4_VALUE = "addr4";
	public static final String CITY_VALUE = "ST PETERSBURG";
	public static final String ST_VALUE = "FL";
	public static final String ZIP_VALUE = "33707";
	public static final Double LATITUDE = 38.25824738029149;
	public static final Double LONGITUDE = -85.75404721970848 ;
	public static final String PROVTYPE_VALUE = "HS";
	public static final String MAJCLSCD_VALUE = "A";
	public static final String GROUPFLAG_VALUE = "groupFlag";
	public static final String SPECCD_VALUE = "82";
	public static final String PHONE_VALUE = "0000000000";
	public static final String ADJNO_VALUE = "ONESHOT";
	public static final LocalDate CHGDT_VALUE = LocalDate.of(2020, 6, 26);
	public static final String PVDSTATUS_VALUE = "0";
	public static final String PVDSTRC_VALUE = " ";
	public static final Boolean ACTIVE_VALUE = null;
	public static final Boolean ARCHIVED_VALUE = null;
	public static final String NOPAYCODE_VALUE = "noPayCode";
	public static final LocalDate NOPAYDT_VALUE = LocalDate.of(2020, 4, 21);
	public static final String NPIID_VALUE = "1234567890";
	public static final String TAXONOMYCD_VALUE = "1234567890";
	
	
	public static ProviderDemoDTO createProviderDemoDTO() {
		return new ProviderDemoDTO()
				.key(createProviderDemoKeyDTO())
				.tinEffDt(TINEFFDT_VALUE)
				.irsNo(IRSNO_VALUE)
				.updateSys(UPDATESYS_VALUE)
				.providerInfo(createProviderDemoProviderInfoDTO());
	}
	private static ProviderDemoKeyDTO createProviderDemoKeyDTO() {
		return new ProviderDemoKeyDTO()
				.client(CLIENT_VALUE)
				.pvdInd(PVDIND_VALUE)
				.prov(PROV_VALUE)
				.multAddressKey(MULTADDRESSKEY_VALUE);
	}
	private static ProviderDemoProviderInfoDTO createProviderDemoProviderInfoDTO() {
		return new ProviderDemoProviderInfoDTO()
				.provName(PROVNAME_VALUE)
				.address(createProviderDemoProviderInfoAddressDTO())
				.city(CITY_VALUE)
				.st(ST_VALUE)
				.zip(ZIP_VALUE)
				.latitude(LATITUDE)
				.longitude(LONGITUDE)
				.provType(PROVTYPE_VALUE)
				.majClsCd(MAJCLSCD_VALUE)
				.groupFlag(GROUPFLAG_VALUE)
				.specCodes(createProviderDemoProviderInfoSpecCodesDTOList())
				.phone(PHONE_VALUE)
				.adjNo(ADJNO_VALUE)
				.chgDt(CHGDT_VALUE)
				.pvdStatus(PVDSTATUS_VALUE)
				.pvdStRc(PVDSTRC_VALUE)
				.active(ACTIVE_VALUE)
				.archived(ARCHIVED_VALUE)
				.noPayCode(NOPAYCODE_VALUE)
				.noPayDt(NOPAYDT_VALUE)
				.npiIds(createProviderDemoProviderInfoNpiIdsDTOList())
				.taxonomyCodes(createProviderDemoProviderInfoTaxonomyCodesDTOList());
	}
	private static ProviderDemoProviderInfoAddressDTO createProviderDemoProviderInfoAddressDTO() {
		return new ProviderDemoProviderInfoAddressDTO()
				.addr1(ADDRESS1_VALUE)
				.addr2(ADDRESS2_VALUE)
				.addr3(ADDRESS3_VALUE)
				.addr4(ADDRESS4_VALUE);
	}
	private static List<ProviderDemoProviderInfoSpecCodesDTO> createProviderDemoProviderInfoSpecCodesDTOList() {
		List<ProviderDemoProviderInfoSpecCodesDTO> specCodes = new ArrayList<>();
		ProviderDemoProviderInfoSpecCodesDTO specCodeDto = new ProviderDemoProviderInfoSpecCodesDTO();
		specCodeDto.setSpecCd(SPECCD_VALUE);
		specCodes.add(specCodeDto);
		return specCodes;
	}	
	private static List<ProviderDemoProviderInfoNpiIdsDTO> createProviderDemoProviderInfoNpiIdsDTOList() {
		List<ProviderDemoProviderInfoNpiIdsDTO> npiIds = new ArrayList<>();
		ProviderDemoProviderInfoNpiIdsDTO npiIdDto = new ProviderDemoProviderInfoNpiIdsDTO();
		npiIdDto.setNpiId(NPIID_VALUE);
		npiIds.add(npiIdDto);
		return npiIds;
	}
	private static List<ProviderDemoProviderInfoTaxonomyCodesDTO> createProviderDemoProviderInfoTaxonomyCodesDTOList() {
		List<ProviderDemoProviderInfoTaxonomyCodesDTO> taxonomyCodes = new ArrayList<>();
		ProviderDemoProviderInfoTaxonomyCodesDTO taxonomyCodeDto = new ProviderDemoProviderInfoTaxonomyCodesDTO();
		taxonomyCodeDto.setTaxonomyCd(TAXONOMYCD_VALUE);
		taxonomyCodes.add(taxonomyCodeDto);
		return taxonomyCodes;
	}
	
	
	public static Demographics createDemographics() {
		Demographics demographics = new Demographics();
		demographics.setKey(createKey());
		demographics.setTinEffDt(TINEFFDT_VALUE);
		demographics.setIrsNo(IRSNO_VALUE);
		demographics.setAlphaKey(ALPHAKEY_VALUE);
		demographics.setUpdateSys(UPDATESYS_VALUE);
		demographics.setPvdStatus(PVDSTATUS_VALUE);
		demographics.setProviderInfo(createProviderInfo());
		return demographics;
	}
	private static DemographicsKey createKey() {
		DemographicsKey demographicsKey = new DemographicsKey();
		demographicsKey.setClient(CLIENT_VALUE);
		demographicsKey.setPvdInd(PVDIND_VALUE);
		demographicsKey.setProv(PROV_VALUE);
		demographicsKey.setMultAddressKey(MULTADDRESSKEY_VALUE);
		return demographicsKey;
	}
	private static ProviderInfo createProviderInfo() {
		ProviderInfo providerInfo = new ProviderInfo();
		providerInfo.setProvName(PROVNAME_VALUE);
		providerInfo.setAddress(createAddress());
		providerInfo.setCity(CITY_VALUE);
		providerInfo.setSt(ST_VALUE);
		providerInfo.setZip(ZIP_VALUE);
		providerInfo.setLatitude(LATITUDE);
		providerInfo.setLongitude(LONGITUDE);
		providerInfo.setProvType(PROVTYPE_VALUE);
		providerInfo.setMajClsCd(MAJCLSCD_VALUE);
		providerInfo.setGroupFlag(GROUPFLAG_VALUE);
		providerInfo.setSpecCodes(createSpecCodeList());
		providerInfo.setPhone(PHONE_VALUE);
		providerInfo.setAdjNo(ADJNO_VALUE);
		providerInfo.setChgDt(CHGDT_VALUE);
		providerInfo.setPvdStRc(PVDSTRC_VALUE);
		providerInfo.setActive(ACTIVE_VALUE);
		providerInfo.setArchived(ARCHIVED_VALUE);
		providerInfo.setPrvNoPay(NOPAYCODE_VALUE);
		providerInfo.setPrvNoPayDt(NOPAYDT_VALUE);
		providerInfo.setNpiIds(createNpiIdList());
		providerInfo.setTaxonomyCodes(createTaxonomyCodeList());
		return providerInfo;
	}
	private static Address createAddress() {
		Address address = new Address();
		address.setAddr1(ADDRESS1_VALUE);
		address.setAddr2(ADDRESS2_VALUE);
		address.setAddr3(ADDRESS3_VALUE);
		address.setAddr4(ADDRESS4_VALUE);
		return address;
	}
	private static List<SpecCode> createSpecCodeList() {
		List<SpecCode> specCodes = new ArrayList<>();
		SpecCode specCode = new SpecCode();
		specCode.setSpecCd(SPECCD_VALUE);
		specCodes.add(specCode);
		return specCodes;
	}
	private static List<NpiInfos> createNpiIdList() {
		List<NpiInfos> npiIds = new ArrayList<>();
		NpiInfos npiInfos = new NpiInfos();
		npiInfos.setNpiId(NPIID_VALUE);
		npiIds.add(npiInfos);
		return npiIds;
	}
	private static List<TaxonomyCode> createTaxonomyCodeList() {
		List<TaxonomyCode> taxonomyCodes = new ArrayList<>();
		TaxonomyCode taxonomyCode = new TaxonomyCode();
		taxonomyCode.setTaxonomyCd(TAXONOMYCD_VALUE);
		taxonomyCodes.add(taxonomyCode);
		return taxonomyCodes;
	}

}
package com.humana.claims.hcaas.provider.demographics.restapi.controller;


import static com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsErrorConstants.INVALID_HEADER_COMBINATION;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.humana.claims.hcaas.common.utils.logging.LogUtils;
import com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsConstants;
import com.humana.claims.hcaas.provider.demographics.core.masker.ProviderDemographicsDataMasker;
import com.humana.claims.hcaas.provider.demographics.core.model.ProviderDemoGetRequest;
import com.humana.claims.hcaas.provider.demographics.core.util.StringUtils;
import com.humana.claims.hcaas.provider.demographics.restapi.exception.InvalidHeaderCombinationException;
import com.humana.claims.hcaas.provider.demographics.restapi.gen.openapi.V1Api;
import com.humana.claims.hcaas.provider.demographics.restapi.gen.openapi.model.ProviderDemoDTO;
import com.humana.claims.hcaas.provider.demographics.restapi.model.ProviderDemoGetResponse;
import com.humana.claims.hcaas.provider.demographics.restapi.service.ProviderDemographicsService;

import lombok.extern.slf4j.Slf4j;

@RestController
@ComponentScan(basePackages = "com.humana.claims.hcaas.provider.demographics.restapi")
@Slf4j
public class ProviderDemographicsController implements V1Api {

	@Autowired
	private ProviderDemographicsService providerDemograhicsService;
	
	@Autowired
	private ProviderDemographicsDataMasker dataMasker;
	
	@Override
	public ResponseEntity<List<ProviderDemoDTO>> getProviderDemographics(String providerId,
			String providerIndicator, String providerMultiAddressKey, String providerTaxId, String npiId, Integer limit,
			Integer offset,  String statusOrReasonCode, String majorClassCode, String provName,String stateCode,Boolean includeCount) throws Exception {
		
		logIncomingRequest(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, npiId, limit, offset,
				statusOrReasonCode, majorClassCode, provName, stateCode, includeCount);
		
		ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().providerId(providerId).providerIndicator(providerIndicator).providerMultiAddressKey(providerMultiAddressKey)
		.providerTaxId(providerTaxId).npiId(npiId).limit(limit).offset(offset).statusOrReasonCode(statusOrReasonCode).majorClassCode(majorClassCode).
		provName(provName).stateCode(stateCode).includeCount(includeCount).build();
				
		if (null != providerId) {
			
			provDemoGetReq.setProviderMultiAddressKey(StringUtils.replaceBlankStringToSingleWhiteSpace(provDemoGetReq.getProviderMultiAddressKey()));
			ProviderDemoGetResponse demographicsResponseObj = providerDemograhicsService.getDemographicsByProviderId(provDemoGetReq);
			return buildAndReturnResponse(demographicsResponseObj, provDemoGetReq.getIncludeCount());
			
		} else if (null != providerTaxId) {
			
			ProviderDemoGetResponse demographicsResponseObj = providerDemograhicsService.getDemographicsByProviderTaxId(provDemoGetReq);
			return buildAndReturnResponse(demographicsResponseObj, provDemoGetReq.getIncludeCount());
			
		} else if (null != npiId) {
			
			ProviderDemoGetResponse demographicsResponseObj = providerDemograhicsService.getDemographicsByProviderNpiId(provDemoGetReq);
			return buildAndReturnResponse(demographicsResponseObj, provDemoGetReq.getIncludeCount());
			
		} else if (null != provName) {
			
			ProviderDemoGetResponse demographicsResponseObj = providerDemograhicsService.getDemographicsByProvName(provDemoGetReq);
			return buildAndReturnResponse(demographicsResponseObj, provDemoGetReq.getIncludeCount());
			
		} else {
			
			Set<String> errorMessages = new HashSet<>();
			errorMessages.add(INVALID_HEADER_COMBINATION);
			throw new InvalidHeaderCombinationException(errorMessages);
			
		}
		
	}
	
	@SuppressWarnings("all")
	private void logIncomingRequest(String providerId,
			String providerIndicator, String providerMultiAddressKey, String providerTaxId, String npiId, Integer limit,
			Integer offset,  String statusOrReasonCode, String majorClassCode, String provName,String stateCode,Boolean includeCount) {
		LogUtils.logAtInfo(log, "providerId: {}, providerIndicator: {}, providerMultiAddressKey: {}, providerTaxId: {}, npiId: {}, limit: {}, offset: {}, statusOrReasonCode: {}, majorClassCode: {}, provName: {}, stateCode: {}, includeCount: {}", 
				dataMasker.maskProviderId(providerId), providerIndicator, providerMultiAddressKey, dataMasker.maskIrsNo(providerTaxId), dataMasker.maskNpiId(npiId),
				limit, offset, statusOrReasonCode, majorClassCode, dataMasker.maskProvName(provName), stateCode, includeCount);
	}
	
	private ResponseEntity<List<ProviderDemoDTO>> buildAndReturnResponse(ProviderDemoGetResponse demographicsResponseObj,Boolean includeCount) {
		List<ProviderDemoDTO> providerDemographicsDtos  = demographicsResponseObj.getDemographicsDtos();
			if(null!= includeCount && includeCount) {
				HttpHeaders responseHeaders = new HttpHeaders();
				responseHeaders.set(ProviderDemographicsConstants.TOTAL_DOCS, demographicsResponseObj.getTotalCount());
				return ResponseEntity.ok().headers(responseHeaders).body(providerDemographicsDtos);
			}
			return ResponseEntity.ok().body(providerDemographicsDtos);
	}

}
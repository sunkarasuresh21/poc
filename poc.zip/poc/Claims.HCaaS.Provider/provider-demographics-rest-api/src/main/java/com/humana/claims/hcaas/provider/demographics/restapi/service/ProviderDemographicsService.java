package com.humana.claims.hcaas.provider.demographics.restapi.service;

import com.humana.claims.hcaas.provider.demographics.core.exception.InvalidRequestException;
import com.humana.claims.hcaas.provider.demographics.core.model.ProviderDemoGetRequest;
import com.humana.claims.hcaas.provider.demographics.restapi.exception.NotFoundException;
import com.humana.claims.hcaas.provider.demographics.restapi.model.ProviderDemoGetResponse;

public interface ProviderDemographicsService {
	
	ProviderDemoGetResponse getDemographicsByProviderId(ProviderDemoGetRequest provDemoGetReq) throws InvalidRequestException, NotFoundException;
	
	ProviderDemoGetResponse getDemographicsByProviderTaxId(ProviderDemoGetRequest provDemoGetReq) throws InvalidRequestException, NotFoundException;
	
	ProviderDemoGetResponse getDemographicsByProviderNpiId(ProviderDemoGetRequest provDemoGetReq) throws InvalidRequestException, NotFoundException;
	
	ProviderDemoGetResponse getDemographicsByProvName(ProviderDemoGetRequest provDemoGetReq) throws InvalidRequestException, NotFoundException;
	
}
	

/*
* Copyright (C) Humana - All Rights Reserved
*
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential
*
* Written by Shridutt Kothari <skothari1@humana.com>, November 2021
*/
package com.humana.claims.hcaas.provider.demographics.restapi.controller;

import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.constraints.NotNull;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.humana.claims.hcaas.common.rest.api.starter.enumerrorcode.ErrorCode;
import com.humana.claims.hcaas.common.rest.api.starter.exceptionhandling.AbstractSpringControllerExceptionHandler;
import com.humana.claims.hcaas.common.rest.api.starter.exceptionhandling.ErrorResponseDTO;
import com.humana.claims.hcaas.provider.demographics.core.exception.InvalidRequestException;
import com.humana.claims.hcaas.provider.demographics.restapi.exception.InvalidHeaderCombinationException;
import com.humana.claims.hcaas.provider.demographics.restapi.exception.NotFoundException;

@ControllerAdvice
public class ProviderDemographicsControllerExceptionHandler extends AbstractSpringControllerExceptionHandler {
	
	@ExceptionHandler(InvalidRequestException.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleInvalidRequestException(InvalidRequestException ex) {
		return respondWith(ex, HttpStatus.BAD_REQUEST, ex.getErrorMessages(), ErrorCode.BAD_REQUEST);
	}
	
	@ExceptionHandler(InvalidHeaderCombinationException.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleInvalidHeaderCombinationException(InvalidHeaderCombinationException e) {
		return respondWith(e, HttpStatus.BAD_REQUEST, e.getErrorMessages(), ErrorCode.BAD_REQUEST);
	}

	@ExceptionHandler(NotFoundException.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleNotFoundException(NotFoundException exception) {
		return respondWith(exception, HttpStatus.BAD_REQUEST, exception.getErrorMessages(), ErrorCode.NOT_FOUND);
	}

	protected ResponseEntity<ErrorResponseDTO> respondWith(Exception exception, @NotNull HttpStatus httpStatus,	Set<String> errorMessages, ErrorCode errorCode) {
		return super.respondWith(exception, httpStatus, errorMessages.stream().collect(Collectors.toList()), errorCode);
	}	
}
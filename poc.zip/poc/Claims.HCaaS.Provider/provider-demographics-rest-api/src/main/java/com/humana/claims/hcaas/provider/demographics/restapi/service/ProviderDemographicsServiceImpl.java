package com.humana.claims.hcaas.provider.demographics.restapi.service;

import static com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsErrorConstants.NO_RECORD_FOUND;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.humana.claims.hcaas.provider.demographics.core.dao.ProviderDemographicsDAO;
import com.humana.claims.hcaas.provider.demographics.core.exception.InvalidRequestException;
import com.humana.claims.hcaas.provider.demographics.core.model.DemographicsDBResponse;
import com.humana.claims.hcaas.provider.demographics.core.model.ProviderDemoGetRequest;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.demographics.core.validator.ProviderDemographicsValidator;
import com.humana.claims.hcaas.provider.demographics.restapi.exception.NotFoundException;
import com.humana.claims.hcaas.provider.demographics.restapi.gen.openapi.model.ProviderDemoDTO;
import com.humana.claims.hcaas.provider.demographics.restapi.mapper.ProviderDemographicsDataMapper;
import com.humana.claims.hcaas.provider.demographics.restapi.model.ProviderDemoGetResponse;

@Service
public class ProviderDemographicsServiceImpl implements ProviderDemographicsService {

	private ProviderDemographicsValidator providerValidator;

	private ProviderDemographicsDAO providerDemographicsDAO;
	
	@Autowired
	public ProviderDemographicsServiceImpl(ProviderDemographicsValidator providerValidator, ProviderDemographicsDAO providerDemographicsDAO) {
		this.providerValidator = providerValidator;
		this.providerDemographicsDAO = providerDemographicsDAO;
	}

	@Override
	public ProviderDemoGetResponse getDemographicsByProviderId(ProviderDemoGetRequest provDemoGetReq)
			throws InvalidRequestException, NotFoundException {

		Map<String, String> queryMap = providerValidator.validateByProviderId(provDemoGetReq);
		DemographicsDBResponse providerDemoGetResponse = providerDemographicsDAO.getDemographicsByProviderId(queryMap,
				provDemoGetReq.getLimit(), provDemoGetReq.getOffset(),
				isIncludeCount(provDemoGetReq.getIncludeCount()));

		return buildResponse(providerDemoGetResponse);
	}

	@Override
	public ProviderDemoGetResponse getDemographicsByProviderTaxId(ProviderDemoGetRequest provDemoGetReq)
			throws InvalidRequestException, NotFoundException {

		Map<String, String> queryMap = providerValidator.validateByProviderTaxId(provDemoGetReq);
		DemographicsDBResponse providerDemoGetResponse = providerDemographicsDAO.getDemographicsByProviderTaxId(
				queryMap, provDemoGetReq.getLimit(), provDemoGetReq.getOffset(), isIncludeCount(provDemoGetReq.getIncludeCount()));

		return buildResponse(providerDemoGetResponse);
	}

	@Override
	public ProviderDemoGetResponse getDemographicsByProviderNpiId(ProviderDemoGetRequest provDemoGetReq)
			throws InvalidRequestException, NotFoundException {

		Map<String, String> queryMap = providerValidator.validateByNpiId(provDemoGetReq);
		DemographicsDBResponse providerDemoGetResponse = providerDemographicsDAO.getDemographicsByNpiId(queryMap,
				provDemoGetReq.getLimit(), provDemoGetReq.getOffset(), isIncludeCount(provDemoGetReq.getIncludeCount()));

		return buildResponse(providerDemoGetResponse);
	}

	@Override
	public ProviderDemoGetResponse getDemographicsByProvName(ProviderDemoGetRequest provDemoGetReq)
			throws InvalidRequestException, NotFoundException {

		Map<String, String> queryMap = providerValidator.validateByProvName(provDemoGetReq);
		DemographicsDBResponse providerDemoGetResponse = providerDemographicsDAO.getDemographicsByProvName(queryMap,
				provDemoGetReq.getLimit(), provDemoGetReq.getOffset(), isIncludeCount(provDemoGetReq.getIncludeCount()));

		return buildResponse(providerDemoGetResponse);

	}

	private ProviderDemoGetResponse buildResponse(DemographicsDBResponse providerDemoGetResponse)
			throws NotFoundException {
		Collection<Demographics> demographicsDBObjs = providerDemoGetResponse.getDemographics();
		List<ProviderDemoDTO> demographicsDtos = new ArrayList<>();

		if (!CollectionUtils.isEmpty(demographicsDBObjs)) {
			demographicsDBObjs.forEach(demographicsDBObj -> {
				ProviderDemoDTO providerDemographicsDto = ProviderDemographicsDataMapper
						.mapProviderDemoDTO(demographicsDBObj);
				demographicsDtos.add(providerDemographicsDto);
			});
			return ProviderDemoGetResponse.builder().demographicsDtos(demographicsDtos)
					.totalCount(providerDemoGetResponse.getTotalCount()).build();
		} else {
			Set<String> errorMessages = new HashSet<>();
			errorMessages.add(NO_RECORD_FOUND);
			throw new NotFoundException(errorMessages);
		}
	}

	private boolean isIncludeCount(Boolean includeCount) {
		if (includeCount != null) {
			return includeCount;
		}
		return false;
	}
}
package com.humana.claims.hcaas.provider.demographics.restapi.mapper;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.demographics.core.model.db.NpiInfos;
import com.humana.claims.hcaas.provider.demographics.core.model.db.SpecCode;
import com.humana.claims.hcaas.provider.demographics.core.model.db.TaxonomyCode;
import com.humana.claims.hcaas.provider.demographics.restapi.gen.openapi.model.ProviderDemoDTO;
import com.humana.claims.hcaas.provider.demographics.restapi.gen.openapi.model.ProviderDemoKeyDTO;
import com.humana.claims.hcaas.provider.demographics.restapi.gen.openapi.model.ProviderDemoProviderInfoAddressDTO;
import com.humana.claims.hcaas.provider.demographics.restapi.gen.openapi.model.ProviderDemoProviderInfoDTO;
import com.humana.claims.hcaas.provider.demographics.restapi.gen.openapi.model.ProviderDemoProviderInfoNpiIdsDTO;
import com.humana.claims.hcaas.provider.demographics.restapi.gen.openapi.model.ProviderDemoProviderInfoSpecCodesDTO;
import com.humana.claims.hcaas.provider.demographics.restapi.gen.openapi.model.ProviderDemoProviderInfoTaxonomyCodesDTO;

public class ProviderDemographicsDataMapper {

	private ProviderDemographicsDataMapper() {

	}

	public static ProviderDemoDTO mapProviderDemoDTO(Demographics demographics) {
		ProviderDemoDTO providerDemoDTO = new ProviderDemoDTO();
		if(null == demographics) {
			return providerDemoDTO;
		}
		return providerDemoDTO
				.key(mapProviderDemoKeyDTO(demographics))
				.tinEffDt(demographics.getTinEffDt())
				.irsNo(demographics.getIrsNo())
				.updateSys(demographics.getUpdateSys())
				.alphaKey(demographics.getAlphaKey())
				.providerInfo(mapProviderDemoProviderInfoDTO(demographics));
	}

	private static ProviderDemoKeyDTO mapProviderDemoKeyDTO(Demographics demographics) {
		ProviderDemoKeyDTO providerDemoKeyDTO = new ProviderDemoKeyDTO();
		providerDemoKeyDTO.client(null == demographics.getKey()? null: demographics.getKey().getClient());
		providerDemoKeyDTO.pvdInd(null == demographics.getKey()? null: demographics.getKey().getPvdInd());
		providerDemoKeyDTO.prov(null == demographics.getKey()? null: demographics.getKey().getProv());
		providerDemoKeyDTO.multAddressKey(null == demographics.getKey()? null: demographics.getKey().getMultAddressKey());
		return providerDemoKeyDTO;
	}

	private static ProviderDemoProviderInfoDTO mapProviderDemoProviderInfoDTO(Demographics demographics) {
		ProviderDemoProviderInfoDTO providerDemoProviderInfoDTO = new ProviderDemoProviderInfoDTO();
		if(null == demographics.getProviderInfo()) {
			return providerDemoProviderInfoDTO;
		}
		return providerDemoProviderInfoDTO
				.provName(demographics.getProviderInfo().getProvName())
				.address(mapProviderDemoProviderInfoAddressDTO(demographics))
				.city(demographics.getProviderInfo().getCity())
				.st(demographics.getProviderInfo().getSt())
				.zip(demographics.getProviderInfo().getZip())
				.latitude(demographics.getProviderInfo().getLatitude())
				.longitude(demographics.getProviderInfo().getLongitude())
				.provType(demographics.getProviderInfo().getProvType())
				.majClsCd(demographics.getProviderInfo().getMajClsCd())
				.groupFlag(demographics.getProviderInfo().getGroupFlag())
				.specCodes(mapProviderDemoProviderInfoSpecCodesDTO(demographics))
				.phone(demographics.getProviderInfo().getPhone())
				.adjNo(demographics.getProviderInfo().getAdjNo())
				.chgDt(demographics.getProviderInfo().getChgDt())
				.pvdStatus(demographics.getPvdStatus())
				.pvdStRc(demographics.getProviderInfo().getPvdStRc())
				.active(demographics.getProviderInfo().getActive())
				.archived(demographics.getProviderInfo().getArchived())
				.noPayCode(mapNoPayCode(demographics))
				.noPayDt(mapNoPayDt(demographics))
				.npiIds(mapProviderDemoProviderInfoNpiIdsDTO(demographics))
				.taxonomyCodes(mapProviderDemoProviderInfoTaxonomyCodesDTO(demographics));
	}

	private static ProviderDemoProviderInfoAddressDTO mapProviderDemoProviderInfoAddressDTO(Demographics demographics) {
		ProviderDemoProviderInfoAddressDTO providerDemoProviderInfoAddressDTO = new ProviderDemoProviderInfoAddressDTO();
		providerDemoProviderInfoAddressDTO.addr1(null == demographics.getProviderInfo()? null: mapAddress1(demographics));
		providerDemoProviderInfoAddressDTO.addr2(null == demographics.getProviderInfo()? null: mapAddress2(demographics));
		providerDemoProviderInfoAddressDTO.addr3(null == demographics.getProviderInfo()? null: mapAddress3(demographics));
		providerDemoProviderInfoAddressDTO.addr4(null == demographics.getProviderInfo()? null: mapAddress4(demographics));
		return providerDemoProviderInfoAddressDTO;
	}
	private static String mapAddress1(Demographics demographics) {
		return (null == demographics.getProviderInfo().getAddress()? null: demographics.getProviderInfo().getAddress().getAddr1());
	}
	private static String mapAddress2(Demographics demographics) {
		return (null == demographics.getProviderInfo().getAddress()? null: demographics.getProviderInfo().getAddress().getAddr2());
	}
	private static String mapAddress3(Demographics demographics) {
		return (null == demographics.getProviderInfo().getAddress()? null: demographics.getProviderInfo().getAddress().getAddr3());
	}
	private static String mapAddress4(Demographics demographics) {
		return (null == demographics.getProviderInfo().getAddress()? null: demographics.getProviderInfo().getAddress().getAddr4());
	}

	private static List<ProviderDemoProviderInfoSpecCodesDTO> mapProviderDemoProviderInfoSpecCodesDTO(Demographics demographics) {
		List<ProviderDemoProviderInfoSpecCodesDTO> specCodeDtos = new ArrayList<>();

		for(SpecCode specCode : demographics.getProviderInfo().getSpecCodes()) {
			specCodeDtos.add(new ProviderDemoProviderInfoSpecCodesDTO().specCd(specCode.getSpecCd()));

		}
		return specCodeDtos;
	}

	private static String mapNoPayCode(Demographics demographics) {
		return (null == demographics.getProviderInfo()? null: demographics.getProviderInfo().getPrvNoPay());
	}

	private static LocalDate mapNoPayDt(Demographics demographics) {
		return (null == demographics.getProviderInfo()? null: demographics.getProviderInfo().getPrvNoPayDt());
	}

	private static List<ProviderDemoProviderInfoNpiIdsDTO> mapProviderDemoProviderInfoNpiIdsDTO(Demographics demographics) {
		List<ProviderDemoProviderInfoNpiIdsDTO> npiIdDtos = new ArrayList<>();

		for(NpiInfos npiIdInfos : demographics.getProviderInfo().getNpiIds()) {
			npiIdDtos.add(new ProviderDemoProviderInfoNpiIdsDTO().npiId(npiIdInfos.getNpiId()));

		}
		return npiIdDtos;
	}

	private static List<ProviderDemoProviderInfoTaxonomyCodesDTO> mapProviderDemoProviderInfoTaxonomyCodesDTO(Demographics demographics) {
		List<ProviderDemoProviderInfoTaxonomyCodesDTO> taxonomyCodeDtos = new ArrayList<>();

		for(TaxonomyCode taxonomyCode : demographics.getProviderInfo().getTaxonomyCodes()) {
			taxonomyCodeDtos.add(new ProviderDemoProviderInfoTaxonomyCodesDTO().taxonomyCd(taxonomyCode.getTaxonomyCd()));

		}
		return taxonomyCodeDtos;
	}

}
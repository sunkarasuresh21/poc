package com.humana.claims.hcaas.provider.demographics.restapi.model;

import java.util.List;

import com.humana.claims.hcaas.provider.demographics.restapi.gen.openapi.model.ProviderDemoDTO;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Getter
@Setter
@ToString
public class ProviderDemoGetResponse {
	private String  totalCount;
	private List<ProviderDemoDTO> demographicsDtos;
}


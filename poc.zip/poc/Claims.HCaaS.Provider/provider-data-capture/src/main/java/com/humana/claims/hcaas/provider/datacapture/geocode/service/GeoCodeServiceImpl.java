package com.humana.claims.hcaas.provider.datacapture.geocode.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import com.humana.claims.hcaas.provider.datacapture.exception.GeoCodeBadRequestException;
import com.humana.claims.hcaas.provider.datacapture.geocode.client.GeoCodeApiClient;
import com.humana.claims.hcaas.provider.datacapture.geocode.model.GeoCodeApiResponse;
import com.humana.claims.hcaas.provider.datacapture.geocode.model.Location;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class GeoCodeServiceImpl implements GeoCodeService {

	@Autowired
	private GeoCodeApiClient geoCodeApiClient;
	
	public static final String GEOCODE_API_FAILED = "Call to Geocode API failed";

	@Override
	public Location getGeoCode(String address) {
		try {
			GeoCodeApiResponse geoCodeApiResponse = geoCodeApiClient.geocode(address);
			if (isSuccess(geoCodeApiResponse)) {
				return locationFromResponse(geoCodeApiResponse);
			} else {
				return null;
			}
		} catch (HttpClientErrorException | HttpServerErrorException | GeoCodeBadRequestException ex) {
			log.warn(GEOCODE_API_FAILED, ex);
			return null;
		}
	}

	private boolean isSuccess(GeoCodeApiResponse geoCodeApiResponse) {
		return null != geoCodeApiResponse && geoCodeApiResponse.status.equalsIgnoreCase("OK");
	}

	private Location locationFromResponse(GeoCodeApiResponse geoCodeApiResponse) {
		return Location.builder().lat(geoCodeApiResponse.results.get(0).geometry.location.getLat())
				.lng(geoCodeApiResponse.results.get(0).geometry.location.getLng()).build();
	}
}

package com.humana.claims.hcaas.provider.datacapture.geocode.service;

import com.humana.claims.hcaas.provider.datacapture.geocode.model.Location;

public interface GeoCodeService {
	public Location getGeoCode(String address);
}

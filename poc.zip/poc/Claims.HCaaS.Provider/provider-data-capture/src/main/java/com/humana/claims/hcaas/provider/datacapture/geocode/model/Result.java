package com.humana.claims.hcaas.provider.datacapture.geocode.model;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class Result {
	
	@JsonProperty("address_components")
	public List<AddressComponent> addressComponents;
	
	@JsonProperty("formatted_address")
	public String formattedAddress;
	
	@JsonProperty("geometry")
	public Geometry geometry;
	
	@JsonProperty("place_id")
	public String placeId;
	
	@JsonProperty("plus_code")
	public PlusCode plusCode;
	
	@JsonProperty("types")
	public List<String> types;
}

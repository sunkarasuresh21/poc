package com.humana.claims.hcaas.provider.datacapture.geocode.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import org.springframework.web.client.RestTemplate;

import com.humana.claims.hcaas.provider.datacapture.exception.GeoCodeBadRequestException;
import com.humana.claims.hcaas.provider.datacapture.geocode.model.GeoCodeApiResponse;

@Component
public class GeoCodeApiClient {

	private final RestTemplate restTemplate;

	private final String key;

	@Autowired
	public GeoCodeApiClient(@Qualifier("geoCodeClientRestTemplate") RestTemplate restTemplate,	@Value("${geocode.api.key}") String key) {
		this.restTemplate = restTemplate;
		this.key = key;
	}
	
	public GeoCodeApiResponse geocode(String address) throws GeoCodeBadRequestException {
		if (ObjectUtils.isEmpty(address)) {
			throw new GeoCodeBadRequestException("Invalid path variable when calling GeoCodeApi");
		}
		return callGeocodeService(address).getBody();
	}

	private ResponseEntity<GeoCodeApiResponse> callGeocodeService(String address) {

		return restTemplate.getForEntity("?address={address}&key={key}", GeoCodeApiResponse.class, address, key);

	}
}

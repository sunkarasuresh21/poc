package com.humana.claims.hcaas.provider.datacapture.service;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.humana.claims.hcaas.provider.attributes.core.dao.ProviderAttributesDAO;
import com.humana.claims.hcaas.provider.attributes.core.exception.ProviderAttributesNotFoundException;
import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.datacapture.mapper.ProviderDataMapper;
import com.humana.claims.hcaas.provider.datacapture.mapper.ProviderMqDeserializer;
import com.humana.claims.hcaas.provider.model.mq.Prv3OutRecord;

import lombok.extern.slf4j.Slf4j;
@Service
@Slf4j
public class ProviderDataCaptureProv3ServiceImpl implements ProviderDataCaptureService {
	
	private ProviderDataMapper converter;

	private ProviderAttributesDAO providerAttributesDAO;
	
	private ProviderMqDeserializer messageDeserializer;
	
	@Autowired
	public ProviderDataCaptureProv3ServiceImpl(ProviderDataMapper converter,
			ProviderAttributesDAO providerAttributesDAO, ProviderMqDeserializer messageDeserializer) {
		this.converter = converter;
		this.providerAttributesDAO = providerAttributesDAO;
		this.messageDeserializer = messageDeserializer;
	}
	
	public void processProviderData(String providerData) throws IOException, ProviderAttributesNotFoundException {
		log.debug("Processing Provider Data - Started");
		Prv3OutRecord prvMaster = messageDeserializer.deserializeProviderOutRecord3(providerData);
		handleProviderAttributes(prvMaster);
		log.debug("Processing Provider Data - Completed");
	}

	private void handleProviderAttributes(Prv3OutRecord prvMaster) throws ProviderAttributesNotFoundException {
		Attributes providerAttributes = converter.mapAttributesFromProviderData3(prvMaster);
		providerAttributesDAO.updateProviderAttributesProv3(providerAttributes);
	}
}
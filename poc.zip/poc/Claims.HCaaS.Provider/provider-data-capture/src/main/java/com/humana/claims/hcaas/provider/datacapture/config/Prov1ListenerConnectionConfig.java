package com.humana.claims.hcaas.provider.datacapture.config;

import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.humana.claims.hcaas.common.data.capture.starter.config.BaseDataCaptureListenerConnectionConfig;

@Configuration
@ConditionalOnProperty(name = "datacapture.prov1.enabled", havingValue = "true")
public class Prov1ListenerConnectionConfig extends BaseDataCaptureListenerConnectionConfig {
	
	@Bean
	public static BeanDefinitionRegistryPostProcessor prov1BeanConfiguration() {
		return dataCaptureListenerDependencyBeanRegisterer("prov1");
	}

}

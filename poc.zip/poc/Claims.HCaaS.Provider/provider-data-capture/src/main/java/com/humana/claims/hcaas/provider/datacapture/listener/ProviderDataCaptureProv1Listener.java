package com.humana.claims.hcaas.provider.datacapture.listener;

import java.io.IOException;

import javax.jms.JMSException;
import javax.jms.Message;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import com.humana.claims.hcaas.common.data.capture.starter.newerrorhandlers.DataCaptureErrorHandler;
import com.humana.claims.hcaas.common.spring.aop.annotation.Listener;
import com.humana.claims.hcaas.common.utils.logging.LogUtils;
import com.humana.claims.hcaas.provider.attributes.core.masker.ProviderAttributesDataMasker;
import com.humana.claims.hcaas.provider.datacapture.service.ProviderDataCaptureProv1ServiceImpl;
import com.mongodb.MongoException;

import io.micrometer.core.annotation.Timed;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@ConditionalOnProperty(name = "datacapture.prov1.enabled", havingValue = "true")
@Listener
public class ProviderDataCaptureProv1Listener {

	@Autowired
	@Qualifier("prov1DataCaptureErrorHandler")
	private DataCaptureErrorHandler errorHandler;
	
	@Autowired
	private ProviderAttributesDataMasker dataMasker;

	@Autowired
	private ProviderDataCaptureProv1ServiceImpl providerDataCaptureProv1ServiceImpl;

	@Timed(value = "messages.processed", extraTags = {"listener","prov1"})
	@JmsListener(containerFactory = "prov1ListenerContainerFactory", destination = "#{@prov1QueueName}")
	@Retryable(value = {
			MongoException.class }, maxAttemptsExpression = "#{${datacapture.retry.attempts}}", backoff = @Backoff(delayExpression = "#{${datacapture.retry.backoff}}"))
	public void newProviderDataRecieved(Message message) throws IOException, JMSException {
		String providerData=message.getBody(String.class);
		LogUtils.logAtInfo(log, "Incoming message : {}", dataMasker.getProv1JsonDataMasker().maskSupplier(providerData));
		providerDataCaptureProv1ServiceImpl.processProviderData(providerData);
	}

	@Recover
	public void handleMongoException(MongoException e, Message message) {
		errorHandler.handleRetryableMessageProcessingException(message, e);
	}

	@Recover
	public void handleException(Exception e, Message message) {
		errorHandler.handleNonretryableMessageProcessingException(message, e);
	}
	


}

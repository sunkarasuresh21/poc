package com.humana.claims.hcaas.provider.datacapture.service;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.humana.claims.hcaas.provider.attributes.core.dao.ProviderAttributesDAO;
import com.humana.claims.hcaas.provider.attributes.core.exception.ProviderAttributesNotFoundException;
import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.datacapture.mapper.ProviderDataMapper;
import com.humana.claims.hcaas.provider.datacapture.mapper.ProviderMqDeserializer;
import com.humana.claims.hcaas.provider.demographics.core.dao.ProviderDemographicsDAO;
import com.humana.claims.hcaas.provider.demographics.core.exception.ProviderDemographicsNotFoundException;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.model.mq.Prv2OutRecord;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ProviderDataCaptureProv2ServiceImpl implements ProviderDataCaptureService {

	private ProviderDataMapper converter;

	private ProviderDemographicsDAO providerDemographicsDAO;

	private ProviderAttributesDAO providerAttributesDAO;

	private ProviderMqDeserializer mqMessageDeserializer;
	
	@Autowired
	public ProviderDataCaptureProv2ServiceImpl(ProviderDataMapper converter,
			ProviderDemographicsDAO providerDemographicsDAO, ProviderAttributesDAO providerAttributesDAO,
			ProviderMqDeserializer mqMessageDeserializer) {
		this.converter = converter;
		this.providerDemographicsDAO = providerDemographicsDAO;
		this.providerAttributesDAO = providerAttributesDAO;
		this.mqMessageDeserializer = mqMessageDeserializer;
	}
	
	@Transactional
	public void processProviderData(String providerData) throws IOException, ProviderDemographicsNotFoundException, ProviderAttributesNotFoundException {
		log.debug("Processing Provider Data - Started");
		Prv2OutRecord prv2OutRecord = mqMessageDeserializer.deserializeProviderOutRecord2(providerData);
		handleProviderDemographics(prv2OutRecord);
		handleProviderAttributes(prv2OutRecord);
		log.debug("Processing Provider Data - Completed");
	}

	private void handleProviderAttributes(Prv2OutRecord prv2OutRecord) throws ProviderAttributesNotFoundException {
		Attributes providerAttributes = converter.mapAttributesFromProviderData2(prv2OutRecord);
		providerAttributesDAO.updateProviderAttributesProv2(providerAttributes);
	}

	private void handleProviderDemographics(Prv2OutRecord prv2OutRecord) throws ProviderDemographicsNotFoundException {
		Demographics demographics = converter.mapDemographicsFromProviderData2(prv2OutRecord);
		providerDemographicsDAO.updateProviderDemographicsProv2(demographics);
	}

	
}

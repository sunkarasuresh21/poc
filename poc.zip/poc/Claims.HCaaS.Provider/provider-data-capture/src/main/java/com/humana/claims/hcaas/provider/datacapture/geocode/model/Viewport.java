package com.humana.claims.hcaas.provider.datacapture.geocode.model;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class Viewport {
	
	@JsonProperty("northeast")
	public Northeast northeast;
	
	@JsonProperty("southwest")
	public Southwest southwest;
}

package com.humana.claims.hcaas.provider.datacapture.exception;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
@AllArgsConstructor
public class GeoCodeBadRequestException extends Exception {
	
	private static final long serialVersionUID = 1L;
	private final String string;
	
}

package com.humana.claims.hcaas.provider.datacapture.mapper;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.humana.claims.hcaas.common.utils.MainframeDateUtils;
import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.attributes.core.model.db.CasName;
import com.humana.claims.hcaas.provider.attributes.core.model.db.PxiZip;
import com.humana.claims.hcaas.provider.attributes.core.model.db.WithholdData;
import com.humana.claims.hcaas.provider.attributes.core.model.db.WthldCurrent;
import com.humana.claims.hcaas.provider.attributes.core.model.db.WthldPrior;
import com.humana.claims.hcaas.provider.datacapture.geocode.model.Location;
import com.humana.claims.hcaas.provider.datacapture.geocode.service.GeoCodeService;
import com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsConstants;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Address;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.demographics.core.model.db.NpiInfos;
import com.humana.claims.hcaas.provider.demographics.core.model.db.ProviderInfo;
import com.humana.claims.hcaas.provider.demographics.core.model.db.SpecCode;
import com.humana.claims.hcaas.provider.demographics.core.model.db.TaxonomyCode;
import com.humana.claims.hcaas.provider.model.mq.Prv2OutRecord;
import com.humana.claims.hcaas.provider.model.mq.Prv2Provider2Info;
import com.humana.claims.hcaas.provider.model.mq.Prv2PxiPtsLobArea;
import com.humana.claims.hcaas.provider.model.mq.Prv3OutRecord;
import com.humana.claims.hcaas.provider.model.mq.PrvMaster;

@Component
public class ProviderDataMapper {

	@Autowired
	private GeoCodeService geoCodeServiceImpl;

	private boolean isArchived(PrvMaster prvMaster) {
		return ProviderDemographicsConstants.ARCHIVED_REASON_CODE.equals(prvMaster.getPrvProviderInfo().getPrvPvdStRc())
				&& ProviderDemographicsConstants.ARCHIVED_STATUS_CODE.equals(prvMaster.getPrvPvdStatus());
	}

	private boolean isActive(PrvMaster prvMaster) {
		return isStatusInactiveWithExceptionalReasonCode(prvMaster) || isStatusAndReasonCodeActive(prvMaster);
	}
	
	private boolean isStatusAndReasonCodeActive(PrvMaster prvMaster) {
		return ((prvMaster.getPrvPvdStatus().equals("0") || prvMaster.getPrvPvdStatus().equals(" "))
				&& prvMaster.getPrvProviderInfo().getPrvPvdStRc().equals(" "));
	}

	private boolean isStatusInactiveWithExceptionalReasonCode(PrvMaster prvMaster) {
		return (prvMaster.getPrvPvdStatus().equals("1")
				&& ProviderDemographicsConstants.listOfReasonCodes.contains(prvMaster.getPrvProviderInfo().getPrvPvdStRc()));
	}

	public Attributes mapAttributesFromProviderData1(PrvMaster prvMaster) {
		Attributes attributes = new Attributes();
		attributes.setKey(getAttributesKey(prvMaster));
		attributes.setIrsNo(prvMaster.getPrvIrsNo());
		attributes.setVch(prvMaster.getPrvProviderInfo().getPrvVch());
		attributes.setTaxType(prvMaster.getPrvProviderInfo().getPrvTaxType());
		attributes.setSend1099Ind(prvMaster.getPrvProviderInfo().getPrvSend1099Ind());
		attributes.setPendEsc(prvMaster.getPrvProviderInfo().getPrvPendEsc());
		attributes.setAutoCheckPullInd(prvMaster.getPrvProviderInfo().getPrvAutoCheckPullInd());
		attributes.setIrsWithholdInd(prvMaster.getPrvProviderInfo().getPrvIrsWithholdInd());
		attributes.setPayCycle(prvMaster.getPrvProviderInfo().getPrvPayCycle());
		attributes.setCrossRef(prvMaster.getPrvProviderInfo().getPrvCrossRef());
		attributes.setMarketId(prvMaster.getPrvProviderInfo().getPrvMarketId());
		attributes.setDg(prvMaster.getPrvProviderInfo().getPrvDg());
		attributes.setAlphaKey(prvMaster.getPrvProviderInfo().getPrvAlphaKey());
		CasName casName = new CasName();
		casName.setFstName(prvMaster.getPrvProviderInfo().getPrvProvCasNameGfld().getPrvProvCasFstName());
		casName.setLastName(prvMaster.getPrvProviderInfo().getPrvProvCasNameGfld().getPrvProvCasLastName());
		attributes.setCasName(casName);
		attributes.setMedSuppWaiveInd(prvMaster.getPrvProviderInfo().getPrvMedSuppWaiveInd());
		attributes.setComment1(prvMaster.getPrvProviderInfo().getPrvComment());
		attributes.setNotifyInd(prvMaster.getPrvProviderInfo().getPrvNotifyInd());
		attributes.setFocusFromDate(MainframeDateUtils
				.convertYYMMDDStringToLocalDate(prvMaster.getPrvProviderInfo().getPrvFocusFromDate()));
		attributes.setClpthInd(prvMaster.getPrvProviderInfo().getPrvClpthInd());
		attributes.setClmChkInd(prvMaster.getPrvProviderInfo().getPrvClmChkInd());
		attributes.setUcZip(prvMaster.getPrvProviderInfo().getPrvUcZip());
		attributes.setFocusToDate(MainframeDateUtils
				.convertYYMMDDStringToLocalDate(prvMaster.getPrvProviderInfo().getPrvFocusToDate()));
		attributes.setAutoLoadInd(prvMaster.getPrvProviderInfo().getPrvAutoLoadInd());
		attributes.setCheckTo(prvMaster.getPrvProviderInfo().getPrvCheckToAixKey().getPrvCheckTo());
		attributes.setSuffixTo(prvMaster.getPrvProviderInfo().getPrvCheckToAixKey().getPrvSuffixTo());
		return attributes;
	}

	public Attributes mapAttributesFromProviderData2(Prv2OutRecord prv2OutRecord) {
		Attributes attributes = new Attributes();
		attributes.setKey(getAttributesKeyPrv2(prv2OutRecord));
		attributes.setApplyTaxInd(prv2OutRecord.getPrv2Provider2Info().getPrv2ApplyTaxInd());
		attributes.setW9Ind(prv2OutRecord.getPrv2Provider2Info().getPrv2W9Ind());
		attributes.setSend480Ind(prv2OutRecord.getPrv2Provider2Info().getPrv2Send480Ind());
		attributes.setComment2(prv2OutRecord.getPrv2Provider2Info().getPrv2Comment2());
		attributes.setComment3(prv2OutRecord.getPrv2Provider2Info().getPrv2Comment3());
		attributes.setVendorId(prv2OutRecord.getPrv2Provider2Info().getPrv2VendorId());
		attributes.setUpdtAdjNo(prv2OutRecord.getPrv2Provider2Info().getPrv2UpdtAdjNo());
		attributes.setUpdtDt(MainframeDateUtils
				.convertMMDDYYYYStringToLocalDate((prv2OutRecord.getPrv2Provider2Info().getPrv2UpdtDt())));
		attributes.setRadSiteCurrInd(prv2OutRecord.getPrv2Provider2Info().getPrv2RadSiteCurrInd());
		attributes.setRadSiteCurrDt(MainframeDateUtils
				.convertYYMMStringToLocalDate(prv2OutRecord.getPrv2Provider2Info().getPrv2RadSiteCurrDt()));
		attributes.setRadSiteP1Ind(prv2OutRecord.getPrv2Provider2Info().getPrv2RadSiteP1Ind());
		attributes.setRadSiteP1Dt(MainframeDateUtils
				.convertYYMMStringToLocalDate(prv2OutRecord.getPrv2Provider2Info().getPrv2RadSiteP1Dt()));
		attributes.setRadSiteP2Ind(prv2OutRecord.getPrv2Provider2Info().getPrv2RadSiteP2Ind());
		attributes.setRadSiteP2Dt(MainframeDateUtils
				.convertYYMMStringToLocalDate(prv2OutRecord.getPrv2Provider2Info().getPrv2RadSiteP2Dt()));
		attributes.setRadScopeCurrInd(prv2OutRecord.getPrv2Provider2Info().getPrv2RadScopeCurrInd());
		attributes.setRadScopeCurrDt(MainframeDateUtils
				.convertYYMMStringToLocalDate(prv2OutRecord.getPrv2Provider2Info().getPrv2RadScopeCurrDt()));
		attributes.setRadScopeP1Ind(prv2OutRecord.getPrv2Provider2Info().getPrv2RadScopeP1Ind());
		attributes.setRadScopeP1Dt(MainframeDateUtils
				.convertYYMMStringToLocalDate(prv2OutRecord.getPrv2Provider2Info().getPrv2RadScopeP1Dt()));
		attributes.setFacUcZip(prv2OutRecord.getPrv2Provider2Info().getPrv2FacUcZip());
		attributes.setPxiUpdtAdjNo(prv2OutRecord.getPrv2Provider2Info().getPrv2PxiUpdtAdjNo());
		attributes.setPxiUpdtDt(MainframeDateUtils
				.convertYYYYMMDDStringToLocalDate(prv2OutRecord.getPrv2Provider2Info().getPrv2PxiUpdtDt()));
		attributes.setClmChkInd(prv2OutRecord.getPrv2Provider2Info().getPrv2ClmChkInd());
		attributes.setSendLtrInd(prv2OutRecord.getPrv2Provider2Info().getPrv2SendLtrInd());
		attributes.setFinalstInd(prv2OutRecord.getPrv2Provider2Info().getPrv2FinalstInd());
		attributes.setCompbidInd(prv2OutRecord.getPrv2Provider2Info().getPrv2CompbidInd());
		attributes.setCompbidEffDt(MainframeDateUtils
				.convertMMDDYYYYStringToLocalDate(prv2OutRecord.getPrv2Provider2Info().getPrv2CompbidEffDt()));
		attributes.setCompbidTrmDt(MainframeDateUtils
				.convertMMDDYYYYStringToLocalDate(prv2OutRecord.getPrv2Provider2Info().getPrv2CompbidTrmDt()));
		// Map contractPointEnable
		mapContractPointEnable(prv2OutRecord.getPrv2Provider2Info().getPrv2PxiPtsLobArea(), attributes);
		attributes.setFacUcZip(prv2OutRecord.getPrv2Provider2Info().getPrv2FacUcZip());
		// PXI Zip
		mapPxiZip(prv2OutRecord.getPrv2Provider2Info(), attributes);
		return attributes;
	}

	public Attributes mapAttributesFromProviderData3(Prv3OutRecord prv3OutRecord) {
		Attributes attributes = new Attributes();
		attributes.setKey(getAttributesKeyPrv3(prv3OutRecord));
		attributes.setWithholdData(getWithHoldData(prv3OutRecord));
		return attributes;
	}

	private WithholdData getWithHoldData(Prv3OutRecord prv3OutRecord) {
		WithholdData withholdData = new WithholdData();
		withholdData.setWthldCurrent(new WthldCurrent());
		withholdData.setWthldPrior(new WthldPrior());
		withholdData.getWthldCurrent().setWthldPerCurrent(
				prv3OutRecord.getPrv3ProvWithholdData().getPrv3ProvWthldCurrent().getPrv3WthldPerC());
		withholdData.getWthldCurrent().setWthldEffDateCurrent(MainframeDateUtils.convertYYYYMMDDStringToLocalDate(
				prv3OutRecord.getPrv3ProvWithholdData().getPrv3ProvWthldCurrent().getPrv3WthldEffDateC()));
		withholdData.getWthldPrior()
				.setWthldPerPrior(prv3OutRecord.getPrv3ProvWithholdData().getPrv3ProvWthldPrior().getPrv3WthldPerP());
		withholdData.getWthldPrior().setWthldEffDatePrior(MainframeDateUtils.convertYYYYMMDDStringToLocalDate(
				prv3OutRecord.getPrv3ProvWithholdData().getPrv3ProvWthldPrior().getPrv3WthldEffDateP()));
		withholdData.setPrTaxfreeAmt(prv3OutRecord.getPrv3ProvWithholdData().getPrv3ProvPrTaxfreeAmt());
		return withholdData;
	}

	public Demographics mapDemographicsFromProviderData1(PrvMaster prvMaster) {
		Demographics demographics = new Demographics();
		demographics.setKey(getDemographicsKey(prvMaster));
		demographics.setIrsNo(prvMaster.getPrvIrsNo());
		demographics.setAlphaKey(prvMaster.getPrvProviderInfo().getPrvAlphaKey());
		demographics.setTinEffDt(MainframeDateUtils.convertYYMMDDStringToLocalDate(prvMaster.getPrvTinEffDt()));
		demographics.setUpdateSys(prvMaster.getPrvUpdateSys());
		demographics.setPvdStatus(prvMaster.getPrvPvdStatus());
		ProviderInfo providerInfo = new ProviderInfo();
		providerInfo.setProvName(prvMaster.getPrvProviderInfo().getPrvProvName());
		providerInfo.setAddress(getAddress(prvMaster));
		providerInfo.setCity(prvMaster.getPrvProviderInfo().getPrvCity());
		providerInfo.setSt(prvMaster.getPrvProviderInfo().getPrvSt());
		providerInfo.setZip(prvMaster.getPrvProviderInfo().getPrvZip());
		Location location = getGeoCode(providerInfo);
		if (location != null) {
			providerInfo.setLatitude(location.getLat());
			providerInfo.setLongitude(location.getLng());
		}
		providerInfo.setProvType(prvMaster.getPrvProviderInfo().getPrvProvType());
		providerInfo.setMajClsCd(prvMaster.getPrvProviderInfo().getPrvMajClsCd());
		providerInfo.setGroupFlag(prvMaster.getPrvProviderInfo().getPrvGroupFlag());
		providerInfo.getSpecCodes().add(getSpecCode(prvMaster.getPrvProviderInfo().getPrvSpecCd()));
		providerInfo.getSpecCodes().add(getSpecCode(prvMaster.getPrvProviderInfo().getPrvSpec1Cd()));
		providerInfo.getSpecCodes().add(getSpecCode(prvMaster.getPrvProviderInfo().getPrvSpec2Cd()));
		providerInfo.getSpecCodes().add(getSpecCode(prvMaster.getPrvProviderInfo().getPrvSpec3Cd()));
		providerInfo.setPhone(prvMaster.getPrvProviderInfo().getPrvPhone());
		providerInfo.setAdjNo(prvMaster.getPrvProviderInfo().getPrvAdjNo());
		providerInfo.setChgDt(
				MainframeDateUtils.convertMMDDYYYYStringToLocalDate(prvMaster.getPrvProviderInfo().getPrvChgDt()));
		providerInfo.setPrvNoPay(prvMaster.getPrvProviderInfo().getPrvPriorInfo().getPrvNoPay());
		providerInfo.setPrvNoPayDt(MainframeDateUtils
				.convertYYMMDDStringToLocalDate(prvMaster.getPrvProviderInfo().getPrvPriorInfo().getPrvNoPayDt()));
		providerInfo.setPvdStRc(prvMaster.getPrvProviderInfo().getPrvPvdStRc());
		providerInfo.setActive(isActive(prvMaster));
		providerInfo.setArchived(isArchived(prvMaster));
		demographics.setProviderInfo(providerInfo);
		return demographics;
	}
	
	private Location getGeoCode(ProviderInfo providerInfo) {
		StringBuilder stringBuilder = new StringBuilder();
		String address = (stringBuilder.append(providerInfo.getAddress().getAddr1()).append(" ")
				.append(providerInfo.getAddress().getAddr2()).append(" ").append(providerInfo.getAddress().getAddr3())
				.append(" ").append(providerInfo.getAddress().getAddr4()).append(" ").append(providerInfo.getCity())
				.append(" ").append(providerInfo.getSt()).append(" ").append(providerInfo.getZip())).toString();
		return geoCodeServiceImpl.getGeoCode(address);
	}

	private Address getAddress(PrvMaster prvMaster) {
		Address address = new Address();
		address.setAddr1(prvMaster.getPrvProviderInfo().getPrvAddress().getPrvAddr1());
		address.setAddr2(prvMaster.getPrvProviderInfo().getPrvAddress().getPrvAddr2());
		address.setAddr3(prvMaster.getPrvProviderInfo().getPrvAddress().getPrvAddr3());
		address.setAddr4(prvMaster.getPrvProviderInfo().getPrvAddress().getPrvAddr4());
		return address;
	}

	private com.humana.claims.hcaas.provider.demographics.core.model.db.DemographicsKey getDemographicsKey(PrvMaster prvMaster) {
		com.humana.claims.hcaas.provider.demographics.core.model.db.DemographicsKey demographicsKey = new com.humana.claims.hcaas.provider.demographics.core.model.db.DemographicsKey();
		demographicsKey.setClient(prvMaster.getPrvKey().getPrvClient());
		demographicsKey.setMultAddressKey(prvMaster.getPrvKey().getPrvMultAddressKey());
		demographicsKey.setProv(prvMaster.getPrvKey().getPrvProv());
		demographicsKey.setPvdInd(prvMaster.getPrvKey().getPrvPvdInd());
		return demographicsKey;
	}

	private com.humana.claims.hcaas.provider.attributes.core.model.db.AttributesKey getAttributesKey(PrvMaster prvMaster) {
		com.humana.claims.hcaas.provider.attributes.core.model.db.AttributesKey attributesKey = new com.humana.claims.hcaas.provider.attributes.core.model.db.AttributesKey();
		attributesKey.setClient(prvMaster.getPrvKey().getPrvClient());
		attributesKey.setMultAddressKey(prvMaster.getPrvKey().getPrvMultAddressKey());
		attributesKey.setProv(prvMaster.getPrvKey().getPrvProv());
		attributesKey.setPvdInd(prvMaster.getPrvKey().getPrvPvdInd());
		return attributesKey;
	}

	private com.humana.claims.hcaas.provider.demographics.core.model.db.DemographicsKey getDemographicsKeyPrv2(Prv2OutRecord prv2OutRecord) {
		com.humana.claims.hcaas.provider.demographics.core.model.db.DemographicsKey demographicsKey = new com.humana.claims.hcaas.provider.demographics.core.model.db.DemographicsKey();
		demographicsKey.setClient(prv2OutRecord.getPrv2Key().getPrv2Client());
		demographicsKey.setMultAddressKey(prv2OutRecord.getPrv2Key().getPrv2MultAddressKey());
		demographicsKey.setProv(prv2OutRecord.getPrv2Key().getPrv2Prov());
		demographicsKey.setPvdInd(prv2OutRecord.getPrv2Key().getPrv2PvdInd());
		return demographicsKey;
	}

	private com.humana.claims.hcaas.provider.attributes.core.model.db.AttributesKey getAttributesKeyPrv2(Prv2OutRecord prv2OutRecord) {
		com.humana.claims.hcaas.provider.attributes.core.model.db.AttributesKey attributesKey = new com.humana.claims.hcaas.provider.attributes.core.model.db.AttributesKey();
		attributesKey.setClient(prv2OutRecord.getPrv2Key().getPrv2Client());
		attributesKey.setMultAddressKey(prv2OutRecord.getPrv2Key().getPrv2MultAddressKey());
		attributesKey.setProv(prv2OutRecord.getPrv2Key().getPrv2Prov());
		attributesKey.setPvdInd(prv2OutRecord.getPrv2Key().getPrv2PvdInd());
		return attributesKey;
	}

	private com.humana.claims.hcaas.provider.attributes.core.model.db.AttributesKey getAttributesKeyPrv3(Prv3OutRecord prv3OutRecord) {
		com.humana.claims.hcaas.provider.attributes.core.model.db.AttributesKey attributesKey = new com.humana.claims.hcaas.provider.attributes.core.model.db.AttributesKey();
		attributesKey.setClient(prv3OutRecord.getPrv3Key().getPrv3Client());
		attributesKey.setMultAddressKey(prv3OutRecord.getPrv3Key().getPrv3MultAddressKey());
		attributesKey.setProv(prv3OutRecord.getPrv3Key().getPrv3Prov());
		attributesKey.setPvdInd(prv3OutRecord.getPrv3Key().getPrv3PvdInd());
		return attributesKey;
	}

	private SpecCode getSpecCode(String specCode) {
		SpecCode specCd = new SpecCode();
		specCd.setSpecCd(specCode);
		return specCd;
	}

	public Demographics mapDemographicsFromProviderData2(Prv2OutRecord prv2OutRecord) {
		Demographics demographics = new Demographics();
		demographics.setKey(getDemographicsKeyPrv2(prv2OutRecord));
		ProviderInfo providerInfo = new ProviderInfo();
		Prv2Provider2Info provider2Info = prv2OutRecord.getPrv2Provider2Info();
		providerInfo.getNpiIds().add(mapPrvNpi(provider2Info.getPrv2Npi()));
		providerInfo.getNpiIds().add(mapPrvNpi(provider2Info.getPrv2Npi2()));
		providerInfo.getNpiIds().add(mapPrvNpi(provider2Info.getPrv2Npi3()));
		providerInfo.getNpiIds().add(mapPrvNpi(provider2Info.getPrv2Npi4()));
		providerInfo.getNpiIds().add(mapPrvNpi(provider2Info.getPrv2Npi5()));
		providerInfo.getNpiIds().add(mapPrvNpi(provider2Info.getPrv2Npi6()));
		providerInfo.getNpiIds().add(mapPrvNpi(provider2Info.getPrv2Npi7()));
		providerInfo.getNpiIds().add(mapPrvNpi(provider2Info.getPrv2Npi8()));
		providerInfo.getNpiIds().add(mapPrvNpi(provider2Info.getPrv2Npi9()));
		providerInfo.getTaxonomyCodes().add(mapTaxanomyCodes(provider2Info.getPrv2TaxonomyCode()));
		providerInfo.getTaxonomyCodes().add(mapTaxanomyCodes(provider2Info.getPrv2TaxonomyCode2()));
		providerInfo.getTaxonomyCodes().add(mapTaxanomyCodes(provider2Info.getPrv2TaxonomyCode3()));
		providerInfo.getTaxonomyCodes().add(mapTaxanomyCodes(provider2Info.getPrv2TaxonomyCode4()));
		providerInfo.getTaxonomyCodes().add(mapTaxanomyCodes(provider2Info.getPrv2TaxonomyCode5()));
		providerInfo.getTaxonomyCodes().add(mapTaxanomyCodes(provider2Info.getPrv2TaxonomyCode6()));
		providerInfo.getTaxonomyCodes().add(mapTaxanomyCodes(provider2Info.getPrv2TaxonomyCode7()));
		providerInfo.getTaxonomyCodes().add(mapTaxanomyCodes(provider2Info.getPrv2TaxonomyCode8()));
		providerInfo.getTaxonomyCodes().add(mapTaxanomyCodes(provider2Info.getPrv2TaxonomyCode9()));
		providerInfo.getTaxonomyCodes().add(mapTaxanomyCodes(provider2Info.getPrv2TaxonomyCode10()));
		demographics.setProviderInfo(providerInfo);
		return demographics;
	}

	private void mapPxiZip(Prv2Provider2Info providerData2, Attributes attributes) {
		attributes.getPxiZip().add(mapPrvPxiZip(providerData2.getPrv2PxiZip1(), providerData2.getPrv2PxiZipInd1()));
		attributes.getPxiZip().add(mapPrvPxiZip(providerData2.getPrv2PxiZip2(), providerData2.getPrv2PxiZipInd2()));
		attributes.getPxiZip().add(mapPrvPxiZip(providerData2.getPrv2PxiZip3(), providerData2.getPrv2PxiZipInd3()));
		attributes.getPxiZip().add(mapPrvPxiZip(providerData2.getPrv2PxiZip4(), providerData2.getPrv2PxiZipInd4()));
		attributes.getPxiZip().add(mapPrvPxiZip(providerData2.getPrv2PxiZip5(), providerData2.getPrv2PxiZipInd5()));
		attributes.getPxiZip().add(mapPrvPxiZip(providerData2.getPrv2PxiZip6(), providerData2.getPrv2PxiZipInd6()));
		attributes.getPxiZip().add(mapPrvPxiZip(providerData2.getPrv2PxiZip7(), providerData2.getPrv2PxiZipInd7()));
		attributes.getPxiZip().add(mapPrvPxiZip(providerData2.getPrv2PxiZip8(), providerData2.getPrv2PxiZipInd8()));
		attributes.getPxiZip().add(mapPrvPxiZip(providerData2.getPrv2PxiZip9(), providerData2.getPrv2PxiZipInd9()));
		attributes.getPxiZip().add(mapPrvPxiZip(providerData2.getPrv2PxiZip10(), providerData2.getPrv2PxiZipInd10()));
		attributes.getPxiZip().add(mapPrvPxiZip(providerData2.getPrv2PxiZip11(), providerData2.getPrv2PxiZipInd11()));
		attributes.getPxiZip().add(mapPrvPxiZip(providerData2.getPrv2PxiZip12(), providerData2.getPrv2PxiZipInd12()));
		attributes.getPxiZip().add(mapPrvPxiZip(providerData2.getPrv2PxiZip13(), providerData2.getPrv2PxiZipInd13()));
		attributes.getPxiZip().add(mapPrvPxiZip(providerData2.getPrv2PxiZip14(), providerData2.getPrv2PxiZipInd14()));
		attributes.getPxiZip().add(mapPrvPxiZip(providerData2.getPrv2PxiZip15(), providerData2.getPrv2PxiZipInd15()));
		attributes.getPxiZip().add(mapPrvPxiZip(providerData2.getPrv2PxiZip16(), providerData2.getPrv2PxiZipInd16()));
		attributes.getPxiZip().add(mapPrvPxiZip(providerData2.getPrv2PxiZip17(), providerData2.getPrv2PxiZipInd17()));
		attributes.getPxiZip().add(mapPrvPxiZip(providerData2.getPrv2PxiZip18(), providerData2.getPrv2PxiZipInd18()));
		attributes.getPxiZip().add(mapPrvPxiZip(providerData2.getPrv2PxiZip19(), providerData2.getPrv2PxiZipInd19()));
		attributes.getPxiZip().add(mapPrvPxiZip(providerData2.getPrv2PxiZip20(), providerData2.getPrv2PxiZipInd20()));

	}

	private void mapContractPointEnable(Prv2PxiPtsLobArea prv2PxiPtsLobArea, Attributes attributes) {
		attributes.getContractPointEnable().put("1", determineContractPointEnableIndicator(prv2PxiPtsLobArea.getPrv2PxiPtsLob1()));
		attributes.getContractPointEnable().put("2", determineContractPointEnableIndicator(prv2PxiPtsLobArea.getPrv2PxiPtsLob2()));
		attributes.getContractPointEnable().put("3", determineContractPointEnableIndicator(prv2PxiPtsLobArea.getPrv2PxiPtsLob3()));
		attributes.getContractPointEnable().put("4", determineContractPointEnableIndicator(prv2PxiPtsLobArea.getPrv2PxiPtsLob4()));
		attributes.getContractPointEnable().put("5", determineContractPointEnableIndicator(prv2PxiPtsLobArea.getPrv2PxiPtsLob5()));
		attributes.getContractPointEnable().put("6", determineContractPointEnableIndicator(prv2PxiPtsLobArea.getPrv2PxiPtsLob6()));
		attributes.getContractPointEnable().put("7", determineContractPointEnableIndicator(prv2PxiPtsLobArea.getPrv2PxiPtsLob7()));
		attributes.getContractPointEnable().put("8", determineContractPointEnableIndicator(prv2PxiPtsLobArea.getPrv2PxiPtsLob8()));
		attributes.getContractPointEnable().put("9", determineContractPointEnableIndicator(prv2PxiPtsLobArea.getPrv2PxiPtsLob9()));
	}
	
	private boolean determineContractPointEnableIndicator(String prv2PxiPtsLobArea) {
		return (StringUtils.isBlank(prv2PxiPtsLobArea) || prv2PxiPtsLobArea.equals("Y"));
	}

	private PxiZip mapPrvPxiZip(String pxiZipCode, String pxiZipInd) {
		PxiZip prvPxiZip = new PxiZip();
		prvPxiZip.setPxiZipCode(pxiZipCode);
		prvPxiZip.setPxiZipInd(pxiZipInd);
		return prvPxiZip;
	}

	private NpiInfos mapPrvNpi(String npiValue) {
		NpiInfos npiInfos = new NpiInfos();
		npiInfos.setNpiId(npiValue);
		return npiInfos;
	}

	private TaxonomyCode mapTaxanomyCodes(String taxonomyCd) {
		TaxonomyCode taxonomyCode = new TaxonomyCode();
		taxonomyCode.setTaxonomyCd(taxonomyCd);
		return taxonomyCode;
	}
}

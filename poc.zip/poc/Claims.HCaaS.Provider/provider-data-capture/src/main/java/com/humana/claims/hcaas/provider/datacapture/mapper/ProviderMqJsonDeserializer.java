package com.humana.claims.hcaas.provider.datacapture.mapper;

import java.io.IOException;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.humana.claims.hcaas.provider.model.mq.Prv2OutRecord;
import com.humana.claims.hcaas.provider.model.mq.Prv3OutRecord;
import com.humana.claims.hcaas.provider.model.mq.PrvMaster;

public class ProviderMqJsonDeserializer implements ProviderMqDeserializer{

	private static final ObjectMapper jsonMapper = new ObjectMapper()
			.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
			.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true)
			.configure(DeserializationFeature.UNWRAP_ROOT_VALUE, true);

	public PrvMaster deserializeProviderMaster(String providerData) throws IOException {
		return jsonMapper.readValue(providerData, PrvMaster.class);
	}

	public Prv2OutRecord deserializeProviderOutRecord2(String providerData) throws IOException {
		return  jsonMapper.readValue(providerData, Prv2OutRecord.class);
	}
	
	public Prv3OutRecord deserializeProviderOutRecord3(String providerData) throws IOException {
		return  jsonMapper.readValue(providerData, Prv3OutRecord.class);
	}
}

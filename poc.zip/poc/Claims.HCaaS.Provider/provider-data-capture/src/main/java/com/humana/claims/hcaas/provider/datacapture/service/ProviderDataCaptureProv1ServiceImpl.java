package com.humana.claims.hcaas.provider.datacapture.service;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.humana.claims.hcaas.provider.attributes.core.dao.ProviderAttributesDAO;
import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.datacapture.mapper.ProviderDataMapper;
import com.humana.claims.hcaas.provider.datacapture.mapper.ProviderMqDeserializer;
import com.humana.claims.hcaas.provider.demographics.core.dao.ProviderDemographicsDAO;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.model.mq.PrvMaster;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ProviderDataCaptureProv1ServiceImpl implements ProviderDataCaptureService {

	private ProviderDataMapper converter;

	private ProviderDemographicsDAO providerDemographicsDAO;

	private ProviderAttributesDAO providerAttributesDAO;
	
	private ProviderMqDeserializer mqDeserializer;
	
	@Autowired
	public ProviderDataCaptureProv1ServiceImpl(ProviderDataMapper converter,
			ProviderDemographicsDAO providerDemographicsDAO, ProviderAttributesDAO providerAttributesDAO,
			ProviderMqDeserializer mqDeserializer) {
		this.converter = converter;
		this.providerDemographicsDAO = providerDemographicsDAO;
		this.providerAttributesDAO = providerAttributesDAO;
		this.mqDeserializer = mqDeserializer;
	}

	@Transactional
	public void processProviderData(String providerData) throws IOException {
		log.debug("Processing Provider Data - Started");
		PrvMaster prvMaster = mqDeserializer.deserializeProviderMaster(providerData);
		handleProviderDemographics(prvMaster);
		handleProviderAttributes(prvMaster);
		log.debug("Processing Provider Data - Completed");

	}

	private void handleProviderAttributes(PrvMaster prvMaster) {
		Attributes providerAttributes = converter.mapAttributesFromProviderData1(prvMaster);
		providerAttributesDAO.upsertProviderAttributesProv1(providerAttributes);
		log.debug("Provider Attributes Data inserted or updated successfully");
	}

	private void handleProviderDemographics(PrvMaster prvMaster) {
		Demographics demographics = converter.mapDemographicsFromProviderData1(prvMaster);
		providerDemographicsDAO.upsertProviderDemographicsProv1(demographics);
		log.debug("Provider Demographics Data inserted or updated successfully");
	}

}
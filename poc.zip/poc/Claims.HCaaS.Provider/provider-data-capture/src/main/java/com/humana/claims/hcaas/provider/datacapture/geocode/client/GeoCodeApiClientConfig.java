package com.humana.claims.hcaas.provider.datacapture.geocode.client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.DefaultUriBuilderFactory;

import lombok.RequiredArgsConstructor;

@Configuration
@RequiredArgsConstructor
public class GeoCodeApiClientConfig {
	
	@Value("${geocode.url}")
	private final String geoCodeUrl;
	
	@Bean("geoCodeClientRestTemplate")
	public RestTemplate geoCodeRestTemplate() {
		return new RestTemplateBuilder()
			.uriTemplateHandler(new DefaultUriBuilderFactory(geoCodeUrl))
			.defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
			.build();
	}	
}

package com.humana.claims.hcaas.provider.datacapture.geocode.model;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class GeoCodeApiResponse {
	
	@JsonProperty("results")
	public List<Result> results = null;
	
	@JsonProperty("status")
	public String status;
}


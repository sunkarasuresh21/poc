package com.humana.claims.hcaas.provider.datacapture.service;

import java.io.IOException;

import com.humana.claims.hcaas.provider.attributes.core.exception.ProviderAttributesNotFoundException;
import com.humana.claims.hcaas.provider.demographics.core.exception.ProviderDemographicsNotFoundException;

public interface ProviderDataCaptureService {

	void processProviderData(String providerData) throws IOException, ProviderDemographicsNotFoundException, ProviderAttributesNotFoundException;
}

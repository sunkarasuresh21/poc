package com.humana.claims.hcaas.provider.datacapture.listener;

import java.io.IOException;

import javax.jms.JMSException;
import javax.jms.Message;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import com.humana.claims.hcaas.common.data.capture.starter.newerrorhandlers.DataCaptureErrorHandler;
import com.humana.claims.hcaas.common.spring.aop.annotation.Listener;
import com.humana.claims.hcaas.common.utils.logging.LogUtils;
import com.humana.claims.hcaas.provider.attributes.core.exception.ProviderAttributesNotFoundException;
import com.humana.claims.hcaas.provider.attributes.core.masker.ProviderAttributesDataMasker;
import com.humana.claims.hcaas.provider.datacapture.service.ProviderDataCaptureProv3ServiceImpl;
import com.humana.claims.hcaas.provider.demographics.core.exception.ProviderDemographicsNotFoundException;
import com.mongodb.MongoException;

import io.micrometer.core.annotation.Timed;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@ConditionalOnProperty(name = "datacapture.prov3.enabled", havingValue = "true")
@Listener
public class ProviderDataCaptureProv3Listener {
	
	@Autowired
	@Qualifier("prov3DataCaptureErrorHandler")
	private DataCaptureErrorHandler errorHandler;
	
	@Autowired
	private ProviderAttributesDataMasker dataMasker;

	@Autowired 
	private ProviderDataCaptureProv3ServiceImpl providerDataCaptureProv3ServiceImpl;

	@Timed(value = "messages.processed", extraTags = {"listener","prov3"})
	@JmsListener(containerFactory = "prov3ListenerContainerFactory", destination = "#{@prov3QueueName}")
	@Retryable(value = {
			ProviderAttributesNotFoundException.class, 
			MongoException.class }, maxAttemptsExpression = "#{${datacapture.retry.attempts}}", backoff = @Backoff(delayExpression = "#{${datacapture.retry.backoff}}"))
	public void newProviderDataRecieved(Message message) throws IOException, ProviderAttributesNotFoundException, JMSException {
		String providerData=message.getBody(String.class);
		LogUtils.logAtInfo(log, "Incoming message : {}", dataMasker.getProv3JsonDataMasker().maskSupplier(providerData));
		providerDataCaptureProv3ServiceImpl.processProviderData(providerData);
	}

	@Recover
	public void handleProviderAttributesNotFoundException(ProviderAttributesNotFoundException e, Message message) {
		errorHandler.handleRetryableMessageProcessingException(message, e);
	}
	
	@Recover
	public void handleMongoException(MongoException e, Message message) {
		errorHandler.handleRetryableMessageProcessingException(message, e);
	}

	@Recover
	public void handleException(Exception e, Message message) {
		errorHandler.handleNonretryableMessageProcessingException(message, e);
	}
}

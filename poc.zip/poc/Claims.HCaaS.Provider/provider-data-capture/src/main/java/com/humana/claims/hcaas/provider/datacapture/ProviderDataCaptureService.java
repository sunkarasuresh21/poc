package com.humana.claims.hcaas.provider.datacapture;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.retry.annotation.EnableRetry;

import com.humana.claims.hcaas.common.spring.boot.starter.HcaasSpringBootApplication;

@SpringBootApplication(scanBasePackages="com.humana.claims.hcaas.provider")
@EnableJms
@EnableRetry
public class ProviderDataCaptureService {

	public static void main(String[] args) {
		HcaasSpringBootApplication.run(ProviderDataCaptureService.class, args);
	}
}

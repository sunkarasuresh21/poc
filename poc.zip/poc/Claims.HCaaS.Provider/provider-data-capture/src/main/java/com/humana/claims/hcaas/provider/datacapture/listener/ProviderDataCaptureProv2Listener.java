package com.humana.claims.hcaas.provider.datacapture.listener;

import java.io.IOException;

import javax.jms.JMSException;
import javax.jms.Message;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import com.humana.claims.hcaas.common.data.capture.starter.newerrorhandlers.DataCaptureErrorHandler;
import com.humana.claims.hcaas.common.spring.aop.annotation.Listener;
import com.humana.claims.hcaas.common.utils.logging.LogUtils;
import com.humana.claims.hcaas.provider.attributes.core.exception.ProviderAttributesNotFoundException;
import com.humana.claims.hcaas.provider.attributes.core.masker.ProviderAttributesDataMasker;
import com.humana.claims.hcaas.provider.datacapture.service.ProviderDataCaptureProv2ServiceImpl;
import com.humana.claims.hcaas.provider.demographics.core.exception.ProviderDemographicsNotFoundException;
import com.mongodb.MongoException;

import io.micrometer.core.annotation.Timed;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@ConditionalOnProperty(name = "datacapture.prov2.enabled", havingValue = "true")
@Listener
public class ProviderDataCaptureProv2Listener {

	@Autowired
	@Qualifier("prov2DataCaptureErrorHandler")
	private DataCaptureErrorHandler errorHandler;
	
	@Autowired
	private ProviderAttributesDataMasker dataMasker;

	@Autowired
	private ProviderDataCaptureProv2ServiceImpl providerDataCaptureProv2ServiceImpl;

	@Timed(value = "messages.processed", extraTags = {"listener","prov2"})
	@JmsListener(containerFactory = "prov2ListenerContainerFactory", destination = "#{@prov2QueueName}")
	@Retryable(value = {ProviderDemographicsNotFoundException.class,
			MongoException.class }, maxAttemptsExpression = "#{${datacapture.retry.attempts}}", backoff = @Backoff(delayExpression = "#{${datacapture.retry.backoff}}"))
	public void newProviderDataRecieved(Message message) throws IOException, ProviderDemographicsNotFoundException, ProviderAttributesNotFoundException, JMSException {
		String providerData=message.getBody(String.class);
		LogUtils.logAtInfo(log, "Incoming message : {}", dataMasker.getProv2JsonDataMasker().maskSupplier(providerData));
		providerDataCaptureProv2ServiceImpl.processProviderData(providerData);
	}


	@Recover
	public void handleProviderDemographicsNotFoundException(ProviderDemographicsNotFoundException e, Message message) {
		errorHandler.handleRetryableMessageProcessingException(message, e);
	}
	
	@Recover
	public void handleMongoException(MongoException e, Message message) {
		errorHandler.handleRetryableMessageProcessingException(message, e);
	}

	@Recover
	public void handleException(Exception e, Message message) {
		errorHandler.handleNonretryableMessageProcessingException(message, e);
	}
}

package com.humana.claims.hcaas.provider.datacapture.mapper.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.humana.claims.hcaas.provider.datacapture.mapper.ProviderMqDeserializer;
import com.humana.claims.hcaas.provider.datacapture.mapper.ProviderMqJsonDeserializer;

@Configuration
public class ProviderJsonDeserializerConfig {
	
	@Bean
	public ProviderMqDeserializer providerMqDeserializer() {
		return new ProviderMqJsonDeserializer();
	}

}

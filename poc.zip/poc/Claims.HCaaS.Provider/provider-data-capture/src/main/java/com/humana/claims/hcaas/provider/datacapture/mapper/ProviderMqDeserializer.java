package com.humana.claims.hcaas.provider.datacapture.mapper;

import java.io.IOException;

import com.humana.claims.hcaas.provider.model.mq.Prv2OutRecord;
import com.humana.claims.hcaas.provider.model.mq.Prv3OutRecord;
import com.humana.claims.hcaas.provider.model.mq.PrvMaster;

public interface ProviderMqDeserializer {

	PrvMaster deserializeProviderMaster(String providerData) throws IOException;

	Prv2OutRecord deserializeProviderOutRecord2(String providerData) throws IOException;

	Prv3OutRecord deserializeProviderOutRecord3(String providerData) throws IOException;
}

package com.humana.claims.hcaas.provider.datacapture.mapper;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.Charset;

import org.apache.commons.io.FileUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.humana.claims.hcaas.provider.model.mq.Prv2OutRecord;
import com.humana.claims.hcaas.provider.model.mq.Prv3OutRecord;
import com.humana.claims.hcaas.provider.model.mq.PrvMaster;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
public class ProviderMqJsonDeserializerTest {

	private static final String prov1File;
	private static final String prov2File;
	private static final String prov3File;
	
	@InjectMocks
	private ProviderMqJsonDeserializer jsonDeserializer;
	
	static {
		prov1File = readFileToString("default-objects/Prov1.json");
		prov2File = readFileToString("default-objects/Prov2.json");
		prov3File = readFileToString("default-objects/Prov3.json");
	}

	@Test
	public void validateProvider1JsonFileDesrialization() throws IOException {
		PrvMaster actual = jsonDeserializer.deserializeProviderMaster(prov1File);
		validateAttributesFieldFromProvider1(actual);
		validateDemographicsFieldFromProvider1(actual);
	}

	@Test
	public void validateProvider2JsonFileDesrialization() throws IOException {
		Prv2OutRecord actual = jsonDeserializer.deserializeProviderOutRecord2(prov2File);
		validateAttributesFieldFromProvider2(actual);
		validateDemographicsFieldFromProvider2(actual);
	}

	@Test
	public void validateProvider3JsonFileDesrialization() throws IOException {
		Prv3OutRecord actual = jsonDeserializer.deserializeProviderOutRecord3(prov3File);
		validateAttributesFieldFromProvider3(actual);
	}

	private void validateAttributesFieldFromProvider1(PrvMaster actual) {
		assertThat(actual.getPrvKey().getPrvClient()).isEqualTo("58");
		assertThat(actual.getPrvKey().getPrvMultAddressKey()).isEqualTo(" ");
		assertThat(actual.getPrvKey().getPrvProv()).isEqualTo("000073867");
		assertThat(actual.getPrvKey().getPrvPvdInd()).isEqualTo("D");
		assertThat(actual.getPrvIrsNo()).isEqualTo("700923759");
		assertProv1AttributeProviderInfoFields(actual);
	}

	private void assertProv1AttributeProviderInfoFields(PrvMaster actual) {
		assertThat(actual.getPrvProviderInfo().getPrvVch()).isEqualTo("K");
		assertThat(actual.getPrvProviderInfo().getPrvTaxType()).isEqualTo("H");
		assertThat(actual.getPrvProviderInfo().getPrvSend1099Ind()).isEqualTo("N");
		assertThat(actual.getPrvProviderInfo().getPrvPendEsc()).isEqualTo("T");
		assertThat(actual.getPrvProviderInfo().getPrvAutoCheckPullInd()).isEqualTo("N");
		assertThat(actual.getPrvProviderInfo().getPrvIrsWithholdInd()).isEqualTo("T");
		assertThat(actual.getPrvProviderInfo().getPrvPayCycle()).isEqualTo("S5");
		assertThat(actual.getPrvProviderInfo().getPrvCrossRef()).isEqualTo("564732222");
		assertThat(actual.getPrvProviderInfo().getPrvMarketId()).isEqualTo("80650");
		assertThat(actual.getPrvProviderInfo().getPrvDg()).isEqualTo("12T");
		assertThat(actual.getPrvProviderInfo().getPrvAlphaKey()).isEqualTo("ROCKY MOUNTAIN FAMIL");
		assertThat(actual.getPrvProviderInfo().getPrvMedSuppWaiveInd()).isEqualTo("X");
		assertThat(actual.getPrvProviderInfo().getPrvComment()).isEqualTo("PRov1 update JSON test");
		assertThat(actual.getPrvProviderInfo().getPrvNotifyInd()).isEqualTo("N");
		assertThat(actual.getPrvProviderInfo().getPrvFocusFromDate()).isEqualTo("101011");
		assertThat(actual.getPrvProviderInfo().getPrvClpthInd()).isEqualTo("E");
		assertThat(actual.getPrvProviderInfo().getPrvClmChkInd()).isEqualTo("Q");
		assertThat(actual.getPrvProviderInfo().getPrvUcZip()).isEqualTo("80022");
		assertThat(actual.getPrvProviderInfo().getPrvFocusToDate()).isEqualTo("101011");
		assertThat(actual.getPrvProviderInfo().getPrvAutoLoadInd()).isEqualTo("2");
		assertProv1AttributeCasNameFields(actual);
		assertProv1CheckToAixFields(actual);
	}
	
	private void assertProv1AttributeCasNameFields(PrvMaster actual) {
		assertThat(actual.getPrvProviderInfo().getPrvProvCasNameGfld().getPrvProvCasFstName()).isEqualTo("PRov1 First name");
		assertThat(actual.getPrvProviderInfo().getPrvProvCasNameGfld().getPrvProvCasLastName()).isEqualTo("PRov1 Last name");
	}
	
	private void assertProv1CheckToAixFields(PrvMaster actual) {
		assertThat(actual.getPrvProviderInfo().getPrvCheckToAixKey().getPrvCheckTo()).isEqualTo("123456789");
		assertThat(actual.getPrvProviderInfo().getPrvCheckToAixKey().getPrvSuffixTo()).isEqualTo("A");
	}

	private void validateDemographicsFieldFromProvider1(PrvMaster actual) {
		assertThat(actual.getPrvKey().getPrvClient()).isEqualTo("58");
		assertThat(actual.getPrvKey().getPrvMultAddressKey()).isEqualTo(" ");
		assertThat(actual.getPrvKey().getPrvProv()).isEqualTo("000073867");
		assertThat(actual.getPrvKey().getPrvPvdInd()).isEqualTo("D");
		assertThat(actual.getPrvIrsNo()).isEqualTo("700923759");
		assertThat(actual.getPrvTinEffDt()).isEqualTo("101011");
		assertThat(actual.getPrvUpdateSys()).isEqualTo("S");
		assertProv1DemographicProviderInfoFields(actual);
	}

	private void assertProv1DemographicProviderInfoFields(PrvMaster actual) {
		assertThat(actual.getPrvProviderInfo().getPrvProvName()).isEqualTo("ROC KY MOUNTAIN FAMILY");
		assertThat(actual.getPrvProviderInfo().getPrvCity()).isEqualTo("DENVERVBFDYUSGB");
		assertThat(actual.getPrvProviderInfo().getPrvSt()).isEqualTo("CO");
		assertThat(actual.getPrvProviderInfo().getPrvZip()).isEqualTo("802173848");
		assertThat(actual.getPrvProviderInfo().getPrvProvType()).isEqualTo("MD");
		assertThat(actual.getPrvProviderInfo().getPrvMajClsCd()).isEqualTo("G");
		assertThat(actual.getPrvProviderInfo().getPrvGroupFlag()).isEqualTo("T");
		assertThat(actual.getPrvProviderInfo().getPrvPhone()).isEqualTo("3036958684");
		assertThat(actual.getPrvProviderInfo().getPrvAdjNo()).isEqualTo("AUTOMKT");
		assertThat(actual.getPrvProviderInfo().getPrvChgDt()).isEqualTo("03182020");
		assertThat(actual.getPrvProviderInfo().getPrvPriorInfo().getPrvNoPay()).isEqualTo("1");
		assertThat(actual.getPrvProviderInfo().getPrvPriorInfo().getPrvNoPayDt()).isEqualTo("101011");
		assertThat(actual.getPrvProviderInfo().getPrvPvdStRc()).isEqualTo("1A");
		validateProv1DemographicAddressFields(actual);
	}
	
	private void validateProv1DemographicAddressFields(PrvMaster actual) {
		assertThat(actual.getPrvProviderInfo().getPrvAddress().getPrvAddr1()).isEqualTo("PO BOX 173848");
		assertThat(actual.getPrvProviderInfo().getPrvAddress().getPrvAddr2()).isEqualTo("PRov1 Addr2");
		assertThat(actual.getPrvProviderInfo().getPrvAddress().getPrvAddr3()).isEqualTo("PRov1 Addr3");
		assertThat(actual.getPrvProviderInfo().getPrvAddress().getPrvAddr4()).isEqualTo("PRov1 Addr4");
	}

	private void validateAttributesFieldFromProvider2(Prv2OutRecord actual) {
		assertThat(actual.getPrv2Key().getPrv2Client()).isEqualTo("58");
		assertThat(actual.getPrv2Key().getPrv2MultAddressKey()).isEqualTo(" ");
		assertThat(actual.getPrv2Key().getPrv2Prov()).isEqualTo("000073867");
		assertThat(actual.getPrv2Key().getPrv2PvdInd()).isEqualTo("D");
		assertPrv2AttributesProviderInfoFields(actual);
	}

	private void assertPrv2AttributesProviderInfoFields(Prv2OutRecord actual) {
		assertThat(actual.getPrv2Provider2Info().getPrv2ApplyTaxInd()).isEqualTo("N");
		assertThat(actual.getPrv2Provider2Info().getPrv2W9Ind()).isEqualTo("T");
		assertThat(actual.getPrv2Provider2Info().getPrv2Send480Ind()).isEqualTo("A");
		assertThat(actual.getPrv2Provider2Info().getPrv2Comment2()).isEqualTo("PRov2 update JSON test");
		assertThat(actual.getPrv2Provider2Info().getPrv2Comment3()).isEqualTo("PRov2 update JSON test");
		assertThat(actual.getPrv2Provider2Info().getPrv2VendorId()).isEqualTo("318282");
		assertThat(actual.getPrv2Provider2Info().getPrv2UpdtAdjNo()).isEqualTo("CFI0017");
		assertThat(actual.getPrv2Provider2Info().getPrv2UpdtDt()).isEqualTo("12152015");
		assertThat(actual.getPrv2Provider2Info().getPrv2FacUcZip()).isEqualTo("08765");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiUpdtAdjNo()).isEqualTo("HFGCBVT");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiUpdtDt()).isEqualTo("20201115");
		assertThat(actual.getPrv2Provider2Info().getPrv2ClmChkInd()).isEqualTo("F");
		assertThat(actual.getPrv2Provider2Info().getPrv2SendLtrInd()).isEqualTo("G");
		assertThat(actual.getPrv2Provider2Info().getPrv2FinalstInd()).isEqualTo("K");
		assertPrv2AttributesPxiZipFields(actual);
		assertPrv2AttributesPxiPtsLobAreaFields(actual);
		assertPrv2AttributesRadFields(actual);
		assertPrv2AttributesCompFields(actual);
	}
	
	private void assertPrv2AttributesCompFields(Prv2OutRecord actual) {
		assertThat(actual.getPrv2Provider2Info().getPrv2CompbidInd()).isEqualTo("N");
		assertThat(actual.getPrv2Provider2Info().getPrv2CompbidEffDt()).isEqualTo("12152015");
		assertThat(actual.getPrv2Provider2Info().getPrv2CompbidTrmDt()).isEqualTo("12152015");
	}

	private void assertPrv2AttributesRadFields(Prv2OutRecord actual) {
		assertThat(actual.getPrv2Provider2Info().getPrv2RadSiteCurrInd()).isEqualTo("Q");
		assertThat(actual.getPrv2Provider2Info().getPrv2RadSiteCurrDt()).isEqualTo("1911");
		assertThat(actual.getPrv2Provider2Info().getPrv2RadSiteP1Ind()).isEqualTo("J");
		assertThat(actual.getPrv2Provider2Info().getPrv2RadSiteP1Dt()).isEqualTo("1911");
		assertThat(actual.getPrv2Provider2Info().getPrv2RadSiteP2Ind()).isEqualTo("A");
		assertThat(actual.getPrv2Provider2Info().getPrv2RadSiteP2Dt()).isEqualTo("1911");
		assertThat(actual.getPrv2Provider2Info().getPrv2RadScopeCurrDt()).isEqualTo("1911");
		assertThat(actual.getPrv2Provider2Info().getPrv2RadScopeCurrInd()).isEqualTo("K");
		assertThat(actual.getPrv2Provider2Info().getPrv2RadScopeP1Ind()).isEqualTo("L");
		assertThat(actual.getPrv2Provider2Info().getPrv2RadScopeP1Dt()).isEqualTo("1911");
	}

	private void assertPrv2AttributesPxiZipFields(Prv2OutRecord actual) {
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiZip1()).isEqualTo("QWE12");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiZip2()).isEqualTo("QWE12");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiZip3()).isEqualTo("QWE12");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiZip4()).isEqualTo("QWE12");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiZip5()).isEqualTo("QWE12");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiZip6()).isEqualTo("QWE12");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiZip7()).isEqualTo("QWE12");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiZip7()).isEqualTo("QWE12");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiZip9()).isEqualTo("QWE12");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiZip10()).isEqualTo("QWE12");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiZip11()).isEqualTo("QWE12");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiZip12()).isEqualTo("QWE12");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiZip13()).isEqualTo("QWE12");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiZip14()).isEqualTo("QWE12");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiZip15()).isEqualTo("QWE12");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiZip16()).isEqualTo("QWE12");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiZip17()).isEqualTo("QWE12");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiZip18()).isEqualTo("QWE12");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiZip19()).isEqualTo("QWE12");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiZip20()).isEqualTo("QWE12");
	}

	private void assertPrv2AttributesPxiPtsLobAreaFields(Prv2OutRecord actual) {
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiPtsLobArea().getPrv2PxiPtsLob1()).isEqualTo("J");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiPtsLobArea().getPrv2PxiPtsLob2()).isEqualTo("J");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiPtsLobArea().getPrv2PxiPtsLob3()).isEqualTo("J");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiPtsLobArea().getPrv2PxiPtsLob4()).isEqualTo("T");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiPtsLobArea().getPrv2PxiPtsLob5()).isEqualTo("T");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiPtsLobArea().getPrv2PxiPtsLob6()).isEqualTo("T");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiPtsLobArea().getPrv2PxiPtsLob7()).isEqualTo("T");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiPtsLobArea().getPrv2PxiPtsLob8()).isEqualTo("T");
		assertThat(actual.getPrv2Provider2Info().getPrv2PxiPtsLobArea().getPrv2PxiPtsLob9()).isEqualTo("T");
	}

	private void validateDemographicsFieldFromProvider2(Prv2OutRecord actual) {
		assertThat(actual.getPrv2Key().getPrv2Client()).isEqualTo("58");
		assertThat(actual.getPrv2Key().getPrv2MultAddressKey()).isEqualTo(" ");
		assertThat(actual.getPrv2Key().getPrv2Prov()).isEqualTo("000073867");
		assertThat(actual.getPrv2Key().getPrv2PvdInd()).isEqualTo("D");
		assertPrv2DemographicNpiFields(actual);
		assertPrv2DemographicTaxanomyCodeFields(actual);
	}

	private void assertPrv2DemographicNpiFields(Prv2OutRecord actual) {
		assertThat(actual.getPrv2Provider2Info().getPrv2Npi()).isEqualTo("N");
		assertThat(actual.getPrv2Provider2Info().getPrv2Npi2()).isEqualTo("P");
		assertThat(actual.getPrv2Provider2Info().getPrv2Npi3()).isEqualTo("I");
		assertThat(actual.getPrv2Provider2Info().getPrv2Npi4()).isEqualTo("N");
		assertThat(actual.getPrv2Provider2Info().getPrv2Npi5()).isEqualTo("P");
		assertThat(actual.getPrv2Provider2Info().getPrv2Npi6()).isEqualTo("I");
		assertThat(actual.getPrv2Provider2Info().getPrv2Npi7()).isEqualTo("N");
		assertThat(actual.getPrv2Provider2Info().getPrv2Npi8()).isEqualTo("P");
		assertThat(actual.getPrv2Provider2Info().getPrv2Npi9()).isEqualTo("I");
	}

	private void assertPrv2DemographicTaxanomyCodeFields(Prv2OutRecord actual) {
		assertThat(actual.getPrv2Provider2Info().getPrv2TaxonomyCode()).isEqualTo("T");
		assertThat(actual.getPrv2Provider2Info().getPrv2TaxonomyCode2()).isEqualTo("A");
		assertThat(actual.getPrv2Provider2Info().getPrv2TaxonomyCode3()).isEqualTo("X");
		assertThat(actual.getPrv2Provider2Info().getPrv2TaxonomyCode4()).isEqualTo("O");
		assertThat(actual.getPrv2Provider2Info().getPrv2TaxonomyCode5()).isEqualTo("N");
		assertThat(actual.getPrv2Provider2Info().getPrv2TaxonomyCode6()).isEqualTo("O");
		assertThat(actual.getPrv2Provider2Info().getPrv2TaxonomyCode7()).isEqualTo("M");
		assertThat(actual.getPrv2Provider2Info().getPrv2TaxonomyCode8()).isEqualTo("Y");
		assertThat(actual.getPrv2Provider2Info().getPrv2TaxonomyCode9()).isEqualTo("C");
		assertThat(actual.getPrv2Provider2Info().getPrv2TaxonomyCode10()).isEqualTo("D");
	}

	private void validateAttributesFieldFromProvider3(Prv3OutRecord actual) {
		assertThat(actual.getPrv3Key().getPrv3Client()).isEqualTo("58");
		assertThat(actual.getPrv3Key().getPrv3MultAddressKey()).isEqualTo(" ");
		assertThat(actual.getPrv3Key().getPrv3Prov()).isEqualTo("000073867");
		assertThat(actual.getPrv3Key().getPrv3PvdInd()).isEqualTo("D");
		assertPrv3AttributesWithHoldData(actual);
	}

	private void assertPrv3AttributesWithHoldData(Prv3OutRecord actual) {
		assertThat(actual.getPrv3ProvWithholdData().getPrv3ProvWthldCurrent().getPrv3WthldPerC()).isEqualTo("255.58");
		assertThat(actual.getPrv3ProvWithholdData().getPrv3ProvWthldPrior().getPrv3WthldPerP()).isEqualTo("455.99");
		assertThat(actual.getPrv3ProvWithholdData().getPrv3ProvPrTaxfreeAmt()).isEqualTo("9899.65");
		assertThat(actual.getPrv3ProvWithholdData().getPrv3ProvWthldCurrent().getPrv3WthldEffDateC()).isEqualTo("20201115");
		assertThat(actual.getPrv3ProvWithholdData().getPrv3ProvWthldPrior().getPrv3WthldEffDateP()).isEqualTo("20201115");
	}

	@SneakyThrows
	private static String readFileToString(String filepath) {
		URI filePathUri = ProviderJsonMessageMasterMother.class.getClassLoader().getResource(filepath).toURI();
		File file = new File(filePathUri);
		return FileUtils.readFileToString(file, Charset.forName("UTF-8"));
	}
}

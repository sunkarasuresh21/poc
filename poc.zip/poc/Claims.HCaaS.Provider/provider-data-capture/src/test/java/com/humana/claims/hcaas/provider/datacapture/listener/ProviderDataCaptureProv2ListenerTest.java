package com.humana.claims.hcaas.provider.datacapture.listener;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import javax.jms.Message;

import org.apache.qpid.jms.message.JmsTextMessage;
import org.apache.qpid.jms.provider.amqp.message.AmqpJmsTextMessageFacade;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.humana.claims.hcaas.common.data.capture.starter.newerrorhandlers.DataCaptureErrorHandler;
import com.humana.claims.hcaas.common.utils.datamasking.JsonMasker;
import com.humana.claims.hcaas.provider.attributes.core.dao.ProviderAttributesDAO;
import com.humana.claims.hcaas.provider.attributes.core.exception.ProviderAttributesNotFoundException;
import com.humana.claims.hcaas.provider.attributes.core.masker.ProviderAttributesDataMasker;
import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.datacapture.geocode.model.Location;
import com.humana.claims.hcaas.provider.datacapture.geocode.service.GeoCodeService;
import com.humana.claims.hcaas.provider.datacapture.mapper.ProviderDataMapper;
import com.humana.claims.hcaas.provider.datacapture.mapper.ProviderMqDeserializer;
import com.humana.claims.hcaas.provider.datacapture.service.ProviderDataCaptureProv2ServiceImpl;
import com.humana.claims.hcaas.provider.demographics.core.dao.ProviderDemographicsDAO;
import com.humana.claims.hcaas.provider.demographics.core.exception.ProviderDemographicsNotFoundException;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.demographics.core.model.db.DemographicsKey;
import com.humana.claims.hcaas.provider.model.mq.Prv2Key;
import com.humana.claims.hcaas.provider.model.mq.Prv2OutRecord;
import com.humana.claims.hcaas.provider.model.mq.Prv2Provider2Info;
import com.mongodb.MongoException;

import lombok.SneakyThrows;

@ExtendWith(SpringExtension.class)
@ContextConfiguration
@TestPropertySource("classpath:test-application.properties")
@DirtiesContext(classMode = ClassMode.AFTER_EACH_TEST_METHOD)
public class ProviderDataCaptureProv2ListenerTest {
	
	@Autowired
	@Qualifier("prov2DataCaptureErrorHandler")
	@Mock
	private DataCaptureErrorHandler errorHandler;

	@Autowired
	private ProviderDataCaptureProv2Listener providerDataCaptureProv2Listener;
	
	@Autowired
	private ProviderDataMapper converter;

	@Autowired
	private ProviderDemographicsDAO providerDemographicsDAO;

	@Autowired
	private ProviderAttributesDAO providerAttributesDAO;
	
	@Autowired
	private ProviderAttributesDataMasker dataMasker;
	
	@Autowired
	private ProviderMqDeserializer mqMessageDeserializer;
	
	@Autowired
	private GeoCodeService geoCodeService;
	
	@Test
	void testRetryLogicWhenMongoExceptionOccurs() throws Exception {
		Demographics demographics = new Demographics();
		DemographicsKey demographicsKey = new DemographicsKey();
		demographicsKey.setClient("50");
		demographics.setKey(demographicsKey);
		Prv2OutRecord prv2OutRecord = getPrv2OutRecord();
		
		when(geoCodeService.getGeoCode(any())).thenReturn(new Location());
		when(dataMasker.getProv2JsonDataMasker()).thenReturn(new JsonMasker());
		when(mqMessageDeserializer.deserializeProviderOutRecord2(any())).thenReturn(prv2OutRecord);
		doReturn(demographics).when(converter).mapDemographicsFromProviderData2(prv2OutRecord);
		doThrow(MongoException.class).when(providerDemographicsDAO).updateProviderDemographicsProv2(demographics);
		doNothing().when(errorHandler).handleRetryableMessageProcessingException(any(), any(Exception.class));
		providerDataCaptureProv2Listener.newProviderDataRecieved(textMessage("'TEST'"));
		verify(providerDemographicsDAO, times(3)).updateProviderDemographicsProv2(demographics);
		verify(errorHandler, times(1)).handleRetryableMessageProcessingException(any(), any(Exception.class));
		verify(errorHandler, times(0)).handleNonretryableMessageProcessingException(any(), any(Exception.class));
		verify(dataMasker, times(3)).getProv2JsonDataMasker();
	}
	

	@Test
	void testRetryLogicWhenProviderDemographicsNotFoundExceptionOccurs() throws Exception {
		Demographics demographics = new Demographics();
		DemographicsKey demographicsKey = new DemographicsKey();
		demographicsKey.setClient("50");
		demographics.setKey(demographicsKey);
		Prv2OutRecord prv2OutRecord = getPrv2OutRecord();
		
		when(geoCodeService.getGeoCode(any())).thenReturn(new Location());
		when(dataMasker.getProv2JsonDataMasker()).thenReturn(new JsonMasker());
		when(mqMessageDeserializer.deserializeProviderOutRecord2(any())).thenReturn(prv2OutRecord);
		doReturn(demographics).when(converter).mapDemographicsFromProviderData2(prv2OutRecord);
		doThrow(ProviderDemographicsNotFoundException.class).when(providerDemographicsDAO).updateProviderDemographicsProv2(demographics);
		doNothing().when(errorHandler).handleRetryableMessageProcessingException(any(), any(Exception.class));
		providerDataCaptureProv2Listener.newProviderDataRecieved(textMessage("'TEST'"));
		verify(providerDemographicsDAO, times(3)).updateProviderDemographicsProv2(demographics);
		verify(errorHandler, times(1)).handleRetryableMessageProcessingException(any(), any(Exception.class));
		verify(errorHandler, times(0)).handleNonretryableMessageProcessingException(any(), any(Exception.class));
		verify(dataMasker, times(3)).getProv2JsonDataMasker();
	}
	
	@Test
	void testRetryLogicWhenNoneRetryExceptionOccurs() throws Exception {
		Demographics demographics = new Demographics();
		DemographicsKey demographicsKey = new DemographicsKey();
		demographicsKey.setClient("50");
		demographics.setKey(demographicsKey);
		Prv2OutRecord prv2OutRecord = getPrv2OutRecord();
		
		when(geoCodeService.getGeoCode(any())).thenReturn(new Location());
		when(dataMasker.getProv2JsonDataMasker()).thenReturn(new JsonMasker());
		when(mqMessageDeserializer.deserializeProviderOutRecord2(any())).thenReturn(prv2OutRecord);
		doReturn(demographics).when(converter).mapDemographicsFromProviderData2(prv2OutRecord);
		doThrow(RuntimeException.class).when(providerDemographicsDAO).updateProviderDemographicsProv2(demographics);
		doNothing().when(errorHandler).handleNonretryableMessageProcessingException(any(), any(Exception.class));
		providerDataCaptureProv2Listener.newProviderDataRecieved(textMessage("'TEST'"));
		verify(providerDemographicsDAO, times(1)).updateProviderDemographicsProv2(demographics);
		verify(errorHandler, times(0)).handleRetryableMessageProcessingException(any(), any(Exception.class));
		verify(errorHandler, times(1)).handleNonretryableMessageProcessingException(any(), any(Exception.class));
		verify(dataMasker, times(1)).getProv2JsonDataMasker();
	}

	@Test
	void testRetryLogicWhenNoExceptionOccursAndSuccessful() throws Exception {
		Demographics demographics = new Demographics();
		DemographicsKey demographicsKey = new DemographicsKey();
		demographicsKey.setClient("50");
		demographics.setKey(demographicsKey);
		Attributes providerAttributes = new Attributes();
		com.humana.claims.hcaas.provider.attributes.core.model.db.AttributesKey attributeKey = new com.humana.claims.hcaas.provider.attributes.core.model.db.AttributesKey();
		demographicsKey.setClient("50");
		providerAttributes.setKey(attributeKey);
		Prv2OutRecord prv2OutRecord = getPrv2OutRecord();
		
		when(geoCodeService.getGeoCode(any())).thenReturn(new Location());
		when(dataMasker.getProv2JsonDataMasker()).thenReturn(new JsonMasker());
		when(mqMessageDeserializer.deserializeProviderOutRecord2(any())).thenReturn(prv2OutRecord);
		doReturn(demographics).when(converter).mapDemographicsFromProviderData2(prv2OutRecord);
		doReturn(providerAttributes).when(converter).mapAttributesFromProviderData2(prv2OutRecord);
		doNothing().when(providerDemographicsDAO).upsertProviderDemographicsProv1(demographics);
		doNothing().when(providerAttributesDAO).upsertProviderAttributesProv1(providerAttributes);
		providerDataCaptureProv2Listener.newProviderDataRecieved(textMessage("'TEST'"));
		verify(mqMessageDeserializer, times(1)).deserializeProviderOutRecord2("'TEST'");
		verify(converter, times(1)).mapAttributesFromProviderData2(prv2OutRecord);
		verify(providerDemographicsDAO, times(1)).updateProviderDemographicsProv2(demographics);
		verify(providerAttributesDAO, times(1)).updateProviderAttributesProv2(providerAttributes);
		verify(dataMasker, times(1)).getProv2JsonDataMasker();
	}
	
	private Prv2OutRecord getPrv2OutRecord() {
		Prv2OutRecord prv2OutRecord = new Prv2OutRecord();
		Prv2Key prv2Key = new Prv2Key();
		Prv2Provider2Info prv2Provider2Info = new Prv2Provider2Info();
		prv2Provider2Info.setPrv2Npi("Prv2Npi");
		prv2OutRecord.setPrv2Key(prv2Key);
		prv2Key.setPrv2Client("Prv2Client");
		prv2Key.setPrv2MultAddressKey("Prv2MultAddressKey");
		prv2Key.setPrv2Prov("Prv2Prov");
		prv2Key.setPrv2PvdInd("Prv2PvdInd");
		prv2OutRecord.setPrv2Provider2Info(prv2Provider2Info);
		return prv2OutRecord;
	}

	@Configuration
	@EnableRetry
	public static class ProviderRetryConfig {

		@Bean
		public DataCaptureErrorHandler prov2DataCaptureErrorHandler() {
			return mock(DataCaptureErrorHandler.class);
		}

		@Bean
		public ProviderDataMapper converter() {
			return mock(ProviderDataMapper.class);
		}

		@Bean
		public ProviderMqDeserializer mqMessageDeserializer() {
			return mock(ProviderMqDeserializer.class);
		}

		@Bean
		public ProviderAttributesDAO providerAttributesDAO() {
			return mock(ProviderAttributesDAO.class);
		}
		
		@Bean
		public ProviderDemographicsDAO providerDemographicsDAO() {
			return mock(ProviderDemographicsDAO.class);
		}
		
		@Bean
		public ProviderAttributesDataMasker dataMasker() {
			return mock(ProviderAttributesDataMasker.class);
		}
		
		@Bean
		public GeoCodeService geoCode() {
			return mock(GeoCodeService.class);
		}
		
		@Bean
		public ProviderDataCaptureProv2Listener providerDataCaptureProv2Listener() throws Exception {
			ProviderDataCaptureProv2Listener exceptionListener = new ProviderDataCaptureProv2Listener();

			ReflectionTestUtils.setField(exceptionListener, "errorHandler", prov2DataCaptureErrorHandler());
			ReflectionTestUtils.setField(exceptionListener, "providerDataCaptureProv2ServiceImpl",
					providerDataCaptureProv2ServiceImpl());
			ReflectionTestUtils.setField(exceptionListener, "dataMasker", dataMasker());
			return exceptionListener;
		}

		@Bean
		public ProviderDataCaptureProv2ServiceImpl providerDataCaptureProv2ServiceImpl() throws Exception {
			return new ProviderDataCaptureProv2ServiceImpl(converter(), providerDemographicsDAO(), providerAttributesDAO(), mqMessageDeserializer());
		}
	}
	
	@SneakyThrows
	public Message textMessage(String text) {
		JmsTextMessage jmsTextMessage = new JmsTextMessage(new AmqpJmsTextMessageFacade());
		jmsTextMessage.setText(text);
		return jmsTextMessage;
	}
	
}
package com.humana.claims.hcaas.provider.datacapture.geocode.client;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.client.ExpectedCount;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.humana.claims.hcaas.provider.datacapture.exception.GeoCodeBadRequestException;
import com.humana.claims.hcaas.provider.datacapture.geocode.model.GeoCodeApiResponse;
import com.humana.claims.hcaas.provider.datacapture.geocode.model.Geometry;
import com.humana.claims.hcaas.provider.datacapture.geocode.model.Location;
import com.humana.claims.hcaas.provider.datacapture.geocode.model.Result;

import lombok.SneakyThrows;

class GeoCodeApiClientTest {

	private GeoCodeApiClient classUnderTest;

	private ObjectMapper objectMapper = new ObjectMapper();

	private MockRestServiceServer mockServer;

	public static final String key = "32646476";

	@BeforeEach
	public void setup() {
		RestTemplate restTemplate = new GeoCodeApiClientConfig("https://geocode-mock-service:8081").geoCodeRestTemplate();

		mockServer = MockRestServiceServer.bindTo(restTemplate).build();

		classUnderTest = new GeoCodeApiClient(restTemplate, key);
	}

	@Test
	void testWhenAddressIsNullThrowsGeoCodeBadRequestException() {

		assertThatExceptionOfType(GeoCodeBadRequestException.class).isThrownBy(() -> {
			classUnderTest.geocode(null);
		});
	}
	
	@Test
	@SneakyThrows
	void getGeoCodeApiResponseFromGeoCodeApi(){

		GeoCodeApiResponse geoCodeApiResponse = geoCodeApiResponse();
		
		mockServer.expect(ExpectedCount.manyTimes(), requestTo(new URI("https://geocode-mock-service:8081?address=321%2Bwest%2Bmain%2Bstreet%2BLouisville%2BKY%2B40202&key=32646476")))
				.andExpect(method(HttpMethod.GET))
				.andRespond(withStatus(HttpStatus.OK).contentType(MediaType.APPLICATION_JSON)
						.body(this.objectMapper.writeValueAsString(geoCodeApiResponse)));

		GeoCodeApiResponse actual = classUnderTest.geocode("321+west+main+street+Louisville+KY+40202");

		mockServer.verify();
		assertThat(actual).isEqualTo(geoCodeApiResponse);
	}

	@Test
	@SneakyThrows
	void spaces_in_address_should_be_url_encoded(){

		GeoCodeApiResponse geoCodeApiResponse = geoCodeApiResponse();
		
		mockServer.expect(ExpectedCount.manyTimes(), requestTo(new URI("https://geocode-mock-service:8081?address=321%20west%20main%20street%20Louisville%20KY%2040202&key=32646476")))
				.andExpect(method(HttpMethod.GET))
				.andRespond(withStatus(HttpStatus.OK).contentType(MediaType.APPLICATION_JSON)
						.body(this.objectMapper.writeValueAsString(geoCodeApiResponse)));

		GeoCodeApiResponse actual = classUnderTest.geocode("321 west main street Louisville KY 40202");

		mockServer.verify();
		assertThat(actual).isEqualTo(geoCodeApiResponse);
	}

	@Test
	@SneakyThrows
	void all_special_chars_should_be_url_encoded(){

		GeoCodeApiResponse geoCodeApiResponse = geoCodeApiResponse();
		
		mockServer.expect(ExpectedCount.manyTimes(), requestTo(new URI("https://geocode-mock-service:8081?address=123space%20plus%2Bcomma%2Clt%3Cgt%3Eoctothorpe%23percent%25pipe%7C&key=32646476")))
				.andExpect(method(HttpMethod.GET))
				.andRespond(withStatus(HttpStatus.OK).contentType(MediaType.APPLICATION_JSON)
						.body(this.objectMapper.writeValueAsString(geoCodeApiResponse)));

		GeoCodeApiResponse actual = classUnderTest.geocode("123space plus+comma,lt<gt>octothorpe#percent%pipe|");

		mockServer.verify();
		assertThat(actual).isEqualTo(geoCodeApiResponse);
	}

	private GeoCodeApiResponse geoCodeApiResponse() throws IOException {

		Location location = new Location();
		location.setLat(38.25824738029149);
		location.setLng(-85.75404721970848);

		Geometry geometry = new Geometry();
		geometry.setLocation(location);

		Result result = new Result();
		result.setGeometry(geometry);

		List<Result> results = new ArrayList<>();
		results.add(result);

		GeoCodeApiResponse testGeoCodeApiResponse = new GeoCodeApiResponse();
		testGeoCodeApiResponse.setResults(results);

		return testGeoCodeApiResponse;
	}
}

package com.humana.claims.hcaas.provider.datacapture.mapper;

import static com.humana.claims.hcaas.provider.datacapture.mapper.ProviderJsonMessageMasterMother.prov1;
import static com.humana.claims.hcaas.provider.datacapture.mapper.ProviderJsonMessageMasterMother.prov2;
import static com.humana.claims.hcaas.provider.datacapture.mapper.ProviderJsonMessageMasterMother.prov3;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.humana.claims.hcaas.common.utils.MainframeDateUtils;
import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.datacapture.geocode.model.Location;
import com.humana.claims.hcaas.provider.datacapture.geocode.service.GeoCodeService;
import com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsConstants;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.demographics.core.model.db.NpiInfos;
import com.humana.claims.hcaas.provider.demographics.core.model.db.TaxonomyCode;
import com.humana.claims.hcaas.provider.model.mq.Prv2OutRecord;
import com.humana.claims.hcaas.provider.model.mq.Prv3OutRecord;
import com.humana.claims.hcaas.provider.model.mq.PrvMaster;

@ExtendWith(MockitoExtension.class)
public class ProviderJsonDataMapperTest {

	@InjectMocks
	private ProviderDataMapper classUnderTest;
	
	@Mock
	private GeoCodeService mockGeoCodeService; 

	@Test
	public void validateDemographicsActiveField() {
		PrvMaster prvMaster = prov1().buildProv1Record();
		prvMaster.getPrvProviderInfo().setPrvPvdStRc("SF");
		
		when(mockGeoCodeService.getGeoCode(any())).thenReturn(dummyLocation());
		
		Demographics actual = classUnderTest.mapDemographicsFromProviderData1(prvMaster);
		
		assertThat(actual.getProviderInfo().getPvdStRc()).isEqualTo("SF");
		assertThat(actual.getPvdStatus()).isEqualTo("1");
	}
	
	@Test
	public void validateDemographicsActiveFieldWithDiffStatus() {
		PrvMaster prvMaster = prov1().buildProv1Record();
		prvMaster.setPrvPvdStatus("0");
		prvMaster.getPrvProviderInfo().setPrvPvdStRc(" ");
		
		when(mockGeoCodeService.getGeoCode(any())).thenReturn(dummyLocation());
		
		Demographics actual = classUnderTest.mapDemographicsFromProviderData1(prvMaster);
		
		assertThat(actual.getProviderInfo().getPvdStRc()).isEqualTo(" ");
		assertThat(actual.getPvdStatus()).isEqualTo("0");
	}
	
	@Test
	public void validateDemographicsArchiveField() {
		
		PrvMaster prvMaster = prov1().buildProv1Record();
		prvMaster.setPrvPvdStatus("1");
		prvMaster.getPrvProviderInfo().setPrvPvdStRc("AR");
		
		when(mockGeoCodeService.getGeoCode(any())).thenReturn(dummyLocation());

		Demographics actual = classUnderTest.mapDemographicsFromProviderData1(prvMaster);
		
		assertThat(actual.getPvdStatus()).isEqualTo(ProviderDemographicsConstants.ARCHIVED_STATUS_CODE);
		assertThat(actual.getProviderInfo().getPvdStRc()).isEqualTo(ProviderDemographicsConstants.ARCHIVED_REASON_CODE);
	}
	
	@Test
	public void validateAttributesFieldFromProvider1() {
		PrvMaster prvMaster = prov1().buildProv1Record();
		Attributes actual = classUnderTest.mapAttributesFromProviderData1(prvMaster);
		assertThat(actual.getKey().getClient()).isEqualTo("58");
		assertThat(actual.getKey().getMultAddressKey()).isEqualTo(" ");
		assertThat(actual.getKey().getProv()).isEqualTo("000073867");
		assertThat(actual.getKey().getPvdInd()).isEqualTo("D");
		assertThat(actual.getIrsNo()).isEqualTo("700923759");
		assertThat(actual.getVch()).isEqualTo("K");
		assertThat(actual.getTaxType()).isEqualTo("H");
		assertThat(actual.getSend1099Ind()).isEqualTo("N");
		assertThat(actual.getPendEsc()).isEqualTo("T");
		assertThat(actual.getAutoCheckPullInd()).isEqualTo("N");
		assertThat(actual.getIrsWithholdInd()).isEqualTo("T");
		assertThat(actual.getPayCycle()).isEqualTo("S5");
		assertThat(actual.getCrossRef()).isEqualTo("564732222");
		assertThat(actual.getMarketId()).isEqualTo("80650");
		assertThat(actual.getDg()).isEqualTo("12T");
		assertThat(actual.getAlphaKey()).isEqualTo("ROCKY MOUNTAIN FAMIL");
		assertThat(actual.getCasName().getFstName()).isEqualTo("PRov1 First name");
		assertThat(actual.getCasName().getLastName()).isEqualTo("PRov1 Last name");
		assertThat(actual.getMedSuppWaiveInd()).isEqualTo("X");
		assertThat(actual.getComment1()).isEqualTo("PRov1 update JSON test");
		assertThat(actual.getNotifyInd()).isEqualTo("N");
		assertThat(actual.getFocusFromDate()).isEqualTo(MainframeDateUtils
				.convertYYMMDDStringToLocalDate("101011"));
		assertThat(actual.getClpthInd()).isEqualTo("E");
		assertThat(actual.getClmChkInd()).isEqualTo("Q");
		assertThat(actual.getUcZip()).isEqualTo("80022");
		assertThat(actual.getFocusToDate()).isEqualTo(MainframeDateUtils
				.convertYYMMDDStringToLocalDate("101011"));
		assertThat(actual.getAutoLoadInd()).isEqualTo("2");
		assertThat(actual.getCheckTo()).isEqualTo("123456789");
		assertThat(actual.getSuffixTo()).isEqualTo("A");
	}

	@Test
	public void validateAttributesFieldFromProvider2() {
		Prv2OutRecord prvMaster = prov2().buildProv2Record();

		Attributes actual = classUnderTest.mapAttributesFromProviderData2(prvMaster);
		assertThat(actual.getKey().getClient()).isEqualTo("58");
		assertThat(actual.getKey().getMultAddressKey()).isEqualTo(" ");
		assertThat(actual.getKey().getProv()).isEqualTo("000073867");
		assertThat(actual.getKey().getPvdInd()).isEqualTo("D");
		assertThat(actual.getApplyTaxInd()).isEqualTo("N");
		assertThat(actual.getW9Ind()).isEqualTo("T");
		assertThat(actual.getSend480Ind()).isEqualTo("A");
		assertThat(actual.getComment2()).isEqualTo("PRov2 update JSON test");
		assertThat(actual.getComment3()).isEqualTo("PRov2 update JSON test");
		assertThat(actual.getVendorId()).isEqualTo("318282");
		assertThat(actual.getUpdtAdjNo()).isEqualTo("CFI0017");
		assertThat(actual.getUpdtDt()).isEqualTo(MainframeDateUtils
				.convertMMDDYYYYStringToLocalDate("12152015"));
		assertThat(actual.getRadSiteCurrInd()).isEqualTo("Q");
		assertThat(actual.getRadSiteCurrDt()).isEqualTo(MainframeDateUtils
				.convertYYMMStringToLocalDate("1911"));
		assertThat(actual.getRadSiteP1Ind()).isEqualTo("J");
		assertThat(actual.getRadSiteP1Dt()).isEqualTo(MainframeDateUtils
				.convertYYMMStringToLocalDate("1911"));
		assertThat(actual.getRadSiteP2Ind()).isEqualTo("A");
		assertThat(actual.getRadSiteP2Dt()).isEqualTo(MainframeDateUtils
				.convertYYMMStringToLocalDate("1911"));
		assertThat(actual.getRadScopeCurrDt()).isEqualTo(MainframeDateUtils
				.convertYYMMStringToLocalDate("1911"));
		assertThat(actual.getRadScopeCurrInd()).isEqualTo("K");
		assertThat(actual.getRadScopeP1Ind()).isEqualTo("L");
		assertThat(actual.getRadScopeP1Dt()).isEqualTo(MainframeDateUtils
				.convertYYMMStringToLocalDate("1911"));
		assertThat(actual.getFacUcZip()).isEqualTo("08765");
		assertThat(actual.getPxiUpdtAdjNo()).isEqualTo("HFGCBVT");
		assertThat(actual.getPxiUpdtDt()).isEqualTo(MainframeDateUtils
				.convertYYYYMMDDStringToLocalDate("20201115"));
		assertThat(actual.getClmChkInd()).isEqualTo("F");
		assertThat(actual.getSendLtrInd()).isEqualTo("G");
		assertThat(actual.getFinalstInd()).isEqualTo("K");
		assertThat(actual.getPxiZip().size()).isEqualTo(20);
		assertThat(actual.getCompbidInd()).isEqualTo("N");
		assertThat(actual.getCompbidEffDt()).isEqualTo(MainframeDateUtils
				.convertMMDDYYYYStringToLocalDate("12152015"));
		assertThat(actual.getCompbidTrmDt()).isEqualTo(MainframeDateUtils
				.convertMMDDYYYYStringToLocalDate("12152015"));
		assertThat(actual.getContractPointEnable().size()).isEqualTo(9);
	}

	@Test
	public void validateAttributesFieldFromProvider3() {
		Prv3OutRecord prvMaster = prov3().buildProv3Record();
		Attributes actual = classUnderTest.mapAttributesFromProviderData3(prvMaster);
		assertThat(actual.getKey().getClient()).isEqualTo("58");
		assertThat(actual.getKey().getMultAddressKey()).isEqualTo(" ");
		assertThat(actual.getKey().getProv()).isEqualTo("000073867");
		assertThat(actual.getKey().getPvdInd()).isEqualTo("D");
		assertThat(actual.getWithholdData().getWthldCurrent().getWthldPerCurrent()).isEqualTo("255.58");
		assertThat(actual.getWithholdData().getWthldCurrent().getWthldEffDateCurrent()).isEqualTo(MainframeDateUtils.convertYYYYMMDDStringToLocalDate(
				"20201115"));
		assertThat(actual.getWithholdData().getWthldPrior().getWthldEffDatePrior()).isEqualTo(MainframeDateUtils.convertYYYYMMDDStringToLocalDate(
				"20201115"));
		assertThat(actual.getWithholdData().getWthldPrior().getWthldPerPrior()).isEqualTo("455.99");
		assertThat(actual.getWithholdData().getPrTaxfreeAmt()).isEqualTo("9899.65");

	}

	@Test
	public void validateDemographicsFieldFromProvider1() {
		PrvMaster prvMaster = prov1().buildProv1Record();
		
		when(mockGeoCodeService.getGeoCode(any())).thenReturn(dummyLocation());
		
		Demographics actual = classUnderTest.mapDemographicsFromProviderData1(prvMaster);
		assertThat(actual.getKey().getClient()).isEqualTo("58");
		assertThat(actual.getKey().getMultAddressKey()).isEqualTo(" ");
		assertThat(actual.getKey().getProv()).isEqualTo("000073867");
		assertThat(actual.getKey().getPvdInd()).isEqualTo("D");
		assertThat(actual.getIrsNo()).isEqualTo("700923759");
		assertThat(actual.getAlphaKey()).isEqualTo("ROCKY MOUNTAIN FAMIL");
		assertThat(actual.getTinEffDt()).isEqualTo(MainframeDateUtils.convertYYMMDDStringToLocalDate("101011"));
		assertThat(actual.getUpdateSys()).isEqualTo("S");
		assertThat(actual.getProviderInfo().getProvName()).isEqualTo("ROC KY MOUNTAIN FAMILY");
		assertThat(actual.getProviderInfo().getAddress().getAddr1()).isEqualTo("PO BOX 173848");
		assertThat(actual.getProviderInfo().getAddress().getAddr2()).isEqualTo("PRov1 Addr2");
		assertThat(actual.getProviderInfo().getAddress().getAddr3()).isEqualTo("PRov1 Addr3");
		assertThat(actual.getProviderInfo().getAddress().getAddr4()).isEqualTo("PRov1 Addr4");
		assertThat(actual.getProviderInfo().getCity()).isEqualTo("DENVERVBFDYUSGB");
		assertThat(actual.getProviderInfo().getSt()).isEqualTo("CO");
		assertThat(actual.getProviderInfo().getZip()).isEqualTo("802173848");
		assertThat(actual.getProviderInfo().getLatitude()).isEqualTo(38.2568984);
		assertThat(actual.getProviderInfo().getLongitude()).isEqualTo(-85.75539619999999);
		assertThat(actual.getProviderInfo().getProvType()).isEqualTo("MD");
		assertThat(actual.getProviderInfo().getMajClsCd()).isEqualTo("G");
		assertThat(actual.getProviderInfo().getGroupFlag()).isEqualTo("T");
		assertThat(actual.getProviderInfo().getSpecCodes().size()).isEqualTo(4);
		assertThat(actual.getProviderInfo().getPhone()).isEqualTo("3036958684");
		assertThat(actual.getProviderInfo().getAdjNo()).isEqualTo("AUTOMKT");
		assertThat(actual.getProviderInfo().getChgDt()).isEqualTo(MainframeDateUtils.convertMMDDYYYYStringToLocalDate("03182020"));
		assertThat(actual.getProviderInfo().getPrvNoPay()).isEqualTo("1");
		assertThat(actual.getProviderInfo().getPrvNoPayDt()).isEqualTo(MainframeDateUtils
				.convertYYMMDDStringToLocalDate("101011"));
		assertThat(actual.getProviderInfo().getPvdStRc()).isEqualTo("1A");
		assertThat(actual.getProviderInfo().getActive()).isEqualTo(false);
		assertThat(actual.getProviderInfo().getArchived()).isEqualTo(false);
	}
	
	@Test
	public void validateDemographicsFieldFromProvider2() {
		Prv2OutRecord prvMaster = prov2().buildProv2Record();
		Demographics actual = classUnderTest.mapDemographicsFromProviderData2(prvMaster);
		assertThat(actual.getKey().getClient()).isEqualTo("58");
		assertThat(actual.getKey().getMultAddressKey()).isEqualTo(" ");
		assertThat(actual.getKey().getProv()).isEqualTo("000073867");
		assertThat(actual.getKey().getPvdInd()).isEqualTo("D");
		assertThat(actual.getProviderInfo().getNpiIds().size()).isEqualTo(9);
		List<NpiInfos> npiInfos = actual.getProviderInfo().getNpiIds();

		assertThat(npiInfos.get(0).getNpiId()).isEqualTo("N");
		assertThat(npiInfos.get(1).getNpiId()).isEqualTo("P");
		assertThat(npiInfos.get(2).getNpiId()).isEqualTo("I");
		assertThat(npiInfos.get(3).getNpiId()).isEqualTo("N");
		assertThat(npiInfos.get(4).getNpiId()).isEqualTo("P");
		assertThat(npiInfos.get(5).getNpiId()).isEqualTo("I");
		assertThat(npiInfos.get(6).getNpiId()).isEqualTo("N");
		assertThat(npiInfos.get(7).getNpiId()).isEqualTo("P");
		assertThat(npiInfos.get(8).getNpiId()).isEqualTo("I");

		List<TaxonomyCode> taxonomyCds = actual.getProviderInfo().getTaxonomyCodes();

		assertThat(actual.getProviderInfo().getTaxonomyCodes().size()).isEqualTo(10);
		assertThat(taxonomyCds.get(0).getTaxonomyCd()).isEqualTo("T");
		assertThat(taxonomyCds.get(1).getTaxonomyCd()).isEqualTo("A");
		assertThat(taxonomyCds.get(2).getTaxonomyCd()).isEqualTo("X");
		assertThat(taxonomyCds.get(3).getTaxonomyCd()).isEqualTo("O");
		assertThat(taxonomyCds.get(4).getTaxonomyCd()).isEqualTo("N");
		assertThat(taxonomyCds.get(5).getTaxonomyCd()).isEqualTo("O");
		assertThat(taxonomyCds.get(6).getTaxonomyCd()).isEqualTo("M");
		assertThat(taxonomyCds.get(7).getTaxonomyCd()).isEqualTo("Y");
		assertThat(taxonomyCds.get(8).getTaxonomyCd()).isEqualTo("C");
		assertThat(taxonomyCds.get(9).getTaxonomyCd()).isEqualTo("D");

	}
	
	private Location dummyLocation() {
		return Location.builder()
				.lat(38.2568984)
				.lng(-85.75539619999999)
				.build();
	}

}
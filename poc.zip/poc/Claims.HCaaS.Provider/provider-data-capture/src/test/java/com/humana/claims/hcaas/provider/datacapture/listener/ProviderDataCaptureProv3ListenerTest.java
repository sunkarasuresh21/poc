package com.humana.claims.hcaas.provider.datacapture.listener;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import javax.jms.Message;

import org.apache.qpid.jms.message.JmsTextMessage;
import org.apache.qpid.jms.provider.amqp.message.AmqpJmsTextMessageFacade;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.humana.claims.hcaas.common.data.capture.starter.newerrorhandlers.DataCaptureErrorHandler;
import com.humana.claims.hcaas.common.utils.datamasking.JsonMasker;
import com.humana.claims.hcaas.provider.attributes.core.dao.ProviderAttributesDAO;
import com.humana.claims.hcaas.provider.attributes.core.exception.ProviderAttributesNotFoundException;
import com.humana.claims.hcaas.provider.attributes.core.masker.ProviderAttributesDataMasker;
import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.attributes.core.model.db.AttributesKey;
import com.humana.claims.hcaas.provider.datacapture.geocode.model.Location;
import com.humana.claims.hcaas.provider.datacapture.geocode.service.GeoCodeService;
import com.humana.claims.hcaas.provider.datacapture.mapper.ProviderDataMapper;
import com.humana.claims.hcaas.provider.datacapture.mapper.ProviderMqDeserializer;
import com.humana.claims.hcaas.provider.datacapture.service.ProviderDataCaptureProv3ServiceImpl;
import com.humana.claims.hcaas.provider.demographics.core.exception.ProviderDemographicsNotFoundException;
import com.humana.claims.hcaas.provider.model.mq.Prv3Key;
import com.humana.claims.hcaas.provider.model.mq.Prv3OutRecord;
import com.humana.claims.hcaas.provider.model.mq.Prv3ProvWithholdData;
import com.mongodb.MongoException;

import lombok.SneakyThrows;

@ExtendWith(SpringExtension.class)
@ContextConfiguration
@TestPropertySource("classpath:test-application.properties")
@DirtiesContext(classMode = ClassMode.AFTER_EACH_TEST_METHOD)
public class ProviderDataCaptureProv3ListenerTest {
	
	@Autowired
	@Qualifier("prov3DataCaptureErrorHandler")
	@Mock
	private DataCaptureErrorHandler errorHandler;

	@Autowired
	private ProviderDataCaptureProv3Listener providerDataCaptureProv3Listener;
	
	@Autowired
	private ProviderDataMapper converter;

	@Autowired
	private ProviderAttributesDAO providerAttributesDAO;
	
	@Autowired
	private ProviderAttributesDataMasker dataMasker;
	
	@Autowired
	private ProviderMqDeserializer messageDeserializer;
	
	@Autowired
	private GeoCodeService geoCodeService;
	
	@Test
	void testRetryLogicWhenMongoExceptionOccurs() throws Exception {
		Attributes providerAttributes = new Attributes();
		AttributesKey attributeKey = new AttributesKey();
		attributeKey.setClient("50");
		providerAttributes.setKey(attributeKey);
		Prv3OutRecord prv3OutRecord = getPrv3OutRecord();
		
		when(geoCodeService.getGeoCode(any())).thenReturn(new Location());
		when(dataMasker.getProv3JsonDataMasker()).thenReturn(new JsonMasker());
		when(messageDeserializer.deserializeProviderOutRecord3(any())).thenReturn(prv3OutRecord);
		doReturn(providerAttributes).when(converter).mapAttributesFromProviderData3(prv3OutRecord);
		doThrow(MongoException.class).when(providerAttributesDAO).updateProviderAttributesProv3(providerAttributes);
		doNothing().when(errorHandler).handleRetryableMessageProcessingException(any(), any(Exception.class));
		providerDataCaptureProv3Listener.newProviderDataRecieved(textMessage("'TEST'"));
		verify(providerAttributesDAO, times(3)).updateProviderAttributesProv3(providerAttributes);
		verify(errorHandler, times(1)).handleRetryableMessageProcessingException(any(), any(Exception.class));
		verify(errorHandler, times(0)).handleNonretryableMessageProcessingException(any(), any(Exception.class));
		verify(dataMasker, times(3)).getProv3JsonDataMasker();
	}
	
	@Test
	void testRetryLogicWhenProviderAttributesNotFoundExceptionOccurs() throws Exception {
		Attributes providerAttributes = new Attributes();
		AttributesKey attributeKey = new AttributesKey();
		attributeKey.setClient("50");
		providerAttributes.setKey(attributeKey);
		Prv3OutRecord prv3OutRecord = getPrv3OutRecord();
		
		when(geoCodeService.getGeoCode(any())).thenReturn(new Location());
		when(dataMasker.getProv3JsonDataMasker()).thenReturn(new JsonMasker());
		when(messageDeserializer.deserializeProviderOutRecord3(any())).thenReturn(prv3OutRecord);
		doReturn(providerAttributes).when(converter).mapAttributesFromProviderData3(prv3OutRecord);
		doThrow(ProviderAttributesNotFoundException.class).when(providerAttributesDAO).updateProviderAttributesProv3(providerAttributes);
		doNothing().when(errorHandler).handleRetryableMessageProcessingException(any(), any(Exception.class));
		providerDataCaptureProv3Listener.newProviderDataRecieved(textMessage("'TEST'"));
		verify(providerAttributesDAO, times(3)).updateProviderAttributesProv3(providerAttributes);
		verify(errorHandler, times(1)).handleRetryableMessageProcessingException(any(), any(Exception.class));
		verify(errorHandler, times(0)).handleNonretryableMessageProcessingException(any(), any(Exception.class));
		verify(dataMasker, times(3)).getProv3JsonDataMasker();
	}
	
	@Test
	void testRetryLogicWhenNoneRetyExceptionOccurs() throws Exception {
		Attributes providerAttributes = new Attributes();
		AttributesKey attributeKey = new AttributesKey();
		attributeKey.setClient("50");
		providerAttributes.setKey(attributeKey);
		Prv3OutRecord prv3OutRecord = getPrv3OutRecord();
		
		when(geoCodeService.getGeoCode(any())).thenReturn(new Location());
		when(dataMasker.getProv3JsonDataMasker()).thenReturn(new JsonMasker());
		when(messageDeserializer.deserializeProviderOutRecord3(any())).thenReturn(prv3OutRecord);
		doReturn(providerAttributes).when(converter).mapAttributesFromProviderData3(prv3OutRecord);
		doThrow(RuntimeException.class).when(providerAttributesDAO).updateProviderAttributesProv3(providerAttributes);
		doNothing().when(errorHandler).handleNonretryableMessageProcessingException(any(), any(Exception.class));
		providerDataCaptureProv3Listener.newProviderDataRecieved(textMessage("'TEST'"));
		verify(providerAttributesDAO, times(1)).updateProviderAttributesProv3(providerAttributes);
		verify(errorHandler, times(0)).handleRetryableMessageProcessingException(any(), any(Exception.class));
		verify(errorHandler, times(1)).handleNonretryableMessageProcessingException(any(), any(Exception.class));
		verify(dataMasker, times(1)).getProv3JsonDataMasker();
	}

	@Test
	void testRetryLogicWhenNoExceptionOccursAndSuccessful() throws Exception {
		Attributes providerAttributes = new Attributes();
		AttributesKey attributeKey = new AttributesKey();
		attributeKey.setClient("50");
		providerAttributes.setKey(attributeKey);
		Prv3OutRecord prv3OutRecord = getPrv3OutRecord();
		
		when(geoCodeService.getGeoCode(any())).thenReturn(new Location());
		when(dataMasker.getProv3JsonDataMasker()).thenReturn(new JsonMasker());
		when(messageDeserializer.deserializeProviderOutRecord3(any())).thenReturn(prv3OutRecord);
		doReturn(providerAttributes).when(converter).mapAttributesFromProviderData3(prv3OutRecord);
		doNothing().when(providerAttributesDAO).updateProviderAttributesProv3(providerAttributes);
		providerDataCaptureProv3Listener.newProviderDataRecieved(textMessage("'TEST'"));
		verify(messageDeserializer, times(1)).deserializeProviderOutRecord3("'TEST'");
		verify(converter, times(1)).mapAttributesFromProviderData3(prv3OutRecord);
		verify(providerAttributesDAO, times(1)).updateProviderAttributesProv3(providerAttributes);
		verify(dataMasker, times(1)).getProv3JsonDataMasker();
	}
	
	private Prv3OutRecord getPrv3OutRecord() {
		Prv3OutRecord prv3OutRecord = new Prv3OutRecord();
		Prv3Key prv3Key = new Prv3Key();
		prv3Key.setPrv3Client("Prv3Client");
		prv3Key.setPrv3MultAddressKey("Prv3MultAddressKey");
		prv3Key.setPrv3Prov("Prv3Prov");
		prv3Key.setPrv3PvdInd("Prv3PvdInd");
		Prv3ProvWithholdData prv3ProvWithholdData = new Prv3ProvWithholdData();
		prv3ProvWithholdData.setPrv3ProvPrTaxfreeAmt("Prv3ProvPrTaxfreeAmt");
		prv3OutRecord.setPrv3ProvWithholdData(prv3ProvWithholdData);
		prv3OutRecord.setPrv3Key(prv3Key);
		return prv3OutRecord;
	}

	@Configuration
	@EnableRetry
	public static class ProviderRetryConfig {

		@Bean
		public DataCaptureErrorHandler prov3DataCaptureErrorHandler() {
			return mock(DataCaptureErrorHandler.class);
		}

		@Bean
		public ProviderDataMapper converter() {
			return mock(ProviderDataMapper.class);
		}

		@Bean
		public ProviderMqDeserializer messageDeserializer() {
			return mock(ProviderMqDeserializer.class);
		}

		@Bean
		public ProviderAttributesDAO providerAttributesDAO() {
			return mock(ProviderAttributesDAO.class);
		}
		
		@Bean
		public ProviderAttributesDataMasker dataMasker() {
			return mock(ProviderAttributesDataMasker.class);
		}
		
		@Bean
		public GeoCodeService geoCode() {
			return mock(GeoCodeService.class);
		}
		
		@Bean
		public ProviderDataCaptureProv3Listener providerDataCaptureProv3Listener() throws Exception {
			ProviderDataCaptureProv3Listener exceptionListener = new ProviderDataCaptureProv3Listener();

			ReflectionTestUtils.setField(exceptionListener, "errorHandler", prov3DataCaptureErrorHandler());
			ReflectionTestUtils.setField(exceptionListener, "providerDataCaptureProv3ServiceImpl",
					providerDataCaptureProv3ServiceImpl());
			ReflectionTestUtils.setField(exceptionListener, "dataMasker", dataMasker());
			return exceptionListener;
		}
		
		@Bean
		public ProviderDataCaptureProv3ServiceImpl  providerDataCaptureProv3ServiceImpl() throws Exception {
			return new ProviderDataCaptureProv3ServiceImpl(converter(), providerAttributesDAO(), messageDeserializer());
		}
	}
	
	@SneakyThrows
	public Message textMessage(String text) {
		JmsTextMessage jmsTextMessage = new JmsTextMessage(new AmqpJmsTextMessageFacade());
		jmsTextMessage.setText(text);
		return jmsTextMessage;
	}
}
package com.humana.claims.hcaas.provider.datacapture.geocode.service;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.humana.claims.hcaas.provider.datacapture.exception.GeoCodeBadRequestException;
import com.humana.claims.hcaas.provider.datacapture.geocode.client.GeoCodeApiClient;
import com.humana.claims.hcaas.provider.datacapture.geocode.model.AddressComponent;
import com.humana.claims.hcaas.provider.datacapture.geocode.model.GeoCodeApiResponse;
import com.humana.claims.hcaas.provider.datacapture.geocode.model.Geometry;
import com.humana.claims.hcaas.provider.datacapture.geocode.model.Location;
import com.humana.claims.hcaas.provider.datacapture.geocode.model.Northeast;
import com.humana.claims.hcaas.provider.datacapture.geocode.model.PlusCode;
import com.humana.claims.hcaas.provider.datacapture.geocode.model.Result;
import com.humana.claims.hcaas.provider.datacapture.geocode.model.Southwest;
import com.humana.claims.hcaas.provider.datacapture.geocode.model.Viewport;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
public class GeoCodeServiceImplTest {
	
	@InjectMocks
	private GeoCodeServiceImpl classUnderTest;

	@Mock
	private GeoCodeApiClient geoCodeApiClient;

	public static final String ADDRESS = "321+west+main+street+Louisville+KY+40202";
	
	@Test
	@SneakyThrows
	public void test_GeoCodeServiceGetRestApiCallReturnsExpectedValuesForGivenParameters(){

		GeoCodeApiResponse geoCodeApiResponse = parseGeoCodeApiResponse();
		geoCodeApiResponse.setStatus("OK");
		
		when(geoCodeApiClient.geocode(ADDRESS)).thenReturn(geoCodeApiResponse);

		Location actual = classUnderTest.getGeoCode(ADDRESS);
		assertThat(actual).isNotNull();
		assertEquals(actual.getLat(), geoCodeApiResponse.getResults().get(0).getGeometry().getLocation().getLat());
		assertEquals(actual.getLng(), geoCodeApiResponse.getResults().get(0).getGeometry().getLocation().getLng());
	}
	
	@Test
	@SneakyThrows
	public void testWhenCallToGeoCodeApiFailReturnsLocationWithNullValues(){
		Mockito.when(geoCodeApiClient.geocode(null))
				.thenThrow(new GeoCodeBadRequestException("Missing the required path variable when calling GeoCodeApi"));		
		
		Location actualLocation = classUnderTest.getGeoCode(null);
		
		assertThat(actualLocation).isNull();
	}
	
	@Test
	@SneakyThrows
	public void test_whenGeoCodeApiReturnsStatusAsZeroResults(){
		GeoCodeApiResponse geoCodeApiResponse = parseGeoCodeApiResponse();
		geoCodeApiResponse.setStatus("ZERO_RESULT");
		geoCodeApiResponse.setResults(null);;
		
		Mockito.when(geoCodeApiClient.geocode(ADDRESS)).thenReturn(geoCodeApiResponse);

		Location actual = classUnderTest.getGeoCode(ADDRESS);

		assertThat(actual).isNull();
	}
	
	@Test
	@SneakyThrows
	public void test_whenGeoCodeApiReturnsGeoCodeApiResponseAsNull(){
		Mockito.when(geoCodeApiClient.geocode(ADDRESS)).thenReturn(null);

		Location actual = classUnderTest.getGeoCode(ADDRESS);

		assertThat(actual).isNull();
	}

	private GeoCodeApiResponse parseGeoCodeApiResponse() throws IOException{

		Location location = new Location();
		location.setLat(38.25824738029149);
		location.setLng(-85.75404721970848);

		Geometry geometry = new Geometry();
		geometry.setLocation(location);
		
		Viewport viewport = new Viewport();
		viewport.setNortheast(new Northeast());
		viewport.setSouthwest(new Southwest());
		geometry.setViewport(viewport);
		
		Result result = new Result();
		result.setGeometry(geometry);
		
		List<AddressComponent> addressComponents = new ArrayList<>();
		addressComponents.add(new AddressComponent());
		result.setAddressComponents(addressComponents);
		result.setPlusCode(new PlusCode());
		
		List<Result> results = new ArrayList<>();
		results.add(result);

		GeoCodeApiResponse testGeoCodeApiResponse = new GeoCodeApiResponse();
		testGeoCodeApiResponse.setResults(results);
		
		return testGeoCodeApiResponse;
	}
}
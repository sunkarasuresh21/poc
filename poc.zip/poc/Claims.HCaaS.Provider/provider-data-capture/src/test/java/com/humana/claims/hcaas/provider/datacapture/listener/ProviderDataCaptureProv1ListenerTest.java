package com.humana.claims.hcaas.provider.datacapture.listener;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import javax.jms.Message;

import org.apache.qpid.jms.message.JmsTextMessage;
import org.apache.qpid.jms.provider.amqp.message.AmqpJmsTextMessageFacade;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.humana.claims.hcaas.common.data.capture.starter.newerrorhandlers.DataCaptureErrorHandler;
import com.humana.claims.hcaas.common.utils.datamasking.JsonMasker;
import com.humana.claims.hcaas.provider.attributes.core.dao.ProviderAttributesDAO;
import com.humana.claims.hcaas.provider.attributes.core.masker.ProviderAttributesDataMasker;
import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.datacapture.geocode.model.Location;
import com.humana.claims.hcaas.provider.datacapture.geocode.service.GeoCodeService;
import com.humana.claims.hcaas.provider.datacapture.mapper.ProviderDataMapper;
import com.humana.claims.hcaas.provider.datacapture.mapper.ProviderMqDeserializer;
import com.humana.claims.hcaas.provider.datacapture.service.ProviderDataCaptureProv1ServiceImpl;
import com.humana.claims.hcaas.provider.demographics.core.dao.ProviderDemographicsDAO;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.demographics.core.model.db.DemographicsKey;
import com.humana.claims.hcaas.provider.model.mq.PrvKey;
import com.humana.claims.hcaas.provider.model.mq.PrvMaster;
import com.humana.claims.hcaas.provider.model.mq.PrvProviderInfo;
import com.mongodb.MongoException;

import lombok.SneakyThrows;

@ExtendWith(SpringExtension.class)
@ContextConfiguration
@TestPropertySource("classpath:test-application.properties")
@DirtiesContext(classMode = ClassMode.AFTER_EACH_TEST_METHOD)
public class ProviderDataCaptureProv1ListenerTest {
	
	@Autowired
	@Qualifier("prov1DataCaptureErrorHandler")
	@Mock
	private DataCaptureErrorHandler errorHandler;
	
	@Autowired
	private ProviderDataCaptureProv1Listener providerDataCaptureProv1Listener;
	
	@Autowired
	private ProviderDataMapper converter;

	@Autowired
	private ProviderDemographicsDAO providerDemographicsDAO;

	@Autowired
	private ProviderAttributesDAO providerAttributesDAO;
	
	@Autowired
	private ProviderAttributesDataMasker dataMasker;
	
	@Autowired
	private GeoCodeService geoCodeService; 
	
	@Autowired
	private ProviderMqDeserializer mqDeserializer;
	
	
	@Test
	void testRetryLogicWhenMongoExceptionOccurs() throws Exception {
		Demographics demographics = new Demographics();
		DemographicsKey demographicsKey = new DemographicsKey();
		demographicsKey.setClient("50");
		demographics.setKey(demographicsKey);
		PrvMaster prvMaster = getPrvMaster();
		
		when(geoCodeService.getGeoCode(any())).thenReturn(new Location());
		when(dataMasker.getProv1JsonDataMasker()).thenReturn(new JsonMasker());
		when(mqDeserializer.deserializeProviderMaster(any())).thenReturn(prvMaster);
		doReturn(demographics).when(converter).mapDemographicsFromProviderData1(prvMaster);
		doThrow(MongoException.class).when(providerDemographicsDAO).upsertProviderDemographicsProv1(demographics);
		doNothing().when(errorHandler).handleRetryableMessageProcessingException(any(), any(Exception.class));
		providerDataCaptureProv1Listener.newProviderDataRecieved(textMessage("'TEST'"));
		verify(providerDemographicsDAO, times(3)).upsertProviderDemographicsProv1(demographics);
		verify(errorHandler, times(1)).handleRetryableMessageProcessingException(any(), any(Exception.class));
		verify(errorHandler, times(0)).handleNonretryableMessageProcessingException(any(), any(Exception.class));
		verify(dataMasker, times(3)).getProv1JsonDataMasker();
	}
	
	@Test
	void testRetryLogicWhenNoneMongoExceptionOccurs() throws Exception {
		Demographics demographics = new Demographics();
		DemographicsKey demographicsKey = new DemographicsKey();
		demographicsKey.setClient("50");
		demographics.setKey(demographicsKey);
		PrvMaster prvMaster = getPrvMaster();
		
		when(geoCodeService.getGeoCode(any())).thenReturn(new Location());
		when(dataMasker.getProv1JsonDataMasker()).thenReturn(new JsonMasker());
		when(mqDeserializer.deserializeProviderMaster(any())).thenReturn(prvMaster);
		doReturn(demographics).when(converter).mapDemographicsFromProviderData1(prvMaster);
		doThrow(RuntimeException.class).when(providerDemographicsDAO).upsertProviderDemographicsProv1(demographics);
		doNothing().when(errorHandler).handleNonretryableMessageProcessingException(any(), any(Exception.class));
		providerDataCaptureProv1Listener.newProviderDataRecieved(textMessage("'TEST'"));
		verify(providerDemographicsDAO, times(1)).upsertProviderDemographicsProv1(demographics);
		verify(errorHandler, times(0)).handleRetryableMessageProcessingException(any(), any(Exception.class));
		verify(errorHandler, times(1)).handleNonretryableMessageProcessingException(any(), any(Exception.class));
		verify(dataMasker, times(1)).getProv1JsonDataMasker();
	}

	@Test
	void testRetryLogicWhenNoExceptionOccursAndSuccessful() throws Exception {
		Demographics demographics = new Demographics();
		DemographicsKey demographicsKey = new DemographicsKey();
		demographicsKey.setClient("50");
		demographics.setKey(demographicsKey);
		Attributes providerAttributes = new Attributes();
		com.humana.claims.hcaas.provider.attributes.core.model.db.AttributesKey attributeKey = new com.humana.claims.hcaas.provider.attributes.core.model.db.AttributesKey();
		demographicsKey.setClient("50");
		providerAttributes.setKey(attributeKey);
		PrvMaster prvMaster = getPrvMaster();
		
		when(geoCodeService.getGeoCode(any())).thenReturn(new Location());
		when(dataMasker.getProv1JsonDataMasker()).thenReturn(new JsonMasker());
		when(mqDeserializer.deserializeProviderMaster(any())).thenReturn(prvMaster);
		doReturn(demographics).when(converter).mapDemographicsFromProviderData1(prvMaster);
		doReturn(providerAttributes).when(converter).mapAttributesFromProviderData1(prvMaster);
		doNothing().when(providerDemographicsDAO).upsertProviderDemographicsProv1(demographics);
		doNothing().when(providerAttributesDAO).upsertProviderAttributesProv1(providerAttributes);
		providerDataCaptureProv1Listener.newProviderDataRecieved(textMessage("'TEST'"));
		verify(mqDeserializer, times(1)).deserializeProviderMaster("'TEST'");
		verify(converter, times(1)).mapAttributesFromProviderData1(prvMaster);
		verify(providerDemographicsDAO, times(1)).upsertProviderDemographicsProv1(demographics);
		verify(providerAttributesDAO, times(1)).upsertProviderAttributesProv1(providerAttributes);
		verify(dataMasker, times(1)).getProv1JsonDataMasker();
	}
	
	private PrvMaster getPrvMaster() {
		PrvMaster prvMaster = new PrvMaster();
		PrvProviderInfo prvProviderInfo = new PrvProviderInfo();
		PrvKey prvKey = new PrvKey();
		prvKey.setPrvClient("PrvClient");
		prvKey.setPrvMultAddressKey("prvMultAddressKey");
		prvKey.setPrvProv("PrvProv");
		prvKey.setPrvPvdInd("PrvPvdInd");
		prvProviderInfo.setPrvCity("PrvCity");
		prvMaster.setPrvProviderInfo(prvProviderInfo);
		prvMaster.setPrvKey(prvKey);
		prvMaster.setPrvPvdStatus("PrvPvdStatus");
		prvMaster.setPrvTinEffDt("PrvTinEffDt");
		prvMaster.setPrvUpdateSys("PrvUpdateSys");
		prvMaster.setPrvIrsNo("PrvIrsNo");
		return prvMaster;
	}

	@Configuration
	@EnableRetry
	public static class ProviderRetryConfig {

		@Bean
		public DataCaptureErrorHandler prov1DataCaptureErrorHandler() {
			return mock(DataCaptureErrorHandler.class);
		}

		@Bean
		public ProviderDataMapper converter() {
			return mock(ProviderDataMapper.class);
		}

		@Bean
		public ProviderMqDeserializer mqDeserializer() {
			return mock(ProviderMqDeserializer.class);
		}

		@Bean
		public ProviderAttributesDAO providerAttributesDAO() {
			return mock(ProviderAttributesDAO.class);
		}
		
		@Bean
		public ProviderDemographicsDAO providerDemographicsDAO() {
			return mock(ProviderDemographicsDAO.class);
		}
		
		@Bean
		public ProviderAttributesDataMasker dataMasker() {
			return mock(ProviderAttributesDataMasker.class);
		}
		
		@Bean
		public GeoCodeService geoCode() {
			return mock(GeoCodeService.class);
		}
		
		@Bean
		public ProviderDataCaptureProv1Listener providerDataCaptureProv1Listener() throws Exception {
			ProviderDataCaptureProv1Listener exceptionListener = new ProviderDataCaptureProv1Listener();

			ReflectionTestUtils.setField(exceptionListener, "errorHandler", prov1DataCaptureErrorHandler());
			ReflectionTestUtils.setField(exceptionListener, "providerDataCaptureProv1ServiceImpl",
					providerDataCaptureProv1ServiceImpl());
			ReflectionTestUtils.setField(exceptionListener, "dataMasker", dataMasker());
			return exceptionListener;
		}

		@Bean
		public ProviderDataCaptureProv1ServiceImpl providerDataCaptureProv1ServiceImpl() throws Exception {
			return new ProviderDataCaptureProv1ServiceImpl(converter(), providerDemographicsDAO(), providerAttributesDAO(), mqDeserializer());
		}
	}
	
	@SneakyThrows
	public Message textMessage(String text) {
		JmsTextMessage jmsTextMessage = new JmsTextMessage(new AmqpJmsTextMessageFacade());
		jmsTextMessage.setText(text);
		return jmsTextMessage;
	}
}
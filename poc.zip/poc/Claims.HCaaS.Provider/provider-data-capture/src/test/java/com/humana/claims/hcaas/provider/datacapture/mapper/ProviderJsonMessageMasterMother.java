package com.humana.claims.hcaas.provider.datacapture.mapper;


import java.io.File;
import java.net.URI;
import java.nio.charset.Charset;

import org.apache.commons.io.FileUtils;

import com.humana.claims.hcaas.provider.model.mq.Prv2OutRecord;
import com.humana.claims.hcaas.provider.model.mq.Prv3OutRecord;
import com.humana.claims.hcaas.provider.model.mq.PrvMaster;

import lombok.SneakyThrows;

public class ProviderJsonMessageMasterMother {

	protected static final String prov1File;
	protected static final String prov2File;
	protected static final String prov3File;

	private PrvMaster prvMaster;

	private Prv2OutRecord prv2OutRecord;

	private Prv3OutRecord prv3OutRecord;
	
	private ProviderMqDeserializer jsonMessageDeserializer = new ProviderMqJsonDeserializer();

	static {
		prov1File = readFileToString("default-objects/Prov1.json");
		prov2File = readFileToString("default-objects/Prov2.json");
		prov3File = readFileToString("default-objects/Prov3.json");

	}

	@SneakyThrows
	private static String readFileToString(String filepath) {
		URI filePathUri = ProviderJsonMessageMasterMother.class.getClassLoader().getResource(filepath).toURI();
		File file = new File(filePathUri);
		return FileUtils.readFileToString(file, Charset.forName("UTF-8"));
	}

	public static ProviderJsonMessageMasterMother prov1() {
		return new ProviderJsonMessageMasterMother("prov1");
	}

	public static ProviderJsonMessageMasterMother prov2() {
		return new ProviderJsonMessageMasterMother("prov2");
	}

	public static ProviderJsonMessageMasterMother prov3() {
		return new ProviderJsonMessageMasterMother("prov3");
	}

	@SneakyThrows
	protected ProviderJsonMessageMasterMother(String queueName) {
		if (queueName.equals("prov1"))
			this.prvMaster = jsonMessageDeserializer.deserializeProviderMaster(prov1File);
		if (queueName.equals("prov2"))
			this.prv2OutRecord = jsonMessageDeserializer.deserializeProviderOutRecord2(prov2File);
		if (queueName.equals("prov3"))
			this.prv3OutRecord = jsonMessageDeserializer.deserializeProviderOutRecord3(prov3File);
	}

	public PrvMaster buildProv1Record() {
		return this.prvMaster;
	}

	public Prv2OutRecord buildProv2Record() {
		return this.prv2OutRecord;
	}

	public Prv3OutRecord buildProv3Record() {
		return this.prv3OutRecord;
	}

}

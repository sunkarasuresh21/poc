package com.humana.claims.hcaas.provider.restapi.controller;

import static com.humana.claims.hcaas.provider.restapi.constants.ProviderErrorConstants.FAILED_TO_CREATE_PROVIDER;
import static com.humana.claims.hcaas.provider.restapi.constants.ProviderErrorConstants.FAILED_TO_UPDATE_PROVIDER;
import static com.humana.claims.hcaas.provider.restapi.constants.ProviderErrorConstants.INVALID_REQUEST_RECEIVED;
import static com.humana.claims.hcaas.provider.restapi.constants.ProviderErrorConstants.NOT_FOUND;
import static com.humana.claims.hcaas.provider.restapi.constants.ProviderErrorConstants.PROVIDER_ALREADY_EXISTS;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.humana.claims.hcaas.common.rest.api.starter.enumerrorcode.ErrorCode;
import com.humana.claims.hcaas.provider.demographics.core.exception.InvalidRequestException;
import com.humana.claims.hcaas.provider.demographics.core.masker.ProviderDemographicsDataMasker;
import com.humana.claims.hcaas.provider.restapi.exception.ConflictException;
import com.humana.claims.hcaas.provider.restapi.exception.NotFoundException;
import com.humana.claims.hcaas.provider.restapi.exception.ProviderCreationException;
import com.humana.claims.hcaas.provider.restapi.exception.ProviderUpdateException;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderDemoModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderKeyModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.UpdateProviderModelDTO;
import com.humana.claims.hcaas.provider.restapi.service.ProviderService;
import com.humana.claims.hcaas.provider.restapi.validator.ProviderValidator;

import lombok.SneakyThrows;

@ExtendWith(SpringExtension.class)
@WebMvcTest(ProviderController.class)
@TestPropertySource("classpath:test-application.properties")
public class ProviderControllerExceptionHandlerTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private ProviderService providerService;
	
	@MockBean
	private ProviderValidator providerValidator;
	
	@MockBean
	private ProviderDemographicsDataMasker dataMasker;
	
	private static final String requestId = "9865743";
	private static final String requestClient = "58";
	
	@Test
	@SneakyThrows
	public void test_whenV1BetaNetworkIdPost_returnsBadRequest(){			
		UpdateProviderModelDTO updateProviderDTO = new UpdateProviderModelDTO();
		updateProviderDTO.setProviderKey(createKey("30", "123456789", "D", "1"));
		updateProviderDTO.setProviderDemo(createProviderDemoDTO());
		
		MockHttpServletRequestBuilder postRequestBuilder =post("/v1/providers");
		postRequestBuilder.contentType(MediaType.APPLICATION_JSON);
		postRequestBuilder.accept(MediaType.APPLICATION_JSON);
		postRequestBuilder.content(convertUpdateProviderModelDTOToJsonString(updateProviderDTO));
		
		this.mockMvc.perform(postRequestBuilder).andDo(print()).andExpect(status().isBadRequest());
	}
	
	@Test
	@SneakyThrows
	public void test_whenV1BetaNetworkIdPostFails_returnsBadRequestMethodArgumentNotValidException(){			
		UpdateProviderModelDTO updateProviderDTO = new UpdateProviderModelDTO();
		updateProviderDTO.setProviderKey(createKey("30", "123456789", "A", "1"));
		
		MockHttpServletRequestBuilder postRequestBuilder =post("/v1/providers");
		postRequestBuilder.contentType(MediaType.APPLICATION_JSON);
		postRequestBuilder.accept(MediaType.APPLICATION_JSON);
		postRequestBuilder.content(convertUpdateProviderModelDTOToJsonString(updateProviderDTO));
		
		this.mockMvc.perform(postRequestBuilder).andDo(print()).andExpect(status().isBadRequest())
		.andExpect(MockMvcResultMatchers.jsonPath("$.errorCode").value(ErrorCode.BAD_REQUEST.toString()));
	}
	
	@Test
	@SneakyThrows
	public void test_whenV1BetaPostThrowsBadRequest_InvalidJSONFormat() {
		MockHttpServletRequestBuilder postRequestBuilder = post("/v1/providers");		
		postRequestBuilder.contentType(MediaType.APPLICATION_JSON);
		postRequestBuilder.accept(MediaType.APPLICATION_JSON);	
		
		this.mockMvc.perform(postRequestBuilder).andDo(print()).andExpect(status().isBadRequest())
		.andExpect(MockMvcResultMatchers.jsonPath("$.errorCode").value(ErrorCode.BAD_REQUEST.toString()));
	}
	
	@Test
	@SneakyThrows
	public void test_whenV1BetaPostThrowsBadRequest_throwsInvalidRequestException() {
		Set<String> errorMessagesSet = new HashSet<>();
		errorMessagesSet.add(INVALID_REQUEST_RECEIVED);
		UpdateProviderModelDTO updateProviderDTO = new UpdateProviderModelDTO();
		updateProviderDTO.setProviderKey(createKey("30", "123456789", "D", "1"));
		updateProviderDTO.setProviderDemo(createProviderDemoDTO());
		
		when(providerService.createProvider(updateProviderDTO, requestId, requestClient)).thenThrow(new InvalidRequestException(errorMessagesSet));
		
		MockHttpServletRequestBuilder postRequestBuilder = post("/v1/providers").header("requestId", "9865743").header("requestClient", "58");
		postRequestBuilder.contentType(MediaType.APPLICATION_JSON);
		postRequestBuilder.accept(MediaType.APPLICATION_JSON);
		postRequestBuilder.content(convertUpdateProviderModelDTOToJsonString(updateProviderDTO));
		this.mockMvc.perform(postRequestBuilder).andDo(print()).andExpect(status().isBadRequest())
		.andExpect(MockMvcResultMatchers.jsonPath("$.errorCode").value(ErrorCode.BAD_REQUEST.toString()));
	}
	
	@Test
	@SneakyThrows
	public void test_whenV1BetaPostThrowsBadRequest_throwsProviderCreationException() {
		Set<String> errorMessagesSet = new HashSet<>();
		errorMessagesSet.add(FAILED_TO_CREATE_PROVIDER);
		UpdateProviderModelDTO updateProviderDTO = new UpdateProviderModelDTO();
		
		when(providerService.createProvider(updateProviderDTO, requestId, requestClient)).thenThrow(new ProviderCreationException(errorMessagesSet));
		
		MockHttpServletRequestBuilder postRequestBuilder = post("/v1/providers");
		postRequestBuilder.contentType(MediaType.APPLICATION_JSON);
		postRequestBuilder.accept(MediaType.APPLICATION_JSON);
		postRequestBuilder.content(convertUpdateProviderModelDTOToJsonString(updateProviderDTO));
		this.mockMvc.perform(postRequestBuilder).andDo(print()).andExpect(status().isInternalServerError())
		.andExpect(MockMvcResultMatchers.jsonPath("$.errorCode").value(ErrorCode.INTERNAL_ERROR.toString()));
	}
	
	@Test
	@SneakyThrows
	public void test_v1BetaNetworkIdGetThrowsConflictException() {
		Set<String> errorMessagesSet = new HashSet<>();
		errorMessagesSet.add(PROVIDER_ALREADY_EXISTS);
		UpdateProviderModelDTO updateProviderDTO = new UpdateProviderModelDTO();
		updateProviderDTO.setProviderKey(createKey("30", "123456789", "D", "1"));
		updateProviderDTO.setProviderDemo(createProviderDemoDTO());
		
		when(providerService.createProvider(updateProviderDTO, requestId, requestClient)).thenThrow(new ConflictException(errorMessagesSet));
		
		MockHttpServletRequestBuilder postRequestBuilder = post("/v1/providers").header("requestId", "9865743").header("requestClient", "58");
		postRequestBuilder.contentType(MediaType.APPLICATION_JSON);
		postRequestBuilder.accept(MediaType.APPLICATION_JSON);
		postRequestBuilder.content(convertUpdateProviderModelDTOToJsonString(updateProviderDTO));
		
		this.mockMvc.perform(postRequestBuilder).andDo(print()).andExpect(status().isConflict())
		.andExpect(MockMvcResultMatchers.jsonPath("$.errorCode").value(ErrorCode.CONFLICT.toString()));
	}
	
	@Test
	@SneakyThrows
	public void test_whenV1BetaNetworkIdPatch_throwsMissingRequestHeaderException(){				
		UpdateProviderModelDTO updateProviderDTO = new UpdateProviderModelDTO();
		
		MockHttpServletRequestBuilder patchRequestBuilder =patch("/v1/providers");
		patchRequestBuilder.contentType(MediaType.APPLICATION_JSON);
		patchRequestBuilder.accept(MediaType.APPLICATION_JSON);
		patchRequestBuilder.content(convertUpdateProviderModelDTOToJsonString(updateProviderDTO));
		
		this.mockMvc.perform(patchRequestBuilder).andDo(print()).andExpect(status().isBadRequest())
		.andExpect(MockMvcResultMatchers.jsonPath("$.errorCode").value(ErrorCode.BAD_REQUEST.toString()));
	}
	
	@Test
	@SneakyThrows
	public void test_whenV1BetaNetworkIdPatch_throwsProviderUpdateException(){	
		Set<String> errorMessagesSet = new HashSet<>();
		errorMessagesSet.add(FAILED_TO_UPDATE_PROVIDER);
		UpdateProviderModelDTO updateProviderDTO = new UpdateProviderModelDTO();
		updateProviderDTO.setProviderDemo(null);
		
		when(providerService.updateProvider(Mockito.any(UpdateProviderModelDTO.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenThrow(new ProviderUpdateException(errorMessagesSet));
		
		MockHttpServletRequestBuilder patchRequestBuilder =patch("/v1/providers").header("provider-id", "99160141").header("provider-indicator","H").header("provider-multi-address-key","8").header("requestId", "9865743").header("requestClient", "58");
		patchRequestBuilder.contentType(MediaType.APPLICATION_JSON);
		patchRequestBuilder.accept(MediaType.APPLICATION_JSON);
		patchRequestBuilder.content(convertUpdateProviderModelDTOToJsonString(updateProviderDTO));
		
		this.mockMvc.perform(patchRequestBuilder).andDo(print()).andExpect(status().isInternalServerError())
		.andExpect(MockMvcResultMatchers.jsonPath("$.errorCode").value(ErrorCode.INTERNAL_ERROR.toString()));
	}
	
	@Test
	@SneakyThrows
	public void test_whenV1BetaNetworkIdPatch_throwsProviderNotFoundException(){	
		Set<String> errorMessagesSet = new HashSet<>();
		errorMessagesSet.add(NOT_FOUND);
		UpdateProviderModelDTO updateProviderDTO = new UpdateProviderModelDTO();
		updateProviderDTO.setProviderAttribute(null);
		
		when(providerService.updateProvider(Mockito.any(UpdateProviderModelDTO.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenThrow(new NotFoundException(errorMessagesSet));
		
		MockHttpServletRequestBuilder patchRequestBuilder =patch("/v1/providers").header("provider-id", "99160141").header("provider-indicator","H").header("provider-multi-address-key","8");
		patchRequestBuilder.contentType(MediaType.APPLICATION_JSON);
		patchRequestBuilder.accept(MediaType.APPLICATION_JSON);
		patchRequestBuilder.content(convertUpdateProviderModelDTOToJsonString(updateProviderDTO));
		
		this.mockMvc.perform(patchRequestBuilder).andDo(print()).andExpect(status().isBadRequest())
		.andExpect(MockMvcResultMatchers.jsonPath("$.errorCode").value(ErrorCode.NOT_FOUND.toString()));
	}
	
	@Test
	@SneakyThrows
	public void test_whenV1BetaNetworkIdPatch_throwsIllegalAccessException(){	
		UpdateProviderModelDTO updateProviderDTO = new UpdateProviderModelDTO();
		updateProviderDTO.setProviderAttribute(null);
		
		when(providerService.updateProvider(Mockito.any(UpdateProviderModelDTO.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenThrow(new IllegalAccessException(null));
		
		MockHttpServletRequestBuilder patchRequestBuilder =patch("/v1/providers").header("provider-id", "99160141").header("provider-indicator","H").header("provider-multi-address-key","8").header("requestId", "9865743").header("requestClient", "58");
		patchRequestBuilder.contentType(MediaType.APPLICATION_JSON);
		patchRequestBuilder.accept(MediaType.APPLICATION_JSON);
		patchRequestBuilder.content(convertUpdateProviderModelDTOToJsonString(updateProviderDTO));
		
		this.mockMvc.perform(patchRequestBuilder).andDo(print()).andExpect(status().isInternalServerError())
		.andExpect(MockMvcResultMatchers.jsonPath("$.errorCode").value(ErrorCode.INTERNAL_ERROR.toString()));
	}
	
	private ProviderKeyModelDTO createKey(String client, String prov, String pvdInd, String multAddressKey) {
		ProviderKeyModelDTO updateProviderKeyDTO = new ProviderKeyModelDTO();
		updateProviderKeyDTO.setClient(client);
		updateProviderKeyDTO.setMultAddressKey(multAddressKey);
		updateProviderKeyDTO.setProv(prov);
		updateProviderKeyDTO.setPvdInd(pvdInd);
		return updateProviderKeyDTO;
	}
	private ProviderDemoModelDTO createProviderDemoDTO() {
		ProviderDemoModelDTO providerDemoDTO = new ProviderDemoModelDTO();
		providerDemoDTO.setIrsNo("123456789");
		return providerDemoDTO;
	}

	@SneakyThrows
	private String convertUpdateProviderModelDTOToJsonString(UpdateProviderModelDTO updateProviderDTO) {
		ObjectMapper objectMapper = createObjectMapper();
		String superNetworkDTOObjectJson = objectMapper.writeValueAsString(updateProviderDTO);
		return superNetworkDTOObjectJson;
	}
	
	private final ObjectMapper createObjectMapper() {
	    ObjectMapper objectMapper = new ObjectMapper();
	    objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
	    objectMapper.registerModule(new JavaTimeModule());
	    return objectMapper;
	}
}

package com.humana.claims.hcaas.provider.restapi.service.datafeed;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;

import com.humana.claims.hcaas.provider.model.mq.Prv2Key;
import com.humana.claims.hcaas.provider.model.mq.Prv2OutRecord;
import com.humana.claims.hcaas.provider.restapi.exception.DataFeedException;
import com.humana.claims.hcaas.provider.restapi.model.datafeed.Prov2DataFeed;
import com.humana.claims.hcaas.provider.restapi.service.datafeed.Prov2DataFeederImpl;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
public class Prov2DataFeederImplTest {

	private Prov2DataFeederImpl classUnderTest;
	
	@Mock
	private JmsTemplate jmsTemplate;
	
	private static final String QUEUE_NAME = "demographics-test-queue";
	
	private static final String REQUEST_ID = "123456";
	private static final String REQUEST_CLIENT = "98";
	
	@BeforeEach
	public void setUp() {
		classUnderTest = new Prov2DataFeederImpl(jmsTemplate, QUEUE_NAME);
	}
	
	@Test
	@SneakyThrows
	public void should_invoke_jms_template_with_demographics_passed_as_parameter() {
		Prov2DataFeed prov2DataFeed = createProv2DataFeed();
		classUnderTest.sendToQueue(prov2DataFeed);
		Mockito.verify(jmsTemplate, times(1)).convertAndSend(QUEUE_NAME, getDemographicsJson());
	}
	
	@Test
	@SneakyThrows
	public void should_throw_datafeed_exception_for_jms_exception() {
		Prov2DataFeed prov2DataFeed = createProv2DataFeed();
		doThrow(new JmsExceptionTest("Data Feed Failed")).when(jmsTemplate).convertAndSend(QUEUE_NAME, getDemographicsJson());
		
		assertThatExceptionOfType(DataFeedException.class)
				.isThrownBy(() -> classUnderTest.sendToQueue(prov2DataFeed)).withMessage("Data Feed Failed");
	}
	
	private Prov2DataFeed createProv2DataFeed() {
		Prov2DataFeed prov2DataFeed = new Prov2DataFeed();
		Prv2OutRecord prv2OutRecord = new Prv2OutRecord();
		Prv2Key prv2Key = new Prv2Key();
		prv2Key.setPrv2Client("58");
		prv2OutRecord.setPrv2Key(prv2Key);
		prov2DataFeed.setRequestId(REQUEST_ID);
		prov2DataFeed.setRequestClient(REQUEST_CLIENT);
		prov2DataFeed.setPrv2OutRecord(prv2OutRecord);
		return prov2DataFeed;
	}
	
	private String getDemographicsJson() {
		return "{\"requestId\":\"123456\",\"requestClient\":\"98\",\"prv2OutRecord\":{\"PRV2-KEY\":{\"PRV2-CLIENT\":\"58\"}}}";
	}
	
	static class JmsExceptionTest extends JmsException {

		private static final long serialVersionUID = 1L;

		public JmsExceptionTest(String msg) {
			super(msg);
		}
	}
}
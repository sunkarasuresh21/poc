package com.humana.claims.hcaas.provider.restapi.service.datafeed;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;

import com.humana.claims.hcaas.provider.model.mq.PrvMaster;
import com.humana.claims.hcaas.provider.restapi.exception.DataFeedException;
import com.humana.claims.hcaas.provider.restapi.model.datafeed.Prov1DataFeed;
import com.humana.claims.hcaas.provider.restapi.service.datafeed.Prov1DataFeederImpl;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
public class Prov1DataFeederImplTest {

	private Prov1DataFeederImpl classUnderTest;
	
	@Mock
	private JmsTemplate jmsTemplate;
	
	private static final String QUEUE_NAME = "attributes-test-queue";
	
	private static final String REQUEST_ID = "123456";
	private static final String REQUEST_CLIENT = "98";
	
	@BeforeEach
	public void setUp() {
		classUnderTest = new Prov1DataFeederImpl(jmsTemplate, QUEUE_NAME);
	}
	
	@Test
	@SneakyThrows
	public void should_invoke_jms_template_with_attributes_passed_as_parameter() {
		Prov1DataFeed prov1DataFeed = createProv1DataFeed();
		classUnderTest.sendToQueue(prov1DataFeed);
		Mockito.verify(jmsTemplate, times(1)).convertAndSend(QUEUE_NAME, getProv1Json());
	}
	
	@Test
	@SneakyThrows
	public void should_throw_datafeed_exception_for_jms_exception() {
		Prov1DataFeed prov1DataFeed = createProv1DataFeed();
		doThrow(new JmsExceptionTest("Data Feed Failed")).when(jmsTemplate).convertAndSend(QUEUE_NAME, getProv1Json());
		
		assertThatExceptionOfType(DataFeedException.class)
				.isThrownBy(() -> classUnderTest.sendToQueue(prov1DataFeed)).withMessage("Data Feed Failed");
	}
	
	private Prov1DataFeed createProv1DataFeed() {
		Prov1DataFeed prov1DataFeed = new Prov1DataFeed();
		PrvMaster prvMaster = new PrvMaster();
		prvMaster.setPrvIrsNo("234124567");
		prov1DataFeed.setRequestId(REQUEST_ID);
		prov1DataFeed.setRequestClient(REQUEST_CLIENT);
		prov1DataFeed.setPrvMaster(prvMaster);
		return prov1DataFeed;
	}
	
	private String getProv1Json() {
		return "{\"requestId\":\"123456\",\"requestClient\":\"98\",\"prvMaster\":{\"PRV-IRS-NO\":\"234124567\"}}";
	}
	
	static class JmsExceptionTest extends JmsException {

		private static final long serialVersionUID = 1L;

		public JmsExceptionTest(String msg) {
			super(msg);
		}
	}
}

package com.humana.claims.hcaas.provider.restapi.validator;

import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Set;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.humana.claims.hcaas.provider.demographics.core.exception.InvalidRequestException;
import com.humana.claims.hcaas.provider.restapi.constants.ProviderErrorConstants;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.UpdateProviderModelDTO;

@ExtendWith(MockitoExtension.class)
public class ProviderValidatorTest {

	@InjectMocks
	ProviderValidator providerValidator;

	@Test
    public void testWithAllValidValues() {
		try {
			UpdateProviderModelDTO updateProviderDTO = createUpdateProviderModelDTO();
			updateProviderDTO.setProviderKey(null);
			providerValidator.validateProviderInfoSentForUpdate(updateProviderDTO,"H","000000011","1");
		} catch (InvalidRequestException e) {
			Assertions.fail("Exception Not Expected");
		}
    }
	
	@Test
	public void testInvalidNullMultiAddressKeyAndValidProviderIDAndValidProviderInd() {
		try {
			providerValidator.validateProviderInfoSentForUpdate(createUpdateProviderModelDTO(),"D","000000011",null);
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(ProviderErrorConstants.INVALID_PROVIDER_MULTI_ADDRESS_KEY));
			assertFalse(errors.contains(ProviderErrorConstants.INVALID_PROVIDER_ID));
			assertFalse(errors.contains(ProviderErrorConstants.INVALID_PROVIDER_IND));
		}
	}
	
	@Test
	public void testInvalidMultiAddressKeyWithLengthGreaterThan1AndValidProviderIndAndValidProviderID() {
		try {
			providerValidator.validateProviderInfoSentForUpdate(createUpdateProviderModelDTO(),"D","000000011","test");
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(ProviderErrorConstants.INVALID_PROVIDER_MULTI_ADDRESS_KEY));
			assertFalse(errors.contains(ProviderErrorConstants.INVALID_PROVIDER_ID));
			assertFalse(errors.contains(ProviderErrorConstants.INVALID_PROVIDER_IND));
		}
	}

	@Test
	public void testInvalidProviderIDAndValidProviderIndAndValidMultiAddressKey() {
		try {
			providerValidator.validateProviderInfoSentForUpdate(createUpdateProviderModelDTO(),"H","testPatch","t");
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(ProviderErrorConstants.INVALID_PROVIDER_ID));
			assertFalse(errors.contains(ProviderErrorConstants.INVALID_PROVIDER_IND));
			assertFalse(errors.contains(ProviderErrorConstants.INVALID_PROVIDER_MULTI_ADDRESS_KEY));
		}
	}
	
	@Test
	public void testNullProviderIDAndValidProviderIndAndValidMultiAddressKey() {
		try {
			providerValidator.validateProviderInfoSentForUpdate(createUpdateProviderModelDTO(),"H",null,"t");
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(ProviderErrorConstants.INVALID_PROVIDER_ID));
			assertFalse(errors.contains(ProviderErrorConstants.INVALID_PROVIDER_IND));
			assertFalse(errors.contains(ProviderErrorConstants.INVALID_PROVIDER_MULTI_ADDRESS_KEY));
		}
	}
	
	@Test
	public void testInvalidProviderIndAndValidProviderIDAndValidMultiAddressKey() {
		try {
			providerValidator.validateProviderInfoSentForUpdate(createUpdateProviderModelDTO(),"S","000000011","t");
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(ProviderErrorConstants.INVALID_PROVIDER_IND));
			assertFalse(errors.contains(ProviderErrorConstants.INVALID_PROVIDER_MULTI_ADDRESS_KEY));
			assertFalse(errors.contains(ProviderErrorConstants.INVALID_PROVIDER_ID));
		}
	}
	
	@Test
	public void testErrorWhenAdjNoNotSent() {
		try {
			UpdateProviderModelDTO updateProviderDTO = createUpdateProviderModelDTO();
			updateProviderDTO.getProviderDemo().getProviderInfo().setAdjNo(null);
			updateProviderDTO.setProviderKey(null);
			providerValidator.validateProviderInfoSentForUpdate(updateProviderDTO,"H","000000011","test");
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(ProviderErrorConstants.ADJNO_NOT_SENT_ERROR));
			assertFalse(errors.contains(ProviderErrorConstants.KEY_VALUE_UPDATE_ERROR));
		}
	}
	
	@Test
	public void testErrorWhenUpdateAdjNoNotSent() {
		try {
			UpdateProviderModelDTO updateProviderDTO = createUpdateProviderModelDTO();
			updateProviderDTO.getProviderAttribute().setUpdtAdjNo(null);
			updateProviderDTO.setProviderKey(null);
			providerValidator.validateProviderInfoSentForUpdate(updateProviderDTO,"H","000000011","test");
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(ProviderErrorConstants.UPDATEADJNO_NOT_SENT_ERROR));
			assertFalse(errors.contains(ProviderErrorConstants.KEY_VALUE_UPDATE_ERROR));
		}
	}
	
	@Test
	public void testErrorResponseWhenProviderAttrObjectIsEmpty() {
		try {
			UpdateProviderModelDTO updateProviderDTO = new UpdateProviderModelDTO();
			updateProviderDTO.setProviderAttribute(null);
			providerValidator.validateProviderInfoSentForUpdate(updateProviderDTO,"H","000000011","test");
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(ProviderErrorConstants.INVALID_REQUEST_RECEIVED));
		}
	}
	
	
	@Test
	public void testErrorWhenKeyInfoSentForUpdate() {
		try {
			providerValidator.validateProviderInfoSentForUpdate(createUpdateProviderModelDTO(),"H","000000011","test");
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(ProviderErrorConstants.KEY_VALUE_UPDATE_ERROR));
			assertFalse(errors.contains(ProviderErrorConstants.UPDATEADJNO_NOT_SENT_ERROR));
		}
	}
	
	@Test
	public void testErrorWhenActiveAndArchivedIsProvided() {
		try {
			UpdateProviderModelDTO updateProviderDTO = createUpdateProviderModelDTO();
			updateProviderDTO.getProviderDemo().getProviderInfo().setActive(true);
			updateProviderDTO.getProviderDemo().getProviderInfo().setArchived(false);
			updateProviderDTO.setProviderKey(null);
			providerValidator.validateProviderInfoSentForUpdate(updateProviderDTO,"H","000000011","test");
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(ProviderErrorConstants.ACTIVE_ARCHIVED_SHOULD_NOT_BE_SET_BY_CONSUMER));
			assertFalse(errors.contains(ProviderErrorConstants.UPDATEADJNO_NOT_SENT_ERROR));
			assertFalse(errors.contains(ProviderErrorConstants.KEY_VALUE_UPDATE_ERROR));
		}
	}
	
	
	
	@Test
	public void testTrueArchivedValidation() {
		UpdateProviderModelDTO updateProviderDTO = createUpdateProviderModelDTO();
		updateProviderDTO.getProviderDemo().getProviderInfo().getPvdStatus();
		updateProviderDTO.getProviderDemo().getProviderInfo().getPvdStRc();
		
		boolean actual= providerValidator.isArchived("AR","1");
		
		assertThat(actual).isTrue();
		
	}
	
	@Test
	public void testTrueActiveValidation() {
		UpdateProviderModelDTO updateProviderDTO = createUpdateProviderModelDTO();
		updateProviderDTO.getProviderDemo().getProviderInfo().getPvdStatus();
		updateProviderDTO.getProviderDemo().getProviderInfo().getPvdStRc();
		
		boolean actual= providerValidator.isActive("1E","1");
		
		assertThat(actual).isTrue();
		
	}
	
	@Test
	public void testTrueActiveValidationForPvdStatus0() {
		UpdateProviderModelDTO updateProviderDTO = createUpdateProviderModelDTO();
		updateProviderDTO.getProviderDemo().getProviderInfo().getPvdStatus();
		updateProviderDTO.getProviderDemo().getProviderInfo().getPvdStRc();
		
		boolean actual= providerValidator.isActive(" ","0");
		
		assertThat(actual).isTrue();
		
	}
	
	@Test
	public void testTrueActiveValidationForBlankPvdStatus() {
		UpdateProviderModelDTO updateProviderDTO = createUpdateProviderModelDTO();
		updateProviderDTO.getProviderDemo().getProviderInfo().setPvdStatus(" ");
		updateProviderDTO.getProviderDemo().getProviderInfo().getPvdStRc();
		
		boolean actual= providerValidator.isActive(" "," ");
		
		assertThat(actual).isTrue();
		
	}
	
	@Test
	public void testValidateInputForPostOperation() {
		try {
			UpdateProviderModelDTO updateProviderDTO = createUpdateProviderModelDTO();
			updateProviderDTO.setProviderKey(null);
			providerValidator.validateInputRequestForPostOperation(updateProviderDTO);
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(ProviderErrorConstants.INVALID_REQUEST_RECEIVED));
		}
	}
	
	@Test
	public void testValidateInputForPostOperationWithUpdateProviderModelDTOIsNull() {
		try {
			UpdateProviderModelDTO updateProviderDTO = createUpdateProviderModelDTO();
			providerValidator.validateInputRequestForPostOperation(updateProviderDTO);
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(ProviderErrorConstants.INVALID_REQUEST_RECEIVED));
		}
	}
	
	@Test
	public void testValidateInputForPostOperationWithActiveArchiveValue() {
		try {
			UpdateProviderModelDTO updateProviderDTO = createUpdateProviderModelDTO();
			updateProviderDTO.getProviderDemo().getProviderInfo().setActive(true);
			updateProviderDTO.getProviderDemo().getProviderInfo().setArchived(false);
			providerValidator.validateInputRequestForPostOperation(updateProviderDTO);
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(ProviderErrorConstants.ACTIVE_ARCHIVED_SHOULD_NOT_BE_SET_BY_CONSUMER));
		}
	}
	
	@Test
	public void testValidateInputForPostOperationWithNullKeyValue() {
		try {
			providerValidator.validateInputRequestForPostOperation(null);
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(ProviderErrorConstants.INVALID_REQUEST_RECEIVED));
		}
	}
	
	@Test
	public void testValidateInputForPostOperationWithNullProviderAttributeValue() {
		try {
			UpdateProviderModelDTO updateProviderDTO = createUpdateProviderModelDTO();
			updateProviderDTO.setProviderAttribute(null);
			providerValidator.validateInputRequestForPostOperation(updateProviderDTO);
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(ProviderErrorConstants.INVALID_REQUEST_RECEIVED));
		}
	}
}

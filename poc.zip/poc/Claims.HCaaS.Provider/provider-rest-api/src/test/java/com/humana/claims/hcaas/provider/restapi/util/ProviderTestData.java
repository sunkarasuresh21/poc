package com.humana.claims.hcaas.provider.restapi.util;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.humana.claims.hcaas.provider.attributes.core.model.RequestKey;
import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.attributes.core.model.db.CasName;
import com.humana.claims.hcaas.provider.attributes.core.model.db.AttributesKey;
import com.humana.claims.hcaas.provider.attributes.core.model.db.PxiZip;
import com.humana.claims.hcaas.provider.attributes.core.model.db.WithholdData;
import com.humana.claims.hcaas.provider.attributes.core.model.db.WthldCurrent;
import com.humana.claims.hcaas.provider.attributes.core.model.db.WthldPrior;
import com.humana.claims.hcaas.provider.contract.restclient.gen.openapi.model.ContractSearchRequestDTO;
import com.humana.claims.hcaas.provider.contract.restclient.gen.openapi.model.ContractSearchResponseDTO;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Address;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.demographics.core.model.db.NpiInfos;
import com.humana.claims.hcaas.provider.demographics.core.model.db.ProviderInfo;
import com.humana.claims.hcaas.provider.demographics.core.model.db.SpecCode;
import com.humana.claims.hcaas.provider.demographics.core.model.db.TaxonomyCode;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderAttributesCasNameModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderAttributesModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderAttributesPxiZipModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderAttributesWithholdDataModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderAttributesWithholdDataWthldCurrentModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderAttributesWithholdDataWthldPriorModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderDemoModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderDemoProviderInfoAddressModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderDemoProviderInfoModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderDemoProviderInfoNpiIdsModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderDemoProviderInfoSpecCodesModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderDemoProviderInfoTaxonomyCodesModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderKeyModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderProviderInfoModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.UpdateProviderModelDTO;

public class ProviderTestData {

	private ProviderTestData() {

	}

	public static final String CLIENT_VALUE = null;
	public static final String PVDIND_VALUE = null; 	
	public static final String PROV_VALUE = null;
	public static final String MULTADDRESSKEY_VALUE = null;
	
	/////////////////////////////////////////////////////////
	//	Demographics Field Value Constants            	   //
	/////////////////////////////////////////////////////////
	public static final LocalDate TINEFFDT_VALUE = LocalDate.of(2020, 4, 21);
	public static final String IRSNO_VALUE = "999999999";
	public static final String UPDATESYS_VALUE = "N";
	public static final String PROVNAME_VALUE = "PALMS OF PASADENA HOSPITAL";
	public static final String ADDRESS1_VALUE = "1501 PASADENA SOUTH";
	public static final String ADDRESS2_VALUE = "addr2";
	public static final String ADDRESS3_VALUE = "addr3";
	public static final String ADDRESS4_VALUE = "addr4";
	public static final String CITY_VALUE = "ST PETERSBURG";
	public static final String ST_VALUE = "FL";
	public static final String ZIP_VALUE = "33707";
	public static final Double LATITUDE = 38.25824738029149;
	public static final Double LONGITUDE = -85.75404721970848;
	public static final String PROVTYPE_VALUE = "HS";
	public static final String MAJCLSCD_VALUE = "A";
	public static final String GROUPFLAG_VALUE = "groupFlag";
	public static final String SPECCD_VALUE = "82";
	public static final String PHONE_VALUE = "0000000000";
	public static final String ADJNO_VALUE = "ONESHOT";
	public static final String PVDSTATUS_VALUE = "0";
	public static final String PVDSTRC_VALUE = " ";
	public static final Boolean ACTIVE_VALUE = null;
	public static final Boolean ARCHIVED_VALUE = null;
	public static final String NOPAYCODE_VALUE = "noPayCode";
	public static final LocalDate NOPAYDT_VALUE = LocalDate.of(2020, 4, 21);
	public static final String NPIID_VALUE = "1234567890";
	public static final String TAXONOMYCD_VALUE = "1234567890";
	/////////////////////////////////////////////////////////
	//	Attributes Field Value Constants                   //
	/////////////////////////////////////////////////////////
	public static final String VCH_VALUE = "VCH";
	public static final String TAXTYPE_VALUE = "TAXTYPE";
	public static final String SEND1099IND_VALUE = "SEND1099IND";
	public static final String PENDESC_VALUE = "PENDESC";
	public static final String AUTOCHECKPULLIND_VALUE = "AUTOCHECKPULLIND";
	public static final String IRSWITHHOLDIND_VALUE = "IRSWITHHOLDIND";
	public static final String PAYCYCLE_VALUE = "PAYCYCLE";
	public static final String CROSSREF_VALUE = "CROSSREF";
	public static final String MARKETID_VALUE = "MARKETID";
	public static final String DG_VALUE = "DG";
	public static final String ALPHAKEY_VALUE = "ALPHAKEY";
	public static final String CASFSTNAME_VALUE = "CASNAME.CASFSTNAME";
	public static final String CASLASTNAME_VALUE = "CASNAME.CASLASTNAME";
	public static final String MEDSUPPWAIVEIND_VALUE = "MEDSUPPWAIVEIND";
	public static final String NOTIFYIND_VALUE = "NOTIFYIND";
	public static final String CLPTHIND_VALUE = "CLPTHIND";
	public static final String CLMCHKIND_VALUE = "CLMCHKIND";
	public static final String UCZIP_VALUE = "UCZIP";
	public static final String AUTOLOADIND_VALUE = "AUTOLOADIND";
	public static final String CHECKTO_VALUE = "CHECKTO";
	public static final String SUFFIXTO_VALUE = "SUFFIXTO";
	public static final String APPLYTAXIND_VALUE = "APPLYTAXIND";
	public static final String W9IND_VALUE = "W9IND";
	public static final String SEND480IND_VALUE = "SEND480IND";
	public static final String WTHLDPERCURRENT_VALUE = "WITHHOLDDATA.WTHLDPERCURRENT";
	public static final String WTHLDEFFDATECURRENT_VALUE = "WITHHOLDDATA.WTHLDEFFDATECURRENT";
	public static final String WTHLDPERPRIOR_VALUE = "WITHHOLDDATA.WTHLDPERPRIOR";
	public static final String WTHLDEFFDATEPRIOR_VALUE = "WITHHOLDDATA.WTHLDEFFDATEPRIOR";
	public static final String PRTAXFREEAMT_VALUE = "WITHHOLDDATA.PRTAXFREEAMT";
	public static final String UPDTADJNO_VALUE = "UPDTADJNO";
	public static final String RADSITECURRIND_VALUE = "RADSITECURRIND";
	public static final String RADSITEP1IND_VALUE = "RADSITEP1IND";
	public static final String RADSITEP2IND_VALUE = "RADSITEP2IND";
	public static final String RADSCOPECURRIND_VALUE = "RADSCOPECURRIND";
	public static final String RADSCOPEP1IND_VALUE = "RADSCOPEP1IND";
	public static final String FACUCZIP_VALUE = "FACUCZIP";
	public static final String PXIUPDTADJNO_VALUE = "PXIUPDTADJNO";
	public static final String SENDLTRIND_VALUE = "SENDLTRIND";
	public static final String FINALSTIND_VALUE = "FINALSTIND";
	public static final String PXIZIPCODE_VALUE = "PXIZIP.PXIZIPCODE";
	public static final String PXIZIPIND_VALUE = "PXIZIP.PXIZIPIND";
	public static final String COMPBIDIND_VALUE = "COMPBIDIND";
	public static final String VENDORID_VALUE = "VENDORID";
	public static final LocalDate LOCALDATE_VALUE = LocalDate.of(2020, 01, 01);
	public static final String COMMENT1_VALUE = "COMMENT1";
	public static final String COMMENT2_VALUE = "COMMENT2";
	public static final String COMMENT3_VALUE = "COMMENT3";
	public static final String REQUEST_ID = "4567835";
	public static final String REQUEST_CLIENT = "98";

	//Prov1 Field Value Constants
	public static final String PRV_IRS_NO = "999999999";
	public static final String PRV_CITY = "ST PETERSBURG";
	public static final String PRV_CLPTH_IND = "CLPTHIND";
	
	//Prov2 Field Value Constants                   //
	public static final String PRV2_NPI = "1234567890";
	public static final String PRV2_TAXONOMY_CODE = "1234567890";
	public static final String PRV2_COMMENT_2 = "COMMENT2";
	
	//Prov3 Field Value Constants  
	public static final String PRV3_WTHLD_PER_C = "WITHHOLDDATA.WTHLDPERCURRENT";
	public static final String PRV3_WTHLD_PER_P = "WITHHOLDDATA.WTHLDPERPRIOR";//
	public static final String PRV3_PROV_PR_TAXFREE_AMT = "WITHHOLDDATA.PRTAXFREEAMT";
	
	public static UpdateProviderModelDTO createUpdateProviderModelDTO() {
		return new UpdateProviderModelDTO()
				.providerKey(createProviderKeyDTO())
				.providerDemo(createProviderDemoDTO())
				.providerAttribute(createProviderAttributesDTO());
	}
	private static ProviderKeyModelDTO createProviderKeyDTO() {
		return new ProviderKeyModelDTO()
				.client(CLIENT_VALUE)
				.pvdInd(PVDIND_VALUE)
				.prov(PROV_VALUE)
				.multAddressKey(MULTADDRESSKEY_VALUE);
	}
	private static ProviderDemoModelDTO createProviderDemoDTO() {
		return new ProviderDemoModelDTO()
				.tinEffDt(TINEFFDT_VALUE)
				.irsNo(IRSNO_VALUE)
				.alphaKey(ALPHAKEY_VALUE)
				.updateSys(UPDATESYS_VALUE)
				.providerInfo(createProviderDemoProviderInfoDTO());
	}
	private static ProviderDemoProviderInfoModelDTO createProviderDemoProviderInfoDTO() {
		return new ProviderDemoProviderInfoModelDTO()
				.provName(PROVNAME_VALUE)
				.address(createProviderDemoProviderInfoAddressDTO())
				.city(CITY_VALUE)
				.st(ST_VALUE)
				.zip(ZIP_VALUE)
				.latitude(LATITUDE)
				.longitude(LONGITUDE)
				.provType(PROVTYPE_VALUE)
				.majClsCd(MAJCLSCD_VALUE)
				.groupFlag(GROUPFLAG_VALUE)
				.specCodes(createProviderDemoProviderInfoSpecCodesDTOList())
				.phone(PHONE_VALUE)
				.adjNo(ADJNO_VALUE)
				.pvdStatus(PVDSTATUS_VALUE)
				.pvdStRc(PVDSTRC_VALUE)
				.active(ACTIVE_VALUE)
				.archived(ARCHIVED_VALUE)
				.noPayCode(NOPAYCODE_VALUE)
				.noPayDt(NOPAYDT_VALUE)
				.npiIds(createProviderDemoProviderInfoNpiIdsDTOList())
				.taxonomyCodes(createProviderDemoProviderInfoTaxonomyCodesDTOList());
	}
	private static ProviderDemoProviderInfoAddressModelDTO createProviderDemoProviderInfoAddressDTO() {
		return new ProviderDemoProviderInfoAddressModelDTO()
				.addr1(ADDRESS1_VALUE)
				.addr2(ADDRESS2_VALUE)
				.addr3(ADDRESS3_VALUE)
				.addr4(ADDRESS4_VALUE);
	}
	private static List<ProviderDemoProviderInfoSpecCodesModelDTO> createProviderDemoProviderInfoSpecCodesDTOList() {
		List<ProviderDemoProviderInfoSpecCodesModelDTO> specCodes = new ArrayList<>();
		ProviderDemoProviderInfoSpecCodesModelDTO specCodeDto = new ProviderDemoProviderInfoSpecCodesModelDTO();
		specCodeDto.setSpecCd(SPECCD_VALUE);
		specCodes.add(specCodeDto);
		return specCodes;
	}	
	private static List<ProviderDemoProviderInfoNpiIdsModelDTO> createProviderDemoProviderInfoNpiIdsDTOList() {
		List<ProviderDemoProviderInfoNpiIdsModelDTO> npiIds = new ArrayList<>();
		ProviderDemoProviderInfoNpiIdsModelDTO npiIdDto = new ProviderDemoProviderInfoNpiIdsModelDTO();
		npiIdDto.setNpiId(NPIID_VALUE);
		npiIds.add(npiIdDto);
		return npiIds;
	}
	private static List<ProviderDemoProviderInfoTaxonomyCodesModelDTO> createProviderDemoProviderInfoTaxonomyCodesDTOList() {
		List<ProviderDemoProviderInfoTaxonomyCodesModelDTO> taxonomyCodes = new ArrayList<>();
		ProviderDemoProviderInfoTaxonomyCodesModelDTO taxonomyCodeDto = new ProviderDemoProviderInfoTaxonomyCodesModelDTO();
		taxonomyCodeDto.setTaxonomyCd(TAXONOMYCD_VALUE);
		taxonomyCodes.add(taxonomyCodeDto);
		return taxonomyCodes;
	}
	private static ProviderAttributesModelDTO createProviderAttributesDTO() {
		return new ProviderAttributesModelDTO()
				.vch(VCH_VALUE)
				.taxType(TAXTYPE_VALUE)
				.send1099Ind(SEND1099IND_VALUE)
				.pendEsc(PENDESC_VALUE)
				.autoCheckPullInd(AUTOCHECKPULLIND_VALUE)
				.irsWithholdInd(IRSWITHHOLDIND_VALUE)
				.payCycle(PAYCYCLE_VALUE)
				.crossRef(CROSSREF_VALUE)
				.marketId(MARKETID_VALUE)
				.dg(DG_VALUE)
				.alphaKey(ALPHAKEY_VALUE)
				.casName(getCasNameDto())
				.medSuppWaiveInd(MEDSUPPWAIVEIND_VALUE)
				.comment1(COMMENT1_VALUE)
				.comment2(COMMENT2_VALUE)
				.comment3(COMMENT3_VALUE)
				.notifyInd(NOTIFYIND_VALUE)
				.focusFromDate(LOCALDATE_VALUE)
				.focusFromDate(LOCALDATE_VALUE)
				.clpthInd(CLPTHIND_VALUE)
				.clmChkInd(CLMCHKIND_VALUE)
				.ucZip(UCZIP_VALUE)
				.focusToDate(LOCALDATE_VALUE)
				.autoLoadInd(AUTOLOADIND_VALUE)
				.checkTo(CHECKTO_VALUE)
				.suffixTo(SUFFIXTO_VALUE)
				.applyTaxInd(APPLYTAXIND_VALUE)
				.w9Ind(W9IND_VALUE)
				.send480Ind(SEND480IND_VALUE)
				.withholdData(getWithholdDataDto())
				.updtAdjNo(UPDTADJNO_VALUE)
				.radSiteCurrInd(RADSITECURRIND_VALUE)
				.radSiteCurrDt(LOCALDATE_VALUE)
				.radSiteP1Ind(RADSITEP1IND_VALUE)
				.radSiteP1Dt(LOCALDATE_VALUE)
				.radSiteP2Ind(RADSITEP2IND_VALUE)
				.radSiteP2Dt(LOCALDATE_VALUE)
				.radScopeCurrInd(RADSCOPECURRIND_VALUE)
				.radScopeCurrDt(LOCALDATE_VALUE)
				.radScopeP1Ind(RADSCOPEP1IND_VALUE)
				.radScopeP1Dt(LOCALDATE_VALUE)
				.facUcZip(FACUCZIP_VALUE)
				.pxiUpdtAdjNo(PXIUPDTADJNO_VALUE)
				.pxiUpdtDt(LOCALDATE_VALUE)
				.sendLtrInd(SENDLTRIND_VALUE)
				.finalstInd(FINALSTIND_VALUE)
				.pxiZip(getPxiZipDto())
				.compbidInd(COMPBIDIND_VALUE)
				.vendorId(VENDORID_VALUE)
				.compbidEffDt(LocalDate.of(2019, 01, 01))
				.compbidTrmDt(LOCALDATE_VALUE)
				.contractPointEnable(buildContractPointEnableMap());
	}
	private static ProviderAttributesCasNameModelDTO getCasNameDto() {
		ProviderAttributesCasNameModelDTO casNameDto = new ProviderAttributesCasNameModelDTO();
		casNameDto.casFstName(CASFSTNAME_VALUE);
		casNameDto.casLastName(CASLASTNAME_VALUE);
		return casNameDto;
	}
	private static ProviderAttributesWithholdDataModelDTO getWithholdDataDto() {
		ProviderAttributesWithholdDataModelDTO withHldDataDto = new ProviderAttributesWithholdDataModelDTO();
		withHldDataDto.wthldCurrent(getWthldCurrentDto());
		withHldDataDto.wthldPrior(getWthldPriorDto());
		withHldDataDto.prTaxfreeAmt(PRTAXFREEAMT_VALUE);
		return withHldDataDto;
	}
	private static ProviderAttributesWithholdDataWthldCurrentModelDTO getWthldCurrentDto() {
		ProviderAttributesWithholdDataWthldCurrentModelDTO withHldCurrentDto = new ProviderAttributesWithholdDataWthldCurrentModelDTO();
		withHldCurrentDto.setWthldPerCurrent(WTHLDPERCURRENT_VALUE);
		withHldCurrentDto.setWthldEffDateCurrent(LOCALDATE_VALUE);
		return withHldCurrentDto;
	}
	private static ProviderAttributesWithholdDataWthldPriorModelDTO getWthldPriorDto() {
		ProviderAttributesWithholdDataWthldPriorModelDTO withHldPriorDto = new ProviderAttributesWithholdDataWthldPriorModelDTO();
		withHldPriorDto.setWthldPerPrior(WTHLDPERPRIOR_VALUE);
		withHldPriorDto.setWthldEffDatePrior(LOCALDATE_VALUE);
		return withHldPriorDto;
	}
	private static List<ProviderAttributesPxiZipModelDTO> getPxiZipDto() {
		List<ProviderAttributesPxiZipModelDTO> pxiZipDtos = new ArrayList<>();
		ProviderAttributesPxiZipModelDTO pxiZipDto = new ProviderAttributesPxiZipModelDTO();
		pxiZipDto.setPxiZipCode(PXIZIPCODE_VALUE);
		pxiZipDto.setPxiZipInd(PXIZIPIND_VALUE);
		pxiZipDtos.add(pxiZipDto);
		return pxiZipDtos;
	}
	private static Map<String, Boolean> buildContractPointEnableMap() {
		Map<String, Boolean> contractPointEnableMap = new HashMap<>();
		contractPointEnableMap.put("1", true);
		contractPointEnableMap.put("2", false);
		return contractPointEnableMap;
	}
	
	public static Demographics createDemographics() {
		Demographics demographics = new Demographics();
		demographics.setKey(createDemographicsKey());
		demographics.setTinEffDt(TINEFFDT_VALUE);
		demographics.setIrsNo(IRSNO_VALUE);
		demographics.setUpdateSys(UPDATESYS_VALUE);
		demographics.setPvdStatus(PVDSTATUS_VALUE);
		demographics.setAlphaKey(ALPHAKEY_VALUE);
		demographics.setProviderInfo(createProviderInfo());
		return demographics;
	}
	private static com.humana.claims.hcaas.provider.demographics.core.model.db.DemographicsKey createDemographicsKey() {
		com.humana.claims.hcaas.provider.demographics.core.model.db.DemographicsKey demographicsKey = new com.humana.claims.hcaas.provider.demographics.core.model.db.DemographicsKey();
		demographicsKey.setClient("30");
		demographicsKey.setPvdInd("H");
		demographicsKey.setProv("542");
		demographicsKey.setMultAddressKey("");
		return demographicsKey;
	}
	private static ProviderInfo createProviderInfo() {
		ProviderInfo providerInfo = new ProviderInfo();
		providerInfo.setProvName(PROVNAME_VALUE);
		providerInfo.setAddress(createAddress());
		providerInfo.setCity(CITY_VALUE);
		providerInfo.setSt(ST_VALUE);
		providerInfo.setZip(ZIP_VALUE);
		providerInfo.setLatitude(LATITUDE);
		providerInfo.setLongitude(LONGITUDE);
		providerInfo.setProvType(PROVTYPE_VALUE);
		providerInfo.setMajClsCd(MAJCLSCD_VALUE);
		providerInfo.setGroupFlag(GROUPFLAG_VALUE);
		providerInfo.setSpecCodes(createSpecCodeList());
		providerInfo.setPhone(PHONE_VALUE);
		providerInfo.setAdjNo(ADJNO_VALUE);
		providerInfo.setPvdStRc(PVDSTRC_VALUE);
		providerInfo.setActive(ACTIVE_VALUE);
		providerInfo.setArchived(ARCHIVED_VALUE);
		providerInfo.setPrvNoPay(NOPAYCODE_VALUE);
		providerInfo.setPrvNoPayDt(NOPAYDT_VALUE);
		providerInfo.setNpiIds(createNpiIdList());
		providerInfo.setTaxonomyCodes(createTaxonomyCodeList());
		return providerInfo;
	}
	private static Address createAddress() {
		Address address = new Address();
		address.setAddr1(ADDRESS1_VALUE);
		address.setAddr2(ADDRESS2_VALUE);
		address.setAddr3(ADDRESS3_VALUE);
		address.setAddr4(ADDRESS4_VALUE);
		return address;
	}
	private static List<SpecCode> createSpecCodeList() {
		List<SpecCode> specCodes = new ArrayList<>();
		SpecCode specCode = new SpecCode();
		specCode.setSpecCd(SPECCD_VALUE);
		specCodes.add(specCode);
		return specCodes;
	}
	private static List<NpiInfos> createNpiIdList() {
		List<NpiInfos> npiIds = new ArrayList<>();
		NpiInfos npiInfos = new NpiInfos();
		npiInfos.setNpiId(NPIID_VALUE);
		npiIds.add(npiInfos);
		return npiIds;
	}
	private static List<TaxonomyCode> createTaxonomyCodeList() {
		List<TaxonomyCode> taxonomyCodes = new ArrayList<>();
		TaxonomyCode taxonomyCode = new TaxonomyCode();
		taxonomyCode.setTaxonomyCd(TAXONOMYCD_VALUE);
		taxonomyCodes.add(taxonomyCode);
		return taxonomyCodes;
	}
	public static UpdateProviderModelDTO createPostRequest() {
		return new UpdateProviderModelDTO()
				.providerKey(createKeyObject())
				.providerDemo(createProviderDemoDTO())
				.providerAttribute(createProviderAttributesDTO());
	}
	private static ProviderKeyModelDTO createKeyObject() {
		return new ProviderKeyModelDTO()
				.client("30")
				.pvdInd("H")
				.prov("542")
				.multAddressKey("");
	}
	
	public static Attributes createAttributes() {
		Attributes attributes = new Attributes();
		attributes.setKey(getKey());
		attributes.setIrsNo(IRSNO_VALUE);
		attributes.setVch(VCH_VALUE);
		attributes.setTaxType(TAXTYPE_VALUE);
		attributes.setSend1099Ind(SEND1099IND_VALUE);
		attributes.setPendEsc(PENDESC_VALUE);
		attributes.setAutoCheckPullInd(AUTOCHECKPULLIND_VALUE);
		attributes.setIrsWithholdInd(IRSWITHHOLDIND_VALUE);
		attributes.setPayCycle(PAYCYCLE_VALUE);
		attributes.setCrossRef(CROSSREF_VALUE);
		attributes.setMarketId(MARKETID_VALUE);
		attributes.setDg(DG_VALUE);
		attributes.setAlphaKey(ALPHAKEY_VALUE);
		attributes.setCasName(getCasName());
		attributes.setMedSuppWaiveInd(MEDSUPPWAIVEIND_VALUE);
		attributes.setComment1(COMMENT1_VALUE);
		attributes.setNotifyInd(NOTIFYIND_VALUE);
		attributes.setFocusFromDate(LocalDate.of(2020, 01, 01));
		attributes.setClpthInd(CLPTHIND_VALUE);
		attributes.setClmChkInd(CLMCHKIND_VALUE);
		attributes.setUcZip(UCZIP_VALUE);
		attributes.setFocusToDate(LocalDate.of(2020, 01, 01));
		attributes.setAutoLoadInd(AUTOLOADIND_VALUE);
		attributes.setCheckTo(CHECKTO_VALUE);
		attributes.setSuffixTo(SUFFIXTO_VALUE);
		attributes.setApplyTaxInd(APPLYTAXIND_VALUE);
		attributes.setW9Ind(W9IND_VALUE);
		attributes.setSend480Ind(SEND480IND_VALUE);
		attributes.setWithholdData(getWithholdData());
		attributes.setComment2(COMMENT2_VALUE);
		attributes.setComment3(COMMENT3_VALUE);
		attributes.setUpdtAdjNo(UPDTADJNO_VALUE);
		attributes.setUpdtDt(LocalDate.of(2020, 01, 01));
		attributes.setRadSiteCurrInd(RADSITECURRIND_VALUE);
		attributes.setRadSiteCurrDt(LocalDate.of(2020, 01, 01));
		attributes.setRadSiteP1Ind(RADSITEP1IND_VALUE);
		attributes.setRadSiteP1Dt(LocalDate.of(2020, 01, 01));
		attributes.setRadSiteP2Ind(RADSITEP2IND_VALUE);
		attributes.setRadSiteP2Dt(LocalDate.of(2020, 01, 01));
		attributes.setRadScopeCurrInd(RADSCOPECURRIND_VALUE);
		attributes.setRadScopeCurrDt(LocalDate.of(2020, 01, 01));
		attributes.setRadScopeP1Ind(RADSCOPEP1IND_VALUE);
		attributes.setRadScopeP1Dt(LocalDate.of(2020, 01, 01));
		attributes.setFacUcZip(FACUCZIP_VALUE);
		attributes.setPxiUpdtAdjNo(PXIUPDTADJNO_VALUE);
		attributes.setPxiUpdtDt(LocalDate.of(2020, 01, 01));
		attributes.setSendLtrInd(SENDLTRIND_VALUE);
		attributes.setFinalstInd(FINALSTIND_VALUE);
		attributes.setPxiZip(getPxiZip());
		attributes.setCompbidInd(COMPBIDIND_VALUE);
		attributes.setVendorId(VENDORID_VALUE);
		attributes.setCompbidEffDt(LocalDate.of(2019, 01, 01));
		attributes.setCompbidTrmDt(LocalDate.of(2020, 01, 01));
		attributes.setContractPointEnable(buildContractPointEnableMap());

		return attributes;					
	}
	private static CasName getCasName() {
		CasName casNameDto = new CasName();
		casNameDto.setFstName(CASFSTNAME_VALUE);
		casNameDto.setLastName(CASLASTNAME_VALUE);
		return casNameDto;
	}
	private static WithholdData getWithholdData() {
		WithholdData withHldDataDto = new WithholdData();
		withHldDataDto.setWthldCurrent(getWthldCurrent());
		withHldDataDto.setWthldPrior(getWthldPrior());
		withHldDataDto.setPrTaxfreeAmt(PRTAXFREEAMT_VALUE);
		return withHldDataDto;
	}
	private static WthldCurrent getWthldCurrent() {
		WthldCurrent withHldCurrentDto = new WthldCurrent();
		withHldCurrentDto.setWthldPerCurrent(WTHLDPERCURRENT_VALUE);
		withHldCurrentDto.setWthldEffDateCurrent(LocalDate.of(2020, 01, 01));
		return withHldCurrentDto;
	}
	private static WthldPrior getWthldPrior() {
		WthldPrior withHldPriorDto = new WthldPrior();
		withHldPriorDto.setWthldPerPrior(WTHLDPERPRIOR_VALUE);
		withHldPriorDto.setWthldEffDatePrior(LocalDate.of(2020, 01, 01));
		return withHldPriorDto;
	}
	private static List<PxiZip> getPxiZip() {
		List<PxiZip> pxiZipDtos = new ArrayList<>();
		PxiZip pxiZipDto = new PxiZip();
		pxiZipDto.setPxiZipCode(PXIZIPCODE_VALUE);
		pxiZipDto.setPxiZipInd(PXIZIPIND_VALUE);
		pxiZipDtos.add(pxiZipDto);
		return pxiZipDtos;
	}
	private static AttributesKey getKey() {
		AttributesKey keyDto = new AttributesKey();
		keyDto.setClient("58");
		keyDto.setPvdInd("H");
		keyDto.setProv("542");
		keyDto.setMultAddressKey(" ");		
		return keyDto;
	}
	
	public static RequestKey getRequestKeyObj(String provId, String provInd, String multiAddrKey) {
		RequestKey requestKey = new RequestKey();
		requestKey.setClient("58");
		requestKey.setMultAddressKey(multiAddrKey);
		requestKey.setProv(provId);
		requestKey.setPvdInd(provInd);
		return requestKey;
	}

	public static Demographics getDemographics(String provId, String provInd, String multiAddrKey) {
		Demographics demographics = new Demographics();
		com.humana.claims.hcaas.provider.demographics.core.model.db.DemographicsKey demographicsKey = new com.humana.claims.hcaas.provider.demographics.core.model.db.DemographicsKey();
		demographicsKey.setClient("58");
		demographicsKey.setProv(provId);
		demographicsKey.setMultAddressKey(multiAddrKey);
		demographicsKey.setPvdInd(provInd);
		demographics.setKey(demographicsKey);
		return demographics;
	}

	public static Attributes getAttributes(String provId, String provInd, String multiAddrKey) {
		Attributes attributes = new Attributes();
		com.humana.claims.hcaas.provider.attributes.core.model.db.AttributesKey attributesKey = new com.humana.claims.hcaas.provider.attributes.core.model.db.AttributesKey();
		attributesKey.setClient("58");
		attributesKey.setProv(provId);
		attributesKey.setMultAddressKey(multiAddrKey);
		attributesKey.setPvdInd(provInd);
		attributes.setKey(attributesKey);
		return attributes;
	}
	
	public static ContractSearchRequestDTO getContractSearchRequestDTO(String provId, String provInd, String multiAddrKey) {
		ContractSearchRequestDTO searchRequestDTO = new ContractSearchRequestDTO();
		searchRequestDTO.setProvId(provId);
		searchRequestDTO.setProvInd(provInd);
		searchRequestDTO.setProvSuffix(multiAddrKey);
		return searchRequestDTO;
	}
	
	public static ContractSearchResponseDTO getContractSearchResponseDTO(String provId, String provInd, String multiAddrKey,List<String> lobs) {
		ContractSearchResponseDTO responseDTO = new ContractSearchResponseDTO();
		responseDTO.setProvId(provId);
		responseDTO.setProvInd(provInd);
		responseDTO.setProvSuffix(multiAddrKey);
		responseDTO.setLobsWithActiveContract(lobs);
		return responseDTO;
	}
	
	public static ProviderModelDTO getProviderDTO(String provId, String provInd, String multiAddrKey,String irsNo,List<String> lobs) {
		ProviderModelDTO providerDTO = new ProviderModelDTO();
		ProviderKeyModelDTO providerKeyDTO = new ProviderKeyModelDTO();
		providerKeyDTO.setProv(provId);
		providerKeyDTO.setPvdInd(provInd);
		providerKeyDTO.setMultAddressKey(multiAddrKey);
		providerDTO.setCfiExistForLineOfBusiness(lobs);
		providerDTO.setKey(providerKeyDTO);
		providerDTO.setIrsNo(irsNo);
		return providerDTO;
	}
	
	public static ProviderProviderInfoModelDTO getProviderInfoDTO(List<ProviderDemoProviderInfoNpiIdsModelDTO> npiIds,String provName) {
		ProviderProviderInfoModelDTO providerInfoDTO =  new ProviderProviderInfoModelDTO();
		providerInfoDTO.setNpiIds(npiIds);
		providerInfoDTO.setProvName(provName);
		return providerInfoDTO;
	}
	
	public static List<ProviderDemoProviderInfoNpiIdsModelDTO> getProviderDemoProviderInfoNpiIdsDTO(String npiId) {
		ProviderDemoProviderInfoNpiIdsModelDTO npiIdObj = new ProviderDemoProviderInfoNpiIdsModelDTO();
		npiIdObj.setNpiId(npiId);
		return Arrays.asList(npiIdObj);
	}

	
}

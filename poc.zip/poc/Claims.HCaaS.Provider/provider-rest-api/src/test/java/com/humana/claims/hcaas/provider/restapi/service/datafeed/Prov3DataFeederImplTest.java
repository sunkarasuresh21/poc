package com.humana.claims.hcaas.provider.restapi.service.datafeed;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;

import com.humana.claims.hcaas.provider.model.mq.Prv3Key;
import com.humana.claims.hcaas.provider.model.mq.Prv3OutRecord;
import com.humana.claims.hcaas.provider.restapi.exception.DataFeedException;
import com.humana.claims.hcaas.provider.restapi.model.datafeed.Prov3DataFeed;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
public class Prov3DataFeederImplTest {

	private Prov3DataFeederImpl classUnderTest;
	
	@Mock
	private JmsTemplate jmsTemplate;
	
	private static final String QUEUE_NAME = "demographics-test-queue";
	
	private static final String REQUEST_ID = "123456";
	private static final String REQUEST_CLIENT = "98";
	
	@BeforeEach
	public void setUp() {
		classUnderTest = new Prov3DataFeederImpl(jmsTemplate, QUEUE_NAME);
	}
	
	@Test
	@SneakyThrows
	public void should_invoke_jms_template_with_demographics_passed_as_parameter() {
		Prov3DataFeed prov3DataFeed = createProv3DataFeed();
		classUnderTest.sendToQueue(prov3DataFeed);
		Mockito.verify(jmsTemplate, times(1)).convertAndSend(QUEUE_NAME, getDemographicsJson());
	}
	
	@Test
	@SneakyThrows
	public void should_throw_datafeed_exception_for_jms_exception() {
		Prov3DataFeed prov3DataFeed = createProv3DataFeed();
		doThrow(new JmsExceptionTest("Data Feed Failed")).when(jmsTemplate).convertAndSend(QUEUE_NAME, getDemographicsJson());
		
		assertThatExceptionOfType(DataFeedException.class)
				.isThrownBy(() -> classUnderTest.sendToQueue(prov3DataFeed)).withMessage("Data Feed Failed");
	}
	
	private Prov3DataFeed createProv3DataFeed() {
		Prov3DataFeed prov3DataFeed = new Prov3DataFeed();
		Prv3OutRecord prv3OutRecord = new Prv3OutRecord();
		Prv3Key prv3Key = new Prv3Key();
		prv3Key.setPrv3Client("58");
		prv3OutRecord.setPrv3Key(prv3Key);
		prov3DataFeed.setRequestId(REQUEST_ID);
		prov3DataFeed.setRequestClient(REQUEST_CLIENT);
		prov3DataFeed.setPrv3OutRecord(prv3OutRecord);
		return prov3DataFeed;
	}
	
	private String getDemographicsJson() {
		return "{\"requestId\":\"123456\",\"requestClient\":\"98\",\"prv3OutRecord\":{\"PRV3-KEY\":{\"PRV3-CLIENT\":\"58\"}}}";
	}
	
	static class JmsExceptionTest extends JmsException {

		private static final long serialVersionUID = 1L;

		public JmsExceptionTest(String msg) {
			super(msg);
		}
	}
}
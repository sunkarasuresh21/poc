package com.humana.claims.hcaas.provider.restapi.controller;

import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.getProviderDTO;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsConstants;
import com.humana.claims.hcaas.provider.demographics.core.exception.InvalidHeaderCombinationException;
import com.humana.claims.hcaas.provider.demographics.core.exception.InvalidRequestException;
import com.humana.claims.hcaas.provider.demographics.core.masker.ProviderDemographicsDataMasker;
import com.humana.claims.hcaas.provider.demographics.core.model.ProviderDemoGetRequest;
import com.humana.claims.hcaas.provider.restapi.constants.ProviderConstants;
import com.humana.claims.hcaas.provider.restapi.constants.ProviderErrorConstants;
import com.humana.claims.hcaas.provider.restapi.exception.ConflictException;
import com.humana.claims.hcaas.provider.restapi.exception.DataFeedException;
import com.humana.claims.hcaas.provider.restapi.exception.NotFoundException;
import com.humana.claims.hcaas.provider.restapi.exception.ProviderCreationException;
import com.humana.claims.hcaas.provider.restapi.exception.ProviderUpdateException;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderDemoModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderKeyModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.UpdateProviderModelDTO;
import com.humana.claims.hcaas.provider.restapi.model.ProviderGetResponse;
import com.humana.claims.hcaas.provider.restapi.service.ProviderService;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
public class ProviderControllerTest {
	
	@InjectMocks
	private ProviderController classUnderTest;
	
	@Mock
	private ProviderDemographicsDataMasker dataMasker;
	
	@Mock
	private ProviderService providerService;
		
	String client = "30";
	String prov = "123456789";
	String pvdInd = "D";
	String multAddressKey = "1";
	String requestId = "9865743";
	String requestClient = "58";
	
	@Test
	public void invalidInputReturnBadRequest() throws InvalidRequestException, ConflictException, ProviderCreationException, DataFeedException {
		UpdateProviderModelDTO updateProviderDTO = new UpdateProviderModelDTO();
		updateProviderDTO.setProviderKey(createKey(client, prov, null, multAddressKey));
		updateProviderDTO.setProviderDemo(createProviderDemoDTO());
		
		ResponseEntity<Void> actual = classUnderTest.createProvider(updateProviderDTO, requestId, requestClient);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST); 
	}
	
	@Test
	public void invalidPvdIndNullReturnBadRequest() throws InvalidRequestException, ConflictException, ProviderCreationException, DataFeedException {
		UpdateProviderModelDTO updateProviderDTO = new UpdateProviderModelDTO();
		updateProviderDTO.setProviderKey(createKey(client, prov, null, multAddressKey));
		updateProviderDTO.setProviderDemo(createProviderDemoDTO());
		
		ResponseEntity<Void> actual = classUnderTest.createProvider(updateProviderDTO, requestId, requestClient);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
	}
	
	@Test
	public void invalidPvdIndNotDorHReturnBadRequest() throws InvalidRequestException, ConflictException, ProviderCreationException, DataFeedException {
		UpdateProviderModelDTO updateProviderDTO = new UpdateProviderModelDTO();
		updateProviderDTO.setProviderKey(createKey(client, prov, "A", multAddressKey));
		updateProviderDTO.setProviderDemo(createProviderDemoDTO());
		
		ResponseEntity<Void> actual = classUnderTest.createProvider(updateProviderDTO, requestId, requestClient);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
	}
	
	@Test
	public void invalidMultAddressKeyNullReturnBadRequest() throws InvalidRequestException, ConflictException, ProviderCreationException, DataFeedException {
		UpdateProviderModelDTO updateProviderDTO = new UpdateProviderModelDTO();
		updateProviderDTO.setProviderKey(createKey(client, prov, pvdInd, null));
		updateProviderDTO.setProviderDemo(createProviderDemoDTO());
		
		ResponseEntity<Void> actual = classUnderTest.createProvider(updateProviderDTO, requestId, requestClient);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
	}
	
	@Test
	public void invalidMultAddressKeyMoreThanOneCharReturnBadRequest() throws InvalidRequestException, ConflictException, ProviderCreationException, DataFeedException {
		UpdateProviderModelDTO updateProviderDTO = new UpdateProviderModelDTO();
		updateProviderDTO.setProviderKey(createKey(client, prov, pvdInd, "AB"));
		updateProviderDTO.setProviderDemo(createProviderDemoDTO());
		
		ResponseEntity<Void> actual = classUnderTest.createProvider(updateProviderDTO, requestId, requestClient);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
	}
	
	@Test
	public void invalidProvNullReturnBadRequest() throws InvalidRequestException, ConflictException, ProviderCreationException, DataFeedException {
		UpdateProviderModelDTO updateProviderDTO = new UpdateProviderModelDTO();
		updateProviderDTO.setProviderKey(createKey(client, null, pvdInd, " "));
		updateProviderDTO.setProviderDemo(createProviderDemoDTO());
		
		ResponseEntity<Void> actual = classUnderTest.createProvider(updateProviderDTO, requestId, requestClient);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
	}
	
	@Test
	public void invalidProvAllZeroReturnBadRequest() throws InvalidRequestException, ConflictException, ProviderCreationException, DataFeedException {
		UpdateProviderModelDTO updateProviderDTO = new UpdateProviderModelDTO();
		updateProviderDTO.setProviderKey(createKey(client, "00000000", pvdInd, " "));
		updateProviderDTO.setProviderDemo(createProviderDemoDTO());
		
		ResponseEntity<Void> actual = classUnderTest.createProvider(updateProviderDTO, requestId, requestClient);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
	}
	
	@Test
	public void invalidRequestReturnBadRequest() throws InvalidRequestException, ConflictException, ProviderCreationException, DataFeedException {
		UpdateProviderModelDTO updateProviderDTO = new UpdateProviderModelDTO();
		updateProviderDTO.setProviderKey(createKey(client, "00000001", pvdInd, " "));
		updateProviderDTO.setProviderDemo(createProviderDemoDTO());
		when(providerService.createProvider(ArgumentMatchers.any(UpdateProviderModelDTO.class), ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(false);
		
		ResponseEntity<Void> actual = classUnderTest.createProvider(updateProviderDTO, requestId, requestClient);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
	}
	
	@Test
	public void validRequestReturnsCreated() throws InvalidRequestException, ConflictException, ProviderCreationException, DataFeedException {
		UpdateProviderModelDTO updateProviderDTO = new UpdateProviderModelDTO();
		updateProviderDTO.setProviderKey(createKey(client, prov, pvdInd, " "));
		updateProviderDTO.setProviderDemo(createProviderDemoDTO());
		when(providerService.createProvider(ArgumentMatchers.any(UpdateProviderModelDTO.class), ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(true);
		
		ResponseEntity<Void> actual = classUnderTest.createProvider(updateProviderDTO, requestId, requestClient);
		
		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.CREATED);
	}
	
	@Test
	public void validRequestReturnsSuccessUpdate() throws InvalidRequestException, IOException, NotFoundException, ProviderUpdateException, IllegalAccessException, DataFeedException{
		UpdateProviderModelDTO updateProviderDTO = new UpdateProviderModelDTO();
		when(providerService.updateProvider(updateProviderDTO, "123456789","1","D", requestId, requestClient)).thenReturn(ProviderConstants.SUCCESS);
		
		ResponseEntity<Void> actual = classUnderTest.updateProvider("123456789","D","1",updateProviderDTO, requestId, requestClient);
		
		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
	}
	
	@Test
	@SneakyThrows
	public void ValidRequestReturnsUpdateFailure() throws InvalidRequestException, IOException, NotFoundException, ProviderUpdateException, IllegalAccessException{
		UpdateProviderModelDTO updateProviderDTO = new UpdateProviderModelDTO();
		when(providerService.updateProvider(updateProviderDTO, "999999999","2","H", requestId, requestClient)).thenReturn(ProviderErrorConstants.NOT_FOUND);
		
		Throwable actualThrown = catchThrowable(() -> classUnderTest.updateProvider(
				"999999999","H","2",updateProviderDTO, requestId, requestClient));
		
		assertThat(actualThrown).isInstanceOf(NotFoundException.class);
	}

	
	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdMultiAddressKeyAndProviderIndicatorShouldReturnResponseIncludeCountTrue200() {
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = "H";
		String npiId = null;
		String providerMultiAddressKey = "";
		String providerTaxId = null;
		Boolean includeCount = true;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Boolean checkContract = true;
		
		List<ProviderModelDTO> providerDtos = Arrays.asList(getProviderDTO(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, 
				Arrays.asList("1*", "2*", "3e")));
		
		Mockito.when(providerService.getProviderByProviderId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderGetResponse .builder().providerDTOs(providerDtos).totalCount("1").build());
		
		ResponseEntity<List<ProviderModelDTO>> actual = classUnderTest.getProvider(providerId, providerIndicator,
				providerMultiAddressKey, providerTaxId, npiId, checkContract, statusOrReasonCode, majorClassCode,
				provName, stateCode, includeCount, limit, offset);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(true);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdMultiAddressKeyAndProviderIndicatorShouldReturnResponseIncludeCountFalse200() {
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = "H";
		String npiId = null;
		String providerMultiAddressKey = "";
		String providerTaxId = null;
		Boolean includeCount = false;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Boolean checkContract = true;
		
		List<ProviderModelDTO> providerDtos = Arrays.asList(getProviderDTO(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, 
				Collections.emptyList()));
		
		Mockito.when(providerService.getProviderByProviderId(any(ProviderDemoGetRequest.class)))
		.thenReturn(ProviderGetResponse .builder().providerDTOs(providerDtos).build());
		
		ResponseEntity<List<ProviderModelDTO>> actual = classUnderTest.getProvider(providerId, providerIndicator,
				providerMultiAddressKey, providerTaxId, npiId, checkContract, statusOrReasonCode, majorClassCode,
				provName, stateCode, includeCount, limit, offset);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderTaxIdShouldReturnResponseIncludeCountTrue200() {
		ProviderDemoModelDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoModelDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String npiId = null;
		String providerTaxId = "999999999";
		Boolean includeCount = true;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Boolean checkContract = true;
		
		List<ProviderModelDTO> providerDtos = Arrays.asList(getProviderDTO(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, 
				Collections.emptyList()));
		
		Mockito.when(providerService.getProviderByProviderTaxId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderGetResponse .builder().providerDTOs(providerDtos).totalCount("1").build());

		ResponseEntity<List<ProviderModelDTO>> actual = classUnderTest.getProvider(providerId, providerIndicator,
				providerMultiAddressKey, providerTaxId, npiId, checkContract, statusOrReasonCode, majorClassCode,
				provName, stateCode, includeCount, limit, offset);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(true);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderTaxIdShouldReturnResponseIncludeCountFalse200() {
		ProviderDemoModelDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoModelDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String npiId = null;
		String providerTaxId = "999999999";
		Boolean includeCount = false;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Boolean checkContract = true;
		
		List<ProviderModelDTO> providerDtos = Arrays.asList(getProviderDTO(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, 
				Collections.emptyList()));
		
		Mockito.when(providerService.getProviderByProviderTaxId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderGetResponse .builder().providerDTOs(providerDtos).build());

		ResponseEntity<List<ProviderModelDTO>> actual = classUnderTest.getProvider(providerId, providerIndicator,
				providerMultiAddressKey, providerTaxId, npiId, checkContract, statusOrReasonCode, majorClassCode,
				provName, stateCode, includeCount, limit, offset);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderTaxIdShouldReturnResponseIncludeCountWithNullValue200() {
		ProviderDemoModelDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoModelDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String npiId = null;
		String providerTaxId = "999999999";
		Boolean includeCount = null;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Boolean checkContract = true;
		
		List<ProviderModelDTO> providerDtos = Arrays.asList(getProviderDTO(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, 
				Collections.emptyList()));
		
		Mockito.when(providerService.getProviderByProviderTaxId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderGetResponse .builder().providerDTOs(providerDtos).build());

		ResponseEntity<List<ProviderModelDTO>> actual = classUnderTest.getProvider(providerId, providerIndicator,
				providerMultiAddressKey, providerTaxId, npiId, checkContract, statusOrReasonCode, majorClassCode,
				provName, stateCode, includeCount, limit, offset);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdShouldReturnResponseIncludeCountTrue200() {
		ProviderDemoModelDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoModelDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = null;
		String npiId = null;
		String providerMultiAddressKey = null;
		String providerTaxId = null;
		Boolean includeCount = true;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Boolean checkContract = true;
		
		List<ProviderModelDTO> providerDtos = Arrays.asList(getProviderDTO(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, 
				Collections.emptyList()));
		
		Mockito.when(providerService.getProviderByProviderId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderGetResponse .builder().providerDTOs(providerDtos).totalCount("1").build());

		ResponseEntity<List<ProviderModelDTO>> actual = classUnderTest.getProvider(providerId, providerIndicator,
				providerMultiAddressKey, providerTaxId, npiId, checkContract, statusOrReasonCode, majorClassCode,
				provName, stateCode, includeCount, limit, offset);
		
		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(true);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdShouldReturnResponseIncludeCountFalse200() {
		ProviderDemoModelDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoModelDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = null;
		String npiId = null;
		String providerMultiAddressKey = null;
		String providerTaxId = null;
		Boolean includeCount = false;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Boolean checkContract = true;
		
		List<ProviderModelDTO> providerDtos = Arrays.asList(getProviderDTO(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, 
				Collections.emptyList()));
		
		Mockito.when(providerService.getProviderByProviderId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderGetResponse .builder().providerDTOs(providerDtos).build());

		ResponseEntity<List<ProviderModelDTO>> actual = classUnderTest.getProvider(providerId, providerIndicator,
				providerMultiAddressKey, providerTaxId, npiId, checkContract, statusOrReasonCode, majorClassCode,
				provName, stateCode, includeCount, limit, offset);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdShouldReturnResponseIncludeCountDefault200() {
		ProviderDemoModelDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoModelDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = null;
		String npiId = null;
		String providerMultiAddressKey = null;
		String providerTaxId = null;
		Boolean includeCount = null;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Boolean checkContract = true;
		
		List<ProviderModelDTO> providerDtos = Arrays.asList(getProviderDTO(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, 
				Collections.emptyList()));
		
		Mockito.when(providerService.getProviderByProviderId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderGetResponse .builder().providerDTOs(providerDtos).build());

		ResponseEntity<List<ProviderModelDTO>> actual = classUnderTest.getProvider(providerId, providerIndicator,
				providerMultiAddressKey, providerTaxId, npiId, checkContract, statusOrReasonCode, majorClassCode,
				provName, stateCode, includeCount, limit, offset);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	
	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdAndIndicatorShouldReturnResponseIncludeCountTrue200() {
		ProviderDemoModelDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoModelDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = "H";
		String providerMultiAddressKey = null;
		String providerTaxId = null;
		String npiId = null;
		Boolean includeCount = true;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Boolean checkContract = true;
		
		List<ProviderModelDTO> providerDtos = Arrays.asList(getProviderDTO(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, 
				Collections.emptyList()));
		
		Mockito.when(providerService.getProviderByProviderId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderGetResponse .builder().providerDTOs(providerDtos).totalCount("1").build());

		ResponseEntity<List<ProviderModelDTO>> actual = classUnderTest.getProvider(providerId, providerIndicator,
				providerMultiAddressKey, providerTaxId, npiId, checkContract, statusOrReasonCode, majorClassCode,
				provName, stateCode, includeCount, limit, offset);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(true);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdAndIndicatorShouldReturnResponseIncludeCountFalse200() {
		ProviderDemoModelDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoModelDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = "H";
		String providerMultiAddressKey = null;
		String providerTaxId = null;
		String npiId = null;
		Boolean includeCount = false;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Boolean checkContract = true;
		
		List<ProviderModelDTO> providerDtos = Arrays.asList(getProviderDTO(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, 
				Collections.emptyList()));
		
		Mockito.when(providerService.getProviderByProviderId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderGetResponse .builder().providerDTOs(providerDtos).build());

		ResponseEntity<List<ProviderModelDTO>> actual = classUnderTest.getProvider(providerId, providerIndicator,
				providerMultiAddressKey, providerTaxId, npiId, checkContract, statusOrReasonCode, majorClassCode,
				provName, stateCode, includeCount, limit, offset);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdAndIndicatorShouldReturnResponseIncludeCountWithNullValue200() {
		ProviderDemoModelDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoModelDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = "H";
		String providerMultiAddressKey = null;
		String providerTaxId = null;
		String npiId = null;
		Boolean includeCount = null;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Boolean checkContract = true;
		
		List<ProviderModelDTO> providerDtos = Arrays.asList(getProviderDTO(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, 
				Collections.emptyList()));
		
		Mockito.when(providerService.getProviderByProviderId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderGetResponse .builder().providerDTOs(providerDtos).build());

		ResponseEntity<List<ProviderModelDTO>> actual = classUnderTest.getProvider(providerId, providerIndicator,
				providerMultiAddressKey, providerTaxId, npiId, checkContract, statusOrReasonCode, majorClassCode,
				provName, stateCode, includeCount, limit, offset);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingNpiIdShouldReturnResponseIncludeCountFalse200() {
		ProviderDemoModelDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoModelDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String npiId = "999999999";
		String providerTaxId = null;
		Boolean includeCount = false;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Boolean checkContract = true;
		
		List<ProviderModelDTO> providerDtos = Arrays.asList(getProviderDTO(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, 
				Collections.emptyList()));
		
		Mockito.when(providerService.getProviderByProviderNpiId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderGetResponse .builder().providerDTOs(providerDtos).build());

		ResponseEntity<List<ProviderModelDTO>> actual = classUnderTest.getProvider(providerId, providerIndicator,
				providerMultiAddressKey, providerTaxId, npiId, checkContract, statusOrReasonCode, majorClassCode,
				provName, stateCode, includeCount, limit, offset);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingNpiIdShouldReturnResponseIncludeCountWithNullValue200() {
		ProviderDemoModelDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoModelDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String npiId = "999999999";
		String providerTaxId = null;
		Boolean includeCount = null;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Boolean checkContract = true;
		
		List<ProviderModelDTO> providerDtos = Arrays.asList(getProviderDTO(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, 
				Collections.emptyList()));
		
		Mockito.when(providerService.getProviderByProviderNpiId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderGetResponse .builder().providerDTOs(providerDtos).build());

		ResponseEntity<List<ProviderModelDTO>> actual = classUnderTest.getProvider(providerId, providerIndicator,
				providerMultiAddressKey, providerTaxId, npiId, checkContract, statusOrReasonCode, majorClassCode,
				provName, stateCode, includeCount, limit, offset);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingNpiIdShouldReturnResponseIncludeCountTrue200() {
		ProviderDemoModelDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoModelDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String npiId = "999999999";
		String providerTaxId = null;
		Boolean includeCount = true;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Boolean checkContract = true;
		
		List<ProviderModelDTO> providerDtos = Arrays.asList(getProviderDTO(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, 
				Collections.emptyList()));
		
		Mockito.when(providerService.getProviderByProviderNpiId(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderGetResponse .builder().providerDTOs(providerDtos).build());

		ResponseEntity<List<ProviderModelDTO>> actual = classUnderTest.getProvider(providerId, providerIndicator,
				providerMultiAddressKey, providerTaxId, npiId, checkContract, statusOrReasonCode, majorClassCode,
				provName, stateCode, includeCount, limit, offset);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(true);
	}
	
	@Test
	@SneakyThrows
	public void validCombinationHavingProvNameShouldReturnResponseIncludeCountWithNullValue200() {
		ProviderDemoModelDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoModelDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String npiId = null;
		String providerTaxId = null;
		Boolean includeCount = null;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Boolean checkContract = true;
		
		List<ProviderModelDTO> providerDtos = Arrays.asList(getProviderDTO(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, 
				Collections.emptyList()));
		
		Mockito.when(providerService.getProviderByProvName(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderGetResponse .builder().providerDTOs(providerDtos).build());

		ResponseEntity<List<ProviderModelDTO>> actual = classUnderTest.getProvider(providerId, providerIndicator,
				providerMultiAddressKey, providerTaxId, npiId, checkContract, statusOrReasonCode, majorClassCode,
				provName, stateCode, includeCount, limit, offset);
		
		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProvNameShouldReturnResponseIncludeCountTrue200() {
		ProviderDemoModelDTO providerDemoDTO = createProviderDemoDTO();
		List<ProviderDemoModelDTO> providerDemographicsDtos = new ArrayList<>();
		providerDemographicsDtos.add(providerDemoDTO);
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String npiId = null;
		String providerTaxId = null;
		Boolean includeCount = true;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = "NORTH HOSP";
		String stateCode = "A";
		Boolean checkContract = true;
		
		List<ProviderModelDTO> providerDtos = Arrays.asList(getProviderDTO(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, 
				Collections.emptyList()));
		
		Mockito.when(providerService.getProviderByProvName(any(ProviderDemoGetRequest.class)))
				.thenReturn(ProviderGetResponse .builder().providerDTOs(providerDtos).build());

		ResponseEntity<List<ProviderModelDTO>> actual = classUnderTest.getProvider(providerId, providerIndicator,
				providerMultiAddressKey, providerTaxId, npiId, checkContract, statusOrReasonCode, majorClassCode,
				provName, stateCode, includeCount, limit, offset);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderDemographicsConstants.TOTAL_DOCS)).isEqualTo(true);
	}

	@Test
	@SneakyThrows
	public void invalidCombinationHavingOnlyOptionalFiltersShouldReturnBadRequest() {
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = "H";
		String providerMultiAddressKey = "S";
		String npiId = null;
		String providerTaxId = null;
		Boolean includeCount = false;
		String majorClassCode = "A";
		String statusOrReasonCode = "AG";
		String provName = null;
		String stateCode = "A";
		Boolean checkContract = true;
		Throwable actualThrown = catchThrowable(() -> classUnderTest.getProvider(providerId, providerIndicator,
				providerMultiAddressKey, providerTaxId, npiId, checkContract, statusOrReasonCode, majorClassCode,
				provName, stateCode, includeCount, limit, offset));
		assertThat(actualThrown).isInstanceOf(InvalidHeaderCombinationException.class);
	}

	
	private ProviderKeyModelDTO createKey(String client, String prov, String pvdInd, String multAddressKey) {
		ProviderKeyModelDTO ProviderKeyDTO = new ProviderKeyModelDTO();
		ProviderKeyDTO.setClient(client);
		ProviderKeyDTO.setMultAddressKey(multAddressKey);
		ProviderKeyDTO.setProv(prov);
		ProviderKeyDTO.setPvdInd(pvdInd);
		return ProviderKeyDTO;
	}
	private ProviderDemoModelDTO createProviderDemoDTO() {
		ProviderDemoModelDTO providerDemoDTO = new ProviderDemoModelDTO();
		providerDemoDTO.setIrsNo("123456789");
		return providerDemoDTO;
	}
	
}
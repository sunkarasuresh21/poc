package com.humana.claims.hcaas.provider.restapi.mapper;

import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.*;
import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.createAttributes;
import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.createDemographics;
import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.createPostRequest;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.UpdateProviderModelDTO;
import com.humana.claims.hcaas.provider.restapi.model.datafeed.Prov1DataFeed;
import com.humana.claims.hcaas.provider.restapi.model.datafeed.Prov2DataFeed;
import com.humana.claims.hcaas.provider.restapi.model.datafeed.Prov3DataFeed;

@ExtendWith(MockitoExtension.class)
public class ProviderServiceDataMapperTest {

	@InjectMocks
	private ProviderServiceDataMapper classUnderTest;
	
	@Test
	public void test_classUnderTest_initialized() {
		assertNotNull(classUnderTest);
	}

	@Test
	public void testMapAttributesWithValidInput() {
		UpdateProviderModelDTO updateProviderDTO = createPostRequest();

		Attributes actual = classUnderTest.mapAttributes(updateProviderDTO);

		assertAttributesData(actual);
	}

	@Test
	public void testMapAttributesWithInvalidInput() {
		UpdateProviderModelDTO updateProviderDTO = createPostRequest();
		updateProviderDTO.getProviderAttribute().setAlphaKey(null);

		Attributes actual = classUnderTest.mapAttributes(updateProviderDTO);

		assertNotNull(actual);
		assertThat(actual.getAlphaKey()).isNull();
	}
	
	@Test
	public void testMapAttributesWithNullProviderAttributes() {
		
		UpdateProviderModelDTO updateProviderDTO = createPostRequest();
		updateProviderDTO.setProviderAttribute(null);

		Attributes actual = classUnderTest.mapAttributes(updateProviderDTO);

		assertThat(actual).isNull();
	}
	
	@Test
	public void testMapAttributesWithNullWithHoldData() {
		UpdateProviderModelDTO updateProviderDTO = createPostRequest();
		updateProviderDTO.getProviderAttribute().setWithholdData(null);
		
		Attributes actual = classUnderTest.mapAttributes(updateProviderDTO);
		
		assertThat(actual.getWithholdData().getPrTaxfreeAmt()).isNull();
	}
	//PxiZip
	@Test
	public void testMapAttributesWithPxiZip() {
		UpdateProviderModelDTO updateProviderDTO = createPostRequest();
		updateProviderDTO.getProviderAttribute().getPxiZip().get(0).setPxiZipCode("pxiZipCode");
		
		Attributes actual = classUnderTest.mapAttributes(updateProviderDTO);
		
		assertThat(actual.getPxiZip().get(0).getPxiZipCode()).isEqualTo("pxiZipCode");
	}
	
	@Test
	public void testMapAttributesWithNullWithLdCurrent() {
		UpdateProviderModelDTO updateProviderDTO = createPostRequest();
		updateProviderDTO.getProviderAttribute().getWithholdData().setWthldCurrent(null);
		
		Attributes actual = classUnderTest.mapAttributes(updateProviderDTO);
		
		assertThat(actual.getWithholdData().getWthldCurrent().getWthldEffDateCurrent()).isNull();
		assertThat(actual.getWithholdData().getWthldCurrent().getWthldPerCurrent()).isNull();
	}
	
	@Test
	public void testMapAttributesWithNullWithLdPrior() {
		UpdateProviderModelDTO updateProviderDTO = createPostRequest();
		updateProviderDTO.getProviderAttribute().getWithholdData().setWthldPrior(null);
		
		Attributes actual = classUnderTest.mapAttributes(updateProviderDTO);
		
		assertThat(actual.getWithholdData().getWthldPrior().getWthldEffDatePrior()).isNull();
		assertThat(actual.getWithholdData().getWthldPrior().getWthldPerPrior()).isNull();
	}
	
	@Test
	public void testMapDemographicsWithValidInput() {
		UpdateProviderModelDTO updateProviderDTO = createPostRequest();

		Demographics actual = classUnderTest.mapDemographics(updateProviderDTO);
		
		assertDemographicsData(actual);
	}
	
	@Test
	public void testMapProv1ForDataFeedOfDemographics() {
		
		Demographics demographics = createDemographics();

		Prov1DataFeed actual = classUnderTest.mapProv1ForDataFeed(null, demographics, REQUEST_ID, REQUEST_CLIENT);
		
		assertThat(actual.getPrvMaster().getPrvProviderInfo().getPrvCity()).isEqualTo(CITY_VALUE);
		assertThat(actual.getPrvMaster().getPrvProviderInfo().getPrvPhone()).isEqualTo(PHONE_VALUE);
		assertThat(actual.getRequestId()).isEqualTo("4567835");
		assertThat(actual.getRequestClient()).isEqualTo("98");
	}
	
	@Test
	public void testMapProv1ForDataFeedOfAttributes() {
		
		Attributes attributes = createAttributes();
		attributes.getKey().setClient("30");
		attributes.getKey().setMultAddressKey("");

		Prov1DataFeed actual = classUnderTest.mapProv1ForDataFeed(attributes, null, REQUEST_ID, REQUEST_CLIENT);
		
		assertThat(actual.getPrvMaster().getPrvProviderInfo().getPrvPendEsc()).isEqualTo(PENDESC_VALUE);
		assertThat(actual.getPrvMaster().getPrvProviderInfo().getPrvClmChkInd()).isEqualTo(CLMCHKIND_VALUE);
		assertThat(actual.getRequestId()).isEqualTo("4567835");
		assertThat(actual.getRequestClient()).isEqualTo("98");
	}
	
	@Test
	public void testMapProv1ForDataFeedOfAttributesWithNullKey() {
		Attributes attributes = createAttributes();
		attributes.setKey(null);

		Prov1DataFeed actual = classUnderTest.mapProv1ForDataFeed(attributes, null, REQUEST_ID, REQUEST_CLIENT);
		
		assertThat(actual.getPrvMaster().getPrvKey().getPrvClient()).isNull();
	}
	
	@Test
	public void testMapProv1ForDataFeedOfDemographicsWithNullKey() {
		Demographics demographics = createDemographics();
		demographics.setKey(null);

		Prov1DataFeed actual = classUnderTest.mapProv1ForDataFeed(null, demographics, REQUEST_ID, REQUEST_CLIENT);
		
		assertThat(actual.getPrvMaster().getPrvKey().getPrvClient()).isNull();
	}
	
	@Test
	public void testMapProv2ForDataFeedOfDemographics() {
		Demographics demographics = createDemographics();

		Prov2DataFeed actual = classUnderTest.mapProv2ForDataFeed(demographics, null, REQUEST_ID, REQUEST_CLIENT);
		
		assertThat(actual.getPrv2OutRecord().getPrv2Provider2Info().getPrv2Npi()).isEqualTo(NPIID_VALUE);
		assertThat(actual.getPrv2OutRecord().getPrv2Provider2Info().getPrv2TaxonomyCode()).isEqualTo(TAXONOMYCD_VALUE);
		assertThat(actual.getRequestId()).isEqualTo("4567835");
		assertThat(actual.getRequestClient()).isEqualTo("98");
	}
	
	@Test
	public void testMapProv2ForDataFeedOfAttributes() {
		
		Attributes attributes = createAttributes();
		attributes.getKey().setClient("30");
		attributes.getKey().setMultAddressKey("");

		Prov2DataFeed actual = classUnderTest.mapProv2ForDataFeed(null, attributes, REQUEST_ID, REQUEST_CLIENT);
		
		assertThat(actual.getPrv2OutRecord().getPrv2Provider2Info().getPrv2PxiZip1()).isEqualTo(PXIZIPCODE_VALUE);
		assertThat(actual.getRequestId()).isEqualTo("4567835");
		assertThat(actual.getRequestClient()).isEqualTo("98");
	}
	
	@Test
	public void testMapProv2ForDataFeedOfAttributesWithNullKey() {
		Attributes attributes = createAttributes();
		attributes.setKey(null);

		Prov2DataFeed actual = classUnderTest.mapProv2ForDataFeed(null, attributes, REQUEST_ID, REQUEST_CLIENT);
		
		assertThat(actual.getPrv2OutRecord().getPrv2Key().getPrv2Client()).isNull();
	}
	
	@Test
	public void testMapProv2ForDataFeedOfDemographicsWithNullKey() {
		Demographics demographics = createDemographics();
		demographics.setKey(null);

		Prov2DataFeed actual = classUnderTest.mapProv2ForDataFeed(demographics, null, REQUEST_ID, REQUEST_CLIENT);
		
		assertThat(actual.getPrv2OutRecord().getPrv2Key().getPrv2Client()).isNull();
	}
	
	@Test
	public void testMapProv3ForDataFeedOfAttributes() {
		Attributes attributes = createAttributes();

		Prov3DataFeed actual = classUnderTest.mapProv3ForDataFeed(attributes, REQUEST_ID, REQUEST_CLIENT);
		
		assertThat(actual.getPrv3OutRecord().getPrv3ProvWithholdData().getPrv3ProvPrTaxfreeAmt()).isEqualTo(PRTAXFREEAMT_VALUE);
		assertThat(actual.getRequestId()).isEqualTo("4567835");
		assertThat(actual.getRequestClient()).isEqualTo("98");
	}
	
	@Test
	public void testMapProv3ForDataFeedOfAttributesWithNullWithHoldData() {
		Attributes attributes = createAttributes();
		attributes.setWithholdData(null);

		Prov3DataFeed actual = classUnderTest.mapProv3ForDataFeed(attributes, REQUEST_ID, REQUEST_CLIENT);
		
		assertThat(actual.getPrv3OutRecord().getPrv3ProvWithholdData().getPrv3ProvPrTaxfreeAmt()).isNull();
		assertThat(actual.getPrv3OutRecord().getPrv3ProvWithholdData().getPrv3ProvWthldCurrent().getPrv3WthldEffDateC()).isNull();
		assertThat(actual.getPrv3OutRecord().getPrv3ProvWithholdData().getPrv3ProvWthldCurrent().getPrv3WthldPerC()).isNull();
		assertThat(actual.getPrv3OutRecord().getPrv3ProvWithholdData().getPrv3ProvWthldPrior().getPrv3WthldEffDateP()).isNull();
		assertThat(actual.getPrv3OutRecord().getPrv3ProvWithholdData().getPrv3ProvWthldPrior().getPrv3WthldPerP()).isNull();
	}
	
	@Test
	public void testMapProv3ForDataFeedOfAttributesWithNullKey() {
		Attributes attributes = createAttributes();
		attributes.setKey(null);

		Prov3DataFeed actual = classUnderTest.mapProv3ForDataFeed(attributes, REQUEST_ID, REQUEST_CLIENT);
		
		assertThat(actual.getPrv3OutRecord().getPrv3Key().getPrv3Client()).isNull();
	}
	
	@Test
	public void testMapDemographicsWithNullKeyValue() {
		UpdateProviderModelDTO updateProviderDTO = createPostRequest();
		updateProviderDTO.setProviderKey(null);
		
		Demographics actual = classUnderTest.mapDemographics(updateProviderDTO);
		
		assertThat(actual.getKey().getClient()).isNull();
		assertThat(actual.getKey().getMultAddressKey()).isNull();
		assertThat(actual.getKey().getProv()).isNull();
		assertThat(actual.getKey().getPvdInd()).isNull();
		
	}
	
	
	
	@Test
	public void testMapAttributesWithNullKeyValue() {
		UpdateProviderModelDTO updateProviderDTO = createPostRequest();
		updateProviderDTO.setProviderKey(null);
		
		Attributes actual = classUnderTest.mapAttributes(updateProviderDTO);
		
		assertThat(actual.getKey().getClient()).isNull();
		assertThat(actual.getKey().getMultAddressKey()).isNull();
		assertThat(actual.getKey().getProv()).isNull();
		assertThat(actual.getKey().getPvdInd()).isNull();
		
	}
	
	@Test
	public void testMapAttributesWithNullCasNameInProviderAttributes() {
		
		UpdateProviderModelDTO updateProviderDTO = createPostRequest();
		updateProviderDTO.getProviderAttribute().setCasName(null);

		Attributes actual = classUnderTest.mapAttributes(updateProviderDTO);

		assertThat(actual.getCasName().getFstName()).isNull();
		assertThat(actual.getCasName().getLastName()).isNull();
		
	}
	
	@Test
	public void testMapDemographicsWithNullProviderDemo() {
		
		UpdateProviderModelDTO updateProviderDTO = createPostRequest();
		updateProviderDTO.setProviderDemo(null);

		Demographics actual = classUnderTest.mapDemographics(updateProviderDTO);

		assertThat(actual).isNull();
	}
	
	@Test
	public void testMapDemographicsWithNullProviderInfo() {
		
		UpdateProviderModelDTO updateProviderDTO = createPostRequest();
		updateProviderDTO.getProviderDemo().setProviderInfo(null);

		Demographics actual = classUnderTest.mapDemographics(updateProviderDTO);

		assertThat(actual.getProviderInfo().getActive()).isEqualTo(null);
	}
	
	@Test
	public void testMapDemographicsWithNullSpecCodeInProviderInfo() {
		
		UpdateProviderModelDTO updateProviderDTO = createPostRequest();
		updateProviderDTO.getProviderDemo().getProviderInfo().getSpecCodes().get(0).setSpecCd("12345");

		Demographics actual = classUnderTest.mapDemographics(updateProviderDTO);

		assertThat(actual.getProviderInfo().getSpecCodes().get(0).getSpecCd()).isEqualTo("12345");
	}
	
	@Test
	public void testMapDemographicsWithInvalidInput() {
		UpdateProviderModelDTO updateProviderDTO = createPostRequest();
		updateProviderDTO.getProviderKey().setProv(null);

		Demographics actual = classUnderTest.mapDemographics(updateProviderDTO);
		
		assertNotNull(actual);
		assertThat(actual.getKey().getProv()).isNull();
	}
	
	@Test
	public void testMapProviderWithAllValidInput() {
		Demographics demographics = createDemographics();
		Attributes attributes = createAttributes();
		List<String> activeLobs = Arrays.asList("1*","2*","3*");

		ProviderModelDTO actual = classUnderTest.mapProviderDBObjToProviderDTO(demographics, attributes, activeLobs);
		
		assertNotNull(actual);
		assertKeyValues(actual);
		assertDemographicsData(demographics);
		assertAttributeData(actual);
		assertEquals(actual.getCfiExistForLineOfBusiness(), activeLobs);
		
	}
	
	@Test
	public void testMapProviderWithEmptyLobValues() {
		Demographics demographics = createDemographics();
		List<String> activeLobs = Collections.emptyList();
		
		ProviderModelDTO actual = classUnderTest.mapProviderDBObjToProviderDTO(demographics, new Attributes(), activeLobs);
		
		assertNotNull(actual);
		assertThat(actual.getCfiExistForLineOfBusiness()).isEmpty();
	}

	private void assertDemographicsData(Demographics demographics) {
		
		assertThat(demographics.getKey().getClient()).isEqualTo("30");
		assertThat(demographics.getKey().getPvdInd()).isEqualTo("H");
		assertThat(demographics.getKey().getProv()).isEqualTo("542");
		assertThat(demographics.getKey().getMultAddressKey()).isEqualTo("");
		assertThat(demographics.getTinEffDt()).isEqualTo(TINEFFDT_VALUE);
		assertThat(demographics.getIrsNo()).isEqualTo(IRSNO_VALUE);
		assertThat(demographics.getAlphaKey()).isEqualTo(ALPHAKEY_VALUE);
		assertThat(demographics.getUpdateSys()).isEqualTo(UPDATESYS_VALUE);
		assertThat(demographics.getProviderInfo().getProvName()).isEqualTo(PROVNAME_VALUE);
		assertThat(demographics.getProviderInfo().getAddress().getAddr1()).isEqualTo(ADDRESS1_VALUE);
		assertThat(demographics.getProviderInfo().getAddress().getAddr2()).isEqualTo(ADDRESS2_VALUE);
		assertThat(demographics.getProviderInfo().getAddress().getAddr3()).isEqualTo(ADDRESS3_VALUE);
		assertThat(demographics.getProviderInfo().getAddress().getAddr4()).isEqualTo(ADDRESS4_VALUE);
		assertThat(demographics.getProviderInfo().getCity()).isEqualTo(CITY_VALUE);
		assertThat(demographics.getProviderInfo().getSt()).isEqualTo(ST_VALUE);
		assertThat(demographics.getProviderInfo().getZip()).isEqualTo(ZIP_VALUE);
		assertThat(demographics.getProviderInfo().getProvType()).isEqualTo(PROVTYPE_VALUE);
		assertThat(demographics.getProviderInfo().getMajClsCd()).isEqualTo(MAJCLSCD_VALUE);
		assertThat(demographics.getProviderInfo().getGroupFlag()).isEqualTo(GROUPFLAG_VALUE);
		assertThat(demographics.getProviderInfo().getSpecCodes().get(0).getSpecCd()).isEqualTo(SPECCD_VALUE);
		assertThat(demographics.getProviderInfo().getPhone()).isEqualTo(PHONE_VALUE);
		assertThat(demographics.getProviderInfo().getAdjNo()).isEqualTo(ADJNO_VALUE);
		assertThat(demographics.getPvdStatus()).isEqualTo(PVDSTATUS_VALUE);
		assertThat(demographics.getProviderInfo().getPvdStRc()).isEqualTo(PVDSTRC_VALUE);
		assertThat(demographics.getProviderInfo().getActive()).isEqualTo(ACTIVE_VALUE);
		assertThat(demographics.getProviderInfo().getArchived()).isEqualTo(ARCHIVED_VALUE);
		assertThat(demographics.getProviderInfo().getPrvNoPay()).isEqualTo(NOPAYCODE_VALUE);
		assertThat(demographics.getProviderInfo().getPrvNoPayDt()).isEqualTo(NOPAYDT_VALUE);
		assertThat(demographics.getProviderInfo().getNpiIds().get(0).getNpiId()).isEqualTo(NPIID_VALUE);
		assertThat(demographics.getProviderInfo().getTaxonomyCodes().get(0).getTaxonomyCd()).isEqualTo(TAXONOMYCD_VALUE);
	}

	private void assertAttributesData(Attributes attributes) {
		
		assertThat(attributes.getKey().getClient()).isEqualTo("30");
		assertThat(attributes.getKey().getPvdInd()).isEqualTo("H");
		assertThat(attributes.getKey().getProv()).isEqualTo("542");
		assertThat(attributes.getKey().getMultAddressKey()).isEqualTo("");
		assertThat(attributes.getVch()).isEqualTo(VCH_VALUE);
		assertThat(attributes.getTaxType()).isEqualTo(TAXTYPE_VALUE);
		assertThat(attributes.getSend1099Ind()).isEqualTo(SEND1099IND_VALUE);
		assertThat(attributes.getPendEsc()).isEqualTo(PENDESC_VALUE);
		assertThat(attributes.getAutoCheckPullInd()).isEqualTo(AUTOCHECKPULLIND_VALUE);
		assertThat(attributes.getIrsWithholdInd()).isEqualTo(IRSWITHHOLDIND_VALUE);
		assertThat(attributes.getPayCycle()).isEqualTo(PAYCYCLE_VALUE);
		assertThat(attributes.getCrossRef()).isEqualTo(CROSSREF_VALUE);
		assertThat(attributes.getMarketId()).isEqualTo(MARKETID_VALUE);
		assertThat(attributes.getDg()).isEqualTo(DG_VALUE);
		assertThat(attributes.getAlphaKey()).isEqualTo(ALPHAKEY_VALUE);
		assertThat(attributes.getCasName().getFstName()).isEqualTo(CASFSTNAME_VALUE);
		assertThat(attributes.getCasName().getLastName()).isEqualTo(CASLASTNAME_VALUE);
		assertThat(attributes.getMedSuppWaiveInd()).isEqualTo(MEDSUPPWAIVEIND_VALUE);
		assertThat(attributes.getComment1()).isEqualTo(COMMENT1_VALUE);
		assertThat(attributes.getComment2()).isEqualTo(COMMENT2_VALUE);
		assertThat(attributes.getComment3()).isEqualTo(COMMENT3_VALUE);
		assertThat(attributes.getNotifyInd()).isEqualTo(NOTIFYIND_VALUE);
		assertThat(attributes.getFocusFromDate()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(attributes.getClpthInd()).isEqualTo(CLPTHIND_VALUE);
		assertThat(attributes.getClmChkInd()).isEqualTo(CLMCHKIND_VALUE);
		assertThat(attributes.getUcZip()).isEqualTo(UCZIP_VALUE);
		assertThat(attributes.getFocusToDate()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(attributes.getAutoLoadInd()).isEqualTo(AUTOLOADIND_VALUE);
		assertThat(attributes.getCheckTo()).isEqualTo(CHECKTO_VALUE);
		assertThat(attributes.getSuffixTo()).isEqualTo(SUFFIXTO_VALUE);
		assertThat(attributes.getApplyTaxInd()).isEqualTo(APPLYTAXIND_VALUE);
		assertThat(attributes.getW9Ind()).isEqualTo(W9IND_VALUE);
		assertThat(attributes.getSend480Ind()).isEqualTo(SEND480IND_VALUE);
		assertThat(attributes.getWithholdData().getWthldCurrent().getWthldPerCurrent()).isEqualTo(WTHLDPERCURRENT_VALUE);
		assertThat(attributes.getWithholdData().getWthldCurrent().getWthldEffDateCurrent()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(attributes.getWithholdData().getWthldPrior().getWthldPerPrior()).isEqualTo(WTHLDPERPRIOR_VALUE);
		assertThat(attributes.getWithholdData().getWthldPrior().getWthldEffDatePrior()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(attributes.getWithholdData().getPrTaxfreeAmt()).isEqualTo(PRTAXFREEAMT_VALUE);
		assertThat(attributes.getUpdtAdjNo()).isEqualTo(UPDTADJNO_VALUE);
		assertThat(attributes.getRadSiteCurrInd()).isEqualTo(RADSITECURRIND_VALUE);
		assertThat(attributes.getRadSiteCurrDt()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(attributes.getRadSiteP1Ind()).isEqualTo(RADSITEP1IND_VALUE);
		assertThat(attributes.getRadSiteP1Dt()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(attributes.getRadSiteP2Ind()).isEqualTo(RADSITEP2IND_VALUE);
		assertThat(attributes.getRadSiteP2Dt()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(attributes.getRadScopeCurrInd()).isEqualTo(RADSCOPECURRIND_VALUE);
		assertThat(attributes.getRadScopeCurrDt()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(attributes.getRadScopeP1Ind()).isEqualTo(RADSCOPEP1IND_VALUE);
		assertThat(attributes.getRadScopeP1Dt()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(attributes.getFacUcZip()).isEqualTo(FACUCZIP_VALUE);
		assertThat(attributes.getPxiUpdtAdjNo()).isEqualTo(PXIUPDTADJNO_VALUE);
		assertThat(attributes.getPxiUpdtDt()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(attributes.getSendLtrInd()).isEqualTo(SENDLTRIND_VALUE);
		assertThat(attributes.getFinalstInd()).isEqualTo(FINALSTIND_VALUE);
		assertThat(attributes.getPxiZip().get(0).getPxiZipCode()).isEqualTo(PXIZIPCODE_VALUE);
		assertThat(attributes.getPxiZip().get(0).getPxiZipInd()).isEqualTo(PXIZIPIND_VALUE);
		assertThat(attributes.getCompbidInd()).isEqualTo(COMPBIDIND_VALUE);
		assertThat(attributes.getVendorId()).isEqualTo(VENDORID_VALUE);
		assertThat(attributes.getCompbidEffDt()).isEqualTo(LocalDate.of(2019, 01, 01));
		assertThat(attributes.getCompbidTrmDt()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(attributes.getContractPointEnable().containsKey("1"));
		assertThat(attributes.getContractPointEnable().containsValue(true));
		assertThat(attributes.getContractPointEnable().containsKey("2"));
		assertThat(attributes.getContractPointEnable().containsValue(false));
	}
	
	private void assertAttributeData(ProviderModelDTO actual) {

		assertThat(actual.getIrsNo()).isEqualTo(IRSNO_VALUE);
		assertThat(actual.getVch()).isEqualTo(VCH_VALUE);
		assertThat(actual.getTaxType()).isEqualTo(TAXTYPE_VALUE);
		assertThat(actual.getSend1099Ind()).isEqualTo(SEND1099IND_VALUE);
		assertThat(actual.getPendEsc()).isEqualTo(PENDESC_VALUE);
		assertThat(actual.getAutoCheckPullInd()).isEqualTo(AUTOCHECKPULLIND_VALUE);
		assertThat(actual.getIrsWithholdInd()).isEqualTo(IRSWITHHOLDIND_VALUE);
		assertThat(actual.getPayCycle()).isEqualTo(PAYCYCLE_VALUE);
		assertThat(actual.getCrossRef()).isEqualTo(CROSSREF_VALUE);
		assertThat(actual.getMarketId()).isEqualTo(MARKETID_VALUE);
		assertThat(actual.getDg()).isEqualTo(DG_VALUE);
		assertThat(actual.getAlphaKey()).isEqualTo(ALPHAKEY_VALUE);
		assertThat(actual.getCasName().getCasFstName()).isEqualTo(CASFSTNAME_VALUE);
		assertThat(actual.getCasName().getCasLastName()).isEqualTo(CASLASTNAME_VALUE);
		assertThat(actual.getMedSuppWaiveInd()).isEqualTo(MEDSUPPWAIVEIND_VALUE);
		assertThat(actual.getComment1()).isEqualTo(COMMENT1_VALUE);
		assertThat(actual.getComment2()).isEqualTo(COMMENT2_VALUE);
		assertThat(actual.getComment3()).isEqualTo(COMMENT3_VALUE);
		assertThat(actual.getNotifyInd()).isEqualTo(NOTIFYIND_VALUE);
		assertThat(actual.getFocusFromDate()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(actual.getClpthInd()).isEqualTo(CLPTHIND_VALUE);
		assertThat(actual.getClmChkInd()).isEqualTo(CLMCHKIND_VALUE);
		assertThat(actual.getUcZip()).isEqualTo(UCZIP_VALUE);
		assertThat(actual.getFocusToDate()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(actual.getAutoLoadInd()).isEqualTo(AUTOLOADIND_VALUE);
		assertThat(actual.getCheckTo()).isEqualTo(CHECKTO_VALUE);
		assertThat(actual.getSuffixTo()).isEqualTo(SUFFIXTO_VALUE);
		assertThat(actual.getApplyTaxInd()).isEqualTo(APPLYTAXIND_VALUE);
		assertThat(actual.getW9Ind()).isEqualTo(W9IND_VALUE);
		assertThat(actual.getSend480Ind()).isEqualTo(SEND480IND_VALUE);
		assertThat(actual.getWithholdData().getWthldCurrent().getWthldPerCurrent()).isEqualTo(WTHLDPERCURRENT_VALUE);
		assertThat(actual.getWithholdData().getWthldCurrent().getWthldEffDateCurrent()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(actual.getWithholdData().getWthldPrior().getWthldPerPrior()).isEqualTo(WTHLDPERPRIOR_VALUE);
		assertThat(actual.getWithholdData().getWthldPrior().getWthldEffDatePrior()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(actual.getWithholdData().getPrTaxfreeAmt()).isEqualTo(PRTAXFREEAMT_VALUE);
		assertThat(actual.getUpdtAdjNo()).isEqualTo(UPDTADJNO_VALUE);
		assertThat(actual.getUpdtDt()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(actual.getRadSiteCurrInd()).isEqualTo(RADSITECURRIND_VALUE);
		assertThat(actual.getRadSiteCurrDt()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(actual.getRadSiteP1Ind()).isEqualTo(RADSITEP1IND_VALUE);
		assertThat(actual.getRadSiteP1Dt()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(actual.getRadSiteP2Ind()).isEqualTo(RADSITEP2IND_VALUE);
		assertThat(actual.getRadSiteP2Dt()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(actual.getRadScopeCurrInd()).isEqualTo(RADSCOPECURRIND_VALUE);
		assertThat(actual.getRadScopeCurrDt()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(actual.getRadScopeP1Ind()).isEqualTo(RADSCOPEP1IND_VALUE);
		assertThat(actual.getRadScopeP1Dt()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(actual.getFacUcZip()).isEqualTo(FACUCZIP_VALUE);
		assertThat(actual.getPxiUpdtAdjNo()).isEqualTo(PXIUPDTADJNO_VALUE);
		assertThat(actual.getPxiUpdtDt()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(actual.getSendLtrInd()).isEqualTo(SENDLTRIND_VALUE);
		assertThat(actual.getFinalstInd()).isEqualTo(FINALSTIND_VALUE);
		assertThat(actual.getPxiZip().get(0).getPxiZipCode()).isEqualTo(PXIZIPCODE_VALUE);
		assertThat(actual.getPxiZip().get(0).getPxiZipInd()).isEqualTo(PXIZIPIND_VALUE);
		assertThat(actual.getCompbidInd()).isEqualTo(COMPBIDIND_VALUE);
		assertThat(actual.getVendorId()).isEqualTo(VENDORID_VALUE);
		assertThat(actual.getCompbidEffDt()).isEqualTo(LocalDate.of(2019, 01, 01));
		assertThat(actual.getCompbidTrmDt()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(actual.getContractPointEnable().containsKey("1"));
		assertThat(actual.getContractPointEnable().containsValue(true));
		assertThat(actual.getContractPointEnable().containsKey("2"));
		assertThat(actual.getContractPointEnable().containsValue(false));
	}	
	
	private void assertKeyValues(ProviderModelDTO actual) {
		
		assertThat(actual.getKey().getClient()).isEqualTo("30");
		assertThat(actual.getKey().getPvdInd()).isEqualTo("H");
		assertThat(actual.getKey().getProv()).isEqualTo("542");
		assertThat(actual.getKey().getMultAddressKey()).isEqualTo("");
	}
}
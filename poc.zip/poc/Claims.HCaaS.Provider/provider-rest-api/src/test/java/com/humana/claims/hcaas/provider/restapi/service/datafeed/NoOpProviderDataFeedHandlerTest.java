package com.humana.claims.hcaas.provider.restapi.service.datafeed;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;

import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.restapi.service.datafeed.NoOpProviderDataFeedHandler;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import lombok.SneakyThrows;

public class NoOpProviderDataFeedHandlerTest {

	private NoOpProviderDataFeedHandler<Demographics> classUnderTest;
	private ListAppender<ILoggingEvent> logAppender;
	private Level originalLogLevel;
	
	@BeforeEach
	public void setup() {
		classUnderTest = new NoOpProviderDataFeedHandler<Demographics>();
		originalLogLevel = getTestLogger().getLevel();
		getTestLogger().setLevel(Level.ALL);
		logAppender = new ListAppender<>();
		getTestLogger().addAppender(logAppender);
		logAppender.start();
	}
	
	@AfterEach
	public void tearDown() {
		getTestLogger().detachAppender(logAppender);
		getTestLogger().setLevel(originalLogLevel);
	}

	private Logger getTestLogger() {
		return (Logger) LoggerFactory.getLogger(NoOpProviderDataFeedHandler.class);
	}
	
	@Test
	@SneakyThrows
	public void should_log_debug_message() {
		classUnderTest.sendToQueue(new Demographics());
		
		assertThat(logAppender.list).anySatisfy(l -> {
			assertThat(l.getMessage()).isEqualTo("No data changes added to queue, AMQP not enabled");
			assertThat(l.getLevel()).isEqualTo(Level.DEBUG);
		});
	}
}
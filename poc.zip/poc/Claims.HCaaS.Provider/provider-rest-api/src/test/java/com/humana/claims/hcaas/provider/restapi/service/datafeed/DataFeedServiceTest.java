package com.humana.claims.hcaas.provider.restapi.service.datafeed;

import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.CLPTHIND_VALUE;
import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.COMMENT2_VALUE;
import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.PRTAXFREEAMT_VALUE;
import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.REQUEST_CLIENT;
import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.REQUEST_ID;
import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.createAttributes;
import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.createDemographics;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.model.mq.Prv2Key;
import com.humana.claims.hcaas.provider.model.mq.Prv2OutRecord;
import com.humana.claims.hcaas.provider.model.mq.Prv2Provider2Info;
import com.humana.claims.hcaas.provider.model.mq.Prv3Key;
import com.humana.claims.hcaas.provider.model.mq.Prv3OutRecord;
import com.humana.claims.hcaas.provider.model.mq.Prv3ProvWithholdData;
import com.humana.claims.hcaas.provider.model.mq.Prv3ProvWthldCurrent;
import com.humana.claims.hcaas.provider.model.mq.Prv3ProvWthldPrior;
import com.humana.claims.hcaas.provider.model.mq.PrvKey;
import com.humana.claims.hcaas.provider.model.mq.PrvMaster;
import com.humana.claims.hcaas.provider.model.mq.PrvProviderInfo;
import com.humana.claims.hcaas.provider.restapi.exception.DataFeedException;
import com.humana.claims.hcaas.provider.restapi.mapper.ProviderServiceDataMapper;
import com.humana.claims.hcaas.provider.restapi.model.datafeed.Prov1DataFeed;
import com.humana.claims.hcaas.provider.restapi.model.datafeed.Prov2DataFeed;
import com.humana.claims.hcaas.provider.restapi.model.datafeed.Prov3DataFeed;
import com.humana.claims.hcaas.provider.restapi.service.datafeed.DataFeedService;
import com.humana.claims.hcaas.provider.restapi.service.datafeed.ProviderDataFeeder;

import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.*;

@ExtendWith(MockitoExtension.class)
public class DataFeedServiceTest {

	@InjectMocks
	private DataFeedService classUnderTest;
	
	@Mock
	private ProviderDataFeeder<Prov1DataFeed> prov1DataFeed;

	@Mock
	private ProviderDataFeeder<Prov2DataFeed> prov2DataFeed;

	@Mock
	private ProviderDataFeeder<Prov3DataFeed> prov3DataFeed;
	
	@Mock
	private ProviderServiceDataMapper providerServiceDataMapper;
	
	@Test
	public void testDataFeedServiceWhenProv1DataFeedInvoked() throws DataFeedException {
		Demographics demographics = createDemographics();
		Prov1DataFeed prov1DataFeedObj = createProv1DataFeed();
		doNothing().when(prov1DataFeed).sendToQueue(prov1DataFeedObj);
		Mockito.when(providerServiceDataMapper.mapProv1ForDataFeed(null, demographics, REQUEST_ID, REQUEST_CLIENT)).thenReturn(prov1DataFeedObj);

		classUnderTest.dataFeed(demographics, null, REQUEST_ID, REQUEST_CLIENT);

		Mockito.verify(providerServiceDataMapper, times(1)).mapProv1ForDataFeed(null, demographics, REQUEST_ID, REQUEST_CLIENT);
		Mockito.verify(prov1DataFeed, times(1)).sendToQueue(prov1DataFeedObj);
	}
	
	@Test
	public void testDataFeedServiceWhenProv1DataFeedInvokedWithAttributes() throws DataFeedException {
		Attributes attributes = createAttributes();
		Prov1DataFeed prov1DataFeedObj = createProv1DataFeed();
		doNothing().when(prov1DataFeed).sendToQueue(prov1DataFeedObj);
		Mockito.when(providerServiceDataMapper.mapProv1ForDataFeed(attributes, null, REQUEST_ID, REQUEST_CLIENT)).thenReturn(prov1DataFeedObj);

		classUnderTest.dataFeed(null, attributes, REQUEST_ID, REQUEST_CLIENT);

		Mockito.verify(providerServiceDataMapper, times(1)).mapProv1ForDataFeed(attributes, null, REQUEST_ID, REQUEST_CLIENT);
		Mockito.verify(prov1DataFeed, times(1)).sendToQueue(prov1DataFeedObj);
	}
	
	@Test
	public void testDataFeedServiceWhenProv1DataFeedNotInvoked() throws DataFeedException {
		Demographics demographics = createDemographics();
		Prov1DataFeed prov1DataFeedObj = null;
		Mockito.when(providerServiceDataMapper.mapProv1ForDataFeed(null, demographics, REQUEST_ID, REQUEST_CLIENT)).thenReturn(prov1DataFeedObj);

		classUnderTest.dataFeed(demographics, null, REQUEST_ID, REQUEST_CLIENT);

		Mockito.verify(providerServiceDataMapper, times(1)).mapProv1ForDataFeed(null, demographics, REQUEST_ID, REQUEST_CLIENT);
		Mockito.verify(prov1DataFeed, times(0)).sendToQueue(prov1DataFeedObj);
	}
	
	@Test
	public void testDataFeedServiceWhenProv2DataFeedInvoked() throws DataFeedException {
		Demographics demographics = createDemographics();
		Prov2DataFeed prov2DataFeedObj = createProv2DataFeed();
		doNothing().when(prov2DataFeed).sendToQueue(prov2DataFeedObj);
		Mockito.when(providerServiceDataMapper.mapProv2ForDataFeed(demographics, null, REQUEST_ID, REQUEST_CLIENT)).thenReturn(prov2DataFeedObj);

		classUnderTest.dataFeed(demographics, null, REQUEST_ID, REQUEST_CLIENT);

		Mockito.verify(providerServiceDataMapper, times(1)).mapProv2ForDataFeed(demographics, null, REQUEST_ID, REQUEST_CLIENT);
		Mockito.verify(prov2DataFeed, times(1)).sendToQueue(prov2DataFeedObj);
	}
	
	@Test
	public void testDataFeedServiceWhenProv2DataFeedInvokedForAttributes() throws DataFeedException {
		Attributes attributes = createAttributes();
		Prov2DataFeed prov2DataFeedObj = createProv2DataFeed();
		doNothing().when(prov2DataFeed).sendToQueue(prov2DataFeedObj);
		Mockito.when(providerServiceDataMapper.mapProv2ForDataFeed(null, attributes, REQUEST_ID, REQUEST_CLIENT)).thenReturn(prov2DataFeedObj);

		classUnderTest.dataFeed(null, attributes, REQUEST_ID, REQUEST_CLIENT);

		Mockito.verify(providerServiceDataMapper, times(1)).mapProv2ForDataFeed(null, attributes, REQUEST_ID, REQUEST_CLIENT);
		Mockito.verify(prov2DataFeed, times(1)).sendToQueue(prov2DataFeedObj);
	}

	@Test
	public void testDataFeedServiceWhenProv2DataFeedNotInvoked() throws DataFeedException {
		Demographics demographics = createDemographics();
		Prov2DataFeed prov2DataFeedObj = null;
		Mockito.when(providerServiceDataMapper.mapProv2ForDataFeed(demographics, null, REQUEST_ID, REQUEST_CLIENT)).thenReturn(prov2DataFeedObj);

		classUnderTest.dataFeed(demographics, null, REQUEST_ID, REQUEST_CLIENT);

		Mockito.verify(providerServiceDataMapper, times(1)).mapProv2ForDataFeed(demographics, null, REQUEST_ID, REQUEST_CLIENT);
		Mockito.verify(prov2DataFeed, times(0)).sendToQueue(prov2DataFeedObj);
	}
	
	@Test
	public void testDataFeedServiceWhenProv3DataFeedInvokedForAttributes() throws DataFeedException {
		Attributes attributes = createAttributes();
		Prov3DataFeed prov3DataFeedObj = createProv3DataFeed();
		doNothing().when(prov3DataFeed).sendToQueue(prov3DataFeedObj);
		Mockito.when(providerServiceDataMapper.mapProv3ForDataFeed(attributes, REQUEST_ID, REQUEST_CLIENT)).thenReturn(prov3DataFeedObj);

		classUnderTest.dataFeed(null, attributes, REQUEST_ID, REQUEST_CLIENT);

		Mockito.verify(providerServiceDataMapper, times(1)).mapProv3ForDataFeed(attributes, REQUEST_ID, REQUEST_CLIENT);
		Mockito.verify(prov3DataFeed, times(1)).sendToQueue(prov3DataFeedObj);
	}
	
	private Prov3DataFeed createProv3DataFeed() {
		Prov3DataFeed prov3DataFeed = new Prov3DataFeed();
		Prv3OutRecord prv3OutRecord = new Prv3OutRecord();
		Prv3ProvWthldPrior prv3ProvWthldPrior = new Prv3ProvWthldPrior();
		prv3ProvWthldPrior.setPrv3WthldPerP(PRV3_WTHLD_PER_P);
		Prv3ProvWthldCurrent prv3ProvWthldCurrent = new Prv3ProvWthldCurrent();
		prv3ProvWthldCurrent.setPrv3WthldPerC(PRV3_WTHLD_PER_C);
		Prv3ProvWithholdData prv3ProvWithholdData = new Prv3ProvWithholdData();
		prv3ProvWithholdData.setPrv3ProvPrTaxfreeAmt(PRTAXFREEAMT_VALUE);
		prv3ProvWithholdData.setPrv3ProvWthldCurrent(prv3ProvWthldCurrent);
		prv3ProvWithholdData.setPrv3ProvWthldPrior(prv3ProvWthldPrior);
		Prv3Key prv3Key = new Prv3Key();
		prv3Key.setPrv3Client(CLIENT_VALUE);
		prv3Key.setPrv3MultAddressKey(MULTADDRESSKEY_VALUE);
		prv3Key.setPrv3Prov(PROV_VALUE);
		prv3Key.setPrv3PvdInd(PVDIND_VALUE);
		prv3OutRecord.setPrv3Key(prv3Key);
		prv3OutRecord.setPrv3ProvWithholdData(prv3ProvWithholdData);
		prov3DataFeed.setRequestId(REQUEST_ID);
		prov3DataFeed.setRequestClient(REQUEST_CLIENT);
		prov3DataFeed.setPrv3OutRecord(prv3OutRecord);
		return prov3DataFeed;
	}

	private Prov2DataFeed createProv2DataFeed() {
		Prov2DataFeed prov2DataFeed = new Prov2DataFeed();
		prov2DataFeed.setRequestClient(REQUEST_ID);
		prov2DataFeed.setRequestClient(REQUEST_CLIENT);
		Prv2Key prv2Key = new Prv2Key();
		prv2Key.setPrv2Client(CLIENT_VALUE);
		prv2Key.setPrv2MultAddressKey(MULTADDRESSKEY_VALUE);
		prv2Key.setPrv2Prov(PROV_VALUE);
		prv2Key.setPrv2PvdInd(PVDIND_VALUE);
		Prv2Provider2Info prv2Provider2Info = new Prv2Provider2Info();
		prv2Provider2Info.setPrv2Npi(PRV2_NPI);
		prv2Provider2Info.setPrv2TaxonomyCode(PRV2_TAXONOMY_CODE);
		prv2Provider2Info.setPrv2Comment2(COMMENT2_VALUE);
		Prv2OutRecord prv2OutRecord = new Prv2OutRecord();
		prv2OutRecord.setPrv2Key(prv2Key);
		prv2OutRecord.setPrv2Provider2Info(prv2Provider2Info);
		return prov2DataFeed;
	}

	private Prov1DataFeed createProv1DataFeed() {

		Prov1DataFeed prov1DataFeed = new Prov1DataFeed();
		PrvMaster prvMaster = new PrvMaster();
		prvMaster.setPrvIrsNo(PRV_IRS_NO);
		PrvKey prvKey = new PrvKey();
		prvKey.setPrvClient(CLIENT_VALUE);
		prvKey.setPrvMultAddressKey(MULTADDRESSKEY_VALUE);
		prvKey.setPrvProv(PROV_VALUE);
		prvKey.setPrvPvdInd(PVDIND_VALUE);
		prvMaster.setPrvKey(prvKey);
		PrvProviderInfo prvProviderInfo = new PrvProviderInfo();
		prvProviderInfo.setPrvCity(PRV_CITY);
		prvProviderInfo.setPrvClpthInd(CLPTHIND_VALUE);
		prvMaster.setPrvProviderInfo(prvProviderInfo);
		prov1DataFeed.setRequestId(REQUEST_ID);
		prov1DataFeed.setRequestClient(REQUEST_CLIENT);
		prov1DataFeed.setPrvMaster(prvMaster);
		return prov1DataFeed;
	}
	
}

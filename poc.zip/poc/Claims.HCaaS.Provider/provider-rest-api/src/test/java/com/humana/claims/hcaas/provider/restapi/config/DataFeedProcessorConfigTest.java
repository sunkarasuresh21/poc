package com.humana.claims.hcaas.provider.restapi.config;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;

class DataFeedProcessorConfigTest {
	
	private final ApplicationContextRunner contextRunner = new ApplicationContextRunner().withUserConfiguration(
			DataFeedProcessorAmqpConfig.class, DataFeedProcessorNoOpConfig.class);
	
	@Test
	void testDataFeedProcessorAmqpConfigChangesIsAppliedCorrectly() {
	    contextRunner.withPropertyValues("datafeed.handler=amqp", "datafeed.amqp.uri=amqp://localhost:5672",
				"datafeed.queue.demographics.queueName=test", "datafeed.queue.demographics.amqp.userName=111",
				"datafeed.queue.demographics.password=222", "datafeed.queue.attributes.queueName=test",
				"datafeed.queue.attributes.userName=111", "datafeed.queue.attributes.password=222")
	            .run(context -> Assertions.assertAll(
	            	    () -> assertThat(context).hasSingleBean(DataFeedProcessorAmqpConfig.class),
	            	    () -> assertThat(context).doesNotHaveBean(DataFeedProcessorNoOpConfig.class)));
	}
	
	@Test
	void testDataFeedProcessorNoOpConfigChangesIsAppliedCorrectly() {
		contextRunner.withPropertyValues("datafeed.handler=noop")
		        .run(context -> Assertions.assertAll(
		        	    () -> assertThat(context).hasSingleBean(DataFeedProcessorNoOpConfig.class),
		        	    () -> assertThat(context).doesNotHaveBean(DataFeedProcessorAmqpConfig.class)));
	}
}
package com.humana.claims.hcaas.provider.restapi.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;

import com.humana.claims.hcaas.gen.openapi.invoker.ApiClient;
import com.humana.claims.hcaas.provider.contract.restclient.gen.openapi.ProviderContractApi;
import com.humana.claims.hcaas.provider.contract.restclient.gen.openapi.model.ContractSearchRequestDTO;
import com.humana.claims.hcaas.provider.contract.restclient.gen.openapi.model.ContractSearchResponseDTO;
import com.humana.claims.hcaas.provider.restapi.exception.ProviderContractDataRetrieveException;

@ExtendWith(MockitoExtension.class)
public class ProviderContractServiceTest {

	@InjectMocks
	ProviderContractServiceImpl classUnderTest;
	
	@Mock
	private ProviderContractApi  providerContractApi;
	

	@Test
	public void testGetActiveContractsReturnsListOfActiveContracts() {
		List<ContractSearchRequestDTO>  contractSearchRequestDTOs = getContractSerachRequest();
		List<ContractSearchResponseDTO>  contractSearchResponseDTOs = getContractSearchResponse();
		when(providerContractApi.getApiClient()).thenReturn(new ApiClient());
		when(providerContractApi.searchActiveContracts(contractSearchRequestDTOs)).thenReturn(getContractSearchResponse());
		List<ContractSearchResponseDTO>  contractSearchResponse = classUnderTest.getActiveContracts(contractSearchRequestDTOs);
		assertEquals(contractSearchResponseDTOs, contractSearchResponse);
	}
	
	@Test
	public void testGetActiveContractsReturnsEmptyList() {
		List<ContractSearchRequestDTO>  contractSearchRequestDTOs = getContractSerachRequest();
		when(providerContractApi.getApiClient()).thenReturn(new ApiClient());
		when(providerContractApi.searchActiveContracts(contractSearchRequestDTOs)).thenReturn(Collections.emptyList());
		List<ContractSearchResponseDTO>  contractSearchResponse = classUnderTest.getActiveContracts(contractSearchRequestDTOs);
		assertThat(contractSearchResponse).isEmpty();
	}
	
	@Test
	public void testGetActiveContractsBadrequestScenario() {
		List<ContractSearchRequestDTO>  contractSearchRequestDTOs = getContractSerachRequest();
		when(providerContractApi.getApiClient()).thenReturn(new ApiClient());
		when(providerContractApi.searchActiveContracts(contractSearchRequestDTOs)).thenThrow(new HttpClientErrorException(HttpStatus.BAD_REQUEST));
		assertThatExceptionOfType(ProviderContractDataRetrieveException.class).isThrownBy(() -> {
			classUnderTest.getActiveContracts(contractSearchRequestDTOs);
		});	
	}
	
	private List<ContractSearchRequestDTO> getContractSerachRequest() {
		List<ContractSearchRequestDTO> contractSearchRequestDTOList = new ArrayList<>();
		ContractSearchRequestDTO searchRequestDTO1 = new ContractSearchRequestDTO();
		searchRequestDTO1.setProvId("123456789");
		searchRequestDTO1.setProvSuffix("A");
		searchRequestDTO1.setProvInd("D");
		
		ContractSearchRequestDTO searchRequestDTO2 = new ContractSearchRequestDTO();
		searchRequestDTO2.setProvId("993456789");
		searchRequestDTO2.setProvSuffix("5");
		searchRequestDTO2.setProvInd("H");
		contractSearchRequestDTOList.add(searchRequestDTO1);
		contractSearchRequestDTOList.add(searchRequestDTO2);
		return contractSearchRequestDTOList;
	}
	
	private List<ContractSearchResponseDTO> getContractSearchResponse() {
		List<ContractSearchResponseDTO> contractSelectonResponseDTOList = new ArrayList<>();
		ContractSearchResponseDTO contractSearchResponseDTO1 = new ContractSearchResponseDTO();
		contractSearchResponseDTO1.setLobsWithActiveContract(Arrays.asList("1","24","3"));
		contractSearchResponseDTO1.setProvId("123456789");
		contractSearchResponseDTO1.setProvInd("D");
		contractSearchResponseDTO1.setProvSuffix("A");
		
		ContractSearchResponseDTO contractSearchResponseDTO2 = new ContractSearchResponseDTO();
		contractSearchResponseDTO2.setLobsWithActiveContract(Arrays.asList("5*","2","9*"));
		contractSearchResponseDTO2.setProvId("993456789");
		contractSearchResponseDTO2.setProvInd("H");
		contractSearchResponseDTO2.setProvSuffix("5");
		
		contractSelectonResponseDTOList.add(contractSearchResponseDTO1);
		contractSelectonResponseDTOList.add(contractSearchResponseDTO2);
		return contractSelectonResponseDTOList;
	}
	
} 

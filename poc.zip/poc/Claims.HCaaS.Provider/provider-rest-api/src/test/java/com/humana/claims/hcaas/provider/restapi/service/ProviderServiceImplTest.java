package com.humana.claims.hcaas.provider.restapi.service;

import static com.humana.claims.hcaas.provider.attributes.core.dao.ProviderAttributesMongoConstants.ATTRIBUTES_ALREADY_EXISTS;
import static com.humana.claims.hcaas.provider.attributes.core.dao.ProviderAttributesMongoConstants.CREATE_ATTRIBUTES_SUCCESS;
import static com.humana.claims.hcaas.provider.demographics.core.dao.ProviderDemographicsMongoConstants.CREATE_DEMOGRAPHICS_SUCCESS;
import static com.humana.claims.hcaas.provider.demographics.core.dao.ProviderDemographicsMongoConstants.DEMOGRAPHICS_ALREADY_EXISTS;
import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.createDemographics;
import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.createPostRequest;
import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.createUpdateProviderModelDTO;
import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.getAttributes;
import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.getContractSearchRequestDTO;
import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.getContractSearchResponseDTO;
import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.getDemographics;
import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.getProviderDTO;
import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.getProviderDemoProviderInfoNpiIdsDTO;
import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.getProviderInfoDTO;
import static com.humana.claims.hcaas.provider.restapi.util.ProviderTestData.getRequestKeyObj;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.humana.claims.hcaas.provider.attributes.core.dao.ProviderAttributesDAO;
import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.demographics.core.dao.ProviderDemographicsDAO;
import com.humana.claims.hcaas.provider.demographics.core.exception.InvalidRequestException;
import com.humana.claims.hcaas.provider.demographics.core.model.DemographicsDBResponse;
import com.humana.claims.hcaas.provider.demographics.core.model.ProviderDemoGetRequest;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.demographics.core.model.db.NpiInfos;
import com.humana.claims.hcaas.provider.demographics.core.model.db.ProviderInfo;
import com.humana.claims.hcaas.provider.demographics.core.validator.ProviderDemographicsValidator;
import com.humana.claims.hcaas.provider.restapi.constants.ProviderConstants;
import com.humana.claims.hcaas.provider.restapi.constants.ProviderErrorConstants;
import com.humana.claims.hcaas.provider.restapi.exception.ConflictException;
import com.humana.claims.hcaas.provider.restapi.exception.DataFeedException;
import com.humana.claims.hcaas.provider.restapi.exception.NotFoundException;
import com.humana.claims.hcaas.provider.restapi.exception.ProviderCreationException;
import com.humana.claims.hcaas.provider.restapi.exception.ProviderUpdateException;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.UpdateProviderModelDTO;
import com.humana.claims.hcaas.provider.restapi.mapper.ProviderServiceDataMapper;
import com.humana.claims.hcaas.provider.restapi.model.ProviderGetResponse;
import com.humana.claims.hcaas.provider.restapi.service.datafeed.DataFeedService;
import com.humana.claims.hcaas.provider.restapi.validator.ProviderValidator;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
public class ProviderServiceImplTest {

	@InjectMocks
	private ProviderServiceImpl classUnderTest;

	@Mock
	private ProviderDemographicsDAO providerDemographicsDAO;

	@Mock
	private ProviderAttributesDAO providerAttributesDAO;

	@Mock
	private ProviderValidator providerValidator;

	@Mock
	private ProviderDemographicsValidator providerDemographicsValidator;

	@Mock
	private ProviderServiceDataMapper providerDataMapper;
	
	@Mock
	private ProviderContractService providerContractService;
	
	@Mock
	private DataFeedService dataFeedService;
	
	private static final String REQUEST_ID = "123456";
	private static final String REQUEST_CLIENT = "98";

	@Test
	public void testUpdateProviderWhenDemographicsSuccessReturnsSuccess() throws IOException, InvalidRequestException,
			ProviderUpdateException, IllegalAccessException, NotFoundException, DataFeedException {
		Demographics demographics = new Demographics();
		doNothing().when(providerValidator).validateProviderInfoSentForUpdate(any(), any(), any(), any());
		Mockito.when(providerDataMapper.mapDemographics(any(UpdateProviderModelDTO.class))).thenReturn(demographics);
		Mockito.when(providerDemographicsDAO.updateProviderDemographics(any(), any(), any(), any()))
				.thenReturn(demographics);
		UpdateProviderModelDTO updateProviderDTO = createUpdateProviderModelDTO();

		String actual = classUnderTest.updateProvider(updateProviderDTO, "000000011", "2", "H",REQUEST_ID, REQUEST_CLIENT);

		assertThat(actual).isEqualTo(ProviderConstants.SUCCESS);
	}

	@Test
	public void testUpdateProviderWhenAttributesSuccessReturnsSuccess() throws IOException, InvalidRequestException,
			ProviderUpdateException, IllegalAccessException, NotFoundException, DataFeedException {
		Attributes attributes = new Attributes();
		doNothing().when(providerValidator).validateProviderInfoSentForUpdate(any(), any(), any(), any());
		Mockito.when(providerDataMapper.mapAttributes(any(UpdateProviderModelDTO.class))).thenReturn(attributes);
		Mockito.when(providerAttributesDAO.updateProviderAttributes(any(), any(), any(), any()))
				.thenReturn(attributes);
		UpdateProviderModelDTO updateProviderDTO = createUpdateProviderModelDTO();

		String actual = classUnderTest.updateProvider(updateProviderDTO, "000000011", "1", "H",REQUEST_ID, REQUEST_CLIENT);

		assertThat(actual).isEqualTo(ProviderConstants.SUCCESS);
	}

	@Test
	public void testUpdateProviderSuccessWhenDemographicsAndAttributesUpdatedSuccessfully() throws IOException,
			InvalidRequestException, ProviderUpdateException, IllegalAccessException, NotFoundException, DataFeedException {
		Demographics demographics = new Demographics();
		Attributes attributes = new Attributes();
		doNothing().when(providerValidator).validateProviderInfoSentForUpdate(any(), any(), any(), any());
		Mockito.when(providerDataMapper.mapDemographics(any(UpdateProviderModelDTO.class))).thenReturn(demographics);
		Mockito.when(providerDataMapper.mapAttributes(any(UpdateProviderModelDTO.class))).thenReturn(attributes);
		Mockito.when(providerDemographicsDAO.updateProviderDemographics(any(), any(), any(), any()))
				.thenReturn(demographics);
		Mockito.when(providerAttributesDAO.updateProviderAttributes(any(), any(), any(), any()))
				.thenReturn(attributes);
		UpdateProviderModelDTO updateProviderDTO = createUpdateProviderModelDTO();

		String actual = classUnderTest.updateProvider(updateProviderDTO, "000000011", "2", "H",REQUEST_ID, REQUEST_CLIENT);

		assertThat(actual).isEqualTo(ProviderConstants.SUCCESS);
	}

	@Test
	public void testUpdateProviderWhenDemographicsSuccessAndAttributesNotFoundReturnsNotFoundException()
			throws InvalidRequestException, IllegalAccessException {
		Demographics demographics = new Demographics();
		Attributes attributes = new Attributes();
		doNothing().when(providerValidator).validateProviderInfoSentForUpdate(any(), any(), any(), any());
		Mockito.when(providerDataMapper.mapDemographics(any(UpdateProviderModelDTO.class))).thenReturn(demographics);
		Mockito.when(providerDataMapper.mapAttributes(any(UpdateProviderModelDTO.class))).thenReturn(attributes);
		Mockito.when(providerDemographicsDAO.updateProviderDemographics(any(), any(), any(), any()))
				.thenReturn(demographics);
		Mockito.when(providerAttributesDAO.updateProviderAttributes(any(), any(), any(), any()))
				.thenReturn(null);
		UpdateProviderModelDTO updateProviderDTO = createUpdateProviderModelDTO();

		Throwable actualThrown = catchThrowable(
				() -> classUnderTest.updateProvider(updateProviderDTO, "000000011", "1", "H",REQUEST_ID, REQUEST_CLIENT));

		assertThat(actualThrown).isInstanceOf(NotFoundException.class);
	}

	@Test
	public void testUpdateProviderWhenDemographicsNotFoundReturnsNotFound() throws IOException, InvalidRequestException,
			ProviderUpdateException, IllegalAccessException, NotFoundException, DataFeedException {
		Demographics demographics = new Demographics();
		doNothing().when(providerValidator).validateProviderInfoSentForUpdate(any(), any(), any(), any());
		Mockito.when(providerDataMapper.mapDemographics(any(UpdateProviderModelDTO.class))).thenReturn(demographics);
		Mockito.when(providerDemographicsDAO.updateProviderDemographics(any(), any(), any(), any()))
				.thenReturn(null);
		UpdateProviderModelDTO updateProviderDTO = createUpdateProviderModelDTO();

		String actual = classUnderTest.updateProvider(updateProviderDTO, "000000011", "1", "H",REQUEST_ID, REQUEST_CLIENT);

		assertThat(actual).isEqualTo(ProviderErrorConstants.NOT_FOUND);
	}

	@Test
	public void testUpdateProviderWhenAttributesNotFoundReturnsNotFound() throws IOException, InvalidRequestException,
			ProviderUpdateException, IllegalAccessException, NotFoundException, DataFeedException {
		Attributes attributes = new Attributes();
		doNothing().when(providerValidator).validateProviderInfoSentForUpdate(any(), any(), any(), any());
		Mockito.when(providerDataMapper.mapAttributes(any(UpdateProviderModelDTO.class))).thenReturn(attributes);
		Mockito.when(providerAttributesDAO.updateProviderAttributes(any(), any(), any(), any()))
				.thenReturn(null);
		UpdateProviderModelDTO updateProviderDTO = createUpdateProviderModelDTO();

		String actual = classUnderTest.updateProvider(updateProviderDTO, "000000011", "2", "H",REQUEST_ID, REQUEST_CLIENT);

		assertThat(actual).isEqualTo(ProviderErrorConstants.NOT_FOUND);
	}

	@Test
	public void testUpdateProviderWhenDemographicsNotCalledAndAttributesUpdateFailedThrowsProviderUpdateException()
			throws IOException, InvalidRequestException, ProviderUpdateException, IllegalAccessException {
		doNothing().when(providerValidator).validateProviderInfoSentForUpdate(any(), any(), any(), any());
		Mockito.when(providerDataMapper.mapDemographics(any(UpdateProviderModelDTO.class))).thenReturn(null);
		Mockito.when(providerDataMapper.mapAttributes(any(UpdateProviderModelDTO.class))).thenReturn(null);
		UpdateProviderModelDTO updateProviderDTO = createUpdateProviderModelDTO();
		
		Throwable actualThrown = catchThrowable(
				() -> classUnderTest.updateProvider(updateProviderDTO, "000000011", "1", "H",REQUEST_ID, REQUEST_CLIENT));

		assertThat(actualThrown).isInstanceOf(ProviderUpdateException.class);
	}
	
	@Test
	@SneakyThrows
	public void testUpdateProviderWhenDemographicsUpdateSuccessThenDemographicDatafeedIsInvoked() {
		Demographics demographics = new Demographics();
		doNothing().when(providerValidator).validateProviderInfoSentForUpdate(any(), any(), any(), any());
		Mockito.when(providerDataMapper.mapDemographics(any(UpdateProviderModelDTO.class))).thenReturn(demographics);
		doNothing().when(dataFeedService).dataFeed(demographics, null, REQUEST_ID, REQUEST_CLIENT);
		Mockito.when(providerDemographicsDAO.updateProviderDemographics(any(), any(), any(), any()))
				.thenReturn(demographics);
		UpdateProviderModelDTO updateProviderDTO = createUpdateProviderModelDTO();

		classUnderTest.updateProvider(updateProviderDTO, "000000011", "2", "H",REQUEST_ID, REQUEST_CLIENT);

		Mockito.verify(dataFeedService, times(1)).dataFeed(demographics, null, REQUEST_ID, REQUEST_CLIENT);
	}
	
	@Test
	@SneakyThrows
	public void testUpdateProviderWhenAttributesUpdateSuccessThenAttributeDatafeedIsInvoked() {
		Attributes attributes = new Attributes();
		doNothing().when(providerValidator).validateProviderInfoSentForUpdate(any(), any(), any(), any());
		Mockito.when(providerDataMapper.mapAttributes(any(UpdateProviderModelDTO.class))).thenReturn(attributes);
		doNothing().when(dataFeedService).dataFeed(null, attributes, REQUEST_ID, REQUEST_CLIENT);
		Mockito.when(providerAttributesDAO.updateProviderAttributes(any(), any(), any(), any()))
				.thenReturn(attributes);
		UpdateProviderModelDTO updateProviderDTO = createUpdateProviderModelDTO();

		classUnderTest.updateProvider(updateProviderDTO, "000000011", "1", "H",REQUEST_ID, REQUEST_CLIENT);

		Mockito.verify(dataFeedService, times(1)).dataFeed(null, attributes, REQUEST_ID, REQUEST_CLIENT);
	}
	
	@Test
	@SneakyThrows
	public void testUpdateProviderWhenAttributesNotFoundThenAttributeDatafeedShouldNotInvoked() {
		Attributes attributes = new Attributes();
		doNothing().when(providerValidator).validateProviderInfoSentForUpdate(any(), any(), any(), any());
		Mockito.when(providerDataMapper.mapAttributes(any(UpdateProviderModelDTO.class))).thenReturn(attributes);
		Mockito.when(providerAttributesDAO.updateProviderAttributes(any(), any(), any(), any()))
				.thenReturn(null);
		UpdateProviderModelDTO updateProviderDTO = createUpdateProviderModelDTO();

		classUnderTest.updateProvider(updateProviderDTO, "000000011", "2", "H",REQUEST_ID, REQUEST_CLIENT);

		Mockito.verify(dataFeedService, times(0)).dataFeed(null, attributes, REQUEST_ID, REQUEST_CLIENT);
	}
	
	@Test
	@SneakyThrows
	public void testUpdateProviderWhenDemographicsNotFoundThenDemographicsDatafeedShouldNotInvoked() {
		Demographics demographics = new Demographics();
		doNothing().when(providerValidator).validateProviderInfoSentForUpdate(any(), any(), any(), any());
		Mockito.when(providerDataMapper.mapDemographics(any(UpdateProviderModelDTO.class))).thenReturn(demographics);
		Mockito.when(providerDemographicsDAO.updateProviderDemographics(any(), any(), any(), any()))
				.thenReturn(null);
		UpdateProviderModelDTO updateProviderDTO = createUpdateProviderModelDTO();

		classUnderTest.updateProvider(updateProviderDTO, "000000011", "2", "H",REQUEST_ID, REQUEST_CLIENT);

		Mockito.verify(dataFeedService, times(0)).dataFeed(demographics, null, REQUEST_ID, REQUEST_CLIENT);
	}

	@Test
	public void testCreateProviderWhenDemographicsRecordAlreadyExistsThrowsConflictException()
			throws ProviderCreationException, InvalidRequestException, ConflictException {
		Demographics demographics = createDemographics();
		List<Demographics> demographicsList = new ArrayList<>();
		demographicsList.add(demographics);
		Mockito.when(providerDemographicsDAO.getDemographicsByProviderId(anyMap(), any(Integer.class),
				any(Integer.class), any(Boolean.class)))
				.thenReturn(DemographicsDBResponse.builder().demographics(demographicsList).build());
		UpdateProviderModelDTO updateProviderDTO = createPostRequest();

		Throwable actualThrown = catchThrowable(() -> classUnderTest.createProvider(updateProviderDTO,REQUEST_ID, REQUEST_CLIENT));

		assertThat(actualThrown).isInstanceOf(ConflictException.class);
	}

	@Test
	public void testCreateProviderWhenDemographicsCreationFailedThrowsProviderCreationException()
			throws ProviderCreationException, InvalidRequestException, ConflictException {
		Mockito.when(providerDemographicsDAO.getDemographicsByProviderId(anyMap(), any(Integer.class),
				any(Integer.class), any(Boolean.class))).thenReturn(DemographicsDBResponse.builder().build());
		Demographics mockedDemographics = new Demographics();
		Mockito.when(providerDataMapper.mapDemographics(any(UpdateProviderModelDTO.class))).thenReturn(mockedDemographics);
		Mockito.when(providerDemographicsDAO.postProviderDemographics(any(Demographics.class)))
				.thenReturn(DEMOGRAPHICS_ALREADY_EXISTS);
		UpdateProviderModelDTO updateProviderDTO = createPostRequest();

		Throwable actualThrown = catchThrowable(() -> classUnderTest.createProvider(updateProviderDTO,REQUEST_ID, REQUEST_CLIENT));

		assertThat(actualThrown).isInstanceOf(ProviderCreationException.class);
	}

	@Test
	public void testCreateProviderWhenDemographicsCreatedButAttributesCreationFailedThrowsProviderCreationException()
			throws ProviderCreationException, InvalidRequestException, ConflictException {
		Mockito.when(providerDemographicsDAO.getDemographicsByProviderId(anyMap(), any(Integer.class),
				any(Integer.class), any(Boolean.class))).thenReturn(DemographicsDBResponse.builder().build());
		Demographics mockedDemographics = new Demographics();
		Attributes mockedAttributes = new Attributes();
		Mockito.when(providerDataMapper.mapDemographics(any(UpdateProviderModelDTO.class))).thenReturn(mockedDemographics);
		Mockito.when(providerDataMapper.mapAttributes(any(UpdateProviderModelDTO.class))).thenReturn(mockedAttributes);
		Mockito.when(providerDemographicsDAO.postProviderDemographics(any(Demographics.class)))
				.thenReturn(CREATE_DEMOGRAPHICS_SUCCESS);
		Mockito.when(providerAttributesDAO.postProviderAttributes(any(Attributes.class)))
				.thenReturn(ATTRIBUTES_ALREADY_EXISTS);
		UpdateProviderModelDTO updateProviderDTO = createPostRequest();

		Throwable actualThrown = catchThrowable(() -> classUnderTest.createProvider(updateProviderDTO,REQUEST_ID, REQUEST_CLIENT));

		assertThat(actualThrown).isInstanceOf(ProviderCreationException.class);
	}

	@Test
	public void testCreateProviderSuccessWhenDemographicsAndAttributesCreatedSuccessfully()
			throws ProviderCreationException, InvalidRequestException, ConflictException, DataFeedException {
		Mockito.when(providerDemographicsDAO.getDemographicsByProviderId(anyMap(), any(Integer.class),
				any(Integer.class), any(Boolean.class))).thenReturn(DemographicsDBResponse.builder().build());
		Demographics mockedDemographics = new Demographics();
		Attributes mockedAttributes = new Attributes();

		Mockito.when(providerDataMapper.mapDemographics(any(UpdateProviderModelDTO.class))).thenReturn(mockedDemographics);
		Mockito.when(providerDataMapper.mapAttributes(any(UpdateProviderModelDTO.class))).thenReturn(mockedAttributes);
		Mockito.when(providerDemographicsDAO.postProviderDemographics(any(Demographics.class)))
				.thenReturn(CREATE_DEMOGRAPHICS_SUCCESS);
		Mockito.when(providerAttributesDAO.postProviderAttributes(any(Attributes.class)))
				.thenReturn(CREATE_ATTRIBUTES_SUCCESS);
		UpdateProviderModelDTO updateProviderDTO = createPostRequest();

		boolean actual = classUnderTest.createProvider(updateProviderDTO,REQUEST_ID, REQUEST_CLIENT);

		assertTrue(actual);
	}
	
	@Test
	@SneakyThrows
	public void testCreateProviderWhenAttributesDemographicsCreateSuccessThenAttributesDemographicDatafeedIsInvoked() {
		Mockito.when(providerDemographicsDAO.getDemographicsByProviderId(anyMap(), any(Integer.class),
				any(Integer.class), any(Boolean.class))).thenReturn(DemographicsDBResponse.builder().build());
		Demographics demographics = new Demographics();
		Attributes attributes = new Attributes();

		Mockito.when(providerDataMapper.mapDemographics(any(UpdateProviderModelDTO.class))).thenReturn(demographics);
		Mockito.when(providerDataMapper.mapAttributes(any(UpdateProviderModelDTO.class))).thenReturn(attributes);
		doNothing().when(dataFeedService).dataFeed(demographics, null, REQUEST_ID, REQUEST_CLIENT);
		Mockito.when(providerDemographicsDAO.postProviderDemographics(any(Demographics.class)))
				.thenReturn(CREATE_DEMOGRAPHICS_SUCCESS);
		Mockito.when(providerAttributesDAO.postProviderAttributes(any(Attributes.class)))
				.thenReturn(CREATE_ATTRIBUTES_SUCCESS);
		UpdateProviderModelDTO updateProviderDTO = createPostRequest();

		classUnderTest.createProvider(updateProviderDTO,REQUEST_ID, REQUEST_CLIENT);

		Mockito.verify(dataFeedService, times(1)).dataFeed(demographics, null, REQUEST_ID, REQUEST_CLIENT);
	}

	@Test
	@SneakyThrows
	public void testNotFoundExceptionForGetProviderByProviderIdAndOptionalFields() {

		ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().providerId("999999999")
				.providerIndicator("H").providerMultiAddressKey(" ").majorClassCode("A").limit(1000).offset(1).build();

		Map<String, String> queryMap = new LinkedHashMap<String, String>();

		Mockito.when((providerDemographicsValidator.validateByProviderId(provDemoGetReq))).thenReturn(queryMap);
		Mockito.when((providerDemographicsDAO.getDemographicsByProviderId(queryMap, 1000, 1, false)))
				.thenReturn(DemographicsDBResponse.builder().build());

		Throwable actualThrown = catchThrowable(() -> classUnderTest.getProviderByProviderId(provDemoGetReq));

		assertThat(actualThrown).isInstanceOf(NotFoundException.class);
	}

	@Test
	@SneakyThrows
	public void testGetProviderByProviderIdAndOptionalFieldsSuccessScenario() {

		ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().providerId("999999999")
				.providerIndicator("H").providerMultiAddressKey(" ").majorClassCode("A").limit(1000).checkContract(true).offset(1).build();

		Map<String, String> queryMap = new LinkedHashMap<String, String>();
		List<String> lobs = Arrays.asList("1*", "2*", "3e");
		List<Demographics> demographicsList = Arrays.asList(getDemographics("123456789", "D", "5"));
		List<Attributes> attributesList = Arrays.asList(getAttributes("123456789", "D", "5"));
		
		Mockito.when(providerDemographicsValidator.validateByProviderId(provDemoGetReq)).thenReturn(queryMap);
		Mockito.when(providerDemographicsDAO.getDemographicsByProviderId(queryMap, 1000, 1, false))
				.thenReturn(DemographicsDBResponse.builder()
						.demographics(demographicsList).totalCount("1").build());
		Mockito.when(providerAttributesDAO.getAttributesByKey(Arrays.asList(getRequestKeyObj("123456789", "D", "5"))))
				.thenReturn(attributesList);
		Mockito.when(providerContractService
				.getActiveContracts(Arrays.asList(getContractSearchRequestDTO("123456789", "D", "5"))))
				.thenReturn(Arrays.asList(getContractSearchResponseDTO("123456789", "D", "5", lobs)));
		Mockito.when(providerDataMapper.mapProviderDBObjToProviderDTO(demographicsList.get(0), attributesList.get(0), lobs))
				.thenReturn(getProviderDTO("123456789", "D", "5", null,lobs));
		
		ProviderGetResponse providerGetResponse = classUnderTest.getProviderByProviderId(provDemoGetReq);

		assertThat(providerGetResponse.getProviderDTOs().size()).isEqualTo(1);
		assertThat(providerGetResponse.getProviderDTOs().get(0).getKey().getProv()).isEqualTo("123456789");
		assertThat(providerGetResponse.getProviderDTOs().get(0).getKey().getPvdInd()).isEqualTo("D");
		assertThat(providerGetResponse.getProviderDTOs().get(0).getKey().getMultAddressKey()).isEqualTo("5");
		assertThat(providerGetResponse.getProviderDTOs().get(0).getCfiExistForLineOfBusiness()).isEqualTo(lobs);
		assertThat(providerGetResponse.getTotalCount()).isEqualTo("1");
	}

	@Test
	@SneakyThrows
	public void testNotFoundExceptionForGetProviderByProviderTaxIdAndOptionalFields() {

		ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().providerTaxId("000000011").limit(1000)
				.offset(1).build();

		Map<String, String> queryMap = new LinkedHashMap<String, String>();

		Mockito.when((providerDemographicsValidator.validateByProviderTaxId(provDemoGetReq))).thenReturn(queryMap);
		Mockito.when((providerDemographicsDAO.getDemographicsByProviderTaxId(queryMap, 1000, 1, false)))
				.thenReturn(DemographicsDBResponse.builder().build());

		Throwable actualThrown = catchThrowable(() -> classUnderTest.getProviderByProviderTaxId(provDemoGetReq));

		assertThat(actualThrown).isInstanceOf(NotFoundException.class);
	}

	@Test
	@SneakyThrows
	public void testGetProviderByProviderTaxIdAndOptionalFieldsSuccessScenario() {

		ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().providerTaxId("000000011").limit(1000)
				.offset(1).build();

		Map<String, String> queryMap = new LinkedHashMap<String, String>();
		List<Demographics> demographicsList = Arrays.asList(getDemographics("123456789", "D", "5"));
		List<Attributes> attributesList = Arrays.asList(getAttributes("123456789", "D", "5"));
		Mockito.when((providerDemographicsValidator.validateByProviderTaxId(provDemoGetReq))).thenReturn(queryMap);
		
		Mockito.when((providerDemographicsDAO.getDemographicsByProviderTaxId(queryMap, 1000, 1, false))).thenReturn(
				DemographicsDBResponse.builder().demographics(demographicsList).totalCount("1").build());
		Mockito.when(providerAttributesDAO.getAttributesByKey(Arrays.asList(getRequestKeyObj("123456789", "D", "5"))))
				.thenReturn(attributesList);
		Mockito.when(providerDataMapper.mapProviderDBObjToProviderDTO(demographicsList.get(0), attributesList.get(0), Collections.emptyList()))
				.thenReturn( getProviderDTO("123456789", "D", "5", "000000011", Collections.emptyList()));
		
		ProviderGetResponse providerGetResponse = classUnderTest.getProviderByProviderTaxId(provDemoGetReq);

		assertThat(providerGetResponse.getProviderDTOs().size()).isEqualTo(1);
		assertThat(providerGetResponse.getProviderDTOs().get(0).getKey().getProv()).isEqualTo("123456789");
		assertThat(providerGetResponse.getProviderDTOs().get(0).getKey().getPvdInd()).isEqualTo("D");
		assertThat(providerGetResponse.getProviderDTOs().get(0).getKey().getMultAddressKey()).isEqualTo("5");
		assertThat(providerGetResponse.getProviderDTOs().get(0).getCfiExistForLineOfBusiness()).isEmpty();
		assertThat(providerGetResponse.getProviderDTOs().get(0).getIrsNo()).isEqualTo("000000011");
		assertThat(providerGetResponse.getTotalCount()).isEqualTo("1");
	}

	@Test
	@SneakyThrows
	public void testNotFoundExceptionForGetProviderByProviderNpiIdAndOptionalFields() {

		ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().npiId("0000000111").limit(1000)
				.offset(1).build();

		Map<String, String> queryMap = new LinkedHashMap<String, String>();

		Mockito.when((providerDemographicsValidator.validateByNpiId(provDemoGetReq))).thenReturn(queryMap);
		Mockito.when((providerDemographicsDAO.getDemographicsByNpiId(queryMap, 1000, 1, false)))
				.thenReturn(DemographicsDBResponse.builder().build());

		Throwable actualThrown = catchThrowable(() -> classUnderTest.getProviderByProviderNpiId(provDemoGetReq));

		assertThat(actualThrown).isInstanceOf(NotFoundException.class);
	}

	@Test
	@SneakyThrows
	public void testGetProviderByNpiIdAndOptionalFieldsSuccessScenario() {

		ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().npiId("0000000111").limit(1000)
				.offset(1).build();

		Map<String, String> queryMap = new LinkedHashMap<String, String>();
		Demographics demographics = getDemographics("123456789", "D", "5");
		ProviderInfo providerInfo = new ProviderInfo();
		NpiInfos npiInfos = new NpiInfos();
		npiInfos.setNpiId("1234567890");
		providerInfo.setNpiIds(Arrays.asList(npiInfos));
		demographics.setProviderInfo((providerInfo));
		
		List<Demographics> demographicsList = Arrays.asList(demographics);
		List<Attributes> attributesList = Arrays.asList(getAttributes("123456789", "D", "5"));
		ProviderModelDTO  providerDTO = getProviderDTO("123456789", "D", "5", null, Collections.emptyList());
		providerDTO.setProviderInfo(getProviderInfoDTO(getProviderDemoProviderInfoNpiIdsDTO("1234567890"),null));

		Mockito.when((providerDemographicsValidator.validateByNpiId(provDemoGetReq))).thenReturn(queryMap);
		Mockito.when((providerDemographicsDAO.getDemographicsByNpiId(queryMap, 1000, 1, false))).thenReturn(
				DemographicsDBResponse.builder().demographics(demographicsList).totalCount("1").build());
		Mockito.when(providerAttributesDAO.getAttributesByKey(Arrays.asList(getRequestKeyObj("123456789", "D", "5"))))
		.thenReturn(attributesList);
		Mockito.when(providerDataMapper.mapProviderDBObjToProviderDTO(demographicsList.get(0), attributesList.get(0), Collections.emptyList()))
		.thenReturn(providerDTO);
		
		ProviderGetResponse providerGetResponse = classUnderTest.getProviderByProviderNpiId(provDemoGetReq);

		assertThat(providerGetResponse.getProviderDTOs().size()).isEqualTo(1);
		assertThat(providerGetResponse.getProviderDTOs().get(0).getKey().getProv()).isEqualTo("123456789");
		assertThat(providerGetResponse.getProviderDTOs().get(0).getKey().getPvdInd()).isEqualTo("D");
		assertThat(providerGetResponse.getProviderDTOs().get(0).getKey().getMultAddressKey()).isEqualTo("5");
		assertThat(providerGetResponse.getProviderDTOs().get(0).getCfiExistForLineOfBusiness()).isEmpty();
		assertThat(providerGetResponse.getProviderDTOs().get(0).getProviderInfo().getNpiIds().get(0).getNpiId()).isEqualTo("1234567890");
		assertThat(providerGetResponse.getTotalCount()).isEqualTo("1");
	}

	@Test
	@SneakyThrows
	public void testNotFoundExceptionForGetProviderByProvNameAndOptionalFields() {

		ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().provName("NORTHERN HOSPITAL")
				.limit(1000).offset(1).build();

		Map<String, String> queryMap = new LinkedHashMap<String, String>();

		Mockito.when((providerDemographicsValidator.validateByProvName(provDemoGetReq))).thenReturn(queryMap);
		Mockito.when((providerDemographicsDAO.getDemographicsByProvName(queryMap, 1000, 1, false)))
				.thenReturn(DemographicsDBResponse.builder().build());

		Throwable actualThrown = catchThrowable(() -> classUnderTest.getProviderByProvName(provDemoGetReq));

		assertThat(actualThrown).isInstanceOf(NotFoundException.class);
	}

	@Test
	@SneakyThrows
	public void testGetProviderByProvNameAndOptionalFieldsSuccessScenario() {

		ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().provName("NORTHERN HOSPITAL")
				.limit(1000).offset(1).build();

		Map<String, String> queryMap = new LinkedHashMap<String, String>();
		Demographics demographics = getDemographics("123456789", "D", "5");
		ProviderInfo providerInfo = new ProviderInfo();
		providerInfo.setProvName("NORTHERN HOSPITAL");
		demographics.setProviderInfo((providerInfo));
		
		List<Demographics> demographicsList = Arrays.asList(demographics);
		List<Attributes> attributesList = Arrays.asList(getAttributes("123456789", "D", "5"));
		ProviderModelDTO  providerDTO = getProviderDTO("123456789", "D", "5", null, Collections.emptyList());
		providerDTO.setProviderInfo(getProviderInfoDTO(null,"NORTHERN HOSPITAL"));

		Mockito.when((providerDemographicsValidator.validateByProvName(provDemoGetReq))).thenReturn(queryMap);
		Mockito.when((providerDemographicsDAO.getDemographicsByProvName(queryMap, 1000, 1, false))).thenReturn(
				DemographicsDBResponse.builder().demographics(demographicsList).totalCount("1").build());
		Mockito.when(providerAttributesDAO.getAttributesByKey(Arrays.asList(getRequestKeyObj("123456789", "D", "5"))))
		.thenReturn(attributesList);
		Mockito.when(providerDataMapper.mapProviderDBObjToProviderDTO(demographicsList.get(0), attributesList.get(0), Collections.emptyList()))
		.thenReturn(providerDTO);
		
		ProviderGetResponse providerGetResponse = classUnderTest.getProviderByProvName(provDemoGetReq);

		assertThat(providerGetResponse.getProviderDTOs().size()).isEqualTo(1);
		assertThat(providerGetResponse.getProviderDTOs().get(0).getProviderInfo().getProvName()).isEqualTo("NORTHERN HOSPITAL");
		assertThat(providerGetResponse.getProviderDTOs().get(0).getKey().getProv()).isEqualTo("123456789");
		assertThat(providerGetResponse.getProviderDTOs().get(0).getKey().getPvdInd()).isEqualTo("D");
		assertThat(providerGetResponse.getProviderDTOs().get(0).getKey().getMultAddressKey()).isEqualTo("5");
		assertThat(providerGetResponse.getProviderDTOs().get(0).getCfiExistForLineOfBusiness()).isEmpty();
		assertThat(providerGetResponse.getTotalCount()).isEqualTo("1");
	}



}

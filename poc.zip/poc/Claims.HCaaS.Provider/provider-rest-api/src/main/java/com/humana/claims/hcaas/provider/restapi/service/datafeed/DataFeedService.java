package com.humana.claims.hcaas.provider.restapi.service.datafeed;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.restapi.exception.DataFeedException;
import com.humana.claims.hcaas.provider.restapi.mapper.ProviderServiceDataMapper;
import com.humana.claims.hcaas.provider.restapi.model.datafeed.Prov1DataFeed;
import com.humana.claims.hcaas.provider.restapi.model.datafeed.Prov2DataFeed;
import com.humana.claims.hcaas.provider.restapi.model.datafeed.Prov3DataFeed;

@Service
public class DataFeedService {

	@Qualifier("prov1DataFeedHandler")
	@Autowired
	private ProviderDataFeeder<Prov1DataFeed> prov1DataFeed;

	@Qualifier("prov2DataFeedHandler")
	@Autowired
	private ProviderDataFeeder<Prov2DataFeed> prov2DataFeed;

	@Qualifier("prov3DataFeedHandler")
	@Autowired
	private ProviderDataFeeder<Prov3DataFeed> prov3DataFeed;

	@Autowired
	private ProviderServiceDataMapper providerDataMapper;

	public void dataFeed(Demographics demographics, Attributes attributes, String requestId, String requestClient)
			throws DataFeedException {

		Prov1DataFeed prov1DataFeedObj = providerDataMapper.mapProv1ForDataFeed(attributes, demographics, requestId,
				requestClient);
		if (ObjectUtils.isNotEmpty(prov1DataFeedObj)) {
			prov1DataFeed.sendToQueue(prov1DataFeedObj);
		}

		Prov2DataFeed prov2DataFeedObj = providerDataMapper.mapProv2ForDataFeed(demographics, attributes, requestId,
				requestClient);
		if (ObjectUtils.isNotEmpty(prov2DataFeedObj)) {
			prov2DataFeed.sendToQueue(prov2DataFeedObj);
		}

		if (attributes != null) {
			Prov3DataFeed prov3DataFeedObj = providerDataMapper.mapProv3ForDataFeed(attributes, requestId,
					requestClient);
			if (ObjectUtils.isNotEmpty(prov3DataFeedObj)) {
				prov3DataFeed.sendToQueue(prov3DataFeedObj);
			}
		}
	}
}

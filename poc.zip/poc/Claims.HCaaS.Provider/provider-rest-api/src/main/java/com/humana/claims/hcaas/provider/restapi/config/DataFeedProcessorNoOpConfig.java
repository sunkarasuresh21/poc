package com.humana.claims.hcaas.provider.restapi.config;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.humana.claims.hcaas.provider.restapi.model.datafeed.Prov3DataFeed;
import com.humana.claims.hcaas.provider.restapi.service.datafeed.NoOpProviderDataFeedHandler;
import com.humana.claims.hcaas.provider.restapi.service.datafeed.ProviderDataFeeder;
import com.humana.claims.hcaas.provider.restapi.model.datafeed.Prov1DataFeed;
import com.humana.claims.hcaas.provider.restapi.model.datafeed.Prov2DataFeed;

@Configuration
@ConditionalOnProperty(name = "datafeed.handler", havingValue = "noop")
public class DataFeedProcessorNoOpConfig {

	@Bean
	public ProviderDataFeeder<Prov1DataFeed> prov1DataFeedHandler() {
		return new NoOpProviderDataFeedHandler<>();
	}

	@Bean
	public ProviderDataFeeder<Prov2DataFeed> prov2DataFeedHandler() {
		return new NoOpProviderDataFeedHandler<>();
	}
	
	@Bean
	public ProviderDataFeeder<Prov3DataFeed> prov3DataFeedHandler() {
		return new NoOpProviderDataFeedHandler<>();
	}
}
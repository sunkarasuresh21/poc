/*
* Copyright (C) Humana - All Rights Reserved
*
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential
*
* Written by Shridutt Kothari <skothari1@humana.com>, November 2021
*/
package com.humana.claims.hcaas.provider.restapi.controller;

import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.constraints.NotNull;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.humana.claims.hcaas.common.rest.api.starter.enumerrorcode.ErrorCode;
import com.humana.claims.hcaas.common.rest.api.starter.exceptionhandling.AbstractSpringControllerExceptionHandler;
import com.humana.claims.hcaas.common.rest.api.starter.exceptionhandling.ErrorResponseDTO;
import com.humana.claims.hcaas.provider.demographics.core.exception.InvalidHeaderCombinationException;
import com.humana.claims.hcaas.provider.demographics.core.exception.InvalidRequestException;
import com.humana.claims.hcaas.provider.restapi.exception.ConflictException;
import com.humana.claims.hcaas.provider.restapi.exception.NotFoundException;
import com.humana.claims.hcaas.provider.restapi.exception.ProviderCreationException;
import com.humana.claims.hcaas.provider.restapi.exception.ProviderUpdateException;

@ControllerAdvice
public class ProviderControllerExceptionHandler extends AbstractSpringControllerExceptionHandler {
	
	@ExceptionHandler(InvalidRequestException.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleInvalidRequestException(InvalidRequestException ex) {
		return respondWith(ex, HttpStatus.BAD_REQUEST, ex.getErrorMessages(), ErrorCode.BAD_REQUEST);
	}
	
	@ExceptionHandler(ConflictException.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleConflictException(ConflictException ex) {
		return respondWith(ex, HttpStatus.CONFLICT, ex.getErrorMessages(), ErrorCode.CONFLICT);
	}
	
	@ExceptionHandler(ProviderCreationException.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleProviderCreationException(ProviderCreationException ex) {
		return respondWith(ex, HttpStatus.INTERNAL_SERVER_ERROR, ErrorCode.INTERNAL_ERROR);
	}
	
	@ExceptionHandler(ProviderUpdateException.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleProviderUpdateException(ProviderUpdateException ex) {
		return respondWith(ex, HttpStatus.INTERNAL_SERVER_ERROR, ErrorCode.INTERNAL_ERROR);
	}
	
	@ExceptionHandler(NotFoundException.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleNotFoundException(NotFoundException ex) {
		return respondWith(ex, HttpStatus.BAD_REQUEST, ex.getErrorMessages(), ErrorCode.NOT_FOUND);
	}
	
	@ExceptionHandler(IllegalAccessException.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleIllegalAccessException(IllegalAccessException ex) {
		return respondWith(ex, HttpStatus.INTERNAL_SERVER_ERROR, ErrorCode.INTERNAL_ERROR);
	}
	
	@ExceptionHandler(InvalidHeaderCombinationException.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleInvalidHeaderCombinationException(InvalidHeaderCombinationException ex) {
		return respondWith(ex, HttpStatus.BAD_REQUEST, ex.getErrorMessages(), ErrorCode.BAD_REQUEST);
	}
	
	protected ResponseEntity<ErrorResponseDTO> respondWith(Exception e, @NotNull HttpStatus httpStatus,	Set<String> errorMessages, ErrorCode errorCode) {
		return super.respondWith(e, httpStatus, errorMessages.stream().collect(Collectors.toList()), errorCode);
	}	

}
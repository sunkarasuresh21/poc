package com.humana.claims.hcaas.provider.restapi.mapper;

import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.model.mq.Prv3Key;
import com.humana.claims.hcaas.provider.model.mq.Prv3ProvWithholdData;
import com.humana.claims.hcaas.provider.model.mq.Prv3ProvWthldCurrent;
import com.humana.claims.hcaas.provider.model.mq.Prv3ProvWthldPrior;

public class Prov3DataFeedMapperUtil {

	private Prov3DataFeedMapperUtil() {
		
	}
	
	static Prv3Key getPrv3Key(Attributes attributes) {
		Prv3Key prv3Key = new Prv3Key();
		prv3Key.setPrv3Client(null == attributes.getKey() ? null : attributes.getKey().getClient());
		prv3Key.setPrv3MultAddressKey(null == attributes.getKey() ? null : attributes.getKey().getMultAddressKey());
		prv3Key.setPrv3Prov(null == attributes.getKey() ? null : attributes.getKey().getProv());
		prv3Key.setPrv3PvdInd(null == attributes.getKey() ? null : attributes.getKey().getPvdInd());

		return prv3Key;
	}
	
	static Prv3ProvWithholdData getPrv3ProvWithholdData(Attributes attributes) {
		Prv3ProvWithholdData prv3ProvWithholdData = new Prv3ProvWithholdData();
		prv3ProvWithholdData.setPrv3ProvWthldCurrent(mapPrv3ProvWthldCurrent(attributes));
		prv3ProvWithholdData.setPrv3ProvWthldPrior(mapPrv3ProvWthldPrior(attributes));
		prv3ProvWithholdData.setPrv3ProvPrTaxfreeAmt(mapPrv3ProvPrTaxfreeAmt(attributes));

		return prv3ProvWithholdData;
	}
	
	private static String mapPrv3ProvPrTaxfreeAmt(Attributes attributes) {
		return (null == attributes.getWithholdData() ? null : attributes.getWithholdData().getPrTaxfreeAmt());
	}

	private static Prv3ProvWthldCurrent mapPrv3ProvWthldCurrent(Attributes attributes) {
		Prv3ProvWthldCurrent prv3ProvWthldCurrent = new Prv3ProvWthldCurrent();
		prv3ProvWthldCurrent.setPrv3WthldPerC(mapPrv3WthldPerC(attributes));
		prv3ProvWthldCurrent.setPrv3WthldEffDateC(mapPrv3WthldEffDateC(attributes));

		return prv3ProvWthldCurrent;
	}
	
	private static String mapPrv3WthldPerC(Attributes attributes) {
		return (null == attributes.getWithholdData() ? null : mapWthldPerCurrent(attributes));
	}

	private static String mapWthldPerCurrent(Attributes attributes) {
		return (null == attributes.getWithholdData().getWthldCurrent() ? null
				: attributes.getWithholdData().getWthldCurrent().getWthldPerCurrent());
	}

	private static String mapPrv3WthldEffDateC(Attributes attributes) {
		return (null == attributes.getWithholdData() ? null : mapWthldEffDateCurrent(attributes));
	}

	private static String mapWthldEffDateCurrent(Attributes attributes) {
		return (null == attributes.getWithholdData().getWthldCurrent().getWthldEffDateCurrent() ? null
				: attributes.getWithholdData().getWthldCurrent().getWthldEffDateCurrent().toString());
	}

	private static Prv3ProvWthldPrior mapPrv3ProvWthldPrior(Attributes attributes) {
		Prv3ProvWthldPrior prv3ProvWthldPrior = new Prv3ProvWthldPrior();
		prv3ProvWthldPrior.setPrv3WthldPerP(mapWthldPrv3WthldPerP(attributes));
		prv3ProvWthldPrior.setPrv3WthldEffDateP(mapPrv3WthldEffDateP(attributes));

		return prv3ProvWthldPrior;
	}

	private static String mapWthldPrv3WthldPerP(Attributes attributes) {
		return (null == attributes.getWithholdData() ? null : mapWthldPerPrior(attributes));
	}

	private static String mapWthldPerPrior(Attributes attributes) {
		return (null == attributes.getWithholdData().getWthldPrior() ? null
				: attributes.getWithholdData().getWthldPrior().getWthldPerPrior());
	}

	private static String mapPrv3WthldEffDateP(Attributes attributes) {
		return (null == attributes.getWithholdData() ? null : mapWthldEffDatePrior(attributes));
	}

	private static String mapWthldEffDatePrior(Attributes attributes) {
		return (null == attributes.getWithholdData().getWthldPrior().getWthldEffDatePrior() ? null
				: attributes.getWithholdData().getWthldPrior().getWthldEffDatePrior().toString());
	}
}
package com.humana.claims.hcaas.provider.restapi.exception;

public class DataFeedException extends Exception {

	private static final long serialVersionUID = 4162571735654219142L;

	public DataFeedException(Throwable cause) {
		super("Data Feed Failed", cause);
	}
}
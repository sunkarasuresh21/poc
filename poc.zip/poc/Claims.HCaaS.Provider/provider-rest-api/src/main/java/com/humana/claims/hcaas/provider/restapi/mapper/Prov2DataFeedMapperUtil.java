package com.humana.claims.hcaas.provider.restapi.mapper;

import java.util.List;

import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.attributes.core.model.db.PxiZip;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.demographics.core.model.db.NpiInfos;
import com.humana.claims.hcaas.provider.demographics.core.model.db.TaxonomyCode;
import com.humana.claims.hcaas.provider.model.mq.Prv2Key;
import com.humana.claims.hcaas.provider.model.mq.Prv2Provider2Info;
import com.humana.claims.hcaas.provider.model.mq.Prv2PxiPtsLobArea;
import static  com.humana.claims.hcaas.provider.restapi.constants.ProviderConstants.*;

public class Prov2DataFeedMapperUtil {

	private Prov2DataFeedMapperUtil() {
		
	}
	
	static Prv2Key getPrv2Key(Demographics demographics) {
		Prv2Key prv2Key = new Prv2Key();
		prv2Key.setPrv2Client(null == demographics.getKey() ? null : demographics.getKey().getClient());
		prv2Key.setPrv2MultAddressKey(null == demographics.getKey() ? null : demographics.getKey().getMultAddressKey());
		prv2Key.setPrv2Prov(null == demographics.getKey() ? null : demographics.getKey().getProv());
		prv2Key.setPrv2PvdInd(null == demographics.getKey() ? null : demographics.getKey().getPvdInd());

		return prv2Key;
	}

	static Prv2Provider2Info getPrv2Provider2InfoOfAttributes(Attributes attributes) {
		Prv2Provider2Info prv2Provider2Info = new Prv2Provider2Info();
		prv2Provider2Info.setPrv2ApplyTaxInd(attributes.getApplyTaxInd());
		prv2Provider2Info.setPrv2W9Ind(attributes.getW9Ind());
		prv2Provider2Info.setPrv2Send480Ind(attributes.getSend480Ind());
		prv2Provider2Info.setPrv2Comment2(attributes.getComment2());
		prv2Provider2Info.setPrv2Comment3(attributes.getComment3());
		prv2Provider2Info.setPrv2VendorId(attributes.getVendorId());
		prv2Provider2Info.setPrv2UpdtAdjNo(attributes.getUpdtAdjNo());
		prv2Provider2Info.setPrv2UpdtDt(null == attributes.getUpdtDt() ? null : attributes.getUpdtDt().toString());
		prv2Provider2Info.setPrv2RadSiteCurrInd(attributes.getRadSiteCurrInd());
		prv2Provider2Info.setPrv2RadSiteCurrDt(
				null == attributes.getRadSiteCurrDt() ? null : attributes.getRadSiteCurrDt().toString());
		prv2Provider2Info.setPrv2RadSiteP1Ind(attributes.getRadSiteP1Ind());
		prv2Provider2Info.setPrv2RadSiteP1Dt(
				null == attributes.getRadSiteP1Dt() ? null : attributes.getRadSiteP1Dt().toString());
		prv2Provider2Info.setPrv2RadSiteP2Ind(attributes.getRadSiteP2Ind());
		prv2Provider2Info.setPrv2RadSiteP2Dt(
				null == attributes.getRadSiteP1Dt() ? null : attributes.getRadSiteP2Dt().toString());
		prv2Provider2Info.setPrv2RadScopeCurrDt(
				null == attributes.getRadScopeCurrDt() ? null : attributes.getRadScopeCurrDt().toString());
		prv2Provider2Info.setPrv2RadScopeCurrInd(attributes.getRadScopeCurrInd());
		prv2Provider2Info.setPrv2RadScopeP1Ind(attributes.getRadScopeP1Ind());
		prv2Provider2Info.setPrv2RadScopeP1Dt(
				null == attributes.getRadScopeP1Dt() ? null : attributes.getRadScopeP1Dt().toString());
		prv2Provider2Info.setPrv2FacUcZip(attributes.getFacUcZip());
		prv2Provider2Info.setPrv2PxiUpdtAdjNo(attributes.getPxiUpdtAdjNo());
		prv2Provider2Info.setPrv2UpdtDt(null == attributes.getUpdtDt() ? null : attributes.getUpdtDt().toString());
		prv2Provider2Info.setPrv2ClmChkInd(attributes.getClmChkInd());
		prv2Provider2Info.setPrv2SendLtrInd(attributes.getSendLtrInd());
		prv2Provider2Info.setPrv2FinalstInd(attributes.getFinalstInd());
		prv2Provider2Info.setPrv2CompbidInd(attributes.getCompbidInd());
		prv2Provider2Info.setPrv2CompbidEffDt(
				null == attributes.getCompbidEffDt() ? null : attributes.getCompbidEffDt().toString());
		prv2Provider2Info.setPrv2CompbidTrmDt(
				null == attributes.getCompbidTrmDt() ? null : attributes.getCompbidTrmDt().toString());
		prv2Provider2Info.setPrv2PxiPtsLobArea(getPrv2PxiPtsLobArea(attributes));
		mapPxiZip(prv2Provider2Info, attributes.getPxiZip());
		mapPxiZipInd(prv2Provider2Info, attributes.getPxiZip());

		return prv2Provider2Info;
	}

	private static Prv2Provider2Info mapPxiZipInd(Prv2Provider2Info prv2Provider2Info, List<PxiZip> pxiZip) {
		
		if (null != pxiZip) {
			prv2Provider2Info.setPrv2PxiZipInd1(mapPxiZipInd(pxiZip.size(), LIST_VALUE_1, pxiZip));
			prv2Provider2Info.setPrv2PxiZipInd2(mapPxiZipInd(pxiZip.size(), LIST_VALUE_2, pxiZip));
			prv2Provider2Info.setPrv2PxiZipInd3(mapPxiZipInd(pxiZip.size(), LIST_VALUE_3, pxiZip));
			prv2Provider2Info.setPrv2PxiZipInd4(mapPxiZipInd(pxiZip.size(), LIST_VALUE_4, pxiZip));
			prv2Provider2Info.setPrv2PxiZipInd5(mapPxiZipInd(pxiZip.size(), LIST_VALUE_5, pxiZip));
			prv2Provider2Info.setPrv2PxiZipInd6(mapPxiZipInd(pxiZip.size(), LIST_VALUE_6, pxiZip));
			prv2Provider2Info.setPrv2PxiZipInd7(mapPxiZipInd(pxiZip.size(), LIST_VALUE_7, pxiZip));
			prv2Provider2Info.setPrv2PxiZipInd8(mapPxiZipInd(pxiZip.size(), LIST_VALUE_8, pxiZip));
			prv2Provider2Info.setPrv2PxiZipInd9(mapPxiZipInd(pxiZip.size(), LIST_VALUE_9, pxiZip));
			prv2Provider2Info.setPrv2PxiZipInd10(mapPxiZipInd(pxiZip.size(), LIST_VALUE_10, pxiZip));
			prv2Provider2Info.setPrv2PxiZipInd11(mapPxiZipInd(pxiZip.size(), LIST_VALUE_11, pxiZip));
			prv2Provider2Info.setPrv2PxiZipInd12(mapPxiZipInd(pxiZip.size(), LIST_VALUE_12, pxiZip));
			prv2Provider2Info.setPrv2PxiZipInd13(mapPxiZipInd(pxiZip.size(), LIST_VALUE_13, pxiZip));
			prv2Provider2Info.setPrv2PxiZipInd14(mapPxiZipInd(pxiZip.size(), LIST_VALUE_14, pxiZip));
			prv2Provider2Info.setPrv2PxiZipInd15(mapPxiZipInd(pxiZip.size(), LIST_VALUE_15, pxiZip));
			prv2Provider2Info.setPrv2PxiZipInd16(mapPxiZipInd(pxiZip.size(), LIST_VALUE_16, pxiZip));
			prv2Provider2Info.setPrv2PxiZipInd17(mapPxiZipInd(pxiZip.size(), LIST_VALUE_17, pxiZip));
			prv2Provider2Info.setPrv2PxiZipInd18(mapPxiZipInd(pxiZip.size(), LIST_VALUE_18, pxiZip));
			prv2Provider2Info.setPrv2PxiZipInd19(mapPxiZipInd(pxiZip.size(), LIST_VALUE_19, pxiZip));
			prv2Provider2Info.setPrv2PxiZipInd20(mapPxiZipInd(pxiZip.size(), LIST_VALUE_20, pxiZip));
		}
		return prv2Provider2Info;
	}
	
	private static String mapPxiZipInd(int size, int num, List<PxiZip> pxiZip) {
		return size < num ? null : pxiZip.get(num - 1).getPxiZipInd();
	}


	private static Prv2Provider2Info mapPxiZip(Prv2Provider2Info prv2Provider2Info, List<PxiZip> pxiZip) {
		if (null != pxiZip) {
			prv2Provider2Info.setPrv2PxiZip1(mapPxiZipCode(pxiZip.size(), LIST_VALUE_1, pxiZip));
			prv2Provider2Info.setPrv2PxiZip2(mapPxiZipCode(pxiZip.size(), LIST_VALUE_2, pxiZip));
			prv2Provider2Info.setPrv2PxiZip3(mapPxiZipCode(pxiZip.size(), LIST_VALUE_3, pxiZip));
			prv2Provider2Info.setPrv2PxiZip4(mapPxiZipCode(pxiZip.size(), LIST_VALUE_4, pxiZip));
			prv2Provider2Info.setPrv2PxiZip5(mapPxiZipCode(pxiZip.size(), LIST_VALUE_5, pxiZip));
			prv2Provider2Info.setPrv2PxiZip6(mapPxiZipCode(pxiZip.size(), LIST_VALUE_6, pxiZip));
			prv2Provider2Info.setPrv2PxiZip7(mapPxiZipCode(pxiZip.size(), LIST_VALUE_7, pxiZip));
			prv2Provider2Info.setPrv2PxiZip8(mapPxiZipCode(pxiZip.size(), LIST_VALUE_8, pxiZip));
			prv2Provider2Info.setPrv2PxiZip9(mapPxiZipCode(pxiZip.size(), LIST_VALUE_9, pxiZip));
			prv2Provider2Info.setPrv2PxiZip10(mapPxiZipCode(pxiZip.size(), LIST_VALUE_10, pxiZip));
			prv2Provider2Info.setPrv2PxiZip11(mapPxiZipCode(pxiZip.size(), LIST_VALUE_11, pxiZip));
			prv2Provider2Info.setPrv2PxiZip12(mapPxiZipCode(pxiZip.size(), LIST_VALUE_12, pxiZip));
			prv2Provider2Info.setPrv2PxiZip13(mapPxiZipCode(pxiZip.size(), LIST_VALUE_13, pxiZip));
			prv2Provider2Info.setPrv2PxiZip14(mapPxiZipCode(pxiZip.size(), LIST_VALUE_14, pxiZip));
			prv2Provider2Info.setPrv2PxiZip15(mapPxiZipCode(pxiZip.size(), LIST_VALUE_15, pxiZip));
			prv2Provider2Info.setPrv2PxiZip16(mapPxiZipCode(pxiZip.size(), LIST_VALUE_16, pxiZip));
			prv2Provider2Info.setPrv2PxiZip17(mapPxiZipCode(pxiZip.size(), LIST_VALUE_17, pxiZip));
			prv2Provider2Info.setPrv2PxiZip18(mapPxiZipCode(pxiZip.size(), LIST_VALUE_18, pxiZip));
			prv2Provider2Info.setPrv2PxiZip19(mapPxiZipCode(pxiZip.size(), LIST_VALUE_19, pxiZip));
			prv2Provider2Info.setPrv2PxiZip20(mapPxiZipCode(pxiZip.size(), LIST_VALUE_20, pxiZip));
		}
		return prv2Provider2Info;

	}

	private static String mapPxiZipCode(int size, int num, List<PxiZip> pxiZip) {
		return size < num ? null : pxiZip.get(num - 1).getPxiZipCode();
	}

	static Prv2Provider2Info getPrv2Provider2InfoOfDemographics(Demographics demographics) {

		Prv2Provider2Info prv2Provider2Info = new Prv2Provider2Info();
		mapPrv2Npi(prv2Provider2Info, demographics.getProviderInfo().getNpiIds());
		mapPrv2TaxnmyCd(prv2Provider2Info, demographics.getProviderInfo().getTaxonomyCodes());

		return prv2Provider2Info;
	}

	private static Prv2Provider2Info mapPrv2TaxnmyCd(Prv2Provider2Info prv2Provider2Info,
			List<TaxonomyCode> taxonomyCodes) {
		if (null != taxonomyCodes) {
			prv2Provider2Info
					.setPrv2TaxonomyCode(mapTaxonomyCode(taxonomyCodes.size(), LIST_VALUE_1, taxonomyCodes));
			prv2Provider2Info
					.setPrv2TaxonomyCode2(mapTaxonomyCode(taxonomyCodes.size(), LIST_VALUE_2, taxonomyCodes));
			prv2Provider2Info
					.setPrv2TaxonomyCode3(mapTaxonomyCode(taxonomyCodes.size(), LIST_VALUE_3, taxonomyCodes));
			prv2Provider2Info
					.setPrv2TaxonomyCode4(mapTaxonomyCode(taxonomyCodes.size(), LIST_VALUE_4, taxonomyCodes));
			prv2Provider2Info
					.setPrv2TaxonomyCode5(mapTaxonomyCode(taxonomyCodes.size(), LIST_VALUE_5, taxonomyCodes));
			prv2Provider2Info
					.setPrv2TaxonomyCode6(mapTaxonomyCode(taxonomyCodes.size(), LIST_VALUE_6, taxonomyCodes));
			prv2Provider2Info
					.setPrv2TaxonomyCode7(mapTaxonomyCode(taxonomyCodes.size(), LIST_VALUE_7, taxonomyCodes));
			prv2Provider2Info
					.setPrv2TaxonomyCode8(mapTaxonomyCode(taxonomyCodes.size(), LIST_VALUE_8, taxonomyCodes));
			prv2Provider2Info
					.setPrv2TaxonomyCode9(mapTaxonomyCode(taxonomyCodes.size(), LIST_VALUE_9, taxonomyCodes));
			prv2Provider2Info
					.setPrv2TaxonomyCode10(mapTaxonomyCode(taxonomyCodes.size(), LIST_VALUE_10, taxonomyCodes));
		}
		return prv2Provider2Info;
	}
	
	private static String mapTaxonomyCode(int size, int num, List<TaxonomyCode> taxonomyCode) {
		return size < num ? null : taxonomyCode.get(num - 1).getTaxonomyCd();
	}

	private static Prv2Provider2Info mapPrv2Npi(Prv2Provider2Info prv2Provider2Info, List<NpiInfos> npiInfos) {
		if (null != npiInfos) {
			prv2Provider2Info.setPrv2Npi(mapNpi(npiInfos.size(), LIST_VALUE_1, npiInfos));
			prv2Provider2Info.setPrv2Npi2(mapNpi(npiInfos.size(), LIST_VALUE_2, npiInfos));
			prv2Provider2Info.setPrv2Npi3(mapNpi(npiInfos.size(), LIST_VALUE_3, npiInfos));
			prv2Provider2Info.setPrv2Npi4(mapNpi(npiInfos.size(), LIST_VALUE_4, npiInfos));
			prv2Provider2Info.setPrv2Npi5(mapNpi(npiInfos.size(), LIST_VALUE_5, npiInfos));
			prv2Provider2Info.setPrv2Npi6(mapNpi(npiInfos.size(), LIST_VALUE_6, npiInfos));
			prv2Provider2Info.setPrv2Npi7(mapNpi(npiInfos.size(), LIST_VALUE_7, npiInfos));
			prv2Provider2Info.setPrv2Npi8(mapNpi(npiInfos.size(), LIST_VALUE_8, npiInfos));
			prv2Provider2Info.setPrv2Npi9(mapNpi(npiInfos.size(), LIST_VALUE_9, npiInfos));
		}
		return prv2Provider2Info;
	}
	
	private static String mapNpi(int size, int num, List<NpiInfos> npiId) {
		return size < num ? null : npiId.get(num - 1).getNpiId();
	}

	private static Prv2PxiPtsLobArea getPrv2PxiPtsLobArea(Attributes attributes) {
		Prv2PxiPtsLobArea prv2PxiPtsLobArea = new Prv2PxiPtsLobArea();
		prv2PxiPtsLobArea.setPrv2PxiPtsLob1(getContractPoints(
				null == attributes.getContractPointEnable() ? null : attributes.getContractPointEnable().get("1")));
		prv2PxiPtsLobArea.setPrv2PxiPtsLob2(getContractPoints(
				null == attributes.getContractPointEnable() ? null : attributes.getContractPointEnable().get("2")));
		prv2PxiPtsLobArea.setPrv2PxiPtsLob3(getContractPoints(
				null == attributes.getContractPointEnable() ? null : attributes.getContractPointEnable().get("3")));
		prv2PxiPtsLobArea.setPrv2PxiPtsLob4(getContractPoints(
				null == attributes.getContractPointEnable() ? null : attributes.getContractPointEnable().get("4")));
		prv2PxiPtsLobArea.setPrv2PxiPtsLob5(getContractPoints(
				null == attributes.getContractPointEnable() ? null : attributes.getContractPointEnable().get("5")));
		prv2PxiPtsLobArea.setPrv2PxiPtsLob6(getContractPoints(
				null == attributes.getContractPointEnable() ? null : attributes.getContractPointEnable().get("6")));
		prv2PxiPtsLobArea.setPrv2PxiPtsLob7(getContractPoints(
				null == attributes.getContractPointEnable() ? null : attributes.getContractPointEnable().get("7")));
		prv2PxiPtsLobArea.setPrv2PxiPtsLob8(getContractPoints(
				null == attributes.getContractPointEnable() ? null : attributes.getContractPointEnable().get("8")));
		prv2PxiPtsLobArea.setPrv2PxiPtsLob9(getContractPoints(
				null == attributes.getContractPointEnable() ? null : attributes.getContractPointEnable().get("9")));
		return prv2PxiPtsLobArea;
	}

	private static String getContractPoints(Boolean contractPointEnable) {
		if (Boolean.TRUE.equals(contractPointEnable)) {
			return "Y";
		}
		return "N";
	}

	static Prv2Key getPrv2Key(Attributes attributes) {
		Prv2Key prv2Key = new Prv2Key();
		prv2Key.setPrv2Client(null == attributes.getKey() ? null : attributes.getKey().getClient());
		prv2Key.setPrv2MultAddressKey(null == attributes.getKey() ? null : attributes.getKey().getMultAddressKey());
		prv2Key.setPrv2Prov(null == attributes.getKey() ? null : attributes.getKey().getProv());
		prv2Key.setPrv2PvdInd(null == attributes.getKey() ? null : attributes.getKey().getPvdInd());

		return prv2Key;
	}
}
package com.humana.claims.hcaas.provider.restapi.model.datafeed;

import com.humana.claims.hcaas.provider.model.mq.Prv3OutRecord;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@ToString
public class Prov3DataFeed {

	private String requestId;
	private String requestClient;
	private Prv3OutRecord prv3OutRecord;

}

package com.humana.claims.hcaas.provider.restapi.config;

import org.apache.qpid.jms.JmsConnectionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.core.JmsTemplate;

import com.humana.claims.hcaas.provider.restapi.model.datafeed.Prov3DataFeed;
import com.humana.claims.hcaas.provider.restapi.service.datafeed.Prov1DataFeederImpl;
import com.humana.claims.hcaas.provider.restapi.service.datafeed.Prov2DataFeederImpl;
import com.humana.claims.hcaas.provider.restapi.service.datafeed.Prov3DataFeederImpl;
import com.humana.claims.hcaas.provider.restapi.service.datafeed.ProviderDataFeeder;
import com.humana.claims.hcaas.provider.restapi.model.datafeed.Prov1DataFeed;
import com.humana.claims.hcaas.provider.restapi.model.datafeed.Prov2DataFeed;

@Configuration
@ConditionalOnProperty(name = "datafeed.handler", havingValue = "amqp")
public class DataFeedProcessorAmqpConfig {

	@Value("${datafeed.amqp.uri}")
	private String amqpUrl;
	
	@Value("${datafeed.queue.prov1.userName}")
	private String prov1UserName;
	
	@Value("${datafeed.queue.prov1.password}")
	private String prov1Password;
	
	@Value("${datafeed.queue.prov2.userName}")
	private String prov2UserName;
	
	@Value("${datafeed.queue.prov2.password}")
	private String prov2Password;
	
	@Value("${datafeed.queue.prov3.userName}")
	private String prov3UserName;
	
	@Value("${datafeed.queue.prov3.password}")
	private String prov3Password;
	
	@Bean
	public ProviderDataFeeder<Prov1DataFeed> prov1DataFeedHandler(@Value("${datafeed.queue.prov1.queueName}") String queueName){
		return new Prov1DataFeederImpl(prov1ConnectionFactory(), queueName);
	}
	
	@Bean
	public ProviderDataFeeder<Prov2DataFeed> prov2DataFeedHandler(@Value("${datafeed.queue.prov2.queueName}") String queueName){
		return new Prov2DataFeederImpl(prov2ConnectionFactory(), queueName);
	}
	
	@Bean
	public ProviderDataFeeder<Prov3DataFeed> prov3DataFeedHandler(@Value("${datafeed.queue.prov3.queueName}") String queueName){
		return new Prov3DataFeederImpl(prov3ConnectionFactory(), queueName);
	}
	
	@Bean
	public JmsTemplate prov1ConnectionFactory() {
		return buildConnectionFactory(prov1UserName, prov1Password);
	}
	
	@Bean
	public JmsTemplate prov2ConnectionFactory() {
		return buildConnectionFactory(prov2UserName, prov2Password);
	}
	
	@Bean
	public JmsTemplate prov3ConnectionFactory() {
		return buildConnectionFactory(prov3UserName, prov3Password);
	}
	
	private JmsTemplate buildConnectionFactory(String userName, String password) {
		JmsConnectionFactory connectionFactory = new JmsConnectionFactory(amqpUrl);
		connectionFactory.setUsername(userName);
		connectionFactory.setPassword(password);
		return new JmsTemplate(new CachingConnectionFactory(connectionFactory));
	}
}
package com.humana.claims.hcaas.provider.restapi;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.humana.claims.hcaas.common.spring.boot.starter.HcaasSpringBootApplication;

@SpringBootApplication(scanBasePackages="com.humana.claims.hcaas")
@EnableAutoConfiguration
public class ProviderRestApiService {

	public static void main(String[] args) {
		HcaasSpringBootApplication.run(ProviderRestApiService.class, args);
	}

}

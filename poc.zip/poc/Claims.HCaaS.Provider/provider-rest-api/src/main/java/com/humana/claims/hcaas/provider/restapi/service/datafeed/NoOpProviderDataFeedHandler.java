package com.humana.claims.hcaas.provider.restapi.service.datafeed;

import com.humana.claims.hcaas.provider.restapi.exception.DataFeedException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class NoOpProviderDataFeedHandler<T> implements ProviderDataFeeder<T> {

	@Override
	public void sendToQueue(T obj) throws DataFeedException {
		log.debug("No data changes added to queue, AMQP not enabled");
	}
}
package com.humana.claims.hcaas.provider.restapi.service.datafeed;

import com.humana.claims.hcaas.provider.restapi.exception.DataFeedException;

public interface ProviderDataFeeder<T> {

	public void sendToQueue(T obj) throws DataFeedException;
}
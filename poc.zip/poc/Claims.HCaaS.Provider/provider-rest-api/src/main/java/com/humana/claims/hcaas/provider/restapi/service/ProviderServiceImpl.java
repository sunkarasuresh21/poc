package com.humana.claims.hcaas.provider.restapi.service;

import static com.humana.claims.hcaas.provider.attributes.core.dao.ProviderAttributesMongoConstants.ATTRIBUTES_ALREADY_EXISTS;
import static com.humana.claims.hcaas.provider.demographics.core.dao.ProviderDemographicsMongoConstants.DEMOGRAPHICS_ALREADY_EXISTS;
import static com.humana.claims.hcaas.provider.demographics.core.dao.ProviderDemographicsMongoConstants.KEY_PROVIDER_ID;
import static com.humana.claims.hcaas.provider.demographics.core.dao.ProviderDemographicsMongoConstants.KEY_PROVIDER_INDICATOR;
import static com.humana.claims.hcaas.provider.demographics.core.dao.ProviderDemographicsMongoConstants.KEY_PROVIDER_SUFFIX;
import static com.humana.claims.hcaas.provider.restapi.constants.ProviderConstants.PROVIDER_NOT_FOUND;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.humana.claims.hcaas.provider.attributes.core.constants.ProviderAttributesConstants;
import com.humana.claims.hcaas.provider.attributes.core.dao.ProviderAttributesDAO;
import com.humana.claims.hcaas.provider.attributes.core.model.RequestKey;
import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.contract.restclient.gen.openapi.model.ContractSearchRequestDTO;
import com.humana.claims.hcaas.provider.contract.restclient.gen.openapi.model.ContractSearchResponseDTO;
import com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsConstants;
import com.humana.claims.hcaas.provider.demographics.core.dao.ProviderDemographicsDAO;
import com.humana.claims.hcaas.provider.demographics.core.exception.InvalidRequestException;
import com.humana.claims.hcaas.provider.demographics.core.model.DemographicsDBResponse;
import com.humana.claims.hcaas.provider.demographics.core.model.ProviderDemoGetRequest;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.demographics.core.validator.ProviderDemographicsValidator;
import com.humana.claims.hcaas.provider.restapi.constants.ProviderConstants;
import com.humana.claims.hcaas.provider.restapi.constants.ProviderErrorConstants;
import com.humana.claims.hcaas.provider.restapi.exception.ConflictException;
import com.humana.claims.hcaas.provider.restapi.exception.DataFeedException;
import com.humana.claims.hcaas.provider.restapi.exception.NotFoundException;
import com.humana.claims.hcaas.provider.restapi.exception.ProviderCreationException;
import com.humana.claims.hcaas.provider.restapi.exception.ProviderUpdateException;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderKeyModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.UpdateProviderModelDTO;
import com.humana.claims.hcaas.provider.restapi.mapper.ProviderServiceDataMapper;
import com.humana.claims.hcaas.provider.restapi.model.ProviderGetResponse;
import com.humana.claims.hcaas.provider.restapi.service.datafeed.DataFeedService;
import com.humana.claims.hcaas.provider.restapi.validator.ProviderValidator;

@Service("ProviderService")
public class ProviderServiceImpl implements ProviderService {

	private ProviderValidator providerValidator;
	
	private ProviderDemographicsValidator providerDemographicsValidator;

	private ProviderDemographicsDAO providerDemographicsDAO;

	private ProviderAttributesDAO providerAttributesDAO;

	private ProviderServiceDataMapper providerDataMapper;
	
	private ProviderContractService providerContractService;
	
	private DataFeedService dataFeedService;
	
	@Autowired
	public ProviderServiceImpl(ProviderValidator providerValidator,
			ProviderDemographicsValidator providerDemographicsValidator,
			ProviderDemographicsDAO providerDemographicsDAO, ProviderAttributesDAO providerAttributesDAO,
			ProviderServiceDataMapper providerDataMapper, ProviderContractService providerContractService,
			DataFeedService dataFeedService) {
		this.providerValidator = providerValidator;
		this.providerDemographicsValidator = providerDemographicsValidator;
		this.providerDemographicsDAO = providerDemographicsDAO;
		this.providerAttributesDAO = providerAttributesDAO;
		this.providerDataMapper = providerDataMapper;
		this.providerContractService = providerContractService;
		this.dataFeedService = dataFeedService;
	}
	
	private static final String CLIENT="58";
	
	private static final String HYPHEN="-";

	@Transactional
	@Override
	public boolean createProvider(UpdateProviderModelDTO updateProviderDTO, String requestId, String requestClient) throws ProviderCreationException, ConflictException, InvalidRequestException, DataFeedException 
	{
		Set<String> errorMessages = new HashSet<>();
		providerValidator.validateInputRequestForPostOperation(updateProviderDTO);
		
		ProviderKeyModelDTO keyDTO = updateProviderDTO.getProviderKey();
		
		Map<String, String> queryMap = new LinkedHashMap<>();
		queryMap.put(KEY_PROVIDER_ID, keyDTO.getProv());
		queryMap.put(KEY_PROVIDER_INDICATOR, keyDTO.getPvdInd());
		queryMap.put(KEY_PROVIDER_SUFFIX, keyDTO.getMultAddressKey());
		
		DemographicsDBResponse  providerDemoGetDaoResponseObj = providerDemographicsDAO.getDemographicsByProviderId(queryMap, 1, 0, false);
		
		if (!CollectionUtils.isEmpty(providerDemoGetDaoResponseObj.getDemographics())) {
			errorMessages.add(ProviderErrorConstants.PROVIDER_ALREADY_EXISTS);
			throw new ConflictException(errorMessages);
		} else {
			deriveActiveAndArchivedFromPvdStRcAndPvdStatus(updateProviderDTO);
			Demographics demographics = providerDataMapper.mapDemographics(updateProviderDTO);
			Attributes attributes = providerDataMapper.mapAttributes(updateProviderDTO);
			String demographicsCreated = providerDemographicsDAO.postProviderDemographics(demographics);
			if(demographicsCreated.equalsIgnoreCase(DEMOGRAPHICS_ALREADY_EXISTS)) {
				errorMessages.add(ProviderErrorConstants.FAILED_TO_CREATE_PROVIDER);
				throw new ProviderCreationException(errorMessages);
			} else {
				dataFeedService.dataFeed(demographics, null, requestId, requestClient);
				String attributesCreated = providerAttributesDAO.postProviderAttributes(attributes);
				if(attributesCreated.equalsIgnoreCase(ATTRIBUTES_ALREADY_EXISTS)) {
					errorMessages.add(ProviderErrorConstants.FAILED_TO_CREATE_PROVIDER);
					throw new ProviderCreationException(errorMessages);					
				}
				dataFeedService.dataFeed(null, attributes, requestId, requestClient);
				return true;
			}
		}
	}

	private void deriveActiveAndArchivedFromPvdStRcAndPvdStatus(UpdateProviderModelDTO updateProviderDTO) {
		String pvdStRc = updateProviderDTO.getProviderDemo().getProviderInfo().getPvdStRc();
		String pvdStatus = updateProviderDTO.getProviderDemo().getProviderInfo().getPvdStatus();
		if(pvdStRc != null && pvdStatus != null) {
			boolean isArchived = providerValidator.isArchived(pvdStRc, pvdStatus);
			boolean isActive = providerValidator.isActive(pvdStRc, pvdStatus);
			updateProviderDTO.getProviderDemo().getProviderInfo().setArchived(isArchived);
			updateProviderDTO.getProviderDemo().getProviderInfo().setActive(isActive);
		}
	}

	@Transactional
	@Override
	public String updateProvider(UpdateProviderModelDTO updateProviderDTO, String providerId, String providerMultiAddressKey, 
			String providerIndicator, String requestId, String requestClient) throws IOException, InvalidRequestException, ProviderUpdateException, IllegalAccessException, NotFoundException, DataFeedException 
	{
		providerValidator.validateProviderInfoSentForUpdate(updateProviderDTO, providerIndicator, providerId, providerMultiAddressKey);
		if(updateProviderDTO.getProviderDemo()!=null) {
			updateArchivedandActiveStatusForPatch(updateProviderDTO);
		}
		Demographics demographics = providerDataMapper.mapDemographics(updateProviderDTO);
		Attributes attributes = providerDataMapper.mapAttributes(updateProviderDTO);

		return updateProvider(demographics, attributes, providerId, providerMultiAddressKey, providerIndicator, requestId, requestClient);
	}

	private void updateArchivedandActiveStatusForPatch(UpdateProviderModelDTO updateProviderDTO) {
		String pvdStRc = updateProviderDTO.getProviderDemo().getProviderInfo().getPvdStRc();
		String pvdStatus = updateProviderDTO.getProviderDemo().getProviderInfo().getPvdStatus();
		if(pvdStRc!=null && pvdStatus!=null) {
			boolean isArchived = providerValidator.isArchived(pvdStRc, pvdStatus);
			boolean isActive = providerValidator.isActive(pvdStRc, pvdStatus);
			updateProviderDTO.getProviderDemo().getProviderInfo().setActive(isActive);
			updateProviderDTO.getProviderDemo().getProviderInfo().setArchived(isArchived);
		}
	}

	private String updateProvider(Demographics demographics, Attributes attributes, String providerId,
			String providerMultiAddressKey, String providerIndicator, String requestId, String requestClient)
			throws ProviderUpdateException, IllegalAccessException, NotFoundException, DataFeedException {
		String resultFromDemographicUpdate = "";
		String resultFromAttributeUpdate = ""; 
		Set<String> errorMessages = new HashSet<>();

		if (demographics != null) {
			resultFromDemographicUpdate = updateDemographics(demographics, providerId, providerMultiAddressKey, providerIndicator, requestId, requestClient);
		}
		if ((attributes != null) && isDemographicsSuccessOrNull(demographics, resultFromDemographicUpdate)) {
			resultFromAttributeUpdate = updateAttributes(attributes, providerId, providerMultiAddressKey,
					providerIndicator, requestId, requestClient);
		}
		return evaluateUpdateProviderResponse(resultFromDemographicUpdate, resultFromAttributeUpdate, attributes, demographics, errorMessages);
	}
	
	private boolean isDemographicsSuccessOrNull(Demographics demographics, String resultFromDemographicUpdate) {
		return ((demographics != null
				&& ProviderDemographicsConstants.SUCCESS.equalsIgnoreCase(resultFromDemographicUpdate))
				|| (demographics == null));
	}

	private String evaluateUpdateProviderResponse(String resultFromDemographicUpdate, String resultFromAttributeUpdate,
			Attributes attributes, Demographics demographics, Set<String> errorMessages)
			throws NotFoundException, ProviderUpdateException {
		if (isAttributeAndDemographicUpdateSuccess(resultFromDemographicUpdate, resultFromAttributeUpdate)
				|| isDemographicUpdateSuccessAndAttributesNull(resultFromDemographicUpdate, attributes)
				|| isAttributeUpdateSuccessAndDemographicsNull(resultFromAttributeUpdate, demographics)) {
			return ProviderConstants.SUCCESS;
		}
		if (ProviderDemographicsConstants.SUCCESS.equalsIgnoreCase(resultFromDemographicUpdate)
				&& ProviderAttributesConstants.NOT_FOUND.equalsIgnoreCase(resultFromAttributeUpdate)) {
			errorMessages.add(ProviderAttributesConstants.NOT_FOUND);
			throw new NotFoundException(errorMessages);
		}

		if (ProviderDemographicsConstants.NOT_FOUND.equalsIgnoreCase(resultFromDemographicUpdate)
				|| ProviderAttributesConstants.NOT_FOUND.equalsIgnoreCase(resultFromAttributeUpdate)) {
			return ProviderErrorConstants.NOT_FOUND;
		}
		errorMessages.add(ProviderErrorConstants.FAILED_TO_UPDATE_PROVIDER);
		throw new ProviderUpdateException(errorMessages);
	}
		
	private boolean isDemographicUpdateSuccessAndAttributesNull(String resultFromDemographicUpdate,
			Attributes attributes) {
		return (ProviderDemographicsConstants.SUCCESS.equalsIgnoreCase(resultFromDemographicUpdate)
				&& attributes == null);
	}

	private boolean isAttributeUpdateSuccessAndDemographicsNull(String resultFromAttributeUpdate,
			Demographics demographics) {
		return (ProviderAttributesConstants.SUCCESS.equalsIgnoreCase(resultFromAttributeUpdate)
				&& demographics == null);
	}

	private boolean isAttributeAndDemographicUpdateSuccess(String resultFromDemographicUpdate,
			String resultFromAttributeUpdate) {
		return (ProviderDemographicsConstants.SUCCESS.equalsIgnoreCase(resultFromDemographicUpdate)
				&& ProviderAttributesConstants.SUCCESS.equalsIgnoreCase(resultFromAttributeUpdate));
	}

	private String updateDemographics(Demographics demographics, String providerId, String providerMultiAddressKey,
			String providerIndicator, String requestId, String requestClient)
			throws IllegalAccessException, DataFeedException {
		Demographics resultFromDemographicUpdate = providerDemographicsDAO.updateProviderDemographics(demographics,
				providerId, providerMultiAddressKey, providerIndicator);
		if (resultFromDemographicUpdate != null) {
			dataFeedService.dataFeed(resultFromDemographicUpdate, null, requestId, requestClient);
		} else {
			return ProviderDemographicsConstants.NOT_FOUND;
		}
		return ProviderDemographicsConstants.SUCCESS;
	}

	private String updateAttributes(Attributes attributes, String providerId, String providerMultiAddressKey,
			String providerIndicator, String requestId, String requestClient) throws IllegalAccessException, DataFeedException {
		Attributes resultFromAttributeUpdate = providerAttributesDAO.updateProviderAttributes(attributes, providerId, providerMultiAddressKey, providerIndicator);
		if (resultFromAttributeUpdate != null) {
			dataFeedService.dataFeed(null, resultFromAttributeUpdate, requestId, requestClient);
		} else {
			return ProviderAttributesConstants.NOT_FOUND;
		}
		return ProviderAttributesConstants.SUCCESS;
	}

	@Override
	public ProviderGetResponse getProviderByProviderId(ProviderDemoGetRequest provDemoGetReq)
			throws NotFoundException, InvalidRequestException {
		Map<String, String> queryMap = providerDemographicsValidator.validateByProviderId(provDemoGetReq);
		
		DemographicsDBResponse providerDemoGetResponse = providerDemographicsDAO.getDemographicsByProviderId(queryMap,
				provDemoGetReq.getLimit(), provDemoGetReq.getOffset(),
				isIncludeCount(provDemoGetReq.getIncludeCount()));
		
		return buildResponse(providerDemoGetResponse,isCheckContract(provDemoGetReq.getCheckContract()));
	}

	@Override
	public ProviderGetResponse getProviderByProviderTaxId(ProviderDemoGetRequest provDemoGetReq)
			throws NotFoundException, InvalidRequestException {
		Map<String, String> queryMap = providerDemographicsValidator.validateByProviderTaxId(provDemoGetReq);
		
		DemographicsDBResponse providerDemoGetResponse = providerDemographicsDAO
				.getDemographicsByProviderTaxId(queryMap, provDemoGetReq.getLimit(),provDemoGetReq.getOffset(), isIncludeCount(provDemoGetReq.getIncludeCount()));
		
		return buildResponse(providerDemoGetResponse,false);
	}

	@Override
	public ProviderGetResponse getProviderByProviderNpiId(ProviderDemoGetRequest provDemoGetReq)
			throws NotFoundException, InvalidRequestException {
		Map<String, String> queryMap = providerDemographicsValidator.validateByNpiId(provDemoGetReq);
		
		DemographicsDBResponse providerDemoGetResponse = providerDemographicsDAO.getDemographicsByNpiId(queryMap,
				provDemoGetReq.getLimit(), provDemoGetReq.getOffset(), isIncludeCount(provDemoGetReq.getIncludeCount()));
		
		return buildResponse(providerDemoGetResponse,false);
	}

	@Override
	public ProviderGetResponse getProviderByProvName(ProviderDemoGetRequest provDemoGetReq)
			throws NotFoundException, InvalidRequestException {
		Map<String, String> queryMap = providerDemographicsValidator.validateByProvName(provDemoGetReq);
		
		DemographicsDBResponse providerDemoGetResponse = providerDemographicsDAO.getDemographicsByProvName(queryMap,
				provDemoGetReq.getLimit(), provDemoGetReq.getOffset(), isIncludeCount(provDemoGetReq.getIncludeCount()));
		
		return buildResponse(providerDemoGetResponse,false);
	}
	
	private ProviderGetResponse buildResponse(DemographicsDBResponse providerDemoGetResponse, boolean checkContract) throws NotFoundException {
		
		List<Demographics> demographicsList = providerDemoGetResponse.getDemographics();
		
		Map<String, Demographics> demographicsMap = getDemographicsMap(demographicsList);

		Map<String, Attributes> attributesMap = getAttributesMap(demographicsList);
		
		Map<String, ContractSearchResponseDTO> activeContractMap = Collections.emptyMap();  
		if (checkContract) {
			activeContractMap = getActiveContracts(demographicsList);
		}
				
		List<ProviderModelDTO> providerDTOs = new ArrayList<>();

		for (Map.Entry<String, Demographics> entry : demographicsMap.entrySet()) {
			Demographics demographics = entry.getValue();
			Attributes attributes = attributesMap.get(entry.getKey());
			List<String> activeLobs = Collections.emptyList();
			if(checkContract && !CollectionUtils.isEmpty(activeContractMap)) {
				activeLobs = activeContractMap.get(entry.getKey()).getLobsWithActiveContract();
			}
			providerDTOs.add(providerDataMapper.mapProviderDBObjToProviderDTO(demographics, attributes, activeLobs));
		}

		return ProviderGetResponse.builder().providerDTOs(providerDTOs).totalCount(providerDemoGetResponse.getTotalCount()).build();
	}
	
	private boolean isIncludeCount(Boolean includeCount) {
		if (includeCount != null) {
			return includeCount;
		}
		return false;
	}
	
	private boolean isCheckContract(Boolean checkContract) {
		if (checkContract != null) {
			return checkContract;
		}
		return false;
	}
	
	private RequestKey createRequestKey(String providerId,String multiAddresskey,String providerInd) {
		RequestKey key = new RequestKey();
		key.setProv(providerId);
		key.setClient(CLIENT);
		key.setMultAddressKey(multiAddresskey);
		key.setPvdInd(providerInd);
		return key;
	}
	
	private ContractSearchRequestDTO createRequestDTO(String providerId,String multiAddresskey,String providerInd) {
		ContractSearchRequestDTO searchRequestDTO = new ContractSearchRequestDTO();
		searchRequestDTO.setProvId(providerId);
		searchRequestDTO.setProvSuffix(multiAddresskey);
		searchRequestDTO.setProvInd(providerInd);
		return searchRequestDTO;
	}
	
	private String getKey(String providerId,String multiAddresskey,String providerInd) {
		return new StringBuffer(CLIENT).append(HYPHEN).append(providerId).append(HYPHEN).append(multiAddresskey)
				.append(HYPHEN).append(providerInd).toString();
	}
	
	private Map<String, Demographics> getDemographicsMap(List<Demographics> demographicsList)throws NotFoundException {
		if (CollectionUtils.isEmpty(demographicsList)) {
			Set<String> errorMessages = new HashSet<>();
			errorMessages.add(PROVIDER_NOT_FOUND);
			throw new NotFoundException(errorMessages);
		}

		return demographicsList.stream().collect(Collectors.toMap(
						demographics -> getKey(demographics.getKey().getProv(),demographics.getKey().getMultAddressKey(), demographics.getKey().getPvdInd()),
						demographics -> demographics));
	}
	
	private Map<String, Attributes> getAttributesMap(List<Demographics> demographicsList) {
		List<RequestKey> requestKeyList = demographicsList.stream().map(
				e -> createRequestKey(e.getKey().getProv(), e.getKey().getMultAddressKey(), e.getKey().getPvdInd()))
				.collect(Collectors.toList());
		
		List<Attributes> attributesList = providerAttributesDAO.getAttributesByKey(requestKeyList);

		return attributesList.stream().collect(Collectors.toMap(attributes -> getKey(attributes.getKey().getProv(),
										attributes.getKey().getMultAddressKey(), attributes.getKey().getPvdInd()),
								attributes -> attributes));
	}
	
	private Map<String, ContractSearchResponseDTO> getActiveContracts(List<Demographics> demographicsList) {
		List<ContractSearchRequestDTO> contractSearchRequestDTOs = demographicsList.stream().map(
				e -> createRequestDTO(e.getKey().getProv(), e.getKey().getMultAddressKey(), e.getKey().getPvdInd()))
				.collect(Collectors.toList());
		List<ContractSearchResponseDTO> contractSearchResponseDTOs = providerContractService
				.getActiveContracts(contractSearchRequestDTOs);
		return contractSearchResponseDTOs.stream()
				.collect(Collectors.toMap(activeContract -> getKey(activeContract.getProvId(),
						activeContract.getProvSuffix(), activeContract.getProvInd()),
						activeContract -> activeContract));
	}

}
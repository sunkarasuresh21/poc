package com.humana.claims.hcaas.provider.restapi.model.datafeed;

import com.humana.claims.hcaas.provider.model.mq.PrvMaster;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@ToString
public class Prov1DataFeed {

	private String requestId;
	private String requestClient;
	private PrvMaster prvMaster;

}

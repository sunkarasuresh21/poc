package com.humana.claims.hcaas.provider.restapi.exception;

public final class ProviderContractDataRetrieveException extends RuntimeException  {
	
	private static final long serialVersionUID = 1L;
	public ProviderContractDataRetrieveException(String message, Throwable cause) {
		super(message, cause);
	}
}
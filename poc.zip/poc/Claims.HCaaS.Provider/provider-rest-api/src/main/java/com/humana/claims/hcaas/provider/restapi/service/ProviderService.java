package com.humana.claims.hcaas.provider.restapi.service;

import java.io.IOException;

import com.humana.claims.hcaas.provider.demographics.core.exception.InvalidRequestException;
import com.humana.claims.hcaas.provider.demographics.core.model.ProviderDemoGetRequest;
import com.humana.claims.hcaas.provider.restapi.exception.ConflictException;
import com.humana.claims.hcaas.provider.restapi.exception.DataFeedException;
import com.humana.claims.hcaas.provider.restapi.exception.NotFoundException;
import com.humana.claims.hcaas.provider.restapi.exception.ProviderCreationException;
import com.humana.claims.hcaas.provider.restapi.exception.ProviderUpdateException;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.UpdateProviderModelDTO;
import com.humana.claims.hcaas.provider.restapi.model.ProviderGetResponse;

public interface ProviderService {
	
	public boolean createProvider(UpdateProviderModelDTO updateProviderDTO, String requestId, String requestClient) throws ProviderCreationException, InvalidRequestException, ConflictException, DataFeedException;
	
	public String updateProvider(UpdateProviderModelDTO updateProviderDTO, String providerId, 
			String providerMultiAddressKey, String providerIndicator, String requestId, String requestClient) throws IOException, InvalidRequestException, ProviderUpdateException, IllegalAccessException, NotFoundException, DataFeedException;
	
	ProviderGetResponse getProviderByProviderId(ProviderDemoGetRequest provDemoGetReq) throws InvalidRequestException, NotFoundException;
	
	ProviderGetResponse getProviderByProviderTaxId(ProviderDemoGetRequest provDemoGetReq) throws InvalidRequestException, NotFoundException;
	
	ProviderGetResponse getProviderByProviderNpiId(ProviderDemoGetRequest provDemoGetReq) throws InvalidRequestException, NotFoundException;
	
	ProviderGetResponse getProviderByProvName(ProviderDemoGetRequest provDemoGetReq) throws InvalidRequestException, NotFoundException;

}

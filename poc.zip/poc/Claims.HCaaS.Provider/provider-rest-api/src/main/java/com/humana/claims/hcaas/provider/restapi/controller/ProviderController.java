package com.humana.claims.hcaas.provider.restapi.controller;

import static com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsErrorConstants.INVALID_HEADER_COMBINATION;
import static com.humana.claims.hcaas.provider.restapi.constants.ProviderConstants.SUCCESS;
import static com.humana.claims.hcaas.provider.restapi.constants.ProviderErrorConstants.PROVIDER_NOT_FOUND_FOR_UPDATE;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.humana.claims.hcaas.common.utils.logging.LogUtils;
import com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsConstants;
import com.humana.claims.hcaas.provider.demographics.core.exception.InvalidHeaderCombinationException;
import com.humana.claims.hcaas.provider.demographics.core.exception.InvalidRequestException;
import com.humana.claims.hcaas.provider.demographics.core.masker.ProviderDemographicsDataMasker;
import com.humana.claims.hcaas.provider.demographics.core.model.ProviderDemoGetRequest;
import com.humana.claims.hcaas.provider.demographics.core.util.StringUtils;
import com.humana.claims.hcaas.provider.restapi.exception.ConflictException;
import com.humana.claims.hcaas.provider.restapi.exception.DataFeedException;
import com.humana.claims.hcaas.provider.restapi.exception.NotFoundException;
import com.humana.claims.hcaas.provider.restapi.exception.ProviderCreationException;
import com.humana.claims.hcaas.provider.restapi.exception.ProviderUpdateException;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.V1Api;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderKeyModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.UpdateProviderModelDTO;
import com.humana.claims.hcaas.provider.restapi.model.ProviderGetResponse;
import com.humana.claims.hcaas.provider.restapi.service.ProviderService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class ProviderController implements V1Api {

	@Autowired
	private ProviderService providerService;
	
	@Autowired
	private ProviderDemographicsDataMasker dataMasker;
	
	@Override
	public ResponseEntity<Void> createProvider(@Valid UpdateProviderModelDTO updateProviderDTO, String requestId, String requestClient) 
			throws ProviderCreationException, InvalidRequestException, ConflictException, DataFeedException
	{
		logIncomingRequestForCreateProvider(updateProviderDTO.getProviderKey(),
				updateProviderDTO.getProviderDemo().getIrsNo());
		
		return providerService.createProvider(updateProviderDTO, requestId, requestClient)
				? ResponseEntity.status(HttpStatus.CREATED).build() : ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
	}
	
	@Override
	public ResponseEntity<Void> updateProvider(String providerId, String providerIndicator,
			String providerMultiAddressKey, @Valid UpdateProviderModelDTO updateProviderDTO, String requestId, String requestClient) 
					throws InvalidRequestException, IOException, NotFoundException, ProviderUpdateException, IllegalAccessException, DataFeedException
	{
		logIncomingRequestForUpdateProvider(providerId, providerIndicator, providerMultiAddressKey);
		
		Set<String> errorMessages = new HashSet<>();
		if(SUCCESS.equalsIgnoreCase(providerService.updateProvider(updateProviderDTO, providerId, providerMultiAddressKey, providerIndicator, requestId, requestClient)))
		{
			return ResponseEntity.status(HttpStatus.OK).build();
		}
		errorMessages.add(PROVIDER_NOT_FOUND_FOR_UPDATE);
		throw new NotFoundException(errorMessages);
	}
	
	@Override
	public ResponseEntity<List<ProviderModelDTO>> getProvider(String providerId, String providerIndicator,
			String providerMultiAddressKey, String providerTaxId, String npiId, Boolean checkContract,
			String statusOrReasonCode, String majorClassCode, String provName, String stateCode, Boolean includeCount,
			Integer limit, Integer offset) throws Exception {
		
		ProviderDemoGetRequest provDemoGetReq = ProviderDemoGetRequest.builder().providerId(providerId).providerIndicator(providerIndicator).providerMultiAddressKey(providerMultiAddressKey)
		.providerTaxId(providerTaxId).npiId(npiId).limit(limit).offset(offset).statusOrReasonCode(statusOrReasonCode).majorClassCode(majorClassCode).
		provName(provName).stateCode(stateCode).includeCount(includeCount).checkContract(checkContract).build();
		
		logIncomingRequestForGet(provDemoGetReq);
				
		if (null != providerId) {
			
			provDemoGetReq.setProviderMultiAddressKey(StringUtils.replaceBlankStringToSingleWhiteSpace(provDemoGetReq.getProviderMultiAddressKey()));
			ProviderGetResponse providerResponseObj = providerService.getProviderByProviderId(provDemoGetReq);
			return buildAndReturnResponse(providerResponseObj, provDemoGetReq.getIncludeCount());
			
		} else if (null != providerTaxId) {
			
			ProviderGetResponse providerResponseObj = providerService.getProviderByProviderTaxId(provDemoGetReq);
			return buildAndReturnResponse(providerResponseObj, provDemoGetReq.getIncludeCount());
			
		} else if (null != npiId) {
			
			ProviderGetResponse providerResponseObj = providerService.getProviderByProviderNpiId(provDemoGetReq);
			return buildAndReturnResponse(providerResponseObj, provDemoGetReq.getIncludeCount());
			
		} else if (null != provName) {
			
			ProviderGetResponse providerResponseObj = providerService.getProviderByProvName(provDemoGetReq);
			return buildAndReturnResponse(providerResponseObj, provDemoGetReq.getIncludeCount());
			
		} else {
			
			Set<String> errorMessages = new HashSet<>();
			errorMessages.add(INVALID_HEADER_COMBINATION);
			throw new InvalidHeaderCombinationException(errorMessages);
			
		}
	}
	
	private void logIncomingRequestForUpdateProvider(String providerId, String providerIndicator, String providerMultiAddressKey) {
		LogUtils.logAtInfo(log, "providerId: {}, providerIndicator: {}, providerMultiAddressKey: {}", 
				dataMasker.maskProviderId(providerId), providerIndicator, providerMultiAddressKey);
	}
	
	private void logIncomingRequestForCreateProvider(ProviderKeyModelDTO keyDTO , String irsNo) {
		ProviderKeyModelDTO keyDtoObj = keyDTO == null ? new ProviderKeyModelDTO() : keyDTO;
		LogUtils.logAtInfo(log, "pvdInd: {}, prov: {}, multAddressKey: {}, irsNo: {}", keyDtoObj.getPvdInd(), dataMasker.maskProviderId(keyDtoObj.getProv()), keyDtoObj.getMultAddressKey(), dataMasker.maskIrsNo(irsNo));
	}
	
	private void logIncomingRequestForGet(ProviderDemoGetRequest provDemoGetRequest) {
		LogUtils.logAtInfo(log,"providerId: {}, providerIndicator: {}, providerMultiAddressKey: {}, providerTaxId: {}, npiId: {}, limit: {}, offset: {}, statusOrReasonCode: {}, majorClassCode: {}, provName: {}, stateCode: {}, includeCount: {}, checkContract: {}",
				dataMasker.maskProviderId(provDemoGetRequest.getProviderId()),provDemoGetRequest.getProviderIndicator(), provDemoGetRequest.getProviderMultiAddressKey(),
				dataMasker.maskIrsNo(provDemoGetRequest.getProviderTaxId()), dataMasker.maskNpiId(provDemoGetRequest.getNpiId()), provDemoGetRequest.getLimit(), provDemoGetRequest.getOffset(), provDemoGetRequest.getStatusOrReasonCode(),
				provDemoGetRequest.getMajorClassCode(), dataMasker.maskProvName(provDemoGetRequest.getProvName()), provDemoGetRequest.getStateCode(), provDemoGetRequest.getIncludeCount(), provDemoGetRequest.getCheckContract());
	}
	
	private ResponseEntity<List<ProviderModelDTO>> buildAndReturnResponse(ProviderGetResponse providerResponseObj,Boolean includeCount) {
		List<ProviderModelDTO> providerDtos  = providerResponseObj.getProviderDTOs();
			if(null!= includeCount && includeCount) {
				HttpHeaders responseHeaders = new HttpHeaders();
				responseHeaders.set(ProviderDemographicsConstants.TOTAL_DOCS, providerResponseObj.getTotalCount());
				return ResponseEntity.ok().headers(responseHeaders).body(providerDtos);
			}
			return ResponseEntity.ok().body(providerDtos);
	}
}
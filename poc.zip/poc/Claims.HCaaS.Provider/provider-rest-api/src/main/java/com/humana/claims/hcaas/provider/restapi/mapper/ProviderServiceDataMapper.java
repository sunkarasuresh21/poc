package com.humana.claims.hcaas.provider.restapi.mapper;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.attributes.core.model.db.CasName;
import com.humana.claims.hcaas.provider.attributes.core.model.db.PxiZip;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.demographics.core.model.db.NpiInfos;
import com.humana.claims.hcaas.provider.demographics.core.model.db.SpecCode;
import com.humana.claims.hcaas.provider.demographics.core.model.db.TaxonomyCode;
import com.humana.claims.hcaas.provider.model.mq.Prv2OutRecord;
import com.humana.claims.hcaas.provider.model.mq.Prv3OutRecord;
import com.humana.claims.hcaas.provider.model.mq.PrvMaster;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderAttributesCasNameModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderAttributesPxiZipModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderAttributesWithholdDataModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderAttributesWithholdDataWthldCurrentModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderAttributesWithholdDataWthldPriorModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderDemoProviderInfoAddressModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderDemoProviderInfoNpiIdsModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderDemoProviderInfoSpecCodesModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderDemoProviderInfoTaxonomyCodesModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderKeyModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderProviderInfoModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.UpdateProviderModelDTO;
import com.humana.claims.hcaas.provider.restapi.model.datafeed.Prov1DataFeed;
import com.humana.claims.hcaas.provider.restapi.model.datafeed.Prov2DataFeed;
import com.humana.claims.hcaas.provider.restapi.model.datafeed.Prov3DataFeed;

@Component
public class ProviderServiceDataMapper {

	private ProviderServiceDataMapper() {

	}

	/**
	 * Maps the relevant fields of UpdateProviderModelDTO to Attributes
	 * 
	 * @param UpdateProviderModelDTO
	 * @return Attributes
	 */
	public Attributes mapAttributes(UpdateProviderModelDTO updateProviderDTO) {
		Attributes attributes = new Attributes();
		if (null == updateProviderDTO.getProviderAttribute()) {
			return null;
		}

		attributes.setAlphaKey(updateProviderDTO.getProviderAttribute().getAlphaKey());
		attributes.setApplyTaxInd(updateProviderDTO.getProviderAttribute().getApplyTaxInd());
		attributes.setAutoCheckPullInd(updateProviderDTO.getProviderAttribute().getAutoCheckPullInd());
		attributes.setAutoLoadInd(updateProviderDTO.getProviderAttribute().getAutoLoadInd());
		CasName casName = new CasName();
		casName.setFstName(AttributesDataMapperUtil.mapCasFstName(updateProviderDTO));
		casName.setLastName(AttributesDataMapperUtil.mapCasLastName(updateProviderDTO));
		attributes.setCasName(casName);
		attributes.setCheckTo(updateProviderDTO.getProviderAttribute().getCheckTo());
		attributes.setClmChkInd(updateProviderDTO.getProviderAttribute().getClmChkInd());
		attributes.setClpthInd(updateProviderDTO.getProviderAttribute().getClpthInd());
		attributes.setComment1(updateProviderDTO.getProviderAttribute().getComment1());
		attributes.setComment2(updateProviderDTO.getProviderAttribute().getComment2());
		attributes.setComment3(updateProviderDTO.getProviderAttribute().getComment3());
		attributes.setCompbidEffDt(updateProviderDTO.getProviderAttribute().getCompbidEffDt());
		attributes.setCompbidInd(updateProviderDTO.getProviderAttribute().getCompbidInd());
		AttributesDataMapperUtil.mapAttributes2(updateProviderDTO, attributes);
		AttributesDataMapperUtil.mapAttributes3(updateProviderDTO, attributes);
		AttributesDataMapperUtil.mapAttributes4(updateProviderDTO, attributes);

		return attributes;
	}

	/**
	 * Maps the relevant fields of UpdateProviderModelDTO to Demographics
	 * 
	 * @param UpdateProviderModelDTO
	 * @return Demographics
	 */
	public Demographics mapDemographics(UpdateProviderModelDTO updateProviderDTO) {
		Demographics demographics = new Demographics();
		if (null == updateProviderDTO.getProviderDemo()) {
			return null;
		}
		demographics.setKey(DemographicsDataMapperUtil.mapDemographicsKey(updateProviderDTO));
		demographics.setTinEffDt(updateProviderDTO.getProviderDemo().getTinEffDt());
		demographics.setIrsNo(updateProviderDTO.getProviderDemo().getIrsNo());
		demographics.setUpdateSys(updateProviderDTO.getProviderDemo().getUpdateSys());
		demographics.setAlphaKey(updateProviderDTO.getProviderDemo().getAlphaKey());
		demographics.setPvdStatus(updateProviderDTO.getProviderDemo().getProviderInfo() != null
				? updateProviderDTO.getProviderDemo().getProviderInfo().getPvdStatus()
				: null);
		demographics.setProviderInfo(DemographicsDataMapperUtil.mapProviderInfo(updateProviderDTO));
		return demographics;
	}

	public ProviderModelDTO mapProviderDBObjToProviderDTO(Demographics demographics, Attributes attributes,	List<String> lineOfBusiness) {
		ProviderModelDTO providerDTO = new ProviderModelDTO();
		mapDemographicsFields(providerDTO, demographics);
		mapAttributesFields(providerDTO, attributes);
		providerDTO.setCfiExistForLineOfBusiness(lineOfBusiness);
		return providerDTO;
	}

	private void mapAttributesFields(ProviderModelDTO providerDTO, Attributes attributes) {
		providerDTO.setApplyTaxInd(attributes.getApplyTaxInd());
		providerDTO.setAutoCheckPullInd(attributes.getAutoCheckPullInd());
		providerDTO.setAutoLoadInd(attributes.getAutoLoadInd());
		providerDTO.setCasName(mapCasNameDto(attributes));
		providerDTO.setCheckTo(attributes.getCheckTo());
		providerDTO.setClmChkInd(attributes.getClmChkInd());
		providerDTO.setClpthInd(attributes.getClpthInd());
		providerDTO.setComment1(attributes.getComment1());
		providerDTO.setComment2(attributes.getComment2());
		providerDTO.setComment3(attributes.getComment3());
		providerDTO.setCompbidEffDt(attributes.getCompbidEffDt());
		providerDTO.setCompbidInd(attributes.getCompbidInd());
		providerDTO.setCompbidTrmDt(attributes.getCompbidTrmDt());
		providerDTO.setCrossRef(attributes.getCrossRef());
		providerDTO.setDg(attributes.getDg());
		providerDTO.setFacUcZip(attributes.getFacUcZip());
		providerDTO.setFinalstInd(attributes.getFinalstInd());
		providerDTO.setFocusFromDate(attributes.getFocusFromDate());
		providerDTO.setFocusToDate(attributes.getFocusToDate());
		providerDTO.setIrsWithholdInd(attributes.getIrsWithholdInd());
		providerDTO.setMarketId(attributes.getMarketId());
		providerDTO.setMedSuppWaiveInd(attributes.getMedSuppWaiveInd());
		providerDTO.setNotifyInd(attributes.getNotifyInd());
		providerDTO.setPayCycle(attributes.getPayCycle());
		providerDTO.setPendEsc(attributes.getPendEsc());
		providerDTO.setPxiUpdtAdjNo(attributes.getPxiUpdtAdjNo());
		providerDTO.setPxiUpdtDt(attributes.getPxiUpdtDt());
		providerDTO.setPxiZip(mapPxiZipDto(attributes));
		providerDTO.setRadScopeCurrDt(attributes.getRadScopeCurrDt());
		providerDTO.setRadScopeCurrInd(attributes.getRadScopeCurrInd());
		providerDTO.setRadScopeP1Dt(attributes.getRadScopeP1Dt());
		providerDTO.setRadScopeP1Ind(attributes.getRadScopeP1Ind());
		providerDTO.setRadSiteCurrDt(attributes.getRadSiteCurrDt());
		providerDTO.setRadSiteCurrInd(attributes.getRadSiteCurrInd());
		providerDTO.setRadSiteP1Ind(attributes.getRadSiteP1Ind());
		providerDTO.setRadSiteP1Dt(attributes.getRadSiteP1Dt());
		providerDTO.setRadSiteP2Dt(attributes.getRadSiteP2Dt());
		providerDTO.setRadSiteP2Ind(attributes.getRadSiteP2Ind());
		providerDTO.setSend1099Ind(attributes.getSend1099Ind());
		providerDTO.setSend480Ind(attributes.getSend480Ind());
		providerDTO.setSendLtrInd(attributes.getSendLtrInd());
		providerDTO.setSuffixTo(attributes.getSuffixTo());
		providerDTO.setTaxType(attributes.getTaxType());
		providerDTO.setUcZip(attributes.getUcZip());
		providerDTO.setUpdtAdjNo(attributes.getUpdtAdjNo());
		providerDTO.setUpdtDt(attributes.getUpdtDt());
		providerDTO.setVch(attributes.getVch());
		providerDTO.setVendorId(attributes.getVendorId());
		providerDTO.setW9Ind(attributes.getW9Ind());
		providerDTO.setWithholdData(mapWithholdDataDto(attributes));
		providerDTO.setContractPointEnable(attributes.getContractPointEnable());
	}

	private void mapDemographicsFields(ProviderModelDTO providerDTO, Demographics demographics) {
		providerDTO.setIrsNo(demographics.getIrsNo());
		providerDTO.setKey(mapProviderDemoKeyDTO(demographics));
		providerDTO.setAlphaKey(demographics.getAlphaKey());
		providerDTO.setProviderInfo(mapProviderDemoProviderInfoDTO(demographics));
		providerDTO.setTinEffDt(demographics.getTinEffDt());
		providerDTO.setUpdateSys(demographics.getUpdateSys());
	}

	private static ProviderKeyModelDTO mapProviderDemoKeyDTO(Demographics demographics) {
		return new ProviderKeyModelDTO().client(demographics.getKey().getClient())
				.pvdInd(demographics.getKey().getPvdInd()).prov(demographics.getKey().getProv())
				.multAddressKey(demographics.getKey().getMultAddressKey());
	}

	private static ProviderProviderInfoModelDTO mapProviderDemoProviderInfoDTO(Demographics demographics) {
		ProviderProviderInfoModelDTO providerProviderInfoDTO = new ProviderProviderInfoModelDTO();
		if (null == demographics.getProviderInfo()) {
			return providerProviderInfoDTO;
		}
		return providerProviderInfoDTO.provName(demographics.getProviderInfo().getProvName())
				.address(mapProviderDemoProviderInfoAddressDTO(demographics))
				.city(demographics.getProviderInfo().getCity()).st(demographics.getProviderInfo().getSt())
				.zip(demographics.getProviderInfo().getZip()).latitude(demographics.getProviderInfo().getLatitude())
				.longitude(demographics.getProviderInfo().getLongitude())
				.provType(demographics.getProviderInfo().getProvType())
				.majClsCd(demographics.getProviderInfo().getMajClsCd())
				.groupFlag(demographics.getProviderInfo().getGroupFlag())
				.specCodes(mapProviderDemoProviderInfoSpecCodesDTO(demographics))
				.phone(demographics.getProviderInfo().getPhone()).adjNo(demographics.getProviderInfo().getAdjNo())
				.chgDt(demographics.getProviderInfo().getChgDt()).pvdStatus(demographics.getPvdStatus())
				.pvdStRc(demographics.getProviderInfo().getPvdStRc()).active(demographics.getProviderInfo().getActive())
				.archived(demographics.getProviderInfo().getArchived()).noPayCode(mapNoPayCode(demographics))
				.noPayDt(mapNoPayDt(demographics)).npiIds(mapProviderDemoProviderInfoNpiIdsDTO(demographics))
				.taxonomyCodes(mapProviderDemoProviderInfoTaxonomyCodesDTO(demographics));
	}

	private static ProviderDemoProviderInfoAddressModelDTO mapProviderDemoProviderInfoAddressDTO(
			Demographics demographics) {
		ProviderDemoProviderInfoAddressModelDTO providerDemoProviderInfoAddressModelDTO = new ProviderDemoProviderInfoAddressModelDTO();
		providerDemoProviderInfoAddressModelDTO.addr1(null == demographics.getProviderInfo() ? null : mapAddress1(demographics));
		providerDemoProviderInfoAddressModelDTO.addr2(null == demographics.getProviderInfo() ? null : mapAddress2(demographics));
		providerDemoProviderInfoAddressModelDTO.addr3(null == demographics.getProviderInfo() ? null : mapAddress3(demographics));
		providerDemoProviderInfoAddressModelDTO.addr4(null == demographics.getProviderInfo() ? null : mapAddress4(demographics));
		return providerDemoProviderInfoAddressModelDTO;
	}

	private static String mapAddress1(Demographics demographics) {
		return (null == demographics.getProviderInfo().getAddress() ? null: demographics.getProviderInfo().getAddress().getAddr1());
	}

	private static String mapAddress2(Demographics demographics) {
		return (null == demographics.getProviderInfo().getAddress() ? null: demographics.getProviderInfo().getAddress().getAddr2());
	}

	private static String mapAddress3(Demographics demographics) {
		return (null == demographics.getProviderInfo().getAddress() ? null: demographics.getProviderInfo().getAddress().getAddr3());
	}

	private static String mapAddress4(Demographics demographics) {
		return (null == demographics.getProviderInfo().getAddress() ? null: demographics.getProviderInfo().getAddress().getAddr4());
	}

	private static List<ProviderDemoProviderInfoSpecCodesModelDTO> mapProviderDemoProviderInfoSpecCodesDTO(Demographics demographics) {
		List<ProviderDemoProviderInfoSpecCodesModelDTO> specCodeDtos = new ArrayList<>();

		for (SpecCode specCode : demographics.getProviderInfo().getSpecCodes()) {
			specCodeDtos.add(new ProviderDemoProviderInfoSpecCodesModelDTO().specCd(specCode.getSpecCd()));

		}
		return specCodeDtos;
	}

	private static String mapNoPayCode(Demographics demographics) {
		return (null == demographics.getProviderInfo() ? null : demographics.getProviderInfo().getPrvNoPay());
	}

	private static LocalDate mapNoPayDt(Demographics demographics) {
		return (null == demographics.getProviderInfo() ? null : demographics.getProviderInfo().getPrvNoPayDt());
	}

	private static List<ProviderDemoProviderInfoNpiIdsModelDTO> mapProviderDemoProviderInfoNpiIdsDTO(Demographics demographics) {
		List<ProviderDemoProviderInfoNpiIdsModelDTO> npiIdDtos = new ArrayList<>();

		for (NpiInfos npiInfos : demographics.getProviderInfo().getNpiIds()) {
			npiIdDtos.add(new ProviderDemoProviderInfoNpiIdsModelDTO().npiId(npiInfos.getNpiId()));

		}
		return npiIdDtos;
	}

	private static List<ProviderDemoProviderInfoTaxonomyCodesModelDTO> mapProviderDemoProviderInfoTaxonomyCodesDTO(Demographics demographics) {
		List<ProviderDemoProviderInfoTaxonomyCodesModelDTO> taxonomyCodeDtos = new ArrayList<>();

		for (TaxonomyCode taxonomyCode : demographics.getProviderInfo().getTaxonomyCodes()) {
			taxonomyCodeDtos
					.add(new ProviderDemoProviderInfoTaxonomyCodesModelDTO().taxonomyCd(taxonomyCode.getTaxonomyCd()));

		}
		return taxonomyCodeDtos;
	}

	private static ProviderAttributesCasNameModelDTO mapCasNameDto(Attributes attributes) {
		ProviderAttributesCasNameModelDTO casNameDto = new ProviderAttributesCasNameModelDTO();
		casNameDto.casFstName(null == attributes.getCasName() ? null : attributes.getCasName().getFstName());
		casNameDto.casLastName(null == attributes.getCasName() ? null : attributes.getCasName().getLastName());

		return casNameDto;
	}

	private static ProviderAttributesWithholdDataModelDTO mapWithholdDataDto(Attributes attributes) {
		ProviderAttributesWithholdDataModelDTO withHldDataDto = new ProviderAttributesWithholdDataModelDTO();
		withHldDataDto.wthldCurrent(mapWthldCurrentDto(attributes));
		withHldDataDto.wthldPrior(mapWthldPriorDto(attributes));
		withHldDataDto.prTaxfreeAmt(
				null == attributes.getWithholdData() ? null : attributes.getWithholdData().getPrTaxfreeAmt());

		return withHldDataDto;
	}

	private static ProviderAttributesWithholdDataWthldCurrentModelDTO mapWthldCurrentDto(Attributes attributes) {
		ProviderAttributesWithholdDataWthldCurrentModelDTO withHldCurrentDto = new ProviderAttributesWithholdDataWthldCurrentModelDTO();
		withHldCurrentDto.setWthldPerCurrent(null == attributes.getWithholdData() ? null : mapldPerCurrent(attributes));
		withHldCurrentDto
				.setWthldEffDateCurrent(null == attributes.getWithholdData() ? null : mapldEffDateCurrent(attributes));

		return withHldCurrentDto;
	}

	private static String mapldPerCurrent(Attributes attributes) {
		return (null == attributes.getWithholdData().getWthldCurrent() ? null
				: attributes.getWithholdData().getWthldCurrent().getWthldPerCurrent());
	}

	private static LocalDate mapldEffDateCurrent(Attributes attributes) {
		return (null == attributes.getWithholdData().getWthldCurrent() ? null
				: attributes.getWithholdData().getWthldCurrent().getWthldEffDateCurrent());
	}

	private static ProviderAttributesWithholdDataWthldPriorModelDTO mapWthldPriorDto(Attributes attributes) {
		ProviderAttributesWithholdDataWthldPriorModelDTO withHldPriorDto = new ProviderAttributesWithholdDataWthldPriorModelDTO();
		withHldPriorDto.setWthldPerPrior(null == attributes.getWithholdData() ? null : mapldPerPrior(attributes));
		withHldPriorDto
				.setWthldEffDatePrior(null == attributes.getWithholdData() ? null : mapldEffDatePrior(attributes));

		return withHldPriorDto;
	}

	private static String mapldPerPrior(Attributes attributes) {
		return (null == attributes.getWithholdData().getWthldPrior() ? null
				: attributes.getWithholdData().getWthldPrior().getWthldPerPrior());
	}

	private static LocalDate mapldEffDatePrior(Attributes attributes) {
		return (null == attributes.getWithholdData().getWthldPrior() ? null
				: attributes.getWithholdData().getWthldPrior().getWthldEffDatePrior());
	}

	private static List<ProviderAttributesPxiZipModelDTO> mapPxiZipDto(Attributes attributes) {
		List<ProviderAttributesPxiZipModelDTO> pxiZipDtos = new ArrayList<>();

		for (PxiZip pxiZip : attributes.getPxiZip()) {
			ProviderAttributesPxiZipModelDTO pxiZipDto = new ProviderAttributesPxiZipModelDTO();
			pxiZipDto.setPxiZipCode(pxiZip.getPxiZipCode());
			pxiZipDto.setPxiZipInd(pxiZip.getPxiZipInd());
			pxiZipDtos.add(pxiZipDto);
		}
		return pxiZipDtos;
	}

	public Prov1DataFeed mapProv1ForDataFeed(Attributes attributes, Demographics demographics, String requestId,
			String requestClient) {
		Prov1DataFeed prov1DataFeed = new Prov1DataFeed();
		PrvMaster prvMaster = new PrvMaster();
		prov1DataFeed.setRequestId(requestId);
		prov1DataFeed.setRequestClient(requestClient);
		prov1DataFeed.setPrvMaster(prvMaster);
		if ((attributes != null) && (demographics == null)) {
			prvMaster.setPrvKey(Prov1DataFeedMapperUtil.getPrvKey(attributes));
			prvMaster.setPrvIrsNo(attributes.getIrsNo());
			prvMaster.setPrvProviderInfo(Prov1DataFeedMapperUtil.getPrvProviderInfoOfAttributes(attributes));
		}
		if ((attributes == null) && (demographics != null)) {
			prvMaster.setPrvKey(Prov1DataFeedMapperUtil.getPrvKey(demographics));
			prvMaster.setPrvIrsNo(demographics.getIrsNo());
			prvMaster.setPrvPvdStatus(demographics.getPvdStatus());
			prvMaster.setPrvUpdateSys(demographics.getUpdateSys());
			prvMaster.setPrvTinEffDt(null == demographics.getTinEffDt() ? null : demographics.getTinEffDt().toString());
			prvMaster.setPrvProviderInfo(Prov1DataFeedMapperUtil.getPrvProviderInfoOfDemographics(demographics));
		}
		return prov1DataFeed;
	}

	public Prov2DataFeed mapProv2ForDataFeed(Demographics demographics, Attributes attributes, String requestId,
			String requestClient) {
		Prov2DataFeed prov2DataFeed = new Prov2DataFeed();
		Prv2OutRecord prv2OutRecord = new Prv2OutRecord();
		prov2DataFeed.setRequestId(requestId);
		prov2DataFeed.setRequestClient(requestClient);
		prov2DataFeed.setPrv2OutRecord(prv2OutRecord);

		if (demographics == null && attributes != null) {

			prv2OutRecord.setPrv2Key(Prov2DataFeedMapperUtil.getPrv2Key(attributes));
			prv2OutRecord.setPrv2Provider2Info(Prov2DataFeedMapperUtil.getPrv2Provider2InfoOfAttributes(attributes));
		}

		if (demographics != null && attributes == null) {

			prv2OutRecord.setPrv2Key(Prov2DataFeedMapperUtil.getPrv2Key(demographics));
			prv2OutRecord.setPrv2Provider2Info(Prov2DataFeedMapperUtil.getPrv2Provider2InfoOfDemographics(demographics));
		}

		return prov2DataFeed;
	}

	public Prov3DataFeed mapProv3ForDataFeed(Attributes attributes, String requestId, String requestClient) {
		Prov3DataFeed prov3DataFeed = new Prov3DataFeed();
		Prv3OutRecord prv3OutRecord = new Prv3OutRecord();
		prv3OutRecord.setPrv3Key(Prov3DataFeedMapperUtil.getPrv3Key(attributes));
		prv3OutRecord.setPrv3ProvWithholdData(Prov3DataFeedMapperUtil.getPrv3ProvWithholdData(attributes));
		prov3DataFeed.setRequestId(requestId);
		prov3DataFeed.setRequestClient(requestClient);
		prov3DataFeed.setPrv3OutRecord(prv3OutRecord);

		return prov3DataFeed;
	}
}
package com.humana.claims.hcaas.provider.restapi.constants;

public class ProviderErrorConstants {
	
	private ProviderErrorConstants() {}
	
	public static final String INVALID_REQUEST_RECEIVED = "Invalid Request Received";

	public static final String INVALID_PROVIDER_IND = "Invalid Provider-Ind";
	
	public static final String INVALID_PROVIDER_MULTI_ADDRESS_KEY = "Invalid Provider-Multi-Address-Key";
	
	public static final String INVALID_PROVIDER_ID = "Invalid Provider-Id";
	
	public static final String PROVIDER_NOT_FOUND_FOR_UPDATE = "Provider not found for update";
	
	public static final String ACTIVE_ARCHIVED_SHOULD_NOT_BE_SET_BY_CONSUMER = 
			"The fields active and archived should not be set by consumer, they should be derived by system using status code and reason code";

	public static final String KEY_VALUE_UPDATE_ERROR = "Update operation on Key fields[client,pvdInd,prov,multAddressKey] is not allowed";
	
	public static final String UPDATEADJNO_NOT_SENT_ERROR = "UpdtAdjNo cannot be empty or null";
	
	public static final String ADJNO_NOT_SENT_ERROR = "adjNo cannot be empty or null";
	
	public static final String NOT_FOUND = "Record not found";
	
	public static final String PROVIDER_ALREADY_EXISTS = "Provider already exists";
	
	public static final String FAILED_TO_CREATE_PROVIDER = "Failed to Create Provider";
	
	public static final String FAILED_TO_UPDATE_PROVIDER = "Failed to Update Provider";
	
	public static final String CONTRACT_API_FAILED = "Call to Contract API failed";
	
}

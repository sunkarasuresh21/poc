package com.humana.claims.hcaas.provider.restapi.model.datafeed;

import com.humana.claims.hcaas.provider.model.mq.Prv2OutRecord;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@ToString
public class Prov2DataFeed {
	
	private String requestId;
	private String requestClient;
	private Prv2OutRecord prv2OutRecord;
	
}

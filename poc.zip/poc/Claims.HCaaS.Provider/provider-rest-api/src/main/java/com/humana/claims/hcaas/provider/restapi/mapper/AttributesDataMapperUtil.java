package com.humana.claims.hcaas.provider.restapi.mapper;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.attributes.core.model.db.AttributesKey;
import com.humana.claims.hcaas.provider.attributes.core.model.db.PxiZip;
import com.humana.claims.hcaas.provider.attributes.core.model.db.WithholdData;
import com.humana.claims.hcaas.provider.attributes.core.model.db.WthldCurrent;
import com.humana.claims.hcaas.provider.attributes.core.model.db.WthldPrior;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderAttributesPxiZipModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.UpdateProviderModelDTO;

public class AttributesDataMapperUtil {
	
	private AttributesDataMapperUtil() {
		
	}

	public static Attributes mapAttributes2(UpdateProviderModelDTO updateProviderDTO, Attributes attributes) {
		attributes.setCrossRef(updateProviderDTO.getProviderAttribute().getCrossRef());
		attributes.setDg(updateProviderDTO.getProviderAttribute().getDg());
		attributes.setFacUcZip(updateProviderDTO.getProviderAttribute().getFacUcZip());
		attributes.setFinalstInd(updateProviderDTO.getProviderAttribute().getFinalstInd());
		attributes.setFocusFromDate(updateProviderDTO.getProviderAttribute().getFocusFromDate());
		attributes.setFocusToDate(updateProviderDTO.getProviderAttribute().getFocusToDate());
		attributes.setIrsWithholdInd(updateProviderDTO.getProviderAttribute().getIrsWithholdInd());
		attributes.setKey(mapAttributesKey(updateProviderDTO));
		attributes.setMarketId(updateProviderDTO.getProviderAttribute().getMarketId());
		attributes.setMedSuppWaiveInd(updateProviderDTO.getProviderAttribute().getMedSuppWaiveInd());
		attributes.setNotifyInd(updateProviderDTO.getProviderAttribute().getNotifyInd());
		attributes.setPayCycle(updateProviderDTO.getProviderAttribute().getPayCycle());
		attributes.setPendEsc(updateProviderDTO.getProviderAttribute().getPendEsc());
		attributes.setContractPointEnable(updateProviderDTO.getProviderAttribute().getContractPointEnable());
		attributes.setPxiUpdtAdjNo(updateProviderDTO.getProviderAttribute().getPxiUpdtAdjNo());

		return attributes;
	}

	public static Attributes mapAttributes3(UpdateProviderModelDTO updateProviderDTO, Attributes attributes) {
		attributes.setPxiUpdtDt(updateProviderDTO.getProviderAttribute().getPxiUpdtDt());
		attributes.setPxiZip(mapPxiZipList(updateProviderDTO.getProviderAttribute().getPxiZip()));
		attributes.setRadScopeCurrDt(updateProviderDTO.getProviderAttribute().getRadScopeCurrDt());
		attributes.setRadScopeCurrInd(updateProviderDTO.getProviderAttribute().getRadScopeCurrInd());
		attributes.setRadScopeP1Dt(updateProviderDTO.getProviderAttribute().getRadScopeP1Dt());
		attributes.setRadScopeP1Ind(updateProviderDTO.getProviderAttribute().getRadScopeP1Ind());
		attributes.setRadSiteCurrDt(updateProviderDTO.getProviderAttribute().getRadSiteCurrDt());
		attributes.setRadSiteCurrInd(updateProviderDTO.getProviderAttribute().getRadSiteCurrInd());
		attributes.setRadSiteP1Dt(updateProviderDTO.getProviderAttribute().getRadSiteP1Dt());
		attributes.setRadSiteP1Ind(updateProviderDTO.getProviderAttribute().getRadSiteP1Ind());
		attributes.setRadSiteP2Dt(updateProviderDTO.getProviderAttribute().getRadSiteP2Dt());
		attributes.setRadSiteP2Ind(updateProviderDTO.getProviderAttribute().getRadSiteP2Ind());
		attributes.setSend1099Ind(updateProviderDTO.getProviderAttribute().getSend1099Ind());
		attributes.setSend480Ind(updateProviderDTO.getProviderAttribute().getSend480Ind());
		attributes.setSendLtrInd(updateProviderDTO.getProviderAttribute().getSendLtrInd());

		return attributes;
	}

	public static Attributes mapAttributes4(UpdateProviderModelDTO updateProviderDTO, Attributes attributes) {
		attributes.setSuffixTo(updateProviderDTO.getProviderAttribute().getSuffixTo());
		attributes.setTaxType(updateProviderDTO.getProviderAttribute().getTaxType());
		attributes.setUcZip(updateProviderDTO.getProviderAttribute().getUcZip());
		attributes.setUpdtAdjNo(updateProviderDTO.getProviderAttribute().getUpdtAdjNo());
		attributes.setVch(updateProviderDTO.getProviderAttribute().getVch());
		attributes.setIrsNo(
				null == updateProviderDTO.getProviderDemo() ? null : updateProviderDTO.getProviderDemo().getIrsNo());
		attributes.setW9Ind(updateProviderDTO.getProviderAttribute().getW9Ind());
		attributes.setWithholdData(mapWithholdData(updateProviderDTO));
		attributes.setVendorId(updateProviderDTO.getProviderAttribute().getVendorId());
		attributes.setCompbidTrmDt(updateProviderDTO.getProviderAttribute().getCompbidTrmDt());

		return attributes;
	}

	public static String mapCasFstName(UpdateProviderModelDTO updateProviderDTO) {
		return (null == updateProviderDTO.getProviderAttribute().getCasName() ? null
				: updateProviderDTO.getProviderAttribute().getCasName().getCasFstName());
	}

	public static String mapCasLastName(UpdateProviderModelDTO updateProviderDTO) {
		return (null == updateProviderDTO.getProviderAttribute().getCasName() ? null
				: updateProviderDTO.getProviderAttribute().getCasName().getCasLastName());
	}

	/**
	 * Maps UpdateProviderModelDTO to Attributes Key
	 * 
	 * @param UpdateProviderModelDTO
	 * @return Key
	 */
	private static AttributesKey mapAttributesKey(UpdateProviderModelDTO updateProviderDTO) {
		AttributesKey key = new AttributesKey();
		key.setClient(null == updateProviderDTO.getProviderKey() ? null : updateProviderDTO.getProviderKey().getClient());
		key.setMultAddressKey(null == updateProviderDTO.getProviderKey() ? null
				: updateProviderDTO.getProviderKey().getMultAddressKey());
		key.setProv(null == updateProviderDTO.getProviderKey() ? null : updateProviderDTO.getProviderKey().getProv());
		key.setPvdInd(null == updateProviderDTO.getProviderKey() ? null : updateProviderDTO.getProviderKey().getPvdInd());

		return key;
	}

	/**
	 * Maps List<ProviderAttributesPxiZipDTO> to List<PxiZip>
	 * 
	 * @param List<ProviderAttributesPxiZipDTO>
	 * @return List<PxiZip>
	 */
	private static List<PxiZip> mapPxiZipList(List<ProviderAttributesPxiZipModelDTO> pxiZipDtoList) {
		List<PxiZip> pxiZipList = new ArrayList<>();
		if (null != pxiZipDtoList) {
			pxiZipDtoList.forEach(pxiZipDto -> {
				PxiZip pxiZip = new PxiZip();
				pxiZip.setPxiZipCode(pxiZipDto.getPxiZipCode());
				pxiZip.setPxiZipInd(pxiZipDto.getPxiZipInd());
				pxiZipList.add(pxiZip);
			});
		}
		return pxiZipList;
	}

	/**
	 * Maps ProviderAttributesWithholdDataDTO to WithholdData
	 * 
	 * @param ProviderAttributesWithholdDataDTO
	 * @return WithholdData
	 */
	private static WithholdData mapWithholdData(UpdateProviderModelDTO updateProviderDTO) {
		WithholdData withholdData = new WithholdData();
		withholdData.setWthldCurrent(mapWthldCurrent(updateProviderDTO));
		withholdData.setWthldPrior(mapWthldPrior(updateProviderDTO));
		withholdData.setPrTaxfreeAmt(mapPrTaxfreeAmt(updateProviderDTO));

		return withholdData;
	}

	private static String mapPrTaxfreeAmt(UpdateProviderModelDTO updateProviderDTO) {
		return (null == updateProviderDTO.getProviderAttribute().getWithholdData() ? null
				: updateProviderDTO.getProviderAttribute().getWithholdData().getPrTaxfreeAmt());
	}

	/**
	 * Maps ProviderAttributesWithholdDataWthldCurrentDTO to WthldCurrent
	 * 
	 * @param ProviderAttributesWithholdDataWthldCurrentDTO
	 * @return WthldCurrent
	 */
	private static WthldCurrent mapWthldCurrent(UpdateProviderModelDTO updateProviderDTO) {
		WthldCurrent wthldCurrent = new WthldCurrent();
		wthldCurrent.setWthldPerCurrent(mapWthldCurrentDTOWthldPerCurrent(updateProviderDTO));
		wthldCurrent.setWthldEffDateCurrent(mapWthldCurrentDTOWthldEffDateCurrent(updateProviderDTO));

		return wthldCurrent;
	}

	private static String mapWthldCurrentDTOWthldPerCurrent(UpdateProviderModelDTO updateProviderDTO) {
		return (null == updateProviderDTO.getProviderAttribute().getWithholdData() ? null
				: mapWthldPerCurrent(updateProviderDTO));
	}

	private static String mapWthldPerCurrent(UpdateProviderModelDTO updateProviderDTO) {
		return (null == updateProviderDTO.getProviderAttribute().getWithholdData().getWthldCurrent() ? null
				: updateProviderDTO.getProviderAttribute().getWithholdData().getWthldCurrent().getWthldPerCurrent());
	}

	private static LocalDate mapWthldCurrentDTOWthldEffDateCurrent(UpdateProviderModelDTO updateProviderDTO) {
		return (null == updateProviderDTO.getProviderAttribute().getWithholdData() ? null
				: mapWthldEffDateCurrent(updateProviderDTO));
	}

	private static LocalDate mapWthldEffDateCurrent(UpdateProviderModelDTO updateProviderDTO) {
		return (null == updateProviderDTO.getProviderAttribute().getWithholdData().getWthldCurrent() ? null
				: updateProviderDTO.getProviderAttribute().getWithholdData().getWthldCurrent()
						.getWthldEffDateCurrent());
	}

	/**
	 * Maps ProviderAttributesWithholdDataWthldPriorDTO to WthldPrior
	 * 
	 * @param ProviderAttributesWithholdDataWthldPriorDTO
	 * @return WthldPrior
	 */
	private static WthldPrior mapWthldPrior(UpdateProviderModelDTO updateProviderDTO) {
		WthldPrior wthldPrior = new WthldPrior();
		wthldPrior.setWthldPerPrior(mapWthldPriorDTOWthldPerPrior(updateProviderDTO));
		wthldPrior.setWthldEffDatePrior(mapWthldPriorDTOWthldEffDatePrior(updateProviderDTO));

		return wthldPrior;
	}

	private static String mapWthldPriorDTOWthldPerPrior(UpdateProviderModelDTO updateProviderDTO) {
		return (null == updateProviderDTO.getProviderAttribute().getWithholdData() ? null
				: mapWthldPerPrior(updateProviderDTO));
	}

	private static String mapWthldPerPrior(UpdateProviderModelDTO updateProviderDTO) {
		return (null == updateProviderDTO.getProviderAttribute().getWithholdData().getWthldPrior() ? null
				: updateProviderDTO.getProviderAttribute().getWithholdData().getWthldPrior().getWthldPerPrior());
	}

	private static LocalDate mapWthldPriorDTOWthldEffDatePrior(UpdateProviderModelDTO updateProviderDTO) {
		return (null == updateProviderDTO.getProviderAttribute().getWithholdData() ? null
				: mapWthldEffDatePrior(updateProviderDTO));
	}

	private static LocalDate mapWthldEffDatePrior(UpdateProviderModelDTO updateProviderDTO) {
		return (null == updateProviderDTO.getProviderAttribute().getWithholdData().getWthldPrior() ? null
				: updateProviderDTO.getProviderAttribute().getWithholdData().getWthldPrior().getWthldEffDatePrior());
	}
}
package com.humana.claims.hcaas.provider.restapi.validator;

import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.humana.claims.hcaas.provider.restapi.constants.ProviderConstants;
import com.humana.claims.hcaas.provider.restapi.constants.ProviderErrorConstants;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.UpdateProviderModelDTO;
import com.humana.claims.hcaas.provider.demographics.core.constants.ProviderDemographicsConstants;
import com.humana.claims.hcaas.provider.demographics.core.exception.InvalidRequestException;

@Component
public class ProviderValidator {

	public void validateProviderInfoSentForUpdate(UpdateProviderModelDTO updateProviderDTO, String providerIndicator, 
			String providerId, String providerMultiAddressKey) throws InvalidRequestException 
	{	
		Set<String> errorMessages = new HashSet<>();

		validateRequestParameters(providerIndicator, providerId, providerMultiAddressKey, errorMessages);
		validateInputJsonAttributes(updateProviderDTO, errorMessages);
		if(updateProviderDTO.getProviderDemo()!=null) {
			validateProviderInfoActiveandArchivedSentForUpdate(updateProviderDTO, errorMessages);
		}

		if (!errorMessages.isEmpty()) {
			throw new InvalidRequestException(errorMessages);
		}
	}

	private void validateProviderInfoActiveandArchivedSentForUpdate(UpdateProviderModelDTO updateProviderDTO, Set<String> errorMessages) {
		Boolean isArchived = false;
		Boolean isActive = false;
		if(updateProviderDTO.getProviderDemo().getProviderInfo().getActive() != null) {
			isActive = updateProviderDTO.getProviderDemo().getProviderInfo().getActive();
		}
		if(updateProviderDTO.getProviderDemo().getProviderInfo().getArchived() != null) {
			isArchived = updateProviderDTO.getProviderDemo().getProviderInfo().getArchived();
		}
		if(isActive || isArchived) {
			errorMessages.add(ProviderErrorConstants.ACTIVE_ARCHIVED_SHOULD_NOT_BE_SET_BY_CONSUMER);
		}
	}

	private void validateInputJsonAttributes(UpdateProviderModelDTO updateProviderDTO, Set<String> errorMessages) {
		if (updateProviderDTO.getProviderKey() != null) {
			errorMessages.add(ProviderErrorConstants.KEY_VALUE_UPDATE_ERROR);
		}
		if (ObjectUtils.isEmpty(updateProviderDTO.getProviderDemo())
				&& ObjectUtils.isEmpty(updateProviderDTO.getProviderAttribute())) {
			errorMessages.add(ProviderErrorConstants.INVALID_REQUEST_RECEIVED);
		} else {
			if (updateProviderDTO.getProviderDemo() != null
					&& updateProviderDTO.getProviderDemo().getProviderInfo() != null
					&& StringUtils.isBlank(updateProviderDTO.getProviderDemo().getProviderInfo().getAdjNo())) {
				errorMessages.add(ProviderErrorConstants.ADJNO_NOT_SENT_ERROR);
			}

			if (updateProviderDTO.getProviderAttribute() != null
					&& StringUtils.isBlank(updateProviderDTO.getProviderAttribute().getUpdtAdjNo())) {
				errorMessages.add(ProviderErrorConstants.UPDATEADJNO_NOT_SENT_ERROR);
			}
		}
	}

	private void validateRequestParameters(String providerIndicator, String providerId, String providerMultiAddressKey, Set<String> errorMessages) 
	{
		if(!(ProviderConstants.PVD_IND_VALID_VALUE_D.equals(providerIndicator) || ProviderConstants.PVD_IND_VALID_VALUE_H.equals(providerIndicator))) {
			errorMessages.add(ProviderErrorConstants.INVALID_PROVIDER_IND);
		}

		if(null == providerMultiAddressKey || providerMultiAddressKey.length() != 1) {
			errorMessages.add(ProviderErrorConstants.INVALID_PROVIDER_MULTI_ADDRESS_KEY);
		}

		if(null == providerId || !Pattern.matches(".*[1-9].*", providerId)) {
			errorMessages.add(ProviderErrorConstants.INVALID_PROVIDER_ID);
		}
	}

	public boolean isArchived(String pvdStRc, String pvdStatus) {
		return ProviderDemographicsConstants.ARCHIVED_REASON_CODE.equals(pvdStRc)
				&& ProviderDemographicsConstants.ARCHIVED_STATUS_CODE.equals(pvdStatus);
	}
	
	public boolean isActive(String pvdStRc, String pvdStatus) {
		return isStatusInactiveWithExceptionalReasonCode(pvdStRc, pvdStatus) || isStatusAndReasonCodeActive(pvdStRc, pvdStatus);
	}
	
	private boolean isStatusAndReasonCodeActive(String pvdStRc, String pvdStatus) {
		return ((pvdStatus.equals("0") || pvdStatus.equals(" ")) && pvdStRc.equals(" "));
	}

	private boolean isStatusInactiveWithExceptionalReasonCode(String pvdStRc, String pvdStatus) {
		return (pvdStatus.equals("1") && ProviderDemographicsConstants.listOfReasonCodes.contains(pvdStRc));
	}

	public void validateInputRequestForPostOperation(UpdateProviderModelDTO updateProviderDTO) throws InvalidRequestException {
		Set<String> errorMessages = new HashSet<>();
		if(null == updateProviderDTO 
				|| null == updateProviderDTO.getProviderKey() 
				|| null == updateProviderDTO.getProviderAttribute()
				|| null == updateProviderDTO.getProviderDemo()) {
			errorMessages.add(ProviderErrorConstants.INVALID_REQUEST_RECEIVED);
		}
		if(null != updateProviderDTO) {
			validateActiveArchived(updateProviderDTO, errorMessages);
		}

		if (!errorMessages.isEmpty()) {
			throw new InvalidRequestException(errorMessages);
		}
	}
	private void validateActiveArchived(UpdateProviderModelDTO updateProviderDTO, Set<String> errorMessages) {
		if(updateProviderDTO.getProviderDemo().getProviderInfo().getActive() != null || updateProviderDTO.getProviderDemo().getProviderInfo().getArchived() != null) {
			errorMessages.add(ProviderErrorConstants.ACTIVE_ARCHIVED_SHOULD_NOT_BE_SET_BY_CONSUMER);
		}
	}
}
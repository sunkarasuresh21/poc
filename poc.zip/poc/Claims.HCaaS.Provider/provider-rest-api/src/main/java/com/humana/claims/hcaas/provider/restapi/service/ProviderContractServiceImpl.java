package com.humana.claims.hcaas.provider.restapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import com.humana.claims.hcaas.provider.contract.restclient.gen.openapi.ProviderContractApi;
import com.humana.claims.hcaas.provider.contract.restclient.gen.openapi.model.ContractSearchRequestDTO;
import com.humana.claims.hcaas.provider.contract.restclient.gen.openapi.model.ContractSearchResponseDTO;
import com.humana.claims.hcaas.provider.restapi.constants.ProviderErrorConstants;
import com.humana.claims.hcaas.provider.restapi.exception.ProviderContractDataRetrieveException;

@Service
public class ProviderContractServiceImpl implements ProviderContractService{

	private ProviderContractApi providerContractApi;
	private String providerContractApiURL;
	
	@Autowired
	public ProviderContractServiceImpl(ProviderContractApi providerContractApi, @Value("${provider.active.contract.api.url}") String providerContractApiURL) {
		this.providerContractApi = providerContractApi;
		this.providerContractApiURL = providerContractApiURL;
	}
	
	@Override
	public List<ContractSearchResponseDTO> getActiveContracts(List<ContractSearchRequestDTO> contractSearchRequestDTO) {
		try {
			providerContractApi.getApiClient().setBasePath(providerContractApiURL);
			return providerContractApi.searchActiveContracts(contractSearchRequestDTO);
		} catch (HttpClientErrorException | HttpServerErrorException ex) {
			throw new ProviderContractDataRetrieveException(ProviderErrorConstants.CONTRACT_API_FAILED, ex);
		}
	}
}
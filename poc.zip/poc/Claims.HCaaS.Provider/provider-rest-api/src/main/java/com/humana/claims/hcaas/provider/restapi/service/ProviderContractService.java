package com.humana.claims.hcaas.provider.restapi.service;

import java.util.List;

import com.humana.claims.hcaas.provider.contract.restclient.gen.openapi.model.ContractSearchRequestDTO;
import com.humana.claims.hcaas.provider.contract.restclient.gen.openapi.model.ContractSearchResponseDTO;

public interface ProviderContractService {

	public List<ContractSearchResponseDTO> getActiveContracts(List<ContractSearchRequestDTO> contractSearchRequestDTO);
	
}

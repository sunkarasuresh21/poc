package com.humana.claims.hcaas.provider.restapi.service.datafeed;

import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.humana.claims.hcaas.provider.restapi.exception.DataFeedException;
import com.humana.claims.hcaas.provider.restapi.model.datafeed.Prov3DataFeed;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class Prov3DataFeederImpl implements ProviderDataFeeder<Prov3DataFeed> {

	private final JmsTemplate jmsTemplate;
	
	private final String queueName;
	
	private final ObjectMapper objectToJsonConverter = new ObjectMapper().registerModule(new JavaTimeModule())
			.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
	
	@Override
	public void sendToQueue(Prov3DataFeed prov3DataFeed) throws DataFeedException {
		try {
			String dataChangesToQueue = objectToJsonConverter.writeValueAsString(prov3DataFeed);
			this.jmsTemplate.convertAndSend(queueName, dataChangesToQueue);
		} catch (JsonProcessingException | JmsException e) {
			throw new DataFeedException(e);
		}
	}
}
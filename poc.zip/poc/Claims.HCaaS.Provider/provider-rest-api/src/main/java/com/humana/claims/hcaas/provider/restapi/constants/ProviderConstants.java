package com.humana.claims.hcaas.provider.restapi.constants;

public class ProviderConstants {
	
	private ProviderConstants() {}

	public static final String PVD_IND_VALID_VALUE_D = "D";
	
	public static final String PVD_IND_VALID_VALUE_H = "H";
	
	public static final String PROVIDER_CREATED_SUCCESSFULLY = "Provider Created Successfully";
	
	public static final String PROVIDER_UPDATED_SUCCESSFULLY = "Provider Updated Successfully";
	
	public static final String SUCCESS = "Success";
	
	public static final String PROVIDER_NOT_FOUND = "Provider not found using request input";
	
	public static final int LIST_VALUE_1 = 1;
	public static final int LIST_VALUE_2 = 2;
	public static final int LIST_VALUE_3 = 3;
	public static final int LIST_VALUE_4 = 4;
	public static final int LIST_VALUE_5 = 5;
	public static final int LIST_VALUE_6 = 6;
	public static final int LIST_VALUE_7 = 7;
	public static final int LIST_VALUE_8 = 8;
	public static final int LIST_VALUE_9 = 9;
	public static final int LIST_VALUE_10 = 10;
	public static final int LIST_VALUE_11 = 11;
	public static final int LIST_VALUE_12 = 12;
	public static final int LIST_VALUE_13 = 13;
	public static final int LIST_VALUE_14 = 14;
	public static final int LIST_VALUE_15 = 15;
	public static final int LIST_VALUE_16 = 16;
	public static final int LIST_VALUE_17 = 17;
	public static final int LIST_VALUE_18 = 18;
	public static final int LIST_VALUE_19 = 19;
	public static final int LIST_VALUE_20 = 20;
}
package com.humana.claims.hcaas.provider.restapi.model;

import java.util.List;

import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderModelDTO;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Getter
@Setter
@ToString
public class ProviderGetResponse {
	private String  totalCount;
	private List<ProviderModelDTO> providerDTOs;
}


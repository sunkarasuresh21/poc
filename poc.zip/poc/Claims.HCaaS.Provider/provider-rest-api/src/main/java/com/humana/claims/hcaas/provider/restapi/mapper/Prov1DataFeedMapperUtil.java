package com.humana.claims.hcaas.provider.restapi.mapper;

import java.util.List;

import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.demographics.core.model.db.Demographics;
import com.humana.claims.hcaas.provider.demographics.core.model.db.SpecCode;
import com.humana.claims.hcaas.provider.model.mq.PrvAddress;
import com.humana.claims.hcaas.provider.model.mq.PrvCheckToAixKey;
import com.humana.claims.hcaas.provider.model.mq.PrvKey;
import com.humana.claims.hcaas.provider.model.mq.PrvPriorInfo;
import com.humana.claims.hcaas.provider.model.mq.PrvProvCasNameGfld;
import com.humana.claims.hcaas.provider.model.mq.PrvProviderInfo;
import static com.humana.claims.hcaas.provider.restapi.constants.ProviderConstants.*;

public class Prov1DataFeedMapperUtil {

	private Prov1DataFeedMapperUtil() {
		
	}
	
	static PrvKey getPrvKey(Attributes attributes) {
		PrvKey prvKey = new PrvKey();
		prvKey.setPrvClient(null == attributes.getKey() ? null : attributes.getKey().getClient());
		prvKey.setPrvMultAddressKey(null == attributes.getKey() ? null : attributes.getKey().getMultAddressKey());
		prvKey.setPrvProv(null == attributes.getKey() ? null : attributes.getKey().getProv());
		prvKey.setPrvPvdInd(null == attributes.getKey() ? null : attributes.getKey().getPvdInd());

		return prvKey;
	}

	static PrvProviderInfo getPrvProviderInfoOfDemographics(Demographics demographics) {
		PrvProviderInfo prvProviderInfo = new PrvProviderInfo();
		prvProviderInfo.setPrvAdjNo(demographics.getProviderInfo().getAdjNo());
		prvProviderInfo.setPrvAlphaKey(demographics.getAlphaKey());
		prvProviderInfo.setPrvGroupFlag(demographics.getProviderInfo().getGroupFlag());
		prvProviderInfo.setPrvMajClsCd(demographics.getProviderInfo().getMajClsCd());
		prvProviderInfo.setPrvChgDt(null == demographics.getProviderInfo().getChgDt() ? null
				: demographics.getProviderInfo().getChgDt().toString());
		prvProviderInfo.setPrvCity(demographics.getProviderInfo().getCity());
		prvProviderInfo.setPrvZip(demographics.getProviderInfo().getZip());
		prvProviderInfo.setPrvLatitiude(null == demographics.getProviderInfo().getLatitude() ? null :demographics.getProviderInfo().getLatitude().toString());
		prvProviderInfo.setPrvLongitude(null == demographics.getProviderInfo().getLongitude() ? null :demographics.getProviderInfo().getLongitude().toString());
		prvProviderInfo.setPrvPhone(demographics.getProviderInfo().getPhone());
		prvProviderInfo.setPrvPriorInfo(getPrvPriorInfo(demographics));
		prvProviderInfo.setPrvAddress(getPrvAddress(demographics));
		prvProviderInfo.setPrvProvType(demographics.getProviderInfo().getProvType());
		prvProviderInfo.setPrvSt(demographics.getProviderInfo().getSt());
		mapSpecCode(prvProviderInfo, demographics.getProviderInfo().getSpecCodes());
		return prvProviderInfo;
	}

	private static PrvProviderInfo mapSpecCode(PrvProviderInfo prvProviderInfo, List<SpecCode> specCdList) {
		if (null != specCdList) {
			prvProviderInfo.setPrvSpecCd(mapspecCd(specCdList.size(), LIST_VALUE_1, specCdList));
			prvProviderInfo.setPrvSpec1Cd(mapspecCd(specCdList.size(), LIST_VALUE_2, specCdList));
			prvProviderInfo.setPrvSpec2Cd(mapspecCd(specCdList.size(), LIST_VALUE_3, specCdList));
			prvProviderInfo.setPrvSpec3Cd(mapspecCd(specCdList.size(), LIST_VALUE_4, specCdList));
		}
		return prvProviderInfo;
	}

	private static String mapspecCd(int size, int num, List<SpecCode> specCdList) {
		return size < num ? null : specCdList.get(num - 1).getSpecCd();
	}
	
	static PrvProviderInfo getPrvProviderInfoOfAttributes(Attributes attributes) {
		PrvProviderInfo prvProviderInfo = new PrvProviderInfo();
		prvProviderInfo.setPrvProvCasNameGfld(getPrvProvCasNameGfld(attributes));
		prvProviderInfo.setPrvComment(attributes.getComment1());
		prvProviderInfo.setPrvClmChkInd(attributes.getClmChkInd());
		prvProviderInfo.setPrvClpthInd(attributes.getClpthInd());
		prvProviderInfo.setPrvCrossRef(attributes.getCrossRef());
		prvProviderInfo.setPrvDg(attributes.getDg());
		prvProviderInfo.setPrvFocusFromDate(
				null == attributes.getFocusFromDate() ? null : attributes.getFocusFromDate().toString());
		prvProviderInfo
				.setPrvFocusToDate(null == attributes.getFocusToDate() ? null : attributes.getFocusToDate().toString());
		prvProviderInfo.setPrvAutoCheckPullInd(attributes.getAutoCheckPullInd());
		prvProviderInfo.setPrvAutoLoadInd(attributes.getAutoLoadInd());
		prvProviderInfo.setPrvMarketId(attributes.getMarketId());
		prvProviderInfo.setPrvMedSuppWaiveInd(attributes.getMedSuppWaiveInd());
		prvProviderInfo.setPrvIrsWithholdInd(attributes.getIrsWithholdInd());
		prvProviderInfo.setPrvNotifyInd(attributes.getNotifyInd());
		prvProviderInfo.setPrvPayCycle(attributes.getPayCycle());
		prvProviderInfo.setPrvPendEsc(attributes.getPendEsc());
		prvProviderInfo.setPrvSend1099Ind(attributes.getSend1099Ind());
		prvProviderInfo.setPrvUcZip(attributes.getUcZip());
		prvProviderInfo.setPrvVch(attributes.getVch());
		prvProviderInfo.setPrvTaxType(attributes.getTaxType());
		prvProviderInfo.setPrvCheckToAixKey(getPrvCheckToAixKey(attributes));

		return prvProviderInfo;
	}

	private static PrvAddress getPrvAddress(Demographics demographics) {
		PrvAddress prvAddress = new PrvAddress();
		prvAddress.setPrvAddr1(demographics.getProviderInfo().getAddress().getAddr1());
		prvAddress.setPrvAddr2(demographics.getProviderInfo().getAddress().getAddr2());
		prvAddress.setPrvAddr3(demographics.getProviderInfo().getAddress().getAddr3());
		prvAddress.setPrvAddr4(demographics.getProviderInfo().getAddress().getAddr4());

		return prvAddress;
	}

	private static PrvProvCasNameGfld getPrvProvCasNameGfld(Attributes attributes) {
		PrvProvCasNameGfld prvProvCasNameGfld = new PrvProvCasNameGfld();
		prvProvCasNameGfld.setPrvProvCasFstName(mapCasFstName(attributes));
		prvProvCasNameGfld.setPrvProvCasLastName(mapCasLastName(attributes));

		return prvProvCasNameGfld;
	}

	private static String mapCasFstName(Attributes attributes) {
		return (null == attributes.getCasName() ? null : attributes.getCasName().getFstName());
	}

	private static String mapCasLastName(Attributes attributes) {
		return (null == attributes.getCasName() ? null : attributes.getCasName().getLastName());
	}

	private static PrvPriorInfo getPrvPriorInfo(Demographics demographics) {
		PrvPriorInfo prvPriorInfo = new PrvPriorInfo();
		prvPriorInfo.setPrvNoPay(demographics.getProviderInfo().getPrvNoPay());
		prvPriorInfo.setPrvNoPayDt(null == demographics.getProviderInfo().getPrvNoPayDt() ? null
				: demographics.getProviderInfo().getPrvNoPayDt().toString());

		return prvPriorInfo;
	}

	private static PrvCheckToAixKey getPrvCheckToAixKey(Attributes attributes) {
		PrvCheckToAixKey prvCheckToAixKey = new PrvCheckToAixKey();
		prvCheckToAixKey.setPrvCheckTo(attributes.getCheckTo());
		prvCheckToAixKey.setPrvSuffixTo(attributes.getSuffixTo());

		return prvCheckToAixKey;
	}

	static PrvKey getPrvKey(Demographics demographics) {
		PrvKey prvKey = new PrvKey();
		prvKey.setPrvClient(null == demographics.getKey() ? null : demographics.getKey().getClient());
		prvKey.setPrvMultAddressKey(null == demographics.getKey() ? null : demographics.getKey().getMultAddressKey());
		prvKey.setPrvProv(null == demographics.getKey() ? null : demographics.getKey().getProv());
		prvKey.setPrvPvdInd(null == demographics.getKey() ? null : demographics.getKey().getPvdInd());

		return prvKey;
	}
}
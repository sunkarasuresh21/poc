package com.humana.claims.hcaas.provider.restapi.exception;

import java.util.Set;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
@AllArgsConstructor
public final class NotFoundException extends Exception {
	
	private static final long serialVersionUID = 1L;
	private final Set<String> errorMessages;

}

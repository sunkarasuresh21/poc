package com.humana.claims.hcaas.provider.restapi.mapper;

import java.util.ArrayList;
import java.util.List;

import com.humana.claims.hcaas.provider.demographics.core.model.db.Address;
import com.humana.claims.hcaas.provider.demographics.core.model.db.DemographicsKey;
import com.humana.claims.hcaas.provider.demographics.core.model.db.NpiInfos;
import com.humana.claims.hcaas.provider.demographics.core.model.db.ProviderInfo;
import com.humana.claims.hcaas.provider.demographics.core.model.db.SpecCode;
import com.humana.claims.hcaas.provider.demographics.core.model.db.TaxonomyCode;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderDemoProviderInfoNpiIdsModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderDemoProviderInfoSpecCodesModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.ProviderDemoProviderInfoTaxonomyCodesModelDTO;
import com.humana.claims.hcaas.provider.restapi.gen.openapi.model.UpdateProviderModelDTO;

public class DemographicsDataMapperUtil {
	
	private DemographicsDataMapperUtil() {
		
	}

	/**
	 * Maps UpdateProviderModelDTO to Demographics Key
	 * 
	 * @param UpdateProviderModelDTO
	 * @return Key
	 */
	static DemographicsKey mapDemographicsKey(UpdateProviderModelDTO updateProviderDTO) {
		DemographicsKey key = new DemographicsKey();
		key.setClient(null == updateProviderDTO.getProviderKey() ? null : updateProviderDTO.getProviderKey().getClient());
		key.setMultAddressKey(null == updateProviderDTO.getProviderKey() ? null
				: updateProviderDTO.getProviderKey().getMultAddressKey());
		key.setProv(null == updateProviderDTO.getProviderKey() ? null : updateProviderDTO.getProviderKey().getProv());
		key.setPvdInd(null == updateProviderDTO.getProviderKey() ? null : updateProviderDTO.getProviderKey().getPvdInd());

		return key;
	}

	/**
	 * Maps UpdateProviderModelDTO to ProviderInfo
	 * 
	 * @param UpdateProviderModelDTO
	 * @return ProviderInfo
	 */
	static ProviderInfo mapProviderInfo(UpdateProviderModelDTO updateProviderDTO) {
		ProviderInfo providerInfo = new ProviderInfo();
		if (null == updateProviderDTO.getProviderDemo().getProviderInfo()) {
			return providerInfo;
		}
		providerInfo.setProvName(updateProviderDTO.getProviderDemo().getProviderInfo().getProvName());
		providerInfo.setAddress(mapAddress(updateProviderDTO));
		providerInfo.setCity(updateProviderDTO.getProviderDemo().getProviderInfo().getCity());
		providerInfo.setSt(updateProviderDTO.getProviderDemo().getProviderInfo().getSt());
		providerInfo.setZip(updateProviderDTO.getProviderDemo().getProviderInfo().getZip());
		providerInfo.setLatitude(updateProviderDTO.getProviderDemo().getProviderInfo().getLatitude());
		providerInfo.setLongitude(updateProviderDTO.getProviderDemo().getProviderInfo().getLongitude());
		providerInfo.setProvType(updateProviderDTO.getProviderDemo().getProviderInfo().getProvType());
		providerInfo.setMajClsCd(updateProviderDTO.getProviderDemo().getProviderInfo().getMajClsCd());
		providerInfo.setGroupFlag(updateProviderDTO.getProviderDemo().getProviderInfo().getGroupFlag());
		providerInfo
				.setSpecCodes(mapSpecCodeList(updateProviderDTO.getProviderDemo().getProviderInfo().getSpecCodes()));
		providerInfo.setPhone(updateProviderDTO.getProviderDemo().getProviderInfo().getPhone());
		providerInfo.setAdjNo(updateProviderDTO.getProviderDemo().getProviderInfo().getAdjNo());
		providerInfo.setPvdStRc(updateProviderDTO.getProviderDemo().getProviderInfo().getPvdStRc());
		providerInfo.setActive(updateProviderDTO.getProviderDemo().getProviderInfo().getActive());
		providerInfo.setArchived(updateProviderDTO.getProviderDemo().getProviderInfo().getArchived());
		providerInfo.setPrvNoPay(updateProviderDTO.getProviderDemo().getProviderInfo().getNoPayCode());
		providerInfo.setPrvNoPayDt(updateProviderDTO.getProviderDemo().getProviderInfo().getNoPayDt());
		providerInfo.setNpiIds(mapNpiIdList(updateProviderDTO.getProviderDemo().getProviderInfo().getNpiIds()));
		providerInfo.setTaxonomyCodes(
				mapTaxonomyCodeList(updateProviderDTO.getProviderDemo().getProviderInfo().getTaxonomyCodes()));

		return providerInfo;
	}

	/**
	 * Maps UpdateProviderModelDTO to Address
	 * 
	 * @param UpdateProviderModelDTO
	 * @return Address
	 */
	private static Address mapAddress(UpdateProviderModelDTO updateProviderDTO) {
		Address address = new Address();
		address.setAddr1(updateProviderDTO.getProviderDemo().getProviderInfo().getAddress().getAddr1());
		address.setAddr2(updateProviderDTO.getProviderDemo().getProviderInfo().getAddress().getAddr2());
		address.setAddr3(updateProviderDTO.getProviderDemo().getProviderInfo().getAddress().getAddr3());
		address.setAddr4(updateProviderDTO.getProviderDemo().getProviderInfo().getAddress().getAddr4());

		return address;
	}

	/**
	 * Maps List<ProviderDemoProviderInfoSpecCodesDTO> to List<SpecCode>
	 * 
	 * @param List<ProviderDemoProviderInfoSpecCodesDTO>
	 * @return List<SpecCode>
	 */
	private static List<SpecCode> mapSpecCodeList(List<ProviderDemoProviderInfoSpecCodesModelDTO> specCodeDtoList) {
		List<SpecCode> specCodelist = new ArrayList<>();
		if (null != specCodeDtoList) {
			specCodeDtoList.forEach(specCodeDto -> {
				SpecCode specCode = new SpecCode();
				specCode.setSpecCd(specCodeDto.getSpecCd());
				specCodelist.add(specCode);
			});
		}
		return specCodelist;
	}

	/**
	 * Maps List<ProviderDemoProviderInfoNpiIdsDTO> to List<NpiId>
	 * 
	 * @param List<ProviderDemoProviderInfoNpiIdsDTO>
	 * @return List<NpiId>
	 */
	private static List<NpiInfos> mapNpiIdList(List<ProviderDemoProviderInfoNpiIdsModelDTO> npiIdDtoList) {
		List<NpiInfos> npiIdList = new ArrayList<>();
		if (null != npiIdDtoList) {
			npiIdDtoList.forEach(npiIdDto -> {
				NpiInfos npiInfos = new NpiInfos();
				npiInfos.setNpiId(npiIdDto.getNpiId());
				npiIdList.add(npiInfos);
			});
		}
		return npiIdList;
	}

	/**
	 * Maps List<ProviderDemoProviderInfoTaxonomyCodesDTO> to List<TaxonomyCode>
	 * 
	 * @param List<ProviderDemoProviderInfoTaxonomyCodesDTO>
	 * @return List<TaxonomyCode>
	 */
	private static List<TaxonomyCode> mapTaxonomyCodeList(
			List<ProviderDemoProviderInfoTaxonomyCodesModelDTO> taxonomyCodeDtoList) {
		List<TaxonomyCode> taxonomyCodeList = new ArrayList<>();
		if (null != taxonomyCodeDtoList) {
			taxonomyCodeDtoList.forEach(taxonomyCodeDto -> {
				TaxonomyCode taxonomyCode = new TaxonomyCode();
				taxonomyCode.setTaxonomyCd(taxonomyCodeDto.getTaxonomyCd());
				taxonomyCodeList.add(taxonomyCode);
			});
		}
		return taxonomyCodeList;
	}
}
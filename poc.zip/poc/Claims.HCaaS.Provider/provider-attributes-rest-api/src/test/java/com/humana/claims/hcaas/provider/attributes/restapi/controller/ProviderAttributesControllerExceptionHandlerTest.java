package com.humana.claims.hcaas.provider.attributes.restapi.controller;
import static com.humana.claims.hcaas.provider.attributes.restapi.constants.ProviderAttributesErrorConstants.INVALID_PROVIDER_ID;
import static com.humana.claims.hcaas.provider.attributes.restapi.constants.ProviderAttributesErrorConstants.NO_RECORD_FOUND;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.humana.claims.hcaas.common.rest.api.starter.enumerrorcode.ErrorCode;
import com.humana.claims.hcaas.provider.attributes.core.mapper.ProviderAttrGetRequest;
import com.humana.claims.hcaas.provider.attributes.core.masker.ProviderAttributesDataMasker;
import com.humana.claims.hcaas.provider.attributes.restapi.exception.InvalidRequestException;
import com.humana.claims.hcaas.provider.attributes.restapi.exception.NotFoundException;
import com.humana.claims.hcaas.provider.attributes.restapi.service.ProviderAttributesService;
import com.humana.claims.hcaas.provider.attributes.restapi.validator.ProviderValidator;

import lombok.SneakyThrows;

@ExtendWith(SpringExtension.class)
@WebMvcTest(ProviderAttributesController.class)
@TestPropertySource("classpath:test-application.properties")
public class ProviderAttributesControllerExceptionHandlerTest {

		@Autowired
		private MockMvc mockMvc;
		
		@MockBean
		private ProviderAttributesService providerAtrributesService;
		
		@MockBean
		private ProviderValidator providerValidator;
		
		@MockBean
		private ProviderAttributesDataMasker dataMasker;
		
		@Test
		@SneakyThrows
		public void test_v1BetaProviderAttributeWhenInvalidHeaderExceptionPassed() {	

			this.mockMvc.perform(get("/v1/providers/attributes")).andDo(print()).andExpect(status().isBadRequest())
			.andExpect(MockMvcResultMatchers.jsonPath("$.errorCode").value(ErrorCode.BAD_REQUEST.toString()));
		}
		
		@Test
		@SneakyThrows
		public void test_v1BetaProviderAtrributeWhenItThrowsNotFoundException() {
			Set<String> errorMessagesSet = new HashSet<>();
			errorMessagesSet.add(NO_RECORD_FOUND);
			
			when(providerAtrributesService.getAttributesByProviderId(any(ProviderAttrGetRequest.class))).thenThrow(new NotFoundException(errorMessagesSet));

			this.mockMvc.perform(get("/v1/providers/attributes").header("provider-id", "999999999")).andDo(print())  
	        .andExpect(status().isBadRequest())
	        .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode").value(ErrorCode.NOT_FOUND.toString()));
		}
		
		@Test
		@SneakyThrows
		public void test_v1BetaProviderAtrributeWhenInvalidRequestPassed() {
			Set<String> errorMessagesSet = new HashSet<>();
			errorMessagesSet.add(INVALID_PROVIDER_ID);
			
			when(providerAtrributesService.getAttributesByProviderId(any(ProviderAttrGetRequest.class))).thenThrow(new InvalidRequestException(errorMessagesSet));
			
			this.mockMvc.perform(get("/v1/providers/attributes").header("provider-id", "123")).andDo(print())  
	        .andExpect(status().isBadRequest())
	        .andExpect(MockMvcResultMatchers.jsonPath("$.errorCode").value(ErrorCode.BAD_REQUEST.toString()));
		}
		
	@Test
	@SneakyThrows
	public void test_v1BetaProviderAtrributeWhenIllegalAccessException() {
		when(providerAtrributesService.getAttributesByProviderId(
				any(ProviderAttrGetRequest.class)))
						.thenThrow(new InternalError());

		this.mockMvc.perform(get("/v1/providers/attributes").header("provider-id", "999999999")).andDo(print())
				.andExpect(status().isInternalServerError())
				.andExpect(MockMvcResultMatchers.jsonPath("$.errorCode").value(ErrorCode.INTERNAL_ERROR.toString()));
	}
}

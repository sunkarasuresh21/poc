package com.humana.claims.hcaas.provider.attributes.restapi.validator;

import static com.humana.claims.hcaas.provider.attributes.restapi.constants.ProviderAttributesErrorConstants.INVALID_FIRST_NAME;
import static com.humana.claims.hcaas.provider.attributes.restapi.constants.ProviderAttributesErrorConstants.INVALID_PROVIDER_ID;
import static com.humana.claims.hcaas.provider.attributes.restapi.constants.ProviderAttributesErrorConstants.INVALID_PROVIDER_IND;
import static com.humana.claims.hcaas.provider.attributes.restapi.constants.ProviderAttributesErrorConstants.INVALID_PROVIDER_MULTI_ADDRESS_KEY;
import static com.humana.claims.hcaas.provider.attributes.restapi.constants.ProviderAttributesErrorConstants.INVALID_TAX_ID;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Set;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.humana.claims.hcaas.provider.attributes.restapi.exception.InvalidRequestException;

@ExtendWith(MockitoExtension.class)
class ProviderValidatorTest {

	@InjectMocks
	ProviderValidator providerValidator;

    @Test
    void testWithAllValidValues() {
		try {
			providerValidator.validateProviderAttributesDataForPATCHandGET("H", "000000011", "1", "FIRST NAME");
		} catch (InvalidRequestException e) {
			Assertions.fail("Exception Not Expected");
		}
    }

	@Test
	void testInvalidProviderIDInvalidFirstNameAndValidProviderIndAndValidMultiAddressKey() {
		try {
			providerValidator.validateProviderAttributesDataForPATCHandGET("H","testPatch","t", "12345");
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(INVALID_PROVIDER_ID));
			assertTrue(errors.contains(INVALID_FIRST_NAME));
			assertFalse(errors.contains(INVALID_PROVIDER_IND));
			assertFalse(errors.contains(INVALID_PROVIDER_MULTI_ADDRESS_KEY));
		}
	}
	
	@Test
	void testNullProviderIDAndValidProviderIndAndValidMultiAddressKeyAndNullFirstName() {
		try {
			providerValidator.validateProviderAttributesDataForPATCHandGET("H",null,"t", null);
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(INVALID_PROVIDER_ID));
			assertFalse(errors.contains(INVALID_PROVIDER_IND));
			assertFalse(errors.contains(INVALID_PROVIDER_MULTI_ADDRESS_KEY));
			assertFalse(errors.contains(INVALID_FIRST_NAME));
		}
	}
	
	@Test
	void testProviderIDNotWith9DigitValueAndValidProviderIndAndValidMultiAddressKeyAndFirstNameMoreThanLength20() {
		try {
			providerValidator.validateProviderAttributesDataForPATCHandGET("H","12345","t","First Name with length more than 20");
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(INVALID_PROVIDER_ID));
			assertFalse(errors.contains(INVALID_PROVIDER_IND));
			assertFalse(errors.contains(INVALID_PROVIDER_MULTI_ADDRESS_KEY));
			assertTrue(errors.contains(INVALID_FIRST_NAME));
		}
	}
	
	@Test
	void testProviderINDWithNullValueAndValidProviderIndAndValidMultiAddressKeyAndValidFirstName() {
		try {
			providerValidator.validateProviderAttributesDataForPATCHandGET(null,"000000011","t","FIRST NAME");
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertFalse(errors.contains(INVALID_PROVIDER_ID));
			assertTrue(errors.contains(INVALID_PROVIDER_IND));
			assertFalse(errors.contains(INVALID_PROVIDER_MULTI_ADDRESS_KEY));
			assertFalse(errors.contains(INVALID_FIRST_NAME));
		}
	}
	
	@Test
	void testInvalidNullMultiAddresskeyAndValidProviderIDAndValidProviderIndAndValidFirstName() {
		try {
			providerValidator.validateProviderAttributesDataForPATCHandGET("D","000000011",null,"First Name");
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(INVALID_PROVIDER_MULTI_ADDRESS_KEY));
			assertFalse(errors.contains(INVALID_PROVIDER_ID));
			assertFalse(errors.contains(INVALID_PROVIDER_IND));
			assertFalse(errors.contains(INVALID_FIRST_NAME));
		}
	}
	
	@Test
	void testInvalidMultiAddresskeyWithLengthGreaterThan1AndFirstNameWithSpecialCharacters() {
		try {
			providerValidator.validateProviderAttributesDataForPATCHandGET("D","000000011","test", "First N@me.");
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(INVALID_PROVIDER_MULTI_ADDRESS_KEY));
			assertTrue(errors.contains(INVALID_FIRST_NAME));
		}
	}
	
	@Test
	void testInvalidProviderIndAndValidProviderIDAndValidMultiAddressKeyAndValidFirstName() {
		try {
			providerValidator.validateProviderAttributesDataForPATCHandGET("S","000000011","t", "Alpha Key");
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(INVALID_PROVIDER_IND));
			assertFalse(errors.contains(INVALID_PROVIDER_MULTI_ADDRESS_KEY));
			assertFalse(errors.contains(INVALID_PROVIDER_ID));
			assertFalse(errors.contains(INVALID_FIRST_NAME));
		}
	}
	

	@Test
	void testInvalidProviderIDAndValidFirstNameForGET() {
		try {
			providerValidator.validateProviderAttributesProviderIdForGET("32456", "Alpha key");
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(INVALID_PROVIDER_ID));
			assertFalse(errors.contains(INVALID_FIRST_NAME));
		}
	}
	
	@Test
	void testInvalidProviderIDPatternAndValidFirstNameForGET() {
		try {
			providerValidator.validateProviderAttributesProviderIdForGET("testPatch","alpha key");
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(INVALID_PROVIDER_ID));
			assertFalse(errors.contains(INVALID_FIRST_NAME));
		}
	}
	
	@Test
	void testInvalidTaxIDAndValidFirstNameForGET() {
		try {
			providerValidator.validateProviderAttributesTaxIdForGET("32456", "AlPhA KeY");
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(INVALID_TAX_ID));
			assertFalse(errors.contains(INVALID_FIRST_NAME));
		}
	}
	
	@Test
	void testInvalidTaxIDPatternAndFirstNameisValidForBlankStringForGET() {
		try {
			providerValidator.validateProviderAttributesTaxIdForGET("testPatch","");
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(INVALID_TAX_ID));
			assertFalse(errors.contains(INVALID_FIRST_NAME));
		}
	}
	
	@Test
	void testInvalidProviderIDandIndicatorAndInvalidAlphaNumericFirstNameForGET() {
		try {
			providerValidator.validateProviderAttributesProviderIdAndProviderIndicatorForGET("32456","A","Alpha12345");
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(INVALID_PROVIDER_ID));
			assertTrue(errors.contains(INVALID_PROVIDER_IND));
			assertTrue(errors.contains(INVALID_FIRST_NAME));
		}
	}	
	
	@Test
	void testInvalidPatternProviderIDandIndicatorAndValidFirstNameForGET() {
		try {
			providerValidator.validateProviderAttributesProviderIdAndProviderIndicatorForGET("testPatch","A","First Name");
		} catch (InvalidRequestException e) {
			Set<String> errors = e.getErrorMessages();
			assertTrue(errors.contains(INVALID_PROVIDER_ID));
			assertTrue(errors.contains(INVALID_PROVIDER_IND));
			assertFalse(errors.contains(INVALID_FIRST_NAME));
		}
	}
}

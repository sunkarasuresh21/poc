package com.humana.claims.hcaas.provider.attributes.restapi.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.mockito.ArgumentMatchers.any;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.humana.claims.hcaas.provider.attributes.core.dao.ProviderAttributesDAO;
import com.humana.claims.hcaas.provider.attributes.core.mapper.ProviderAttrGetRequest;
import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.attributes.core.model.db.CasName;
import com.humana.claims.hcaas.provider.attributes.core.model.db.AttributesKey;
import com.humana.claims.hcaas.provider.attributes.core.model.db.PxiZip;
import com.humana.claims.hcaas.provider.attributes.core.model.db.WithholdData;
import com.humana.claims.hcaas.provider.attributes.core.model.db.WthldCurrent;
import com.humana.claims.hcaas.provider.attributes.core.model.db.WthldPrior;
import com.humana.claims.hcaas.provider.attributes.restapi.exception.InvalidRequestException;
import com.humana.claims.hcaas.provider.attributes.restapi.exception.NotFoundException;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesCasNameDTO;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesDTO;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesKeyDTO;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesPxiZipDTO;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesWithholdDataDTO;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesWithholdDataWthldCurrentDTO;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesWithholdDataWthldPriorDTO;
import com.humana.claims.hcaas.provider.attributes.restapi.mapper.ProviderAttributesDataMapper;
import com.humana.claims.hcaas.provider.attributes.restapi.validator.ProviderValidator;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
public class ProviderAttributesServiceImplTest {

	@InjectMocks
	private ProviderAttributesServiceImpl classUnderTest;

	@Mock
	private ProviderAttributesDAO providerAttributesDAO;
		
	@Mock
	private ProviderValidator providerValidator;
	
	@Mock
	private ProviderAttributesDataMapper attributesDataMapper;
	
	@Test
	@SneakyThrows
	public void testNotFoundExceptionForGetAttributesByProviderIdMultiAddressKeyAndIndicator() {
		Mockito.when((providerAttributesDAO.getAttributesByProviderIdMultiAddressKeyAndIndicator(any(ProviderAttrGetRequest.class)))).thenReturn(null);
		
		Throwable actualThrown = catchThrowable(() -> classUnderTest.
				getAttributesByProviderIdMultiAddressKeyAndIndicator(createProvAttrGetReqObj()));
		
		assertThat(actualThrown)
 	   		   .isInstanceOf(NotFoundException.class);
	}
	
	@Test
	@SneakyThrows
	public void testNotFoundExceptionForGetAttributesByProviderTaxId() {
		Mockito.when((providerAttributesDAO.getAttributesByProviderTaxId(any(ProviderAttrGetRequest.class)))).thenReturn(null);

		Throwable actualThrown = catchThrowable(() -> classUnderTest.getAttributesByProviderTaxId(createProvAttrGetReqObj()));
		
		assertThat(actualThrown)
 		   .isInstanceOf(NotFoundException.class);
	}
	
	@Test
	@SneakyThrows
	public void testNotFoundExceptionForGetAttributesByProviderId() {
		Mockito.when((providerAttributesDAO.getAttributesByProviderId(any(ProviderAttrGetRequest.class)))).thenReturn(null);

		Throwable actualThrown = catchThrowable(() -> classUnderTest.getAttributesByProviderId(createProvAttrGetReqObj()));
		
		assertThat(actualThrown)
		   .isInstanceOf(NotFoundException.class);
	}
	
	@Test
	@SneakyThrows
	public void testNotFoundExceptionForGetAttributesByProviderIdAndIndicator() {
		Mockito.when((providerAttributesDAO.getAttributesByProviderIdAndIndicator(any(ProviderAttrGetRequest.class)))).thenReturn(null);

		Throwable actualThrown = catchThrowable(() -> classUnderTest.getAttributesByProviderIdAndIndicator(createProvAttrGetReqObj()));
		
		assertThat(actualThrown)
		   .isInstanceOf(NotFoundException.class);
	}
	
	@Test
	@SneakyThrows
	public void testGetAttributesByProviderIdMultiAddressKeyAndIndicator() {
		Attributes attributes = createAttributes();
		List<Attributes> attributesList = new ArrayList<>();
		attributesList.add(attributes);
		Mockito.when((providerAttributesDAO.getAttributesByProviderIdMultiAddressKeyAndIndicator(any(ProviderAttrGetRequest.class)))).thenReturn(attributesList);
		Mockito.when(attributesDataMapper.mapProviderAttributesDto(any())).thenReturn(createProviderAttributesDto());

		List<ProviderAttributesDTO> actual = classUnderTest
				.getAttributesByProviderIdMultiAddressKeyAndIndicator(createProvAttrGetReqObj());

		assertionsForGetAttributesByProviderIdMultiAddressKeyAndIndicator(actual, attributes);
	}
	
	@Test
	@SneakyThrows
	public void testGetAttributesTotalDocumentsByProviderIdMultiAddressKeyAndIndicatorWithTotalCount() {
		
		String totaldocs = "10";
		Mockito.when((providerAttributesDAO.getAttributesTotalDocumentsByProviderIdMultiAddressKeyAndIndicator(any(ProviderAttrGetRequest.class)))).thenReturn(totaldocs);

		String actual = classUnderTest
				.getAttributesTotalDocumentsByProviderIdMultiAddressKeyAndIndicator(createProvAttrGetReqObj());

		assertThat(actual).isEqualTo(totaldocs);
	}
	
	@Test
	public void testGetAttributesByProviderIdAndIndicator() throws InvalidRequestException, NotFoundException {
		Attributes attributes = createAttributes();
		List<Attributes> attributesList = new ArrayList<>();
		attributesList.add(attributes);
		Mockito.when((providerAttributesDAO.getAttributesByProviderIdAndIndicator(any(ProviderAttrGetRequest.class)))).thenReturn(attributesList);
		Mockito.when(attributesDataMapper.mapProviderAttributesDto(any())).thenReturn(createProviderAttributesDto());

		List<ProviderAttributesDTO> actual = classUnderTest
				.getAttributesByProviderIdAndIndicator(createProvAttrGetReqObj());

		assertionsForGetAttributes(actual, attributesList);
	}
	
	@Test
	@SneakyThrows
	public void testGetAttributesTotalDocumentsByProviderIdAndIndicatorWithTotalCount() {
		
		String totaldocs = "10";
		Mockito.when((providerAttributesDAO.getAttributesTotalDocumentsByProviderIdAndIndicator(any(ProviderAttrGetRequest.class)))).thenReturn(totaldocs);

		String actual = classUnderTest
				.getAttributesTotalDocumentsByProviderIdAndIndicator(createProvAttrGetReqObj());

		assertThat(actual).isEqualTo(totaldocs);
	}

	@Test
	@SneakyThrows
	public void testGetAttributesByProviderTaxId() {
		Attributes attributes = createAttributes();
		List<Attributes> attributesList = new ArrayList<>();
		attributesList.add(attributes);
		Mockito.when(providerAttributesDAO.getAttributesByProviderTaxId(any(ProviderAttrGetRequest.class))).thenReturn(attributesList);
		Mockito.when(attributesDataMapper.mapProviderAttributesDto(any())).thenReturn(createProviderAttributesDto());

		List<ProviderAttributesDTO> actual = classUnderTest.getAttributesByProviderTaxId(createProvAttrGetReqObj());

		assertionsForGetAttributes(actual, attributesList);
	}
	
	@Test
	@SneakyThrows
	public void testGetAttributesByProviderTaxIdWithTotalCount() {
		
		String totaldocs = "10";
		Mockito.when((providerAttributesDAO.getAttributesTotalDocumentsByProviderIdTaxId(any(ProviderAttrGetRequest.class)))).thenReturn(totaldocs);

		String actual = classUnderTest
				.getAttributesTotalDocumentsByProviderIdTaxId(createProvAttrGetReqObj());

		assertThat(actual).isEqualTo(totaldocs);
	}

	@Test
	@SneakyThrows
	public void testGetAttributesByProviderId() {
		Attributes attributes = createAttributes();
		List<Attributes> attributesList = new ArrayList<>();
		attributesList.add(attributes);
		Mockito.when((providerAttributesDAO.getAttributesByProviderId(any(ProviderAttrGetRequest.class)))).thenReturn(attributesList);
		Mockito.when(attributesDataMapper.mapProviderAttributesDto(any())).thenReturn(createProviderAttributesDto());

		List<ProviderAttributesDTO> actual = classUnderTest.getAttributesByProviderId(createProvAttrGetReqObj());

		assertionsForGetAttributes(actual, attributesList);
	}
	
	@Test
	@SneakyThrows
	public void testGetAttributesByProviderIdWithTotalCount() {		
		String totaldocs = "10";
		Mockito.when((providerAttributesDAO.getAttributesTotalDocumentsByProviderId(any(ProviderAttrGetRequest.class)))).thenReturn(totaldocs);

		String actual = classUnderTest
				.getAttributesTotalDocumentsByProviderId(createProvAttrGetReqObj());

		assertThat(actual).isEqualTo(totaldocs);
	}
	
	private void assertionsForGetAttributesByProviderIdMultiAddressKeyAndIndicator(List<ProviderAttributesDTO> actual, Attributes attributes) {

		assertThat(actual.get(0).getKey().getClient()).isEqualTo(attributes.getKey().getClient());
		assertThat(actual.get(0).getKey().getPvdInd()).isEqualTo(attributes.getKey().getPvdInd());
		assertThat(actual.get(0).getKey().getProv()).isEqualTo(attributes.getKey().getProv());
		assertThat(actual.get(0).getKey().getMultAddressKey()).isEqualTo(attributes.getKey().getMultAddressKey());

		assertThat(actual.get(0).getIrsNo()).isEqualTo(attributes.getIrsNo());

		assertThat(actual.get(0).getVch()).isEqualTo(attributes.getVch());

		assertThat(actual.get(0).getTaxType()).isEqualTo(attributes.getTaxType());

		assertThat(actual.get(0).getSend1099Ind()).isEqualTo(attributes.getSend1099Ind());

		assertThat(actual.get(0).getPendEsc()).isEqualTo(attributes.getPendEsc());

		assertThat(actual.get(0).getAutoCheckPullInd()).isEqualTo(attributes.getAutoCheckPullInd());

		assertThat(actual.get(0).getIrsWithholdInd()).isEqualTo(attributes.getIrsWithholdInd());

		assertThat(actual.get(0).getPayCycle()).isEqualTo(attributes.getPayCycle());

		assertThat(actual.get(0).getCrossRef()).isEqualTo(attributes.getCrossRef());

		assertThat(actual.get(0).getMarketId()).isEqualTo(attributes.getMarketId());

		assertThat(actual.get(0).getDg()).isEqualTo(attributes.getDg());

		assertThat(actual.get(0).getAlphaKey()).isEqualTo(attributes.getAlphaKey());

		assertThat(actual.get(0).getCasName().getCasFstName()).isEqualTo(attributes.getCasName().getFstName());
		assertThat(actual.get(0).getCasName().getCasLastName()).isEqualTo(attributes.getCasName().getLastName());

		assertThat(actual.get(0).getMedSuppWaiveInd()).isEqualTo(attributes.getMedSuppWaiveInd());

		assertThat(actual.get(0).getComment1()).isEqualTo(attributes.getComment1());
		
		assertThat(actual.get(0).getComment2()).isEqualTo(attributes.getComment2());
		
		assertThat(actual.get(0).getComment3()).isEqualTo(attributes.getComment3());

		assertThat(actual.get(0).getNotifyInd()).isEqualTo(attributes.getNotifyInd());

		assertThat(actual.get(0).getFocusFromDate()).isEqualTo(attributes.getFocusFromDate());

		assertThat(actual.get(0).getClpthInd()).isEqualTo(attributes.getClpthInd());

		assertThat(actual.get(0).getClmChkInd()).isEqualTo(attributes.getClmChkInd());

		assertThat(actual.get(0).getUcZip()).isEqualTo(attributes.getUcZip());

		assertThat(actual.get(0).getFocusToDate()).isEqualTo(attributes.getFocusToDate());

		assertThat(actual.get(0).getAutoLoadInd()).isEqualTo(attributes.getAutoLoadInd());

		assertThat(actual.get(0).getCheckTo()).isEqualTo(attributes.getCheckTo());

		assertThat(actual.get(0).getSuffixTo()).isEqualTo(attributes.getSuffixTo());

		assertThat(actual.get(0).getApplyTaxInd()).isEqualTo(attributes.getApplyTaxInd());

		assertThat(actual.get(0).getW9Ind()).isEqualTo(attributes.getW9Ind());

		assertThat(actual.get(0).getSend480Ind()).isEqualTo(attributes.getSend480Ind());

		assertThat(actual.get(0).getWithholdData().getWthldCurrent().getWthldPerCurrent()).isEqualTo(attributes.getWithholdData().getWthldCurrent().getWthldPerCurrent());
		assertThat(actual.get(0).getWithholdData().getWthldCurrent().getWthldEffDateCurrent()).isEqualTo(attributes.getWithholdData().getWthldCurrent().getWthldEffDateCurrent());
		assertThat(actual.get(0).getWithholdData().getWthldPrior().getWthldPerPrior()).isEqualTo(attributes.getWithholdData().getWthldPrior().getWthldPerPrior());
		assertThat(actual.get(0).getWithholdData().getWthldPrior().getWthldEffDatePrior()).isEqualTo(attributes.getWithholdData().getWthldPrior().getWthldEffDatePrior());
		assertThat(actual.get(0).getWithholdData().getPrTaxfreeAmt()).isEqualTo(attributes.getWithholdData().getPrTaxfreeAmt());

		assertThat(actual.get(0).getUpdtAdjNo()).isEqualTo(attributes.getUpdtAdjNo());

		assertThat(actual.get(0).getRadSiteCurrInd()).isEqualTo(attributes.getRadSiteCurrInd());

		assertThat(actual.get(0).getRadSiteCurrDt()).isEqualTo(attributes.getRadSiteCurrDt());

		assertThat(actual.get(0).getRadSiteP1Ind()).isEqualTo(attributes.getRadSiteP1Ind());

		assertThat(actual.get(0).getRadSiteP1Dt()).isEqualTo(attributes.getRadSiteP1Dt());

		assertThat(actual.get(0).getRadSiteP2Ind()).isEqualTo(attributes.getRadSiteP2Ind());

		assertThat(actual.get(0).getRadSiteP2Dt()).isEqualTo(attributes.getRadSiteP2Dt());

		assertThat(actual.get(0).getRadScopeCurrInd()).isEqualTo(attributes.getRadScopeCurrInd());

		assertThat(actual.get(0).getRadScopeCurrDt()).isEqualTo(attributes.getRadScopeCurrDt());

		assertThat(actual.get(0).getRadScopeP1Ind()).isEqualTo(attributes.getRadScopeP1Ind());

		assertThat(actual.get(0).getRadScopeP1Dt()).isEqualTo(attributes.getRadScopeP1Dt());

		assertThat(actual.get(0).getFacUcZip()).isEqualTo(attributes.getFacUcZip());

		assertThat(actual.get(0).getPxiUpdtAdjNo()).isEqualTo(attributes.getPxiUpdtAdjNo());

		assertThat(actual.get(0).getPxiUpdtDt()).isEqualTo(attributes.getPxiUpdtDt());

		assertThat(actual.get(0).getSendLtrInd()).isEqualTo(attributes.getSendLtrInd());

		assertThat(actual.get(0).getFinalstInd()).isEqualTo(attributes.getFinalstInd());

		assertThat(actual.get(0).getPxiZip().get(0).getPxiZipCode()).isEqualTo(attributes.getPxiZip().get(0).getPxiZipCode());
		assertThat(actual.get(0).getPxiZip().get(0).getPxiZipInd()).isEqualTo(attributes.getPxiZip().get(0).getPxiZipInd());

		assertThat(actual.get(0).getCompbidInd()).isEqualTo(attributes.getCompbidInd());
		
		assertThat(actual.get(0).getVendorId()).isEqualTo(attributes.getVendorId());

		assertThat(actual.get(0).getCompbidEffDt()).isEqualTo(attributes.getCompbidEffDt());

		assertThat(actual.get(0).getCompbidTrmDt()).isEqualTo(attributes.getCompbidTrmDt());

		assertThat(actual.get(0).getContractPointEnable()).isEqualTo(attributes.getContractPointEnable());

	}

	private void assertionsForGetAttributes(List<ProviderAttributesDTO> actual, List<Attributes> attributesList) {

		assertThat(actual.get(0).getKey().getClient()).isEqualTo(attributesList.get(0).getKey().getClient());
		assertThat(actual.get(0).getKey().getPvdInd()).isEqualTo(attributesList.get(0).getKey().getPvdInd());
		assertThat(actual.get(0).getKey().getProv()).isEqualTo(attributesList.get(0).getKey().getProv());
		assertThat(actual.get(0).getKey().getMultAddressKey()).isEqualTo(attributesList.get(0).getKey().getMultAddressKey());

		assertThat(actual.get(0).getIrsNo()).isEqualTo(attributesList.get(0).getIrsNo());

		assertThat(actual.get(0).getVch()).isEqualTo(attributesList.get(0).getVch());

		assertThat(actual.get(0).getTaxType()).isEqualTo(attributesList.get(0).getTaxType());

		assertThat(actual.get(0).getSend1099Ind()).isEqualTo(attributesList.get(0).getSend1099Ind());

		assertThat(actual.get(0).getPendEsc()).isEqualTo(attributesList.get(0).getPendEsc());

		assertThat(actual.get(0).getAutoCheckPullInd()).isEqualTo(attributesList.get(0).getAutoCheckPullInd());

		assertThat(actual.get(0).getIrsWithholdInd()).isEqualTo(attributesList.get(0).getIrsWithholdInd());

		assertThat(actual.get(0).getPayCycle()).isEqualTo(attributesList.get(0).getPayCycle());

		assertThat(actual.get(0).getCrossRef()).isEqualTo(attributesList.get(0).getCrossRef());

		assertThat(actual.get(0).getMarketId()).isEqualTo(attributesList.get(0).getMarketId());

		assertThat(actual.get(0).getDg()).isEqualTo(attributesList.get(0).getDg());

		assertThat(actual.get(0).getAlphaKey()).isEqualTo(attributesList.get(0).getAlphaKey());

		assertThat(actual.get(0).getCasName().getCasFstName()).isEqualTo(attributesList.get(0).getCasName().getFstName());
		assertThat(actual.get(0).getCasName().getCasLastName()).isEqualTo(attributesList.get(0).getCasName().getLastName());

		assertThat(actual.get(0).getMedSuppWaiveInd()).isEqualTo(attributesList.get(0).getMedSuppWaiveInd());

		assertThat(actual.get(0).getComment1()).isEqualTo(attributesList.get(0).getComment1());
		
		assertThat(actual.get(0).getComment2()).isEqualTo(attributesList.get(0).getComment2());
		
		assertThat(actual.get(0).getComment3()).isEqualTo(attributesList.get(0).getComment3());

		assertThat(actual.get(0).getNotifyInd()).isEqualTo(attributesList.get(0).getNotifyInd());

		assertThat(actual.get(0).getFocusFromDate()).isEqualTo(attributesList.get(0).getFocusFromDate());

		assertThat(actual.get(0).getClpthInd()).isEqualTo(attributesList.get(0).getClpthInd());

		assertThat(actual.get(0).getClmChkInd()).isEqualTo(attributesList.get(0).getClmChkInd());

		assertThat(actual.get(0).getUcZip()).isEqualTo(attributesList.get(0).getUcZip());

		assertThat(actual.get(0).getFocusToDate()).isEqualTo(attributesList.get(0).getFocusToDate());

		assertThat(actual.get(0).getAutoLoadInd()).isEqualTo(attributesList.get(0).getAutoLoadInd());

		assertThat(actual.get(0).getCheckTo()).isEqualTo(attributesList.get(0).getCheckTo());

		assertThat(actual.get(0).getSuffixTo()).isEqualTo(attributesList.get(0).getSuffixTo());

		assertThat(actual.get(0).getApplyTaxInd()).isEqualTo(attributesList.get(0).getApplyTaxInd());

		assertThat(actual.get(0).getW9Ind()).isEqualTo(attributesList.get(0).getW9Ind());

		assertThat(actual.get(0).getSend480Ind()).isEqualTo(attributesList.get(0).getSend480Ind());

		assertThat(actual.get(0).getWithholdData().getWthldCurrent().getWthldPerCurrent()).isEqualTo(attributesList.get(0).getWithholdData().getWthldCurrent().getWthldPerCurrent());
		assertThat(actual.get(0).getWithholdData().getWthldCurrent().getWthldEffDateCurrent()).isEqualTo(attributesList.get(0).getWithholdData().getWthldCurrent().getWthldEffDateCurrent());
		assertThat(actual.get(0).getWithholdData().getWthldPrior().getWthldPerPrior()).isEqualTo(attributesList.get(0).getWithholdData().getWthldPrior().getWthldPerPrior());
		assertThat(actual.get(0).getWithholdData().getWthldPrior().getWthldEffDatePrior()).isEqualTo(attributesList.get(0).getWithholdData().getWthldPrior().getWthldEffDatePrior());
		assertThat(actual.get(0).getWithholdData().getPrTaxfreeAmt()).isEqualTo(attributesList.get(0).getWithholdData().getPrTaxfreeAmt());

		assertThat(actual.get(0).getUpdtAdjNo()).isEqualTo(attributesList.get(0).getUpdtAdjNo());
		
		assertThat(actual.get(0).getRadSiteCurrInd()).isEqualTo(attributesList.get(0).getRadSiteCurrInd());

		assertThat(actual.get(0).getRadSiteCurrDt()).isEqualTo(attributesList.get(0).getRadSiteCurrDt());

		assertThat(actual.get(0).getRadSiteP1Ind()).isEqualTo(attributesList.get(0).getRadSiteP1Ind());

		assertThat(actual.get(0).getRadSiteP1Dt()).isEqualTo(attributesList.get(0).getRadSiteP1Dt());

		assertThat(actual.get(0).getRadSiteP2Ind()).isEqualTo(attributesList.get(0).getRadSiteP2Ind());

		assertThat(actual.get(0).getRadSiteP2Dt()).isEqualTo(attributesList.get(0).getRadSiteP2Dt());

		assertThat(actual.get(0).getRadScopeCurrInd()).isEqualTo(attributesList.get(0).getRadScopeCurrInd());

		assertThat(actual.get(0).getRadScopeCurrDt()).isEqualTo(attributesList.get(0).getRadScopeCurrDt());

		assertThat(actual.get(0).getRadScopeP1Ind()).isEqualTo(attributesList.get(0).getRadScopeP1Ind());

		assertThat(actual.get(0).getRadScopeP1Dt()).isEqualTo(attributesList.get(0).getRadScopeP1Dt());

		assertThat(actual.get(0).getFacUcZip()).isEqualTo(attributesList.get(0).getFacUcZip());

		assertThat(actual.get(0).getPxiUpdtAdjNo()).isEqualTo(attributesList.get(0).getPxiUpdtAdjNo());

		assertThat(actual.get(0).getPxiUpdtDt()).isEqualTo(attributesList.get(0).getPxiUpdtDt());

		assertThat(actual.get(0).getSendLtrInd()).isEqualTo(attributesList.get(0).getSendLtrInd());

		assertThat(actual.get(0).getFinalstInd()).isEqualTo(attributesList.get(0).getFinalstInd());

		assertThat(actual.get(0).getPxiZip().get(0).getPxiZipCode()).isEqualTo(attributesList.get(0).getPxiZip().get(0).getPxiZipCode());
		assertThat(actual.get(0).getPxiZip().get(0).getPxiZipInd()).isEqualTo(attributesList.get(0).getPxiZip().get(0).getPxiZipInd());

		assertThat(actual.get(0).getCompbidInd()).isEqualTo(attributesList.get(0).getCompbidInd());
		
		assertThat(actual.get(0).getVendorId()).isEqualTo(attributesList.get(0).getVendorId());

		assertThat(actual.get(0).getCompbidEffDt()).isEqualTo(attributesList.get(0).getCompbidEffDt());

		assertThat(actual.get(0).getCompbidTrmDt()).isEqualTo(attributesList.get(0).getCompbidTrmDt());

		assertThat(actual.get(0).getContractPointEnable()).isEqualTo(attributesList.get(0).getContractPointEnable());

	}

	private LocalDate dateInStringToLocalDate(String dateInString) {
		if(dateInString == null || dateInString == "") {
			return LocalDate.now();
		}
		else {
			Instant instant = Instant.parse(dateInString);
			LocalDateTime dateTime = LocalDateTime.ofInstant(instant, ZoneId.of(ZoneOffset.UTC.getId()));
			LocalDate localDate = dateTime.toLocalDate();
			return localDate;
		}
	}
	
	private ProviderAttributesDTO createProviderAttributesDto() {
		ProviderAttributesDTO providerAttributesDto = new ProviderAttributesDTO();
		providerAttributesDto.setKey(createKeyDto("30", "H", "542", " "));
		providerAttributesDto.setIrsNo("999999999");
		providerAttributesDto.setVch("K");
		providerAttributesDto.setTaxType("");
		providerAttributesDto.setSend1099Ind("N");
		providerAttributesDto.setPendEsc("");
		providerAttributesDto.setAutoCheckPullInd("N");
		providerAttributesDto.setIrsWithholdInd("");
		providerAttributesDto.setPayCycle("");
		providerAttributesDto.setCrossRef("0");
		providerAttributesDto.setMarketId("0");
		providerAttributesDto.setDg("");
		providerAttributesDto.setAlphaKey("PALMS OF PASADENA HO");
		providerAttributesDto.setCasName(createProvCasNameGfldDto("", ""));
		providerAttributesDto.setMedSuppWaiveInd("");
		providerAttributesDto.setComment1("Comment1");
		providerAttributesDto.setComment2("Comment2");
		providerAttributesDto.setComment3("Comment3");
		providerAttributesDto.setNotifyInd("N");
		providerAttributesDto.setFocusFromDate(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		providerAttributesDto.setClpthInd("");
		providerAttributesDto.setClmChkInd("");
		providerAttributesDto.setUcZip("");
		providerAttributesDto.setFocusToDate(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		providerAttributesDto.setAutoLoadInd("");
		providerAttributesDto.setCheckTo("");
		providerAttributesDto.setSuffixTo("");
		providerAttributesDto.setApplyTaxInd("");
		providerAttributesDto.setW9Ind("");
		providerAttributesDto.setSend480Ind("");
		providerAttributesDto.setWithholdData(createWithholdDataAttribute(dateInStringToLocalDate("2012-09-30T00:00:00Z"),"110.00",dateInStringToLocalDate("2012-09-30T00:00:00Z"),"9.00"," "));
		providerAttributesDto.setUpdtAdjNo("");
		providerAttributesDto.setRadSiteCurrInd("");
		providerAttributesDto.setRadSiteCurrDt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		providerAttributesDto.setRadSiteP1Ind("");
		providerAttributesDto.setRadSiteP1Dt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		providerAttributesDto.setRadSiteP2Ind("");
		providerAttributesDto.setRadSiteP2Dt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		providerAttributesDto.setRadScopeCurrInd("");
		providerAttributesDto.setRadScopeCurrDt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		providerAttributesDto.setRadScopeP1Ind("");
		providerAttributesDto.setRadScopeP1Dt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		providerAttributesDto.setFacUcZip("");
		providerAttributesDto.setPxiUpdtAdjNo("");
		providerAttributesDto.setPxiUpdtDt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		providerAttributesDto.setSendLtrInd("");
		providerAttributesDto.setFinalstInd("");
		providerAttributesDto.setPxiZip(createPxiZipDto("40245", "A"));
		providerAttributesDto.setCompbidInd("");
		providerAttributesDto.setVendorId("12345");
		providerAttributesDto.setCompbidEffDt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		providerAttributesDto.setCompbidTrmDt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		providerAttributesDto.setContractPointEnable(buildContractPointEnableMap());
		
		return providerAttributesDto;
	}
	private ProviderAttributesKeyDTO createKeyDto(String client, String pvdInd, String prov, String multAddressKey) {
		ProviderAttributesKeyDTO keyDto = new ProviderAttributesKeyDTO();
		keyDto.setClient(client);
		keyDto.setPvdInd(pvdInd);
		keyDto.setProv(prov);
		keyDto.setMultAddressKey(multAddressKey);
		
		return keyDto;
	}
	private ProviderAttributesCasNameDTO createProvCasNameGfldDto(String firstName, String lastName) {
		ProviderAttributesCasNameDTO casNameDto = new ProviderAttributesCasNameDTO();
		casNameDto.setCasFstName(firstName);
		casNameDto.setCasLastName(lastName);
		
		return casNameDto;
	}
	private List<ProviderAttributesPxiZipDTO> createPxiZipDto(String zipCode, String zipInd) {
		List<ProviderAttributesPxiZipDTO> PxiZips = new ArrayList<>();
		ProviderAttributesPxiZipDTO pxiZip = new ProviderAttributesPxiZipDTO();
		pxiZip.setPxiZipCode(zipCode);
		pxiZip.setPxiZipInd(zipInd);
		PxiZips.add(pxiZip);
		
		return PxiZips;
	}
	private static ProviderAttributesWithholdDataDTO createWithholdDataAttribute(
			LocalDate WthldEffDateCurrent, String WthldPerCurrent, LocalDate setWthldEffDatePrior, String WthldPerPrior, String prTaxfreeAmt) {
		ProviderAttributesWithholdDataDTO withholdDataDto = new ProviderAttributesWithholdDataDTO(); 
		withholdDataDto.setWthldCurrent(createWthldCurrentAttribute(WthldEffDateCurrent,WthldPerCurrent));
		withholdDataDto.setWthldPrior(createWthldPriorDtoAttribute(setWthldEffDatePrior,WthldPerPrior));
		withholdDataDto.setPrTaxfreeAmt(prTaxfreeAmt);
		
		return withholdDataDto;
	}
	private static ProviderAttributesWithholdDataWthldCurrentDTO createWthldCurrentAttribute(LocalDate WthldEffDateCurrent, String WthldPerCurrent) {
		ProviderAttributesWithholdDataWthldCurrentDTO wthldCurrentDto = new ProviderAttributesWithholdDataWthldCurrentDTO();
		wthldCurrentDto.setWthldEffDateCurrent(WthldEffDateCurrent);
		wthldCurrentDto.setWthldPerCurrent(WthldPerCurrent);
		
		return wthldCurrentDto;
	}
	private static ProviderAttributesWithholdDataWthldPriorDTO createWthldPriorDtoAttribute(LocalDate setWthldEffDatePrior, String WthldPerPrior) {
		ProviderAttributesWithholdDataWthldPriorDTO wthldPriorDto = new ProviderAttributesWithholdDataWthldPriorDTO();
		wthldPriorDto.setWthldEffDatePrior(setWthldEffDatePrior);
		wthldPriorDto.setWthldPerPrior(WthldPerPrior);
		
		return wthldPriorDto;
	}
	
	private Attributes createAttributes() {
		Attributes attributes = new Attributes();
		attributes.setKey(createKey("30", "H", "542", " "));
		attributes.setIrsNo("999999999");
		attributes.setVch("K");
		attributes.setTaxType("");
		attributes.setSend1099Ind("N");
		attributes.setPendEsc("");
		attributes.setAutoCheckPullInd("N");
		attributes.setIrsWithholdInd("");
		attributes.setPayCycle("");
		attributes.setCrossRef("0");
		attributes.setMarketId("0");
		attributes.setDg("");
		attributes.setAlphaKey("PALMS OF PASADENA HO");
		attributes.setCasName(createCasName("",""));
		attributes.setMedSuppWaiveInd("");
		attributes.setComment1("Comment1");
		attributes.setComment2("Comment2");
		attributes.setComment3("Comment3");
		attributes.setNotifyInd("N");
		attributes.setFocusFromDate(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		attributes.setClpthInd("");
		attributes.setClmChkInd("");
		attributes.setUcZip("");
		attributes.setFocusToDate(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		attributes.setAutoLoadInd("");
		attributes.setCheckTo("");
		attributes.setSuffixTo("");
		attributes.setApplyTaxInd("");
		attributes.setW9Ind("");
		attributes.setSend480Ind("");
		attributes.setWithholdData(createWithholdData(dateInStringToLocalDate("2012-09-30T00:00:00Z"),"110.00",dateInStringToLocalDate("2012-09-30T00:00:00Z"),"9.00"," "));
		attributes.setUpdtAdjNo("");
		attributes.setUpdtDt(dateInStringToLocalDate(""));
		attributes.setRadSiteCurrInd("");
		attributes.setRadSiteCurrDt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		attributes.setRadSiteP1Ind("");
		attributes.setRadSiteP1Dt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		attributes.setRadSiteP2Ind("");
		attributes.setRadSiteP2Dt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		attributes.setRadScopeCurrInd("");
		attributes.setRadScopeCurrDt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		attributes.setRadScopeP1Ind("");
		attributes.setRadScopeP1Dt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		attributes.setFacUcZip("");
		attributes.setPxiUpdtAdjNo("");
		attributes.setPxiUpdtDt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		attributes.setSendLtrInd("");
		attributes.setFinalstInd("");
		attributes.setPxiZip(createPxiZip("40245", "A"));
		attributes.setCompbidInd("");
		attributes.setVendorId("12345");
		attributes.setCompbidEffDt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		attributes.setCompbidTrmDt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		attributes.setContractPointEnable(buildContractPointEnableMap());

		return attributes;
	}
	private AttributesKey createKey(String client,String pvdInd,String prov, String multAddressKey) {
		AttributesKey attributesKey = new AttributesKey();
		attributesKey.setClient(client);
		attributesKey.setPvdInd(pvdInd);
		attributesKey.setProv(prov);
		attributesKey.setMultAddressKey(multAddressKey);
		
		return attributesKey;
	}
	private CasName createCasName(String firstName,String lastName) {
		CasName casName = new CasName();
		casName.setFstName(firstName);
		casName.setLastName(lastName);

		return casName;
	}
	private WithholdData createWithholdData(LocalDate WthldEffDateCurrent,String WthldPerCurrent,LocalDate setWthldEffDatePrior, String WthldPerPrior,String prvPrTaxfreeAmt) {
		WithholdData withholdData = new WithholdData();
		withholdData.setWthldCurrent(createWthldCurrent(WthldEffDateCurrent,WthldPerCurrent));
		withholdData.setWthldPrior(createWthldPrior(setWthldEffDatePrior,WthldPerPrior));
		withholdData.setPrTaxfreeAmt(prvPrTaxfreeAmt);

		return withholdData;
	}
	private WthldCurrent createWthldCurrent(LocalDate WthldEffDateCurrent,String WthldPerCurrent) {
		WthldCurrent wthldCurrent = new WthldCurrent();
		wthldCurrent.setWthldPerCurrent(WthldPerCurrent);
		wthldCurrent.setWthldEffDateCurrent(WthldEffDateCurrent);

		return wthldCurrent;
	}
	private WthldPrior createWthldPrior(LocalDate setWthldEffDatePrior, String WthldPerPrior) {
		WthldPrior wthldPrior = new WthldPrior();
		wthldPrior.setWthldPerPrior(WthldPerPrior);
		wthldPrior.setWthldEffDatePrior(setWthldEffDatePrior);

		return wthldPrior;
	}
	private List<PxiZip> createPxiZip(String zipcode,String zipInd) {
		List<PxiZip> pxiZips = new ArrayList<>();
		PxiZip pxiZip = new PxiZip();
		pxiZip.setPxiZipCode(zipcode);
		pxiZip.setPxiZipInd(zipInd);
		pxiZips.add(pxiZip);

		return pxiZips;
	}
	private Map<String, Boolean> buildContractPointEnableMap() {
		Map<String, Boolean> contractPointEnableMap = new HashMap<>();
		contractPointEnableMap.put("1", true);
		contractPointEnableMap.put("2", false);
		
		return contractPointEnableMap;
	}
	
	private ProviderAttrGetRequest createProvAttrGetReqObj() {
		return ProviderAttrGetRequest.builder().providerId("999999999").providerIndicator("H").providerMultiAddressKey(" ").providerTaxId("999999999")
				.firstName("ALPHAKEY").limit(100).offset(1).includeCount(true).build();
	}

}
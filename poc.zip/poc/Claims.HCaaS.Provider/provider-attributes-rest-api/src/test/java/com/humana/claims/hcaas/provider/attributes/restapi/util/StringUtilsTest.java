package com.humana.claims.hcaas.provider.attributes.restapi.util;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class StringUtilsTest {

	@Test
	public void testreplaceBlankStringToWhiteSpaceWithNull() {
		
		String actual = StringUtils.replaceBlankStringToSingleWhiteSpace(null);
		Assertions.assertNull(actual);
	}
	
	@Test
	public void testreplaceBlankStringToWhiteSpaceWithNoSpaces() {
		
		String actual = StringUtils.replaceBlankStringToSingleWhiteSpace("");
		Assertions.assertEquals(" ", actual);
	}
	
	@Test
	public void testreplaceBlankStringToWhiteSpaceWithSingleSpaces() {
		
		String actual = StringUtils.replaceBlankStringToSingleWhiteSpace(" ");
		Assertions.assertEquals(" ", actual);
	}
	
	@Test
	public void testreplaceBlankStringToWhiteSpaceWithMultipleSpaces() {
		
		String actual = StringUtils.replaceBlankStringToSingleWhiteSpace("    ");
		Assertions.assertEquals(" ", actual);
	}
}

package com.humana.claims.hcaas.provider.attributes.restapi.mapper;

import static com.humana.claims.hcaas.provider.attributes.restapi.util.ProviderAttributesTestData.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesDTO;
import com.humana.claims.hcaas.provider.attributes.restapi.util.ProviderAttributesTestData;

@ExtendWith(MockitoExtension.class)
public class ProviderAttributesDataMapperImplTest {

	@InjectMocks
	private ProviderAttributesDataMapperImpl classUnderTest;

	@Test
	public void test_classUnderTest_initialized() {
		assertNotNull(classUnderTest);
	}

	@Test
	public void test_whenMapProviderAttributesDtoInvokedWithAttributesDataObject() {
		Attributes attributes = ProviderAttributesTestData.getAttributesData();

		ProviderAttributesDTO actual = classUnderTest.mapProviderAttributesDto(attributes);

		assertProviderAttributesDtoData(actual);
	}
	
	@Test
	public void test_whenMapProviderAttributesDtoInvokedWithInvalidAttributesDataObject() {
		Attributes attributes = ProviderAttributesTestData.getAttributesData();
		attributes.setFinalstInd(null);

		ProviderAttributesDTO actual = classUnderTest.mapProviderAttributesDto(attributes);

		assertNotNull(actual);
		assertThat(actual.getFinalstInd()).isNull();
	}
	
	@Test
	public void test_whenMapProviderAttributesDtoInvokedWithInvalidAttributesClientNullDataObject() {
		Attributes attributes = ProviderAttributesTestData.getAttributesData();
		attributes.setKey(null);
		ProviderAttributesDTO actual = classUnderTest.mapProviderAttributesDto(attributes);

		assertNotNull(actual);
		assertThat(actual.getKey().getClient()).isNull();
	}
	
	@Test
	public void test_whenMapProviderAttributesDtoInvokedWithInvalidAttributesDataObjectWithNullCasFirstNameAndLastName() {
		Attributes attributes = ProviderAttributesTestData.getAttributesData();
		attributes.getCasName().setFstName(null);
		attributes.getCasName().setLastName(null);
		ProviderAttributesDTO actual = classUnderTest.mapProviderAttributesDto(attributes);

		assertNotNull(actual);
		assertThat(actual.getCasName().getCasFstName()).isNull();
		assertThat(actual.getCasName().getCasLastName()).isNull();
	}
	
	@Test
	public void test_whenMapProviderAttributesDtoInvokedWithInvalidAttributesDataObjectWithNullCasName() {
		Attributes attributes = ProviderAttributesTestData.getAttributesData();
		attributes.setCasName(null);
		ProviderAttributesDTO actual = classUnderTest.mapProviderAttributesDto(attributes);

		assertNotNull(actual);
		assertThat(actual.getCasName().getCasFstName()).isNull();
	}
	
	@Test
	public void test_whenMapProviderAttributesDtoInvokedWithInvalidAttributesDataObjectWithNullWithHoldData() {
		Attributes attributes = ProviderAttributesTestData.getAttributesData();
		attributes.setWithholdData(null);
		ProviderAttributesDTO actual = classUnderTest.mapProviderAttributesDto(attributes);

		assertNotNull(actual);
		assertThat(actual.getWithholdData().getPrTaxfreeAmt()).isNull();
	}
	
	@Test
	public void test_whenMapProviderAttributesDtoInvokedWithInvalidAttributesDataObjectWithNullWithHoldLdCurrent() {
		Attributes attributes = ProviderAttributesTestData.getAttributesData();
		attributes.getWithholdData().setWthldCurrent(null);
		ProviderAttributesDTO actual = classUnderTest.mapProviderAttributesDto(attributes);

		assertNotNull(actual);
		assertThat(actual.getWithholdData().getWthldCurrent().getWthldEffDateCurrent()).isNull();
	}
	
	@Test
	public void test_whenMapProviderAttributesDtoInvokedWithInvalidAttributesDataObjectWithNullWithHoldLdPrior() {
		Attributes attributes = ProviderAttributesTestData.getAttributesData();
		attributes.getWithholdData().setWthldPrior(null);
		ProviderAttributesDTO actual = classUnderTest.mapProviderAttributesDto(attributes);

		assertNotNull(actual);
		assertThat(actual.getWithholdData().getWthldPrior().getWthldPerPrior()).isNull();
	}
	
	private void assertProviderAttributesDtoData(ProviderAttributesDTO attributesDto) {

		assertThat(attributesDto.getKey().getClient()).isEqualTo("30");
		assertThat(attributesDto.getKey().getPvdInd()).isEqualTo("H");
		assertThat(attributesDto.getKey().getProv()).isEqualTo("542");
		assertThat(attributesDto.getKey().getMultAddressKey()).isEqualTo(" ");
		assertThat(attributesDto.getIrsNo()).isEqualTo(IRSNO_VALUE);
		assertThat(attributesDto.getVch()).isEqualTo(VCH_VALUE);
		assertThat(attributesDto.getTaxType()).isEqualTo(TAXTYPE_VALUE);
		assertThat(attributesDto.getSend1099Ind()).isEqualTo(SEND1099IND_VALUE);
		assertThat(attributesDto.getPendEsc()).isEqualTo(PENDESC_VALUE);
		assertThat(attributesDto.getAutoCheckPullInd()).isEqualTo(AUTOCHECKPULLIND_VALUE);
		assertThat(attributesDto.getIrsWithholdInd()).isEqualTo(IRSWITHHOLDIND_VALUE);
		assertThat(attributesDto.getPayCycle()).isEqualTo(PAYCYCLE_VALUE);
		assertThat(attributesDto.getCrossRef()).isEqualTo(CROSSREF_VALUE);
		assertThat(attributesDto.getMarketId()).isEqualTo(MARKETID_VALUE);
		assertThat(attributesDto.getDg()).isEqualTo(DG_VALUE);
		assertThat(attributesDto.getAlphaKey()).isEqualTo(ALPHAKEY_VALUE);
		assertThat(attributesDto.getCasName().getCasFstName()).isEqualTo(CASFSTNAME_VALUE);
		assertThat(attributesDto.getCasName().getCasLastName()).isEqualTo(CASLASTNAME_VALUE);
		assertThat(attributesDto.getMedSuppWaiveInd()).isEqualTo(MEDSUPPWAIVEIND_VALUE);
		assertThat(attributesDto.getComment1()).isEqualTo(COMMENT1_VALUE);
		assertThat(attributesDto.getComment2()).isEqualTo(COMMENT2_VALUE);
		assertThat(attributesDto.getComment3()).isEqualTo(COMMENT3_VALUE);
		assertThat(attributesDto.getNotifyInd()).isEqualTo(NOTIFYIND_VALUE);
		assertThat(attributesDto.getFocusFromDate()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(attributesDto.getClpthInd()).isEqualTo(CLPTHIND_VALUE);
		assertThat(attributesDto.getClmChkInd()).isEqualTo(CLMCHKIND_VALUE);
		assertThat(attributesDto.getUcZip()).isEqualTo(UCZIP_VALUE);
		assertThat(attributesDto.getFocusToDate()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(attributesDto.getAutoLoadInd()).isEqualTo(AUTOLOADIND_VALUE);
		assertThat(attributesDto.getCheckTo()).isEqualTo(CHECKTO_VALUE);
		assertThat(attributesDto.getSuffixTo()).isEqualTo(SUFFIXTO_VALUE);
		assertThat(attributesDto.getApplyTaxInd()).isEqualTo(APPLYTAXIND_VALUE);
		assertThat(attributesDto.getW9Ind()).isEqualTo(W9IND_VALUE);
		assertThat(attributesDto.getSend480Ind()).isEqualTo(SEND480IND_VALUE);
		assertThat(attributesDto.getWithholdData().getWthldCurrent().getWthldPerCurrent()).isEqualTo(WTHLDPERCURRENT_VALUE);
		assertThat(attributesDto.getWithholdData().getWthldCurrent().getWthldEffDateCurrent()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(attributesDto.getWithholdData().getWthldPrior().getWthldPerPrior()).isEqualTo(WTHLDPERPRIOR_VALUE);
		assertThat(attributesDto.getWithholdData().getWthldPrior().getWthldEffDatePrior()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(attributesDto.getWithholdData().getPrTaxfreeAmt()).isEqualTo(PRTAXFREEAMT_VALUE);
		assertThat(attributesDto.getUpdtAdjNo()).isEqualTo(UPDTADJNO_VALUE);
		assertThat(attributesDto.getUpdtDt()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(attributesDto.getRadSiteCurrInd()).isEqualTo(RADSITECURRIND_VALUE);
		assertThat(attributesDto.getRadSiteCurrDt()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(attributesDto.getRadSiteP1Ind()).isEqualTo(RADSITEP1IND_VALUE);
		assertThat(attributesDto.getRadSiteP1Dt()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(attributesDto.getRadSiteP2Ind()).isEqualTo(RADSITEP2IND_VALUE);
		assertThat(attributesDto.getRadSiteP2Dt()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(attributesDto.getRadScopeCurrInd()).isEqualTo(RADSCOPECURRIND_VALUE);
		assertThat(attributesDto.getRadScopeCurrDt()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(attributesDto.getRadScopeP1Ind()).isEqualTo(RADSCOPEP1IND_VALUE);
		assertThat(attributesDto.getRadScopeP1Dt()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(attributesDto.getFacUcZip()).isEqualTo(FACUCZIP_VALUE);
		assertThat(attributesDto.getPxiUpdtAdjNo()).isEqualTo(PXIUPDTADJNO_VALUE);
		assertThat(attributesDto.getPxiUpdtDt()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(attributesDto.getSendLtrInd()).isEqualTo(SENDLTRIND_VALUE);
		assertThat(attributesDto.getFinalstInd()).isEqualTo(FINALSTIND_VALUE);
		assertThat(attributesDto.getPxiZip().get(0).getPxiZipCode()).isEqualTo(PXIZIPCODE_VALUE);
		assertThat(attributesDto.getPxiZip().get(0).getPxiZipInd()).isEqualTo(PXIZIPIND_VALUE);
		assertThat(attributesDto.getCompbidInd()).isEqualTo(COMPBIDIND_VALUE);
		assertThat(attributesDto.getVendorId()).isEqualTo(VENDORID_VALUE);
		assertThat(attributesDto.getCompbidEffDt()).isEqualTo(LocalDate.of(2019, 01, 01));
		assertThat(attributesDto.getCompbidTrmDt()).isEqualTo(LocalDate.of(2020, 01, 01));
		assertThat(attributesDto.getContractPointEnable().containsKey("1"));
		assertThat(attributesDto.getContractPointEnable().containsValue(true));
		assertThat(attributesDto.getContractPointEnable().containsKey("2"));
		assertThat(attributesDto.getContractPointEnable().containsValue(false));
	}	
	
}
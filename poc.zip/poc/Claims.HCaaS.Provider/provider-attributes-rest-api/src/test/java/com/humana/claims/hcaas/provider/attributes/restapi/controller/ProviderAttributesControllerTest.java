package com.humana.claims.hcaas.provider.attributes.restapi.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.mockito.ArgumentMatchers.any;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.humana.claims.hcaas.provider.attributes.core.constants.ProviderAttributesConstants;
import com.humana.claims.hcaas.provider.attributes.core.mapper.ProviderAttrGetRequest;
import com.humana.claims.hcaas.provider.attributes.core.masker.ProviderAttributesDataMasker;
import com.humana.claims.hcaas.provider.attributes.restapi.exception.InvalidHeaderCombinationException;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesCasNameDTO;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesDTO;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesKeyDTO;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesPxiZipDTO;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesWithholdDataDTO;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesWithholdDataWthldCurrentDTO;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesWithholdDataWthldPriorDTO;
import com.humana.claims.hcaas.provider.attributes.restapi.service.ProviderAttributesService;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
public class ProviderAttributesControllerTest {

	@InjectMocks
	private ProviderAttributesController classUnderTest;

	@Mock
	private ProviderAttributesService providerAttributesService;
	
	@Mock
	private ProviderAttributesDataMasker dataMasker;

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdMultiAddressKeyAndProviderIndicatorShouldReturnResponseIncludeCountTrue200() {
		ProviderAttributesDTO attributesList = createProviderAttributesDto();
		List<ProviderAttributesDTO> providerAttributesDtos = new ArrayList<>();
		providerAttributesDtos.add(attributesList);
		int limit = 1;
		int offset = 0;
		String totalCount = "1";
		String providerId = "999999999";
		String providerIndicator = "H";
		String providerMultiAddressKey = "";
		String providerTaxId = null;
		String firstName = "B M A NORTH ORLANDO";
		Boolean includeCount = true;
		Mockito.when((providerAttributesService.getAttributesByProviderIdMultiAddressKeyAndIndicator(any(ProviderAttrGetRequest.class)))).thenReturn(providerAttributesDtos);
		Mockito.when((providerAttributesService.getAttributesTotalDocumentsByProviderIdMultiAddressKeyAndIndicator(any(ProviderAttrGetRequest.class)))).thenReturn(totalCount);
		
		ResponseEntity<List<ProviderAttributesDTO>> actual = classUnderTest.getProviderAttributes(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount);
		
		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderAttributesConstants.TOTAL_DOCS)).isEqualTo(true);
	}
	
	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdMultiAddressKeyAndProviderIndicatorShouldReturnResponseIncludeCountFalse200() {
		ProviderAttributesDTO attributesList = createProviderAttributesDto();
		List<ProviderAttributesDTO> providerAttributesDtos = new ArrayList<>();
		providerAttributesDtos.add(attributesList);
		int limit = 1;
		int offset = 0;
		String providerId = "999999999";
		String providerIndicator = "H";
		String providerMultiAddressKey = "";
		String providerTaxId = null;
		String firstName = "B M A NORTH ORLANDO";
		Boolean includeCount = false;
		Mockito.when((providerAttributesService.getAttributesByProviderIdMultiAddressKeyAndIndicator(any(ProviderAttrGetRequest.class)))).thenReturn(providerAttributesDtos);

		ResponseEntity<List<ProviderAttributesDTO>> actual = classUnderTest.getProviderAttributes(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount);
		
		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderAttributesConstants.TOTAL_DOCS)).isEqualTo(false);
	}
	
	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdMultiAddressKeyAndProviderIndicatorShouldReturnResponseIncludeCountWithNullValue200() {
		ProviderAttributesDTO attributesList = createProviderAttributesDto();
		List<ProviderAttributesDTO> providerAttributesDtos = new ArrayList<>();
		providerAttributesDtos.add(attributesList);
		int limit = 1;
		int offset = 0;
		String providerId = "999999999";
		String providerIndicator = "H";
		String providerMultiAddressKey = "";
		String providerTaxId = null;
		String firstName = "B M A NORTH ORLANDO";
		Boolean includeCount = null;
		Mockito.when((providerAttributesService.getAttributesByProviderIdMultiAddressKeyAndIndicator(any(ProviderAttrGetRequest.class)))).thenReturn(providerAttributesDtos);

		ResponseEntity<List<ProviderAttributesDTO>> actual = classUnderTest.getProviderAttributes(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount);
		
		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderAttributesConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderTaxIdShouldReturnResponseIncludeCountTrue200() {
		ProviderAttributesDTO attributesList = createProviderAttributesDto();
		List<ProviderAttributesDTO> providerAttributesDtos = new ArrayList<>();
		providerAttributesDtos.add(attributesList);
		int limit = 100;
		int offset = 1;
		String totalCount = "1";
		String providerId = null;
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String providerTaxId = "999999999";
		String firstName = "B M A NORTH ORLANDO";
		Boolean includeCount = true;
		Mockito.when((providerAttributesService.getAttributesByProviderTaxId(any(ProviderAttrGetRequest.class)))).thenReturn(providerAttributesDtos);
		Mockito.when((providerAttributesService.getAttributesTotalDocumentsByProviderIdTaxId(any(ProviderAttrGetRequest.class)))).thenReturn(totalCount);
				
		ResponseEntity<List<ProviderAttributesDTO>> actual = classUnderTest.getProviderAttributes(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderAttributesConstants.TOTAL_DOCS)).isEqualTo(true);
	}
	
	@Test
	@SneakyThrows
	public void validCombinationHavingProviderTaxIdShouldReturnResponseIncludeCountFalse200() {
		ProviderAttributesDTO attributesList = createProviderAttributesDto();
		List<ProviderAttributesDTO> providerAttributesDtos = new ArrayList<>();
		providerAttributesDtos.add(attributesList);
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String providerTaxId = "999999999";
		String firstName = "B M A NORTH ORLANDO";
		Boolean includeCount = false;
		Mockito.when((providerAttributesService.getAttributesByProviderTaxId(any(ProviderAttrGetRequest.class)))).thenReturn(providerAttributesDtos);
		
		ResponseEntity<List<ProviderAttributesDTO>> actual = classUnderTest.getProviderAttributes(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderAttributesConstants.TOTAL_DOCS)).isEqualTo(false);
	}
	
	@Test
	@SneakyThrows
	public void validCombinationHavingProviderTaxIdShouldReturnResponseIncludeCountWithNull200() {
		ProviderAttributesDTO attributesList = createProviderAttributesDto();
		List<ProviderAttributesDTO> providerAttributesDtos = new ArrayList<>();
		providerAttributesDtos.add(attributesList);
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String providerTaxId = "999999999";
		Boolean includeCount = null;
		String firstName = "B M A NORTH ORLANDO";
		Mockito.when((providerAttributesService.getAttributesByProviderTaxId(any(ProviderAttrGetRequest.class)))).thenReturn(providerAttributesDtos);
		
		ResponseEntity<List<ProviderAttributesDTO>> actual = classUnderTest.getProviderAttributes(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderAttributesConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderTaxIdShouldReturnResponseBadRequest() {
		List<ProviderAttributesDTO> providerAttributesDtos = new ArrayList<>();
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String providerTaxId = "999999999";
		String firstName = "B M A NORTH ORLANDO";
		Boolean includeCount = false;
		Mockito.when((providerAttributesService.getAttributesByProviderTaxId(any(ProviderAttrGetRequest.class)))).thenReturn(providerAttributesDtos);

		ResponseEntity<List<ProviderAttributesDTO>> actual = classUnderTest.getProviderAttributes(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset,includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
	}
	
	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdShouldReturnResponseIncludeTrueCountDefault200() {
		ProviderAttributesDTO attributesList = createProviderAttributesDto();
		List<ProviderAttributesDTO> providerAttributesDtos = new ArrayList<>();
		providerAttributesDtos.add(attributesList);
		int limit = 100;
		int offset = 1;
		String totalCount = "1";
		String providerId = "999999999";
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String providerTaxId = null;
		String firstName = "B M A NORTH ORLANDO";
		Boolean includeCount = true;
		Mockito.when((providerAttributesService.getAttributesByProviderId(any(ProviderAttrGetRequest.class)))).thenReturn(providerAttributesDtos);
		Mockito.when((providerAttributesService.getAttributesTotalDocumentsByProviderId(any(ProviderAttrGetRequest.class)))).thenReturn(totalCount);
		
		ResponseEntity<List<ProviderAttributesDTO>> actual = classUnderTest.getProviderAttributes(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderAttributesConstants.TOTAL_DOCS)).isEqualTo(true);
	}
	
	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdShouldReturnResponseIncludeFalseCountDefault200() {
		ProviderAttributesDTO attributesList = createProviderAttributesDto();
		List<ProviderAttributesDTO> providerAttributesDtos = new ArrayList<>();
		providerAttributesDtos.add(attributesList);
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String providerTaxId = null;
		String firstName = "B M A NORTH ORLANDO";
		Boolean includeCount = false;
		Mockito.when((providerAttributesService.getAttributesByProviderId(any(ProviderAttrGetRequest.class)))).thenReturn(providerAttributesDtos);
		
		ResponseEntity<List<ProviderAttributesDTO>> actual = classUnderTest.getProviderAttributes(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderAttributesConstants.TOTAL_DOCS)).isEqualTo(false);
	}
	
	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdShouldReturnResponseIncludeCountWithNullValueDefault200() {
		ProviderAttributesDTO attributesList = createProviderAttributesDto();
		List<ProviderAttributesDTO> providerAttributesDtos = new ArrayList<>();
		providerAttributesDtos.add(attributesList);
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String providerTaxId = null;
		String firstName = "B M A NORTH ORLANDO";
		Boolean includeCount = null;
		Mockito.when((providerAttributesService.getAttributesByProviderId(any(ProviderAttrGetRequest.class)))).thenReturn(providerAttributesDtos);
		
		ResponseEntity<List<ProviderAttributesDTO>> actual = classUnderTest.getProviderAttributes(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderAttributesConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdShouldReturnResponseBadRequest() throws Exception{
		List<ProviderAttributesDTO> providerAttributesDtos = new ArrayList<>();
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String providerTaxId = null;
		String firstName = "B M A NORTH ORLANDO";
		Boolean includeCount = false;
		Mockito.when((providerAttributesService.getAttributesByProviderId(any(ProviderAttrGetRequest.class)))).thenReturn(providerAttributesDtos);

		ResponseEntity<List<ProviderAttributesDTO>> actual = classUnderTest.getProviderAttributes(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset,includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
	}
	
	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdAndIndicatorShouldReturnResponseIncludeCountTrue200() {
		ProviderAttributesDTO attributesList = createProviderAttributesDto();
		List<ProviderAttributesDTO> providerAttributesDtos = new ArrayList<>();
		providerAttributesDtos.add(attributesList);
		int limit = 100;
		int offset = 1;
		String totalCount ="1";
		String providerId = "999999999";
		String providerIndicator = "H";
		String providerMultiAddressKey = null;
		String providerTaxId = null;
		String firstName = "B M A NORTH ORLANDO";
		Boolean includeCount = true;
		Mockito.when((providerAttributesService.getAttributesByProviderIdAndIndicator(any(ProviderAttrGetRequest.class)))).thenReturn(providerAttributesDtos);
		Mockito.when((providerAttributesService.getAttributesTotalDocumentsByProviderIdAndIndicator(any(ProviderAttrGetRequest.class)))).thenReturn(totalCount);
		
		ResponseEntity<List<ProviderAttributesDTO>> actual = classUnderTest.getProviderAttributes(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderAttributesConstants.TOTAL_DOCS)).isEqualTo(true);
	}
	
	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdAndIndicatorShouldReturnResponseIncludeCountFalse200() {
		ProviderAttributesDTO attributesList = createProviderAttributesDto();
		List<ProviderAttributesDTO> providerAttributesDtos = new ArrayList<>();
		providerAttributesDtos.add(attributesList);
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = "H";
		String providerMultiAddressKey = null;
		String providerTaxId = null;
		String firstName = "B M A NORTH ORLANDO";
		Boolean includeCount = false;
		Mockito.when((providerAttributesService.getAttributesByProviderIdAndIndicator(any(ProviderAttrGetRequest.class)))).thenReturn(providerAttributesDtos);

		ResponseEntity<List<ProviderAttributesDTO>> actual = classUnderTest.getProviderAttributes(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderAttributesConstants.TOTAL_DOCS)).isEqualTo(false);
	}
	
	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdAndIndicatorShouldReturnResponseIncludeCountWithNullValue200() {
		ProviderAttributesDTO attributesList = createProviderAttributesDto();
		List<ProviderAttributesDTO> providerAttributesDtos = new ArrayList<>();
		providerAttributesDtos.add(attributesList);
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = "H";
		String providerMultiAddressKey = null;
		String providerTaxId = null;
		String firstName = "B M A NORTH ORLANDO";
		Boolean includeCount = null;
		Mockito.when((providerAttributesService.getAttributesByProviderIdAndIndicator(any(ProviderAttrGetRequest.class)))).thenReturn(providerAttributesDtos);

		ResponseEntity<List<ProviderAttributesDTO>> actual = classUnderTest.getProviderAttributes(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount);

		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.OK);
		assertThat(actual.getHeaders().containsKey(ProviderAttributesConstants.TOTAL_DOCS)).isEqualTo(false);
	}

	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdAndIndicatorShouldReturnResponseBadRequest() throws Exception {
		List<ProviderAttributesDTO> providerAttributesDtos = new ArrayList<>();
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = "H";
		String providerMultiAddressKey = null;
		String providerTaxId = null;
		String firstName = null;
		Boolean includeCount = false;
		Mockito.when((providerAttributesService.getAttributesByProviderIdAndIndicator(any(ProviderAttrGetRequest.class)))).thenReturn(providerAttributesDtos);
		
		ResponseEntity<List<ProviderAttributesDTO>> actual = classUnderTest.getProviderAttributes(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset,includeCount);
		
		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
	}
	
	@Test
	@SneakyThrows
	public void validCombinationHavingProviderIdMultiAddressKeyIndicatorShouldReturnResponseBadRequest() throws Exception {
		List<ProviderAttributesDTO> providerAttributesDtos = new ArrayList<>();
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = "H";
		String providerMultiAddressKey = "1";
		String providerTaxId = null;
		String firstName = null;
		Boolean includeCount = false;
		Mockito.when((providerAttributesService.getAttributesByProviderIdMultiAddressKeyAndIndicator(any(ProviderAttrGetRequest.class)))).thenReturn(providerAttributesDtos);
		
		ResponseEntity<List<ProviderAttributesDTO>> actual = classUnderTest.getProviderAttributes(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset,includeCount);
		
		assertThat(actual.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
	}
	
	@Test
	@SneakyThrows
	public void invalidCombinationHavingProviderIdIndicatorMultiAddressKeyAndProviderTaxIdShouldReturnBadRequest() {
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = "H";
		String providerMultiAddressKey = "";
		String providerTaxId = "999999999";
		String firstName = "B M A NORTH ORLANDO";
		Boolean includeCount = false;
		
		Throwable actualThrown = catchThrowable(() -> classUnderTest.getProviderAttributes(
				providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount));
		
		assertThat(actualThrown)
			   .isInstanceOf(InvalidHeaderCombinationException.class);
	}

	@Test
	@SneakyThrows
	public void invalidCombinationHavingProviderIdMultiAddressKeyAndProviderTaxIdShouldReturnBadRequest() {
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = null;
		String providerMultiAddressKey = "";
		String providerTaxId = "999999999";
		String firstName = "B M A NORTH ORLANDO";
		Boolean includeCount = false; 
		
		Throwable actualThrown = catchThrowable(() -> classUnderTest.getProviderAttributes(
				providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount));
		
		assertThat(actualThrown)
			   .isInstanceOf(InvalidHeaderCombinationException.class);
	}

	@Test
	@SneakyThrows
	public void invalidCombinationHavingProviderIndicatorMultiAddressKeyAndProviderTaxIdShouldReturnBadRequest() {
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = "H";
		String providerMultiAddressKey = "";
		String providerTaxId = "999999999";
		String firstName = "B M A NORTH ORLANDO";
		Boolean includeCount = false;
	
		Throwable actualThrown = catchThrowable(() -> classUnderTest.getProviderAttributes(
				providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount));
		
		assertThat(actualThrown)
			   .isInstanceOf(InvalidHeaderCombinationException.class);
	}

	@Test
	@SneakyThrows
	public void invalidCombinationHavingProviderIdIndicatorAndProviderTaxIdShouldReturnBadRequest() {
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = "H";
		String providerMultiAddressKey = null;
		String providerTaxId = "999999999";
		String firstName = "B M A NORTH ORLANDO";
		Boolean includeCount = false; 
		
		Throwable actualThrown = catchThrowable(() -> classUnderTest.getProviderAttributes(
				providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount));
		
		assertThat(actualThrown)
			   .isInstanceOf(InvalidHeaderCombinationException.class);
	}

	@Test
	@SneakyThrows
	public void invalidCombinationHavingProviderIdAndProviderTaxIdShouldReturnBadRequest() {
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = null;
		String providerMultiAddressKey = null;
		String providerTaxId = "999999999";
		String firstName = "B M A NORTH ORLANDO";
		Boolean includeCount = false;
		
		Throwable actualThrown = catchThrowable(() -> classUnderTest.getProviderAttributes(
				providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount));
		
		assertThat(actualThrown)
			   .isInstanceOf(InvalidHeaderCombinationException.class);
	}

	@Test
	@SneakyThrows
	public void invalidCombinationHavingProviderIdAndProviderMultiAddressKeyShouldReturnBadRequest() {
		int limit = 100;
		int offset = 1;
		String providerId = "999999999";
		String providerIndicator = null;
		String providerMultiAddressKey = "";
		String providerTaxId = null;
		String firstName = "B M A NORTH ORLANDO";
		Boolean includeCount = false;
		
		Throwable actualThrown = catchThrowable(() -> classUnderTest.getProviderAttributes(
				providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount));
		
		assertThat(actualThrown)
			   .isInstanceOf(InvalidHeaderCombinationException.class);
	}

	@Test
	@SneakyThrows
	public void invalidCombinationHavingProviderMultiAddressKeyAndProviderTaxIdShouldReturnBadRequest() {
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = null;
		String providerMultiAddressKey = "";
		String providerTaxId = "999999999";
		String firstName = "B M A NORTH ORLANDO";
		Boolean includeCount = false;
	
		Throwable actualThrown = catchThrowable(() -> classUnderTest.getProviderAttributes(
				providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount));
		
		assertThat(actualThrown)
			   .isInstanceOf(InvalidHeaderCombinationException.class);
	}

	@Test
	@SneakyThrows
	public void invalidCombinationHavingProviderIndicatorAndProviderMultiAddressKeyShouldReturnBadRequest() {
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = "H";
		String providerMultiAddressKey = "";
		String providerTaxId = null;
		String firstName = "B M A NORTH ORLANDO";
		Boolean includeCount= false;
		
		Throwable actualThrown = catchThrowable(() -> classUnderTest.getProviderAttributes(
				providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount));
		
		assertThat(actualThrown)
			   .isInstanceOf(InvalidHeaderCombinationException.class);
	}

	@Test
	@SneakyThrows
	public void invalidCombinationHavingProviderIndicatorAndProviderTaxIdShouldReturnBadRequest() {
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = "H";
		String providerMultiAddressKey = null;
		String providerTaxId = "999999999";
		String firstName = "B M A NORTH ORLANDO";
		Boolean includeCount = false;
	
		Throwable actualThrown = catchThrowable(() -> classUnderTest.getProviderAttributes(
				providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount));
		
		assertThat(actualThrown)
			   .isInstanceOf(InvalidHeaderCombinationException.class);
	}

	@Test
	@SneakyThrows
	public void invalidCombinationHavingProviderIndicatorShouldReturnBadRequest() {
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = "H";
		String providerMultiAddressKey = null;
		String providerTaxId = null;
		String firstName = null;
		Boolean includeCount= false; 
		
		Throwable actualThrown = catchThrowable(() -> classUnderTest.getProviderAttributes(
				providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount));
		
		assertThat(actualThrown)
			   .isInstanceOf(InvalidHeaderCombinationException.class);
	}

	@Test
	@SneakyThrows
	public void invalidCombinationHavingProviderMultiAddressKeyShouldReturnBadRequest() {
		int limit = 100;
		int offset = 1;
		String providerId = null;
		String providerIndicator = null;
		String providerMultiAddressKey = "";
		String providerTaxId = null;
		String firstName = null;
		Boolean includeCount = false; 
	
		Throwable actualThrown = catchThrowable(() -> classUnderTest.getProviderAttributes(
				providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount));
		
		assertThat(actualThrown)
			   .isInstanceOf(InvalidHeaderCombinationException.class);
	}
	

	private LocalDate dateInStringToLocalDate(String dateInString) {
		if(dateInString == null || dateInString == "") {
			return LocalDate.now();
		}
		else {
			Instant instant = Instant.parse(dateInString);
			LocalDateTime dateTime = LocalDateTime.ofInstant(instant, ZoneId.of(ZoneOffset.UTC.getId()));
			LocalDate localDate = dateTime.toLocalDate();
			return localDate;
		}
	}

	private ProviderAttributesDTO createProviderAttributesDto() {
		ProviderAttributesDTO providerAttributesDto = new ProviderAttributesDTO();
		providerAttributesDto.setKey(createKeyDto());
		providerAttributesDto.setIrsNo("999999999");
		providerAttributesDto.setVch("K");
		providerAttributesDto.setTaxType("");
		providerAttributesDto.setSend1099Ind("N");
		providerAttributesDto.setPendEsc("");
		providerAttributesDto.setAutoCheckPullInd("N");
		providerAttributesDto.setIrsWithholdInd("");
		providerAttributesDto.setPayCycle("");
		providerAttributesDto.setCrossRef("0");
		providerAttributesDto.setMarketId("0");
		providerAttributesDto.setDg("");
		providerAttributesDto.setAlphaKey("PALMS OF PASADENA HO");
		providerAttributesDto.setCasName(createProvCasNameGfldDto());
		providerAttributesDto.setMedSuppWaiveInd("");
		providerAttributesDto.setComment1("");
		providerAttributesDto.setComment2("");
		providerAttributesDto.setComment3("");
		providerAttributesDto.setNotifyInd("N");
		providerAttributesDto.setFocusFromDate(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		providerAttributesDto.setClpthInd("");
		providerAttributesDto.setClmChkInd("");
		providerAttributesDto.setUcZip("");
		providerAttributesDto.setFocusToDate(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		providerAttributesDto.setAutoLoadInd("");
		providerAttributesDto.setCheckTo("");
		providerAttributesDto.setSuffixTo("");
		providerAttributesDto.setApplyTaxInd("");
		providerAttributesDto.setW9Ind("");
		providerAttributesDto.setSend480Ind("");
		providerAttributesDto.setWithholdData(createWithholdDataDto());
		providerAttributesDto.setUpdtAdjNo("");
		providerAttributesDto.setRadSiteCurrInd("");
		providerAttributesDto.setRadSiteCurrDt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		providerAttributesDto.setRadSiteP1Ind("");
		providerAttributesDto.setRadSiteP1Dt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		providerAttributesDto.setRadSiteP2Ind("");
		providerAttributesDto.setRadSiteP2Dt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		providerAttributesDto.setRadScopeCurrInd("");
		providerAttributesDto.setRadScopeCurrDt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		providerAttributesDto.setRadScopeP1Ind("");
		providerAttributesDto.setRadScopeP1Dt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		providerAttributesDto.setFacUcZip("");
		providerAttributesDto.setPxiUpdtAdjNo("");
		providerAttributesDto.setPxiUpdtDt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		providerAttributesDto.setSendLtrInd("");
		providerAttributesDto.setFinalstInd("");
		providerAttributesDto.setPxiZip(createPxiZipDto());
		providerAttributesDto.setCompbidInd("");
		providerAttributesDto.setVendorId("12345");
		providerAttributesDto.setCompbidEffDt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		providerAttributesDto.setCompbidTrmDt(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		providerAttributesDto.setContractPointEnable(buildContractPointEnableMap());
		return providerAttributesDto;
	}

	private ProviderAttributesKeyDTO createKeyDto() {
		ProviderAttributesKeyDTO keyDto = new ProviderAttributesKeyDTO();
		keyDto.setClient("30");
		keyDto.setPvdInd("H");
		keyDto.setProv("542");
		keyDto.setMultAddressKey(null);
		return keyDto;
	}

	private ProviderAttributesCasNameDTO createProvCasNameGfldDto() {
		ProviderAttributesCasNameDTO casNameDto = new ProviderAttributesCasNameDTO();
		casNameDto.setCasFstName("");
		casNameDto.setCasLastName("");
		return casNameDto;
	}

	private ProviderAttributesWithholdDataDTO createWithholdDataDto() {
		ProviderAttributesWithholdDataDTO withHldDataDto = new ProviderAttributesWithholdDataDTO();
		withHldDataDto.setWthldCurrent(createWthldCurrentDto());
		withHldDataDto.setWthldPrior(createWthldPriorDto());
		withHldDataDto.setPrTaxfreeAmt("");
		return withHldDataDto;
	}

	private ProviderAttributesWithholdDataWthldCurrentDTO createWthldCurrentDto() {
		ProviderAttributesWithholdDataWthldCurrentDTO withHldCurrentDto = new ProviderAttributesWithholdDataWthldCurrentDTO();
		withHldCurrentDto.setWthldPerCurrent("110.00");
		withHldCurrentDto.setWthldEffDateCurrent(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		return withHldCurrentDto;
	}

	private ProviderAttributesWithholdDataWthldPriorDTO createWthldPriorDto() {
		ProviderAttributesWithholdDataWthldPriorDTO withHldPriorDto = new ProviderAttributesWithholdDataWthldPriorDTO();
		withHldPriorDto.setWthldPerPrior("9.00");
		withHldPriorDto.setWthldEffDatePrior(dateInStringToLocalDate("2012-09-30T00:00:00Z"));
		return withHldPriorDto;
	}

	private List<ProviderAttributesPxiZipDTO> createPxiZipDto() {
		List<ProviderAttributesPxiZipDTO> pxiZipDtos = new ArrayList<>();
		ProviderAttributesPxiZipDTO pxiZipDto = new ProviderAttributesPxiZipDTO();
		pxiZipDto.setPxiZipCode("40245");
		pxiZipDto.setPxiZipInd("A");
		pxiZipDtos.add(pxiZipDto);
		return pxiZipDtos;
	}

	private static Map<String, Boolean> buildContractPointEnableMap() {
		Map<String, Boolean> contractPointEnableMap = new HashMap<>();
		contractPointEnableMap.put("1", true);
		contractPointEnableMap.put("2", false);
		return contractPointEnableMap;
	}

}
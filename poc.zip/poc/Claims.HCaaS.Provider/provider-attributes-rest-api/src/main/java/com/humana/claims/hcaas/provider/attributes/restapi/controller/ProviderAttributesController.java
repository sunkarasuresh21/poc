package com.humana.claims.hcaas.provider.attributes.restapi.controller;

import static com.humana.claims.hcaas.provider.attributes.restapi.constants.ProviderAttributesErrorConstants.INVALID_HEADER_COMBINATION;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.humana.claims.hcaas.common.utils.logging.LogUtils;
import com.humana.claims.hcaas.provider.attributes.core.constants.ProviderAttributesConstants;
import com.humana.claims.hcaas.provider.attributes.core.mapper.ProviderAttrGetRequest;
import com.humana.claims.hcaas.provider.attributes.core.masker.ProviderAttributesDataMasker;
import com.humana.claims.hcaas.provider.attributes.restapi.exception.InvalidHeaderCombinationException;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.V1Api;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesDTO;
import com.humana.claims.hcaas.provider.attributes.restapi.service.ProviderAttributesService;
import com.humana.claims.hcaas.provider.attributes.restapi.util.StringUtils;

import lombok.extern.slf4j.Slf4j;

@RestController
@ComponentScan(basePackages = "com.humana.claims.hcaas.provider.attributes.restapi")
@Slf4j
public class ProviderAttributesController implements V1Api {

	@Autowired
	private ProviderAttributesService providerAttributesService;
	
	@Autowired
	private ProviderAttributesDataMasker dataMasker;

	private String totalDocs;
	
	private HttpHeaders responseHeaders;
	
	@Override
	public ResponseEntity<List<ProviderAttributesDTO>> getProviderAttributes(String providerId,
			String providerIndicator, String providerMultiAddressKey, String providerTaxId, String firstName, Integer limit,
			Integer offset, Boolean includeCount) throws Exception {
		
		logIncomingRequest(providerId, providerIndicator, providerMultiAddressKey, providerTaxId, firstName, limit, offset, includeCount);
		
		ProviderAttrGetRequest provAttrGetReq = ProviderAttrGetRequest.builder().providerId(providerId).providerIndicator(providerIndicator).providerMultiAddressKey(providerMultiAddressKey).providerTaxId(providerTaxId)
				.firstName(firstName).limit(limit).offset(offset).includeCount(includeCount).build();
		
		if (allNotNull(providerId, providerMultiAddressKey, providerIndicator) && isNull(providerTaxId)) {

			provAttrGetReq.setProviderMultiAddressKey(StringUtils.replaceBlankStringToSingleWhiteSpace(providerMultiAddressKey));
			List<ProviderAttributesDTO> providerAttributesDtos = providerAttributesService
					.getAttributesByProviderIdMultiAddressKeyAndIndicator(provAttrGetReq);
			return getResponseEntityByProviderIdMultiAddressKeyAndIndicator(provAttrGetReq, providerAttributesDtos);

		} else if(isNotNull(providerTaxId) && allNull(providerId, providerMultiAddressKey, providerIndicator)) {
			
			provAttrGetReq.setProviderTaxId(StringUtils.replaceBlankStringToSingleWhiteSpace(providerTaxId));
			List<ProviderAttributesDTO> providerAttributesDtos = providerAttributesService
					.getAttributesByProviderTaxId(provAttrGetReq);
			return getResponseEntityByProviderIdTaxId(provAttrGetReq, providerAttributesDtos);
			
		} else if(isNotNull(providerId) && allNull(providerTaxId, providerMultiAddressKey, providerIndicator)) {
			List<ProviderAttributesDTO> providerAttributesDtos = providerAttributesService
					.getAttributesByProviderId(provAttrGetReq);
			return getResponseEntityByProviderId(provAttrGetReq, providerAttributesDtos);
			
		} else if (allNotNull(providerId, providerIndicator) && isNull(providerTaxId)) {
			List<ProviderAttributesDTO> providerAttributesDtos = providerAttributesService
					.getAttributesByProviderIdAndIndicator(provAttrGetReq);
			return getResponseEntityByProviderIdAndIndicator(provAttrGetReq, providerAttributesDtos);

		} else {
			Set<String> errorMessages = new HashSet<>();
			errorMessages.add(INVALID_HEADER_COMBINATION);
			throw new InvalidHeaderCombinationException(errorMessages);
		}
	}
	
	private boolean allNull(String... strs) {
		for (String s : strs) {
			if (s != null) {
				return false;
			}
		}
		return true;
	}

	private boolean allNotNull(String... strs) {
		for (String s : strs) {
			if (s == null) {
				return false;
			}
		}
		return true;
	}

	private boolean isNull(String s) {
		return s == null;
	}

	private boolean isNotNull(String s) {
		return s != null;
	}

	private ResponseEntity<List<ProviderAttributesDTO>>  getResponseEntityByProviderIdMultiAddressKeyAndIndicator(ProviderAttrGetRequest provAttrGetReq, List<ProviderAttributesDTO> providerAttributesDtos) {
		
		if (!providerAttributesDtos.isEmpty()) {
			if( null != provAttrGetReq.getIncludeCount() && provAttrGetReq.getIncludeCount()) {
				responseHeaders = new HttpHeaders();
				totalDocs = providerAttributesService.getAttributesTotalDocumentsByProviderIdMultiAddressKeyAndIndicator(
						provAttrGetReq);
				responseHeaders.set(ProviderAttributesConstants.TOTAL_DOCS, totalDocs);
				return ResponseEntity.ok().headers(responseHeaders).body(providerAttributesDtos);
			}
			return ResponseEntity.ok(providerAttributesDtos);
		} else {
			return ResponseEntity.badRequest().build();
		}
	}

	private ResponseEntity<List<ProviderAttributesDTO>>  getResponseEntityByProviderIdTaxId(ProviderAttrGetRequest provAttrGetReq, List<ProviderAttributesDTO> providerAttributesDtos) {
		
		if (!providerAttributesDtos.isEmpty()) {
			if( null != provAttrGetReq.getIncludeCount() && provAttrGetReq.getIncludeCount()) {
				responseHeaders = new HttpHeaders();
				totalDocs = providerAttributesService.getAttributesTotalDocumentsByProviderIdTaxId(provAttrGetReq);
				responseHeaders.set(ProviderAttributesConstants.TOTAL_DOCS, totalDocs);
				return ResponseEntity.ok().headers(responseHeaders).body(providerAttributesDtos);
			}
			return ResponseEntity.ok(providerAttributesDtos);
		} else {
			return ResponseEntity.badRequest().build();
		}
	}
	
	private ResponseEntity<List<ProviderAttributesDTO>>  getResponseEntityByProviderId(ProviderAttrGetRequest provAttrGetReq, List<ProviderAttributesDTO> providerAttributesDtos ) {
		
		if (!providerAttributesDtos.isEmpty()) {
			if( null != provAttrGetReq.getIncludeCount() && provAttrGetReq.getIncludeCount()) {
				responseHeaders = new HttpHeaders();
				totalDocs = providerAttributesService.getAttributesTotalDocumentsByProviderId(provAttrGetReq);
				responseHeaders.set(ProviderAttributesConstants.TOTAL_DOCS, totalDocs);
				return ResponseEntity.ok().headers(responseHeaders).body(providerAttributesDtos);
			}
			return ResponseEntity.ok(providerAttributesDtos);
		} else {
			return ResponseEntity.badRequest().build();
		}
	}

	private ResponseEntity<List<ProviderAttributesDTO>>  getResponseEntityByProviderIdAndIndicator(ProviderAttrGetRequest provAttrGetReq, List<ProviderAttributesDTO> providerAttributesDtos) {
	
		if (!providerAttributesDtos.isEmpty()) {
			if( null != provAttrGetReq.getIncludeCount() && provAttrGetReq.getIncludeCount()) {
				responseHeaders = new HttpHeaders();
				totalDocs = providerAttributesService.getAttributesTotalDocumentsByProviderIdAndIndicator(provAttrGetReq);
				responseHeaders.set(ProviderAttributesConstants.TOTAL_DOCS, totalDocs);
				return ResponseEntity.ok().headers(responseHeaders).body(providerAttributesDtos);
			}
			return ResponseEntity.ok(providerAttributesDtos);
		} else {
			return ResponseEntity.badRequest().build();
		}
	}
	
	@SuppressWarnings("all")
	private void logIncomingRequest(String providerId, String providerIndicator, String providerMultiAddressKey, String providerTaxId, String firstName, Integer limit, 
			Integer offset, Boolean includeCount) {
		LogUtils.logAtInfo(log, "providerId: {}, providerIndicator: {}, providerMultiAddressKey: {}, providerTaxId: {}, firstName: {}, limit: {}, offset: {}, includeCount: {}", 
				dataMasker.maskProviderId(providerId), providerIndicator, providerMultiAddressKey, dataMasker.maskIrsNo(providerTaxId), firstName, limit, offset, includeCount);
	}
	
}

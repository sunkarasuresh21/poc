package com.humana.claims.hcaas.provider.attributes.restapi.service;

import java.util.List;

import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesDTO;
import com.humana.claims.hcaas.provider.attributes.core.mapper.ProviderAttrGetRequest;
import com.humana.claims.hcaas.provider.attributes.restapi.exception.InvalidRequestException;
import com.humana.claims.hcaas.provider.attributes.restapi.exception.NotFoundException;

public interface ProviderAttributesService {

	 List<ProviderAttributesDTO> getAttributesByProviderIdMultiAddressKeyAndIndicator(ProviderAttrGetRequest provAttrGetReq) throws NotFoundException, InvalidRequestException;

	 List<ProviderAttributesDTO> getAttributesByProviderTaxId(ProviderAttrGetRequest provAttrGetReq) throws NotFoundException, InvalidRequestException;

	 List<ProviderAttributesDTO> getAttributesByProviderId(ProviderAttrGetRequest provAttrGetReq) throws NotFoundException, InvalidRequestException;
	
	 List<ProviderAttributesDTO> getAttributesByProviderIdAndIndicator(ProviderAttrGetRequest provAttrGetReq) throws InvalidRequestException, NotFoundException;
	 
	 String getAttributesTotalDocumentsByProviderIdMultiAddressKeyAndIndicator(ProviderAttrGetRequest provAttrGetReq); 
		
	 String getAttributesTotalDocumentsByProviderIdTaxId(ProviderAttrGetRequest provAttrGetReq); 
		
	 String getAttributesTotalDocumentsByProviderId(ProviderAttrGetRequest provAttrGetReq); 
		
	 String getAttributesTotalDocumentsByProviderIdAndIndicator(ProviderAttrGetRequest provAttrGetReq);

}
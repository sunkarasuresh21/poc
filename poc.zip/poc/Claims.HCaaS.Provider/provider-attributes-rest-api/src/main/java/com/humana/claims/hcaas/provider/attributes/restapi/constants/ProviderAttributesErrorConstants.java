package com.humana.claims.hcaas.provider.attributes.restapi.constants;

public class ProviderAttributesErrorConstants {

	private ProviderAttributesErrorConstants() {

	}

	public static final String NO_RECORD_FOUND = "Provider Attributes not found using request input";

	public static final String INVALID_PROVIDER_IND = "Invalid Provider-Ind, Provider-Ind should contain [D, H]";

	public static final String INVALID_PROVIDER_MULTI_ADDRESS_KEY = "Invalid Provider-Multi-Address-Key, length should be 1";

	public static final String INVALID_PROVIDER_ID = "Invalid provId, provId should be 9 digit numeric value.";

	public static final String INVALID_TAX_ID = "Invalid provTaxId, provTaxId should be 9 digit numeric value.";

	public static final String INVALID_HEADER_COMBINATION = "Invalid input combination";
	
	public static final String INVALID_FIRST_NAME = "Invalid firstName, firstName should be of max 20 alphabets and not case sensitive.";
	
}
package com.humana.claims.hcaas.provider.attributes.restapi.service;

import static com.humana.claims.hcaas.provider.attributes.restapi.constants.ProviderAttributesErrorConstants.NO_RECORD_FOUND;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.humana.claims.hcaas.provider.attributes.core.dao.ProviderAttributesDAO;
import com.humana.claims.hcaas.provider.attributes.core.mapper.ProviderAttrGetRequest;
import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.attributes.restapi.exception.InvalidRequestException;
import com.humana.claims.hcaas.provider.attributes.restapi.exception.NotFoundException;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesDTO;
import com.humana.claims.hcaas.provider.attributes.restapi.mapper.ProviderAttributesDataMapper;
import com.humana.claims.hcaas.provider.attributes.restapi.validator.ProviderValidator;

@Service("ProviderAttributesService")
public class ProviderAttributesServiceImpl implements ProviderAttributesService {

	private ProviderAttributesDAO providerAttributesDAO;
	
	private ProviderValidator providerValidator;
	
	private ProviderAttributesDataMapper attributesDataMapper;
	
	@Autowired
	public ProviderAttributesServiceImpl(ProviderAttributesDAO providerAttributesDAO,
			ProviderValidator providerValidator, ProviderAttributesDataMapper attributesDataMapper) {
		this.providerAttributesDAO = providerAttributesDAO;
		this.providerValidator = providerValidator;
		this.attributesDataMapper = attributesDataMapper;
	}
	
	@Override
	public List<ProviderAttributesDTO> getAttributesByProviderIdMultiAddressKeyAndIndicator(ProviderAttrGetRequest provAttrGetReq) throws NotFoundException, InvalidRequestException{
		providerValidator.validateProviderAttributesDataForPATCHandGET(provAttrGetReq.getProviderIndicator(), provAttrGetReq.getProviderId(), provAttrGetReq.getProviderMultiAddressKey(), provAttrGetReq.getFirstName());
		Collection<Attributes> attributesCollection = providerAttributesDAO.getAttributesByProviderIdMultiAddressKeyAndIndicator(provAttrGetReq);
		return getAttributes(attributesCollection);
	}

	@Override
	public List<ProviderAttributesDTO> getAttributesByProviderTaxId(ProviderAttrGetRequest provAttrGetReq) 
		throws NotFoundException, InvalidRequestException {
		providerValidator.validateProviderAttributesTaxIdForGET(provAttrGetReq.getProviderTaxId(), provAttrGetReq.getFirstName());
		Collection<Attributes> attributesCollection = providerAttributesDAO.getAttributesByProviderTaxId(provAttrGetReq);
		return getAttributes(attributesCollection);
	}

	@Override
	public List<ProviderAttributesDTO> getAttributesByProviderId(ProviderAttrGetRequest provAttrGetReq) 
		throws NotFoundException, InvalidRequestException {
		providerValidator.validateProviderAttributesProviderIdForGET(provAttrGetReq.getProviderId(), provAttrGetReq.getFirstName());
		Collection<Attributes> attributesCollection = providerAttributesDAO.getAttributesByProviderId(provAttrGetReq);
		return getAttributes(attributesCollection);
	}
	
	@Override
	public List<ProviderAttributesDTO> getAttributesByProviderIdAndIndicator(ProviderAttrGetRequest provAttrGetReq) throws InvalidRequestException, NotFoundException {
		providerValidator.validateProviderAttributesProviderIdAndProviderIndicatorForGET(provAttrGetReq.getProviderId(), provAttrGetReq.getProviderIndicator(), provAttrGetReq.getFirstName());
		Collection<Attributes> attributesCollection = providerAttributesDAO.getAttributesByProviderIdAndIndicator(provAttrGetReq);
		return getAttributes(attributesCollection);
	}
	
	private List<ProviderAttributesDTO> getAttributes(Collection<Attributes> attributesCollection) throws NotFoundException {
		List<ProviderAttributesDTO> attributesDtos = new ArrayList<>();		
		if(!CollectionUtils.isEmpty(attributesCollection)) {
			attributesCollection.forEach(attributes -> {
				ProviderAttributesDTO attributesDtoMapper = attributesDataMapper.mapProviderAttributesDto(attributes);
				attributesDtos.add(attributesDtoMapper);
			});	
			return attributesDtos;
		} else {
			Set<String> errorMessages = new HashSet<>();
			errorMessages.add(NO_RECORD_FOUND);
			throw new NotFoundException(errorMessages);
		}
	}
	
	@Override
	public String getAttributesTotalDocumentsByProviderIdMultiAddressKeyAndIndicator(ProviderAttrGetRequest provAttrGetReq)  {	
		return providerAttributesDAO.getAttributesTotalDocumentsByProviderIdMultiAddressKeyAndIndicator(provAttrGetReq);
	}
	
	@Override
	public String getAttributesTotalDocumentsByProviderIdTaxId(ProviderAttrGetRequest provAttrGetReq)  {	
		return providerAttributesDAO.getAttributesTotalDocumentsByProviderIdTaxId(provAttrGetReq);
	}
	
	@Override
	public String getAttributesTotalDocumentsByProviderId(ProviderAttrGetRequest provAttrGetReq)  {	
		return providerAttributesDAO.getAttributesTotalDocumentsByProviderId(provAttrGetReq);
	}
	
	@Override
	public String getAttributesTotalDocumentsByProviderIdAndIndicator(ProviderAttrGetRequest provAttrGetReq)  {	
		return providerAttributesDAO.getAttributesTotalDocumentsByProviderIdAndIndicator(provAttrGetReq);
	}

}
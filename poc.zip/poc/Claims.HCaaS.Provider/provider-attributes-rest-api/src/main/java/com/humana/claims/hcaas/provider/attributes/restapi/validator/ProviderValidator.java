package com.humana.claims.hcaas.provider.attributes.restapi.validator;

import static com.humana.claims.hcaas.provider.attributes.restapi.constants.FieldConstants.PVD_IND_VALID_VALUE_D;
import static com.humana.claims.hcaas.provider.attributes.restapi.constants.FieldConstants.PVD_IND_VALID_VALUE_H;
import static com.humana.claims.hcaas.provider.attributes.restapi.constants.FieldConstants.PROVIDER_ID_LENGTH;
import static com.humana.claims.hcaas.provider.attributes.restapi.constants.FieldConstants.TAX_ID_LENGTH;
import static com.humana.claims.hcaas.provider.attributes.restapi.constants.ProviderAttributesErrorConstants.INVALID_FIRST_NAME;
import static com.humana.claims.hcaas.provider.attributes.restapi.constants.ProviderAttributesErrorConstants.INVALID_PROVIDER_ID;
import static com.humana.claims.hcaas.provider.attributes.restapi.constants.ProviderAttributesErrorConstants.INVALID_PROVIDER_IND;
import static com.humana.claims.hcaas.provider.attributes.restapi.constants.ProviderAttributesErrorConstants.INVALID_PROVIDER_MULTI_ADDRESS_KEY;
import static com.humana.claims.hcaas.provider.attributes.restapi.constants.ProviderAttributesErrorConstants.INVALID_TAX_ID;

import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

import com.humana.claims.hcaas.provider.attributes.restapi.exception.InvalidRequestException;

@Component
public class ProviderValidator {
	public static final Pattern FIRSTNAME_REGEX_PATTERN = Pattern.compile("^[a-zA-Z ]{0,20}$");
	
	private static final Pattern PROVIDER_ID_PATTERN = Pattern.compile(".*[1-9].*");
	
	public void validateProviderAttributesDataForPATCHandGET(String providerIndicator,
		String providerId, String providerMultiAddressKey, String firstName) throws InvalidRequestException {	
		
		Set<String> errorMessages = new HashSet<>();
					
		if(isInvalidProviderId(providerId)) {
			errorMessages.add(INVALID_PROVIDER_ID);
		}

		if(isInvalidProviderIndicator(providerIndicator)) {
			errorMessages.add(INVALID_PROVIDER_IND);
		}
		
		if(null == providerMultiAddressKey || providerMultiAddressKey.length() !=1) {
			errorMessages.add(INVALID_PROVIDER_MULTI_ADDRESS_KEY);
		}
		
		if(null != firstName && !FIRSTNAME_REGEX_PATTERN.matcher(firstName).matches()) {
			errorMessages.add(INVALID_FIRST_NAME);
		}
				
		if (!errorMessages.isEmpty()) {
			throw new InvalidRequestException(errorMessages);
		}
	}
	
	private boolean isInvalidProviderId(String providerId) {
		return (null == providerId || (!PROVIDER_ID_PATTERN.matcher(providerId).matches()) || providerId.length() != PROVIDER_ID_LENGTH);
	}

	private boolean isInvalidProviderIndicator(String providerIndicator) {
		return (null == providerIndicator || !(PVD_IND_VALID_VALUE_D.equals(providerIndicator)
				|| PVD_IND_VALID_VALUE_H.equals(providerIndicator)));
	}

	public void validateProviderAttributesProviderIdForGET(String providerId, String firstName) throws InvalidRequestException {	

			Set<String> errorMessages = new HashSet<>();
						
			if(!PROVIDER_ID_PATTERN.matcher(providerId).matches() || providerId.length() != PROVIDER_ID_LENGTH) {
				errorMessages.add(INVALID_PROVIDER_ID);
			}
			
			if(null != firstName && !FIRSTNAME_REGEX_PATTERN.matcher(firstName).matches()) {
				errorMessages.add(INVALID_FIRST_NAME);
			}

			if (!errorMessages.isEmpty()) {
				throw new InvalidRequestException(errorMessages);
			}
	}
	
	public void validateProviderAttributesTaxIdForGET(String taxId, String firstName) throws InvalidRequestException {	

			Set<String> errorMessages = new HashSet<>();

			if(!PROVIDER_ID_PATTERN.matcher(taxId).matches() || taxId.length() != TAX_ID_LENGTH) {
				errorMessages.add(INVALID_TAX_ID);
			}

			if(null != firstName && !FIRSTNAME_REGEX_PATTERN.matcher(firstName).matches()) {
				errorMessages.add(INVALID_FIRST_NAME);
			}
			
			if (!errorMessages.isEmpty()) {
				throw new InvalidRequestException(errorMessages);
			}
			
	}	
	
	public void validateProviderAttributesProviderIdAndProviderIndicatorForGET(String providerId, String providerIndicator, String firstName) throws InvalidRequestException {	

			Set<String> errorMessages = new HashSet<>();
						
			if(!PROVIDER_ID_PATTERN.matcher(providerId).matches() || providerId.length() != PROVIDER_ID_LENGTH) {
				errorMessages.add(INVALID_PROVIDER_ID);
			}
			
			if(!(PVD_IND_VALID_VALUE_D.equals(providerIndicator)|| PVD_IND_VALID_VALUE_H.equals(providerIndicator))) {
				errorMessages.add(INVALID_PROVIDER_IND);
			}
			
			if(null != firstName && !FIRSTNAME_REGEX_PATTERN.matcher(firstName).matches()) {
				errorMessages.add(INVALID_FIRST_NAME);
			}

			if (!errorMessages.isEmpty()) {
				throw new InvalidRequestException(errorMessages);
			}			
	}
}

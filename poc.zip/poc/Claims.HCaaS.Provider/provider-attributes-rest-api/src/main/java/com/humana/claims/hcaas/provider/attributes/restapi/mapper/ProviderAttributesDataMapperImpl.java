package com.humana.claims.hcaas.provider.attributes.restapi.mapper;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;
import com.humana.claims.hcaas.provider.attributes.core.model.db.PxiZip;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesCasNameDTO;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesDTO;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesKeyDTO;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesPxiZipDTO;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesWithholdDataDTO;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesWithholdDataWthldCurrentDTO;
import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesWithholdDataWthldPriorDTO;

@Component
public class ProviderAttributesDataMapperImpl implements ProviderAttributesDataMapper {	

	@Override
	public ProviderAttributesDTO mapProviderAttributesDto(Attributes attributes) {
		ProviderAttributesDTO attributesDto = new ProviderAttributesDTO();
		attributesDto.setKey(mapAttributesKeyDto(attributes));
		attributesDto.setIrsNo(attributes.getIrsNo());
		attributesDto.setVch(attributes.getVch());
		attributesDto.setTaxType(attributes.getTaxType());
		attributesDto.setSend1099Ind(attributes.getSend1099Ind());
		attributesDto.setPendEsc(attributes.getPendEsc());
		attributesDto.setAutoCheckPullInd(attributes.getAutoCheckPullInd());
		attributesDto.setIrsWithholdInd(attributes.getIrsWithholdInd());
		attributesDto.setPayCycle(attributes.getPayCycle());
		attributesDto.setCrossRef(attributes.getCrossRef());
		attributesDto.setMarketId(attributes.getMarketId());
		attributesDto.setDg(attributes.getDg());
		attributesDto.setAlphaKey(attributes.getAlphaKey());
		attributesDto.setCasName(mapCasNameDto(attributes));
		attributesDto.setMedSuppWaiveInd(attributes.getMedSuppWaiveInd());
		attributesDto.setComment1(attributes.getComment1());
		attributesDto.setComment2(attributes.getComment2());
		attributesDto.setComment3(attributes.getComment3());
		attributesDto.setNotifyInd(attributes.getNotifyInd());
		attributesDto.setFocusFromDate(attributes.getFocusFromDate());
		attributesDto.setClpthInd(attributes.getClpthInd());
		attributesDto.setClmChkInd(attributes.getClmChkInd());
		attributesDto.setUcZip(attributes.getUcZip());
		attributesDto.setFocusToDate(attributes.getFocusToDate());
		attributesDto.setAutoLoadInd(attributes.getAutoLoadInd());
		attributesDto.setCheckTo(attributes.getCheckTo());
		attributesDto.setSuffixTo(attributes.getSuffixTo());
		attributesDto.setApplyTaxInd(attributes.getApplyTaxInd());
		attributesDto.setW9Ind(attributes.getW9Ind());
		attributesDto.setSend480Ind(attributes.getSend480Ind());
		attributesDto.setWithholdData(mapWithholdDataDto(attributes));
		attributesDto.setComment1(attributes.getComment1());
		attributesDto.setUpdtAdjNo(attributes.getUpdtAdjNo());
		attributesDto.setUpdtDt(attributes.getUpdtDt());
		attributesDto.setRadSiteCurrInd(attributes.getRadSiteCurrInd());
		attributesDto.setRadSiteCurrDt(attributes.getRadSiteCurrDt());
		attributesDto.setRadSiteP1Ind(attributes.getRadSiteP1Ind());
		attributesDto.setRadSiteP1Dt(attributes.getRadSiteP1Dt());
		attributesDto.setRadSiteP2Ind(attributes.getRadSiteP2Ind());
		attributesDto.setRadSiteP2Dt(attributes.getRadSiteP2Dt());
		attributesDto.setRadScopeCurrInd(attributes.getRadScopeCurrInd());
		attributesDto.setRadScopeCurrDt(attributes.getRadScopeCurrDt());
		attributesDto.setRadScopeP1Ind(attributes.getRadScopeP1Ind());
		attributesDto.setRadScopeP1Dt(attributes.getRadScopeP1Dt());
		attributesDto.setFacUcZip(attributes.getFacUcZip());
		attributesDto.setPxiUpdtAdjNo(attributes.getPxiUpdtAdjNo());
		attributesDto.setPxiUpdtDt(attributes.getPxiUpdtDt());
		attributesDto.setSendLtrInd(attributes.getSendLtrInd());
		attributesDto.setFinalstInd(attributes.getFinalstInd());
		attributesDto.setPxiZip(mapPxiZipDto(attributes));
		attributesDto.setCompbidInd(attributes.getCompbidInd());
		attributesDto.setVendorId(attributes.getVendorId());
		attributesDto.setCompbidEffDt(attributes.getCompbidEffDt());
		attributesDto.setCompbidTrmDt(attributes.getCompbidTrmDt());
		attributesDto.setContractPointEnable(attributes.getContractPointEnable());

		return attributesDto;
	}
	
	private static ProviderAttributesKeyDTO mapAttributesKeyDto(Attributes attributes) {
		ProviderAttributesKeyDTO keyDto = new ProviderAttributesKeyDTO();		
		keyDto.setClient(null == attributes.getKey()? null: attributes.getKey().getClient());
		keyDto.setPvdInd(null == attributes.getKey()? null: attributes.getKey().getPvdInd());
		keyDto.setProv(null == attributes.getKey()? null: attributes.getKey().getProv());
		keyDto.setMultAddressKey(null == attributes.getKey()? null: attributes.getKey().getMultAddressKey());
		
		return keyDto;
	}
	
	private static ProviderAttributesCasNameDTO mapCasNameDto(Attributes attributes) {
		ProviderAttributesCasNameDTO casNameDto = new ProviderAttributesCasNameDTO();
		casNameDto.casFstName(null == attributes.getCasName()? null: attributes.getCasName().getFstName());
		casNameDto.casLastName(null == attributes.getCasName()? null: attributes.getCasName().getLastName());
		
		return casNameDto;
	}
	
	private static ProviderAttributesWithholdDataDTO mapWithholdDataDto(Attributes attributes) {
		ProviderAttributesWithholdDataDTO withHldDataDto = new ProviderAttributesWithholdDataDTO();
		withHldDataDto.wthldCurrent(mapWthldCurrentDto(attributes));
		withHldDataDto.wthldPrior(mapWthldPriorDto(attributes));
		withHldDataDto.prTaxfreeAmt(null == attributes.getWithholdData()? null: attributes.getWithholdData().getPrTaxfreeAmt());
		
		return withHldDataDto;
	}

	private static ProviderAttributesWithholdDataWthldCurrentDTO mapWthldCurrentDto(Attributes attributes) {
		ProviderAttributesWithholdDataWthldCurrentDTO withHldCurrentDto = new ProviderAttributesWithholdDataWthldCurrentDTO();
		withHldCurrentDto.setWthldPerCurrent(null == attributes.getWithholdData()? null: mapldPerCurrent(attributes));
		withHldCurrentDto.setWthldEffDateCurrent(null == attributes.getWithholdData()? null: mapldEffDateCurrent(attributes));
		
		return withHldCurrentDto;
	}

	private static String mapldPerCurrent(Attributes attributes) {
		return (null == attributes.getWithholdData().getWthldCurrent() ? null: attributes.getWithholdData().getWthldCurrent().getWthldPerCurrent());
	}
	
	private static LocalDate mapldEffDateCurrent(Attributes attributes) {
		return (null == attributes.getWithholdData().getWthldCurrent()? null : attributes.getWithholdData().getWthldCurrent().getWthldEffDateCurrent());
	}
	
	private static ProviderAttributesWithholdDataWthldPriorDTO mapWthldPriorDto(Attributes attributes) {
		ProviderAttributesWithholdDataWthldPriorDTO withHldPriorDto = new ProviderAttributesWithholdDataWthldPriorDTO();
		withHldPriorDto.setWthldPerPrior(null == attributes.getWithholdData()? null: mapldPerPrior(attributes));
		withHldPriorDto.setWthldEffDatePrior(null == attributes.getWithholdData()? null: mapldEffDatePrior(attributes));
		
		return withHldPriorDto;
	}
	
	private static String mapldPerPrior(Attributes attributes) {
		return (null == attributes.getWithholdData().getWthldPrior()? null: attributes.getWithholdData().getWthldPrior().getWthldPerPrior());
	}

	private static LocalDate mapldEffDatePrior(Attributes attributes) {
		return (null == attributes.getWithholdData().getWthldPrior()? null: attributes.getWithholdData().getWthldPrior().getWthldEffDatePrior());
	}
	
	private static List<ProviderAttributesPxiZipDTO> mapPxiZipDto(Attributes attributes) {
		List<ProviderAttributesPxiZipDTO> pxiZipDtos = new ArrayList<>();

		for(PxiZip pxiZip : attributes.getPxiZip()) {
			ProviderAttributesPxiZipDTO pxiZipDto = new ProviderAttributesPxiZipDTO();
			pxiZipDto.setPxiZipCode(pxiZip.getPxiZipCode());
			pxiZipDto.setPxiZipInd(pxiZip.getPxiZipInd());
			pxiZipDtos.add(pxiZipDto);
		}
		return pxiZipDtos;
	}

}
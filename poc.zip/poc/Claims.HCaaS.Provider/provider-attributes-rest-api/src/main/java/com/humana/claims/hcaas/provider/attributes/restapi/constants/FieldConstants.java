package com.humana.claims.hcaas.provider.attributes.restapi.constants;

public class FieldConstants {
	
	private FieldConstants() {
		
	}
	
	public static final String PVD_IND_VALID_VALUE_D = "D";
	
	public static final String PVD_IND_VALID_VALUE_H = "H";	
	
	public static final int PROVIDER_ID_LENGTH = 9;

	public static final int TAX_ID_LENGTH = 9;

}

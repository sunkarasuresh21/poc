package com.humana.claims.hcaas.provider.attributes.restapi.mapper;

import com.humana.claims.hcaas.provider.attributes.restapi.gen.openapi.model.ProviderAttributesDTO;
import com.humana.claims.hcaas.provider.attributes.core.model.db.Attributes;

public interface ProviderAttributesDataMapper {

	 ProviderAttributesDTO mapProviderAttributesDto(Attributes attributes);
	 
}
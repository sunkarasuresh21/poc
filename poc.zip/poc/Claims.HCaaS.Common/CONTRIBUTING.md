# Contributing to HCaaS Common Libraries

Please review this entire document before proceeding.  Ask if you have any questions or concerns.

## Testing

1. Clone the Claims.HCaaS.Common repo to your hard drive
2. Update the version
	- Bump the version up and add SNAPSHOT (ex: if the current version is 1.0.0, use 1.0.1-SNAPSHOT)
	- See Versioning below for description on what version to use
	- See the "Versioning/Updating the Version" sections below for steps on how to update the version
3. In an STS workspace with an existing application (ex: dbar-umt), Use Import Existing Maven Projects to import the HCaaS Common Projects
4. In the existing application, update the root pom (/pom.xml) parent to use the version you just set on the common project (ex: 1.0.1-SNAPSHOT).  ex:

```xml
<project>
	<parent>
		<groupId>com.humana.claims.hcaas.common</groupId>
		<artifactId>hcaas-common-parent</artifactId>
		<version>1.0.0</version> <-- UPDATE THIS VERSION -->
		<relativePath />
	</parent>
</project>
```

If everything is setup correctly, there should be no build errors in STS, and your application will be using the HCaaS Common Libraries in the STS workspace.

## Pushing changes
1. Once code is completed, run `./update-version.sh` again to update the version to a non-snapshot version (ex: 1.0.1)
2. Validate unit tests pass, and all new code is covered by unit tests
3. Update the Changelog and Readme as appropriate
4. Push to a feature branch in ADO, and Open a PR to master
5. The PR must be approved and completed, AND the master branch build must successful
6. In all the HCaaS repos that should receive this change, update the root pom (/pom.xml) parent to the version you set on the common project (ex: 1.0.1)

# Versioning
Versions should always increase!  If the latest version on master is 1.2.3, do not merge into master an earlier version number (ex: 1.1.2 or 1.2.2 would be invalid)

Once a version has been merged into master, the library is pushed to our Artifactory repo.  This version cannot be updated - any changes require the version to be updated.

Use [Semantic Versioning](https://semver.org/):
- Update the MAJOR version when you make a non-backwards compatible change
- Update the MINOR version when you add functionality in a backwards compatible manner
- Update the PATCH version when you make backwards compatible bug fixes

## Updating the Version (STS/Eclipse)
1. Right-click on the hcaas-common-parent project, and choose `Run As > Maven build` (be sure to select the one _without_ an ellipsis )
2. If prompted to Select Configuration, select "Update hcaas-common version"
	- The Select Configuration prompt will only appear if there is another m2e run configuration for the hcaas-common-parent project in the Eclipse workspace
	- The run configuration is stored in the eclipse/ directory of the repository and should be imported automatically into STS/Eclipse.
3. When prompted, enter the new version for hcaas-common
4. Wait a moment for the maven command to complete (you will see the output in the Console view)

## Updating the Version (CLI)

1. Open Windows Command Prompt or Git Bash on your workstation
2. `cd` to the directory where your HCaaS Common working directory is
3. Run the update version script
	- If using Command Prompt, run `update-version.bat`
	- If using Git Bash, run `./update-version.bat`
4. Answer the prompts

If you get an error, review the maven setup in the onboarding documentation, and confirm both maven is configured.

## Updating the Version (Manually)

**Note**: Using any of the other options is preferred, as they are quicker and ensure there no mistakes.

1. `hcaas-common-parent/pom.xml`: Update the version tag
2. `hcaas-common-parent/pom.xml`: Update all the dependencyManagement/dependencies/dependency/version tags where the groupId is com.humana.claims.hcaas.common
3. All other modules: Update the parent/version tag

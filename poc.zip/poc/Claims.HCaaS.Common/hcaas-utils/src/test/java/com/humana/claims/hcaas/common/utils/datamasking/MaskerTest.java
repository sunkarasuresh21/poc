package com.humana.claims.hcaas.common.utils.datamasking;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.function.Supplier;

import org.junit.jupiter.api.Test;


class MaskerTest {
	
	@Test
	void mask_supplier_should_return_lambda_that_masks() {
		Masker masker = StringMasker.stringMasker(0,3);

		Supplier<String> actual = masker.maskSupplier("test_string");
		
		assertThat(actual).isNotNull();

		assertThat(actual.get()).isEqualTo("***ing");
	}
}

package com.humana.claims.hcaas.common.utils.datamasking;

import static com.humana.claims.hcaas.common.utils.datamasking.JsonMaskerConfiguration.jsonMaskerConfig;
import static com.humana.claims.hcaas.common.utils.datamasking.StringMasker.stringMasker;
import static org.assertj.core.api.Assertions.assertThat;

import org.json.JSONException;
import org.junit.jupiter.api.Test;
import org.skyscreamer.jsonassert.JSONAssert;

class JsonMaskerTest {
	
	@Test
	void no_configuration_returns_same_string() throws JSONException {
		JsonMasker classUnderTest = new JsonMasker();
		
		String actual = classUnderTest.mask(jsonString("{ 'name': 'Fred' }"));
		
		JSONAssert.assertEquals(jsonString("{ 'name': 'Fred' }"), actual, true);
	}
	
	@Test
	void invalid_json_returns_invalid_json_msg() {
		JsonMasker classUnderTest = new JsonMasker();
		
		String actual = classUnderTest.mask(jsonString("{ 'name': 'Fred' ")); // missing end curly bracket
		
		assertThat(actual).containsSubsequence("Error parsing JSON");
	}
	
	@Test
	void mask_single_field() throws JSONException {
		JsonMasker classUnderTest = new JsonMasker(jsonMaskerConfig(stringMasker(0,2), "provid"));
		
		String actual = classUnderTest.mask(jsonString("{ 'provid': '123456789', 'provname': 'Fred' }"));
		
		JSONAssert.assertEquals(jsonString("{ 'provid': '***89', 'provname': 'Fred' }"), actual, true);
	}
	
	@Test
	void mask_multiple_field_inside_array() throws JSONException {
		JsonMasker classUnderTest = new JsonMasker(jsonMaskerConfig(stringMasker(1,1), "color"),jsonMaskerConfig(stringMasker(2,0), "component"));
		
		String actual = classUnderTest.mask(jsonString(
				"{ 'UI' :["
				+ "{ 'name': 'footer', 'color': 'green', 'component': 'htmlfooter'}, "
				+ "{ 'name': 'table', 'ColOR': 'white', 'component':  'htmltable'}, "
				+ "{ 'name': 'combo-box','color': 'blue','component': 'htmlcombobox'}"
				+ "]"
				+ "}"));
		
		JSONAssert.assertEquals(jsonString(
				"{ 'UI' :["
				+ "{ 'name': 'footer', 'color': 'g***n', 'component': 'ht***'}, "
				+ "{ 'name': 'table', 'ColOR': 'w***e', 'component':  'ht***'}, "
				+ "{ 'name': 'combo-box','color': 'b***e','component': 'ht***'}"
				+ "]"
				+ "}"),actual, true);
	}
	
	@Test
	void mask_multiple_fields_inside_nested_documents_and_array() throws JSONException {
		JsonMasker classUnderTest = new JsonMasker(jsonMaskerConfig(stringMasker(0,2), "type"),jsonMaskerConfig(stringMasker(1,1), "visual"));
		
		String actual = classUnderTest.mask(jsonString(
				"{" + 
				"	'id': '0001'," + 
				"	'type': 'donut'," + 
				"	'batters':" + 
				"		{" + 
				"			'batter':" + 
				"				{" + 
				"					'type': 'Regular' ," + 
				"					'choice' : {" + 
				"							'visual': 'Chocolate' " + 
				"					}" + 
				"				}" + 
				"		}," + 
				"	'topping':" + 
				"		[" + 
				"			{ 'id': '5001', 'VISuaL': 'None' }," + 
				"			{ 'id': '5002', 'visual': 'Glazed' }" + 
				"		]" + 
				"}"));
		
		JSONAssert.assertEquals(jsonString(
				"{" + 
				"	'id': '0001'," + 
				"	'type': '***ut'," + 
				"	'batters':" + 
				"		{" + 
				"			'batter':" + 
				"				{" + 
				"					'type': '***ar' ," + 
				"					'choice' : {" + 
				"							'visual': 'C***e' " + 
				"					}" + 
				"				}" + 
				"		}," + 
				"	'topping':" + 
				"		[" + 
				"			{ 'id': '5001', 'VISuaL': 'N***e' }," + 
				"			{ 'id': '5002', 'visual': 'G***d' }" + 
				"		]" + 
				"}"),actual, true);
	}

	@Test
	void mask_multiple_fields_inside_array_of_nested_documets() throws JSONException {
		JsonMasker classUnderTest = new JsonMasker(jsonMaskerConfig(stringMasker(2,2), "choice"),jsonMaskerConfig(stringMasker(0,2), "comment"));
		
		String actual = classUnderTest.mask(jsonString(
				"{" + 
				"	'choices':[" + 
				"		{" + 
				"			'id': '0001'," + 
				"			'choice': 'fruit'," + 
				"			'batters':" + 
				"				{" + 
				"					'batter':" + 
				"						[" + 
				"							" + 
				"							{  'CHOICE': 'Blueberry' }," + 
				"							{ 'comment': 'yummy' }" + 
				"						]" + 
				"				}," + 
				"			'topping':" + 
				"				[" + 
				"					{  'choice': 'strawberry' }," + 
				"					{ 'COMMENT': 'veryTasty' }" + 
				"				]" + 
				"		}," + 
				"		{" + 
				"			'id': '0002'," + 
				"			'CHOICE': 'donut'," + 
				"			'batters':" + 
				"				{" + 
				"					'batter':" + 
				"						[" + 
				"							{  'chOIce': 'pinkdonut' }," + 
				"							{ 'comment': 'highsugar' }" + 
				"						]" + 
				"				}," + 
				"			'topping':" + 
				"				[" + 
				"					{  'CHOICE': 'bluedonut' }," + 
				"					{ 'COMMENT': 'lowsugar' }" + 
				"				]" + 
				"		}" + 
				"	]" + 
				"}"));
		
		JSONAssert.assertEquals(jsonString(
				"{" + 
				"	'choices':[" + 
				"		{" + 
				"			'id': '0001'," + 
				"			'choice': 'fr***it'," + 
				"			'batters':" + 
				"				{" + 
				"					'batter':" + 
				"						[" + 
				"							" + 
				"							{  'CHOICE': 'Bl***ry' }," + 
				"							{ 'comment': '***my' }" + 
				"						]" + 
				"				}," + 
				"			'topping':" + 
				"				[" + 
				"					{  'choice': 'st***ry' }," + 
				"					{ 'COMMENT': '***ty' }" + 
				"				]" + 
				"		}," + 
				"		{" + 
				"			'id': '0002'," + 
				"			'CHOICE': 'do***ut'," + 
				"			'batters':" + 
				"				{" + 
				"					'batter':" + 
				"						[" + 
				"							{  'chOIce': 'pi***ut' }," + 
				"							{ 'comment': '***ar' }" + 
				"						]" + 
				"				}," + 
				"			'topping':" + 
				"				[" + 
				"					{  'CHOICE': 'bl***ut' }," + 
				"					{ 'COMMENT': '***ar' }" + 
				"				]" + 
				"		}" + 
				"	]" + 
				"}"),actual, true);
	} 

	/** convert ' to " (makes it easier to build JSON strings) */
	private String jsonString(String jsonishString) {
		return jsonishString.replace("'", "\"");
	}

}

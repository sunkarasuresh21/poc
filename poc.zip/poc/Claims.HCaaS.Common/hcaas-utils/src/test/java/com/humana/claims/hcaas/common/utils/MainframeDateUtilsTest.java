package com.humana.claims.hcaas.common.utils;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;

import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;


class MainframeDateUtilsTest {

	@Test
	void convertMMDDYYYYStringToLocalDateShouldRetunNullWhenInputIsZeros() {
		LocalDate actual = MainframeDateUtils.convertMMDDYYYYStringToLocalDate("00000000");

		Assertions.assertThat(actual).isNull();
	}
	
	@Test
	void convertMMDDYYYYStringToLocalDateShouldRetunNullWhenInputIsZero() {
		LocalDate actual = MainframeDateUtils.convertMMDDYYYYStringToLocalDate("0");

		Assertions.assertThat(actual).isNull();
	}

	@Test
	void convertMMDDYYYYStringToLocalDateShouldRetunNullWhenInputIsNull() {
		LocalDate actual = MainframeDateUtils.convertMMDDYYYYStringToLocalDate(null);

		Assertions.assertThat(actual).isNull();
	}

	@Test
	void convertMMDDYYYYStringToLocalDateShouldThrowDateTimeParseExceptionWhenInvalidFormat() {
		String invalidFormat = "123";
		
		Throwable t = catchThrowable(() -> MainframeDateUtils.convertMMDDYYYYStringToLocalDate(invalidFormat));
		
		assertThat(t).isInstanceOf(DateTimeParseException.class);
	}


	@Test
	void convertMMDDYYYYStringToLocalDateShouldRetunNullWhenInputIs9s() {
		LocalDate actual = MainframeDateUtils.convertMMDDYYYYStringToLocalDate("99999999");

		Assertions.assertThat(actual).isNull();
	}

	@Test
	void convertMMDDYYYYStringToLocalDateShouldRetunValidDateWhenInputIsValidStringDate() {
		LocalDate actual = MainframeDateUtils.convertMMDDYYYYStringToLocalDate("09301999");

		Assertions.assertThat(actual).isEqualTo(LocalDate.of(1999, 9, 30));
	}

	@Test
	void convertYYMMStringToLocalDateShouldRetunNullWhenInputIsZeros() {
		LocalDate actual = MainframeDateUtils.convertYYMMStringToLocalDate("0000");
		
		Assertions.assertThat(actual).isNull();
	}
	
	@Test
	void convertYYMMStringToLocalDateShouldRetunNullWhenInputIsZero() {
		LocalDate actual = MainframeDateUtils.convertYYMMStringToLocalDate("0");
		
		Assertions.assertThat(actual).isNull();
	}

	@Test
	void convertYYMMStringToLocalDateShouldRetunNullWhenInputIsNull() {
		LocalDate actual = MainframeDateUtils.convertYYMMStringToLocalDate(null);
		
		Assertions.assertThat(actual).isNull();
	}

	@Test
	void convertYYMMStringToLocalDateShouldRetunNullWhenInputIs9s() {
		LocalDate actual = MainframeDateUtils.convertYYMMStringToLocalDate("9999");
		
		Assertions.assertThat(actual).isNull();
	}
	
	@Test
	void convertYYMMStringToLocalDateShouldThrowDateTimeParseExceptionWhenInvalidFormat() {
		String invalidFormat = "123";
		
		Throwable t = catchThrowable(() -> MainframeDateUtils.convertYYMMStringToLocalDate(invalidFormat));
		
		assertThat(t).isInstanceOf(DateTimeParseException.class);
	}

	@Test
	void convertYYMMStringToLocalDateShouldRetunValidDateInTwentyFirstCenturyWhenInputIsValidStringDateStartsWithLessThan40() {
		LocalDate actual = MainframeDateUtils.convertYYMMStringToLocalDate("1909");
		
		Assertions.assertThat(actual).isEqualTo(LocalDate.of(2019, 9, 1));
	}

	@Test
	void convertYYMMStringToLocalDateShouldRetunValidDateInTwentiethCenturyWhenInputIsValidStringDateStartsWithGreaterThan40() {
		LocalDate actual = MainframeDateUtils.convertYYMMStringToLocalDate("4109");
		
		Assertions.assertThat(actual).isEqualTo(LocalDate.of(1941, 9, 1));
	}

	@Test
	void convertYYMMDDStringToLocalDateShouldRetunNullWhenInputIsZeros() {
		LocalDate actual = MainframeDateUtils.convertYYMMDDStringToLocalDate("000000");
		
		Assertions.assertThat(actual).isNull();
	}
	
	@Test
	void convertYYMMDDStringToLocalDateShouldRetunNullWhenInputIsZero() {
		LocalDate actual = MainframeDateUtils.convertYYMMDDStringToLocalDate("0");
		
		Assertions.assertThat(actual).isNull();
	}

	@Test
	void convertYYMMDDStringToLocalDateShouldRetunNullWhenInputIsNull() {
		LocalDate actual = MainframeDateUtils.convertYYMMDDStringToLocalDate(null);
		
		Assertions.assertThat(actual).isNull();
	}

	@Test
	void convertYYMMDDStringToLocalDateShouldRetunNullWhenInputIs9s() {
		LocalDate actual = MainframeDateUtils.convertYYMMDDStringToLocalDate("999999");
		
		Assertions.assertThat(actual).isNull();
	}
	
	@Test
	void convertYYMMDDStringToLocalDateShouldRetunValidDateInTwentyFirstCenturyWhenInputIsValidStringDateStartsWithLessThan40() {
		LocalDate actual = MainframeDateUtils.convertYYMMDDStringToLocalDate("190930");
		
		Assertions.assertThat(actual).isEqualTo(LocalDate.of(2019, 9, 30));
	}

	@Test
	void convertYYMMDDStringToLocalDateShouldRetunValidDateInTwentiethCenturyWhenInputIsValidStringDateStartsWithGreaterThan40() {
		LocalDate actual = MainframeDateUtils.convertYYMMDDStringToLocalDate("410930");
		
		Assertions.assertThat(actual).isEqualTo(LocalDate.of(1941, 9, 30));
	}
	
	@Test
	void convertYYMMDDStringToLocalDateShouldThrowDateTimeParseExceptionWhenInvalidFormat() {
		String invalidFormat = "123";
		
		Throwable t = catchThrowable(() -> MainframeDateUtils.convertYYMMDDStringToLocalDate(invalidFormat));
		
		assertThat(t).isInstanceOf(DateTimeParseException.class);
	}

	@Test
    void convertYYYYMMDDStringToLocalDateShouldRetunNullWhenInputIsZeros() {
		LocalDate actual = MainframeDateUtils.convertYYYYMMDDStringToLocalDate("00000000");
		
		Assertions.assertThat(actual).isNull();
	}
	
	@Test
	void convertYYYYMMDDStringToLocalDateShouldRetunNullWhenInputIsZero() {
		LocalDate actual = MainframeDateUtils.convertYYYYMMDDStringToLocalDate("0");
		
		Assertions.assertThat(actual).isNull();
	}

	@Test
	void convertYYYYMMDDStringToLocalDateShouldRetunNullWhenInputIsNull() {
		LocalDate actual = MainframeDateUtils.convertYYYYMMDDStringToLocalDate(null);
		
		Assertions.assertThat(actual).isNull();
	}

	@Test
	void convertYYYYMMDDStringToLocalDateShouldRetunNullWhenInputIs9s() {
		LocalDate actual = MainframeDateUtils.convertYYYYMMDDStringToLocalDate("99999999");
		
		Assertions.assertThat(actual).isNull();
	}
	
	@Test
	void convertYYYYMMDDStringToLocalDateShouldThrowDateTimeParseExceptionWhenInvalidFormat() {
		String invalidFormat = "123";
		
		Throwable t = catchThrowable(() -> MainframeDateUtils.convertYYYYMMDDStringToLocalDate(invalidFormat));
		
		assertThat(t).isInstanceOf(DateTimeParseException.class);
	}

	@Test
	void convertYYYYMMDDStringToLocalDateShouldReturnValidDateWhenInputIsValidStringDate() {
		LocalDate actual = MainframeDateUtils.convertYYYYMMDDStringToLocalDate("20190915");
		
		Assertions.assertThat(actual).isEqualTo(LocalDate.of(2019, 9, 15));
	}
	
	@Test
	void convertYYYYdashMMdashDDStringToLocalDateShouldReturnValidDateWhenInputIsValidStringDate() {
		LocalDate actual = MainframeDateUtils.convertYYYYdashMMdashDDStringToLocalDate("2019-09-15");
		
		Assertions.assertThat(actual).isEqualTo(LocalDate.of(2019, 9, 15));
	}
	
	@Test
	void convertYYYYdashMMdashDDStringToLocalDateShouldThrowDateTimeParseExceptionWhenInvalidFormat() {
		String invalidFormat = "123";
		
		Throwable t = catchThrowable(() -> MainframeDateUtils.convertYYYYdashMMdashDDStringToLocalDate(invalidFormat));
		
		assertThat(t).isInstanceOf(DateTimeParseException.class);
	}
	
	@Test
	void null_toInstant_should_return_null() {
		Instant actual = MainframeDateUtils.toInstant(null);
		
		assertThat(actual).isNull();
	}

	@Test
	void toInstant_should_return_Instant_at_midnight_eastern_time() {
		Instant actual = MainframeDateUtils.toInstant(LocalDate.of(2018, 12, 23));
		
		assertThat(actual).isEqualTo(Instant.parse("2018-12-23T05:00:00Z"));
	}

	@Test
	void toInstant_should_return_Instant_at_midnight_eastern_time_during_DST() {
		Instant actual = MainframeDateUtils.toInstant(LocalDate.of(2020, 06, 18));
		
		assertThat(actual).isEqualTo(Instant.parse("2020-06-18T04:00:00Z"));
	}

	@Test
	void null_toMainframeLocalDate_should_return_null() {
		LocalDate actual = MainframeDateUtils.toMainframeLocalDate(null);
		
		assertThat(actual).isNull();
	}

	@Test
	void toMainframeLocalDate_should_return_LocalDate() {
		LocalDate actual = MainframeDateUtils.toMainframeLocalDate(Instant.parse("2018-12-23T12:07:42Z"));
		
		assertThat(actual).isEqualTo(LocalDate.of(2018, 12, 23));
	}

	@Test
	void toMainframeLocalDate_should_return_LocalDate_in_EST() {
		LocalDate actual = MainframeDateUtils.toMainframeLocalDate(Instant.parse("2020-12-01T04:59:59Z"));
		
		assertThat(actual).isEqualTo(LocalDate.of(2020, 11, 30));
	}

	@Test
	void toMainframeLocalDate_should_return_LocalDate_in_EDT() {
		LocalDate actual = MainframeDateUtils.toMainframeLocalDate(Instant.parse("2020-06-15T04:59:59Z"));
		
		assertThat(actual).isEqualTo(LocalDate.of(2020, 6, 15));
	}

}

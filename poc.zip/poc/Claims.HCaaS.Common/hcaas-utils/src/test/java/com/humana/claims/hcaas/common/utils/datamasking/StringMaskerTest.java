package com.humana.claims.hcaas.common.utils.datamasking;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class StringMaskerTest {

	@Test
	void no_unmasked_chars_should_return_only_the_mask() {
		StringMasker classUnderTest = StringMasker.stringMasker(0,0);
		
		String actual = classUnderTest.mask("test_string");
		
		assertThat(actual).isEqualTo("***");
	}
	
	@Test
	void should_include_correct_number_of_trailing_unmasked_chars() {
		StringMasker classUnderTest = StringMasker.stringMasker(0,3);
		
		String actual = classUnderTest.mask("test_string");
		
		assertThat(actual).isEqualTo("***ing");
	}
	
	@Test
	void should_include_all_characters_and_spacing_when_unmasked_chars_length_less_than_string_length() {
		StringMasker classUnderTest = StringMasker.stringMasker(0,4);
		
		String actual = classUnderTest.mask("AB");
		
		assertThat(actual).isEqualTo("***  AB");
	}

	@Test
	void should_include_correct_number_of_leading_unmasked_chars() {
		StringMasker classUnderTest = StringMasker.stringMasker(3,0);
		
		String actual = classUnderTest.mask("test_string");
		
		assertThat(actual).isEqualTo("tes***");
	}

	@Test
	void should_include_all_characters_and_spacing_when_leading_unmasked_chars_length_less_than_string_length() {
		StringMasker classUnderTest = StringMasker.stringMasker(4,0);
		
		String actual = classUnderTest.mask("AB");
		
		assertThat(actual).isEqualTo("AB  ***");
	}

	@Test
	void null_should_return_string_null() {
		StringMasker classUnderTest = StringMasker.stringMasker(3,4);
		
		String actual = classUnderTest.mask(null);
		
		assertThat(actual).isEqualTo("null");
	}
	
	@Test
	void nomask_create_instance_that_does_not_mask() {
		StringMasker nomask = StringMasker.nomask();
		
		String actual = nomask.mask("test_string");
		
		assertThat(actual).isEqualTo("test_string");
	}
	
}

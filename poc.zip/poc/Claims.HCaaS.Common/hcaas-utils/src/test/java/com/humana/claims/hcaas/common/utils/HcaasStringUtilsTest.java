package com.humana.claims.hcaas.common.utils;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;


@ExtendWith(SpringExtension.class)
class HcaasStringUtilsTest {
	
	@Test
	void zeroIfBlankShouldReturnInputWhenNotBlank() {
		String actual = HcaasStringUtils.zeroIfBlank("9");

		Assertions.assertThat(actual.toString()).isEqualTo("9");
	}

	@Test
	void zeroIfBlankShouldReturnZeroWhenBlank() {
		String actual = HcaasStringUtils.zeroIfBlank("");

		Assertions.assertThat(actual.toString()).isEqualTo("0");
	}
}

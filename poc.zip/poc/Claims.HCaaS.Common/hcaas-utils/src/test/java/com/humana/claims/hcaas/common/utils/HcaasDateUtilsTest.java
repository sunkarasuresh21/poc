package com.humana.claims.hcaas.common.utils;

import static org.assertj.core.api.Assertions.assertThat;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
public class HcaasDateUtilsTest {

	private static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";
	SimpleDateFormat formatter = new SimpleDateFormat(DATE_TIME_FORMAT);

	@Test
	public void iso8601_extended_utc_formatter_should_format_dates_correctly() {
		Date test_javaUtilDate = Date.from(Instant.parse("2021-12-24T01:07:45Z"));

		String actual = HcaasDateUtils.ISO_8601_EXTENDED_DATETIME_UTC_FORMAT.format(test_javaUtilDate);

		assertThat(actual).isEqualTo("2021-12-24T01:07:45.000Z");
	}

	@Test
	public void iso8601_extended_utc_formatter_should_format_datesWithMillisecondPrecision_correctly() {
		Date test_javaUtilDate = Date.from(Instant.parse("2021-12-24T01:07:45.123Z"));

		String actual = HcaasDateUtils.ISO_8601_EXTENDED_DATETIME_UTC_FORMAT.format(test_javaUtilDate);

		assertThat(actual).isEqualTo("2021-12-24T01:07:45.123Z");
	}

	@Test
	@SneakyThrows
	public void iso8601_extended_utc_formatter_should_parse_datesWithMillisecondPrecision_correctly() {
		Date actual = HcaasDateUtils.ISO_8601_EXTENDED_DATETIME_UTC_FORMAT.parse("2021-12-24T01:07:45.123Z");

		assertThat(actual).isEqualTo(Date.from(Instant.parse("2021-12-24T01:07:45.123Z")));
	}

	@Test
	@SneakyThrows
	public void iso8601_extended_utc_formatter_should_parse_datesWithZeroForMillis_correctly() {
		Date actual = HcaasDateUtils.ISO_8601_EXTENDED_DATETIME_UTC_FORMAT.parse("2021-12-24T01:07:45.000Z");

		assertThat(actual).isEqualTo(Date.from(Instant.parse("2021-12-24T01:07:45.000Z")));
	}

}

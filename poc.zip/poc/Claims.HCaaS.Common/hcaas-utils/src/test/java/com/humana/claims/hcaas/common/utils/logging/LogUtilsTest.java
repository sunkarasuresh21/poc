package com.humana.claims.hcaas.common.utils.logging;

import static com.humana.claims.hcaas.common.utils.datamasking.StringMasker.stringMasker;
import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.humana.claims.hcaas.common.utils.datamasking.StringMasker;
import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;


class LogUtilsTest {

	private Logger log;
	private ch.qos.logback.classic.Logger logImpl;
	private ListAppender<ILoggingEvent> logAppender;
	
	@BeforeEach
	public void setup() {
	    this.logAppender = new ListAppender<>();
	    logAppender.start();

	    this.log = LoggerFactory.getLogger(this.getClass());
	    this.logImpl = (ch.qos.logback.classic.Logger)log;
		logImpl.addAppender(logAppender);
	}

	@AfterEach
	public void teardownLogAppender() {
		logImpl.detachAndStopAllAppenders();
	}
	
	@Test
	void should_log_if_enabled() {
		logImpl.setLevel(Level.INFO);
		
		LogUtils.logAtInfo(log, "test");
		
		assertThat(logAppender.list)
			.extracting(ILoggingEvent::getFormattedMessage)
			.contains("test");
	}

	
	@Test
	void no_logging_if_logging_disabled() {
		logImpl.setLevel(Level.OFF);
		
		LogUtils.logAtInfo(log, "test");
		
		assertThat(logAppender.list)
			.extracting(ILoggingEvent::getFormattedMessage)
			.hasSize(0);
	}

	@Test
	void should_pass_args() {
		logImpl.setLevel(Level.INFO);

		LogUtils.logAtInfo(log, "test {} {}", "arg1", "arg2");
		
		assertThat(logAppender.list)
			.extracting(ILoggingEvent::getFormattedMessage)
			.contains("test arg1 arg2");
	}
	
	@Test
	void should_execute_suppliers_when_logging() {
		StringMasker providerIdMasker = StringMasker.stringMasker(0, 2);
		String providerId = "ABCD";
		logImpl.setLevel(Level.INFO);
		
		LogUtils.logAtInfo(log, "values {} {}", "value1", providerIdMasker.maskSupplier(providerId));
		
		assertThat(logAppender.list)
			.extracting(ILoggingEvent::getFormattedMessage)
			.contains("values value1 ***CD");
	}

	@Test
	void should_log_at_warn_if_warn_enabled() {
		logImpl.setLevel(Level.WARN);
		
		LogUtils.logAtWarn(log, "values {} {}", "value1", stringMasker(0, 2).maskSupplier("ABCD"));
		
		assertThat(logAppender.list)
			.extracting(ILoggingEvent::getFormattedMessage)
			.contains("values value1 ***CD");
	}

	@Test
	void should_not_log_at_warn_if_warn_disabled() {
		logImpl.setLevel(Level.ERROR);
		
		LogUtils.logAtWarn(log, "values {} {}", "value1", stringMasker(0, 2).maskSupplier("ABCD"));
		
		assertThat(logAppender.list)
			.extracting(ILoggingEvent::getFormattedMessage)
			.hasSize(0);
	}

	@Test
	void should_log_at_debug_if_warn_enabled() {
		logImpl.setLevel(Level.DEBUG);
		
		LogUtils.logAtDebug(log, "values {} {}", "value1", stringMasker(0, 2).maskSupplier("ABCD"));
		
		assertThat(logAppender.list)
			.extracting(ILoggingEvent::getFormattedMessage)
			.contains("values value1 ***CD");
	}

	@Test
	void should_not_log_at_debug_if_warn_disabled() {
		logImpl.setLevel(Level.OFF);
		
		LogUtils.logAtDebug(log, "values {} {}", "value1", stringMasker(0, 2).maskSupplier("ABCD"));
		
		assertThat(logAppender.list)
			.extracting(ILoggingEvent::getFormattedMessage)
			.hasSize(0);
	}

	@Test
	void should_log_at_trace_if_warn_enabled() {
		logImpl.setLevel(Level.TRACE);
		
		LogUtils.logAtTrace(log, "values {} {}", "value1", stringMasker(0, 2).maskSupplier("ABCD"));
		
		assertThat(logAppender.list)
			.extracting(ILoggingEvent::getFormattedMessage)
			.contains("values value1 ***CD");
	}

	@Test
	void should_not_log_at_trace_if_warn_disabled() {
		logImpl.setLevel(Level.OFF);
		
		LogUtils.logAtTrace(log, "values {} {}", "value1", stringMasker(0, 2).maskSupplier("ABCD"));
		
		assertThat(logAppender.list)
			.extracting(ILoggingEvent::getFormattedMessage)
			.hasSize(0);
	}

}

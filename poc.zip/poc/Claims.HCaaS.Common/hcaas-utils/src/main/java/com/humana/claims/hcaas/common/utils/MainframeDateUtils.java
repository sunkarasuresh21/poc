package com.humana.claims.hcaas.common.utils;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;

import org.apache.commons.lang3.StringUtils;

/**
 * Contains methods to convert dates stored in mainframe to required date
 * formats in Java.
 *
 * @version 1.0
 */
public class MainframeDateUtils {

	private MainframeDateUtils() {

	}
	
	private static final ZoneId MAINFRAME_TZ = ZoneId.of("America/New_York");

	private static final String YYYY_MM_DD = "yyyy-MM-dd";
	private static final String YYYYMMDD = "yyyyMMdd";
	private static final String MMDDYYYY = "MMddyyyy";
	private static final String YYMMDD = "yyMMdd";
	private static final String MM = "MM";
	private static final String YYMM = "yyMM";
	private static final String MMDD = "MMdd";
	
	private static final String ZERO = "0";
	private static final String EIGHT_TIMES_ZERO = "00000000";
	private static final String EIGHT_TIMES_NINE = "99999999";
	private static final String SIX_TIMES_ZERO = "000000";
	private static final String SIX_TIMES_NINE = "999999";
	private static final String FOUR_TIMES_ZERO = "0000";
	private static final String FOUR_TIMES_NINE = "9999";
	
	/**
	 * Converts given <code>date</code> {@link java.lang.String} of format
	 * <code>MMddyyyy</code> into {@link LocalDate}, or null for values 
	 * that are treated as no value on the mainframe.
	 * 
     * <pre>
     * convertMMDDYYYYStringToLocalDate("09301999") = LocalDate.of(1999, 9, 30)
     * convertMMDDYYYYStringToLocalDate(null)       = null
     * convertMMDDYYYYStringToLocalDate("00000000") = null
     * convertMMDDYYYYStringToLocalDate("99999999") = null
     * convertMMDDYYYYStringToLocalDate("0")        = null
     * convertMMDDYYYYStringToLocalDate("123")      throws DateTimeParseException
     * </pre>
     * 
	 * @param date <code>String</code> in the format <code>MMddyyyy</code>
	 * @return <code>LocalDate</code> if <code>date</code> parses successfully into
	 *         <code>LocalDate</code> or null if <code>date</code> is blank, eight
	 *         times zero, eight times nine or zero.
	 * @throws java.time.format.DateTimeParseException if <code>date</code> is not
	 *         in format <code>MMddyyyy</code>
	 * 
	 */
	public static LocalDate convertMMDDYYYYStringToLocalDate(String date) {
		if (StringUtils.isBlank(date) || EIGHT_TIMES_ZERO.equals(date) || EIGHT_TIMES_NINE.equals(date)
				|| ZERO.equals(date)) {
			return null;
		} else {
			return LocalDate.parse(date, DateTimeFormatter.ofPattern(MMDDYYYY));
		}
	}

	/**
	 * Converts given <code>date</code> {@link java.lang.String} of format
	 * <code>yyMMdd</code> into {@link LocalDate} or null for values that are
	 * treated as no value on the mainframe.If <code>yy</code> is greater than 40
	 * then year will be in the range 1941 to 1999.If <code>yy</code> is less than
	 * 40 then year will be in range 2000 to 2040.
	 * 
	 * <pre>
	 * convertYYMMDDStringToLocalDate("190930") = LocalDate.of(2019, 9, 30)
	 * convertYYMMDDStringToLocalDate("410930") = LocalDate.of(1941, 9, 30)
	 * convertYYMMDDStringToLocalDate(null)     = null
	 * convertYYMMDDStringToLocalDate("000000") = null
	 * convertYYMMDDStringToLocalDate("999999") = null
	 * convertYYMMDDStringToLocalDate("0")      = null
	 * convertYYMMDDStringToLocalDate("123")    throws DateTimeParseException
	 * </pre>
	 * 
	 * @param date <code>String</code> in the format <code>yyMMdd</code>
	 * @return <code>LocalDate</code> in 20th century if <code>date</code> has first
	 *         two digits greater than 40 and parses successfully into
	 *         <code>LocalDate</code> or <code>LocalDate</code> in 21st century if
	 *         <code>date</code> has first two digits less than 40 and parses
	 *         successfully into <code>LocalDate</code> or null if <code>date</code>
	 *         is blank, six times zero, six times nine or zero.
	 * @throws java.time.format.DateTimeParseException if <code>date</code> is not
	 *         in <code>yyMMdd</code> format
	 * 
	 */
	public static LocalDate convertYYMMDDStringToLocalDate(String date) {
		if (StringUtils.isBlank(date) || SIX_TIMES_ZERO.equals(date) || SIX_TIMES_NINE.equals(date)
				|| ZERO.equals(date)) {
			return null;
		} else if (Integer.parseInt(date.substring(0, 2)) > 40) {
			return LocalDate.parse(date, dateTimeFormatter20thCenturyYYMMDD());
		} else {
			return LocalDate.parse(date, DateTimeFormatter.ofPattern(YYMMDD));
		}
	}

	/**
	 * Converts given <code>date</code> {@link java.lang.String} of format
	 * <code>yyMM</code> into {@link LocalDate} or null for values 
	 * that are treated as no value on the mainframe.If <code>yy</code> is greater than 40
	 * then year will be in the range 1941 to 1999.If <code>yy</code> is less than
	 * 40 then year will be in range 2000 to 2040. Day of month will be 1.
	 * 
	 * <pre>
	 * convertYYMMStringToLocalDate("1909") = LocalDate.of(2019, 9, 1)
	 * convertYYMMStringToLocalDate("4109") = LocalDate.of(1941, 9, 1)
	 * convertYYMMStringToLocalDate(null)   = null
	 * convertYYMMStringToLocalDate("0000") = null
	 * convertYYMMStringToLocalDate("9999") = null
	 * convertYYMMStringToLocalDate("0")    = null
	 * convertYYMMStringToLocalDate("123")  throws DateTimeParseException
	 * </pre>
	 * 
	 * @param date <code>String</code> in the format <code>yyMM</code>
	 * @return <code>LocalDate</code> in 20th century with 1st day of month if
	 *         <code>date</code> has first two digits greater than 40 and parses
	 *         successfully into <code>LocalDate</code> or <code>LocalDate</code> in
	 *         21st century with 1st day of month if <code>date</code> has first two
	 *         digits less than 40 and parses successfully into
	 *         <code>LocalDate</code> or null if <code>date</code> is blank, four
	 *         times zero, four times nine or zero.
	 * @throws java.time.format.DateTimeParseException if <code>date</code> is not
	 *         in <code>yyMM</code> format
	 * 
	 */
	public static LocalDate convertYYMMStringToLocalDate(String date) {
		if (StringUtils.isBlank(date) || FOUR_TIMES_ZERO.equals(date) || FOUR_TIMES_NINE.equals(date)
				|| ZERO.equals(date)) {
			return null;
		} else if (Integer.parseInt(date.substring(0, 2)) > 40) {
			return LocalDate.parse(date, dateTimeFormatter20thCenturyYYMM());
		} else {
			return LocalDate.parse(date, dateTimeFormatter21stCenturyYYMM());
		}
	}

	/**
	 * Converts given <code>date</code> {@link java.lang.String} of format
	 * <code>yyyyMMdd</code> into {@link LocalDate} or null for values 
	 * that are treated as no value on the mainframe.
	 * 
	 * <pre>
     * convertYYYYMMDDStringToLocalDate("20190915") = LocalDate.of(2019, 9, 15)
     * convertYYYYMMDDStringToLocalDate(null)       = null
     * convertYYYYMMDDStringToLocalDate("00000000") = null
     * convertYYYYMMDDStringToLocalDate("99999999") = null
     * convertYYYYMMDDStringToLocalDate("0")        = null
     * convertYYMMStringToLocalDate("123")          throws DateTimeParseException
     * </pre>
     * 
	 * @param date <code>String</code> in the format <code>yyyyMMdd</code>
	 * @return <code>LocalDate</code> if <code>date</code> parses successfully into
	 *         <code>LocalDate</code> or null if <code>date</code> is blank, eight
	 *         times zero, eight times nine or zero.
	 * @throws java.time.format.DateTimeParseException if <code>date</code> is not
	 *         in format <code>yyyyMMdd</code>
	 * 
	 */
	public static LocalDate convertYYYYMMDDStringToLocalDate(String date) {
		if (StringUtils.isBlank(date) || EIGHT_TIMES_ZERO.equals(date) || EIGHT_TIMES_NINE.equals(date)
				|| ZERO.equals(date)) {
			return null;
		} else {
			return LocalDate.parse(date, DateTimeFormatter.ofPattern(YYYYMMDD));
		}
	}

	/**
	 * Converts given <code>date</code> {@link java.lang.String} of format
	 * <code>yyyy-MM-dd<code> into {@link LocalDate} 
	 * 
	 * <pre>
     * convertYYYYdashMMdashDDStringToLocalDate("2019-09-15") = LocalDate.of(2019, 9, 15)
     * convertYYMMStringToLocalDate("123")                    throws DateTimeParseException
     * </pre> 
	 * 
	 * @param date <code>String</code> in the format <code>yyyy-MM-dd</code>
	 * 
	 * @return <code>LocalDate</code> if <code>date</code> parses successfully into
	 *         <code>LocalDate</code>
	 * @throws java.time.format.DateTimeParseException if <code>date</code> is not
	 *         in format <code>yyyy-MM-dd</code>
	 * 
	 */
	public static LocalDate convertYYYYdashMMdashDDStringToLocalDate(String date) {
		return LocalDate.parse(date, DateTimeFormatter.ofPattern(YYYY_MM_DD));
	}

	/**
	 * Convert a LocalDate from the mainframe to an Instant for use and persistence
	 * in HCaaS.
	 * 
	 * Conversion uses Eastern (Louisville) time, and is null-safe
	 * 
	 * Examples:
	 * <pre>
	 * toInstant(LocalDate.of(2018, 12, 23)) = Instant.parse("2018-12-23T05:00:00Z")
	 * toInstant(LocalDate.of(2020, 06, 18)) = Instant.parse("2020-06-18T04:00:00Z")
	 * toInstant(null)                       = null
	 * </pre>
	 * 
	 * @param mainframeLocalDate the LocalDate from the mainframe
	 * @return an Instant at midnight EST/EDT (represented in UTC), or null
	 */
	public static Instant toInstant(LocalDate mainframeLocalDate) {
		if (mainframeLocalDate == null) {
			return null;
		}
		return mainframeLocalDate.atStartOfDay(MAINFRAME_TZ).toInstant();
	}


	/**
	 * Convert an Instant to a LocalDate for the mainframe.
	 * 
	 * Conversion uses Eastern (Louisville) time, and is null-safe
	 * 
	 * Examples:
	 * <pre>
	 * toMainframeLocalDate(Instant.parse("2018-12-23T12:07:42Z")) = LocalDate.of(2018, 12, 23)
	 * toMainframeLocalDate(Instant.parse("2020-12-01T04:59:59Z")) = LocalDate.of(2020, 11, 30)
	 * toMainframeLocalDate(Instant.parse("2020-06-15T04:59:59Z")) = LocalDate.of(2020, 6, 15)
	 * toMainframeLocalDate(null)                                  = null
	 * </pre>
	 * 
	 * @param instant an Instant
	 * @return the LocalDate of the Instant in EST/EDT, or null
	 */
	public static LocalDate toMainframeLocalDate(Instant instant) {
		if (instant == null) {
			return null;
		}
		return instant.atZone(MAINFRAME_TZ).toLocalDate();
	}

	private static DateTimeFormatter dateTimeFormatter20thCenturyYYMM() {
		return new DateTimeFormatterBuilder().appendValueReduced(ChronoField.YEAR, 2, 2, 1900).appendPattern(MM)
				.parseDefaulting(ChronoField.DAY_OF_MONTH, 1).toFormatter();
	}

	private static DateTimeFormatter dateTimeFormatter21stCenturyYYMM() {
		return new DateTimeFormatterBuilder().appendPattern(YYMM).parseDefaulting(ChronoField.DAY_OF_MONTH, 1)
				.toFormatter();
	}

	private static DateTimeFormatter dateTimeFormatter20thCenturyYYMMDD() {
		return new DateTimeFormatterBuilder().appendValueReduced(ChronoField.YEAR, 2, 2, 1900).appendPattern(MMDD)
				.toFormatter();
	}

}

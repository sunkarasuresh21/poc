package com.humana.claims.hcaas.common.utils.datamasking;

import lombok.Getter;

@Getter
public class JsonMaskerConfiguration {
	private final StringMasker masker;
	private final String propertyName;
	
	private JsonMaskerConfiguration(StringMasker masker, String propertyName) {
		this.masker = masker;
		this.propertyName = propertyName;
	}
	
	public static JsonMaskerConfiguration jsonMaskerConfig(StringMasker masker, String jsonPath) {
		return new JsonMaskerConfiguration(masker, jsonPath);
	}
}

package com.humana.claims.hcaas.common.utils;

import org.apache.commons.lang3.StringUtils;

/**
 * Common Operations on Strings for HCaaS 
 *
 * @version 1.0
 */
public class HcaasStringUtils {

	private HcaasStringUtils() {

	}

	private static final String ZERO = "0";

	/**
	 * Replace given {@link java.lang.String} <code>value</code> with
	 * <code>"0"</code> if is blank otherwise returns the <code>value</code> itself
	 * 
	 * @param value <code>String</code>
	 * @return <code>value</code> if it is not blank or <code>"0"</code> if is blank
	 * 
	 */
	public static String zeroIfBlank(String value) {
		if (StringUtils.isBlank(value)) {
			return ZERO;
		} else {
			return value;
		}
	}
}

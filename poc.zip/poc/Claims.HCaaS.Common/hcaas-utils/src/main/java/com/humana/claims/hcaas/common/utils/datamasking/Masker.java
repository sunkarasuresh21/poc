package com.humana.claims.hcaas.common.utils.datamasking;

import java.util.function.Supplier;

public interface Masker {

	String mask(String string);

	default Supplier<String> maskSupplier(String string) {
		return () -> mask(string);
	}
}
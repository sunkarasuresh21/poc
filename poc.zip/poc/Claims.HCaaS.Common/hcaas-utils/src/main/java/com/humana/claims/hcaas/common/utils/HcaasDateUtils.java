package com.humana.claims.hcaas.common.utils;

import java.util.TimeZone;

import org.apache.commons.lang3.time.FastDateFormat;

public final class HcaasDateUtils {

    private HcaasDateUtils() {}

    /** A java.util.Date formatter using ISO8601 format (with **required millisecond precision**) using UTC timezone.
    */
    public static final FastDateFormat ISO_8601_EXTENDED_DATETIME_UTC_FORMAT = FastDateFormat.getInstance(
        "yyyy-MM-dd'T'HH:mm:ss.SSSZZ", 
        TimeZone.getTimeZone("UTC"),
        null);

}

package com.humana.claims.hcaas.common.utils.logging;

import java.util.Arrays;
import java.util.function.Supplier;

import org.slf4j.Logger;

public class LogUtils {

	private LogUtils() {

	}

	/**
	 * Log at a warn level. Passes to Slf4j log.info(msg, ...args), replacing any
	 * arg that is a Supplier (or no-param Lambda) with the return value of the
	 * Supplier
	 */
	public static void logAtWarn(Logger logger, String msg, Object... args) {
		if (logger.isWarnEnabled()) {
			logger.warn(msg, getSupplierValues(args));
		}
	}
	
	/**
	 * Log at an info level. Passes to Slf4j log.info(msg, ...args), replacing any
	 * arg that is a Supplier (or no-param Lambda) with the return value of the
	 * Supplier
	 */
	public static void logAtInfo(Logger logger, String msg, Object... args) {
		if (logger.isInfoEnabled()) {
			logger.info(msg, getSupplierValues(args));
		}
	}

	/**
	 * Log at a debug level. Passes to Slf4j log.info(msg, ...args), replacing any
	 * arg that is a Supplier (or no-param Lambda) with the return value of the
	 * Supplier
	 */
	public static void logAtDebug(Logger logger, String msg, Object... args) {
		if (logger.isDebugEnabled()) {
			logger.debug(msg, getSupplierValues(args));
		}
	}

	/**
	 * Log at a trace level. Passes to Slf4j log.info(msg, ...args), replacing any
	 * arg that is a Supplier (or no-param Lambda) with the return value of the
	 * Supplier
	 */
	public static void logAtTrace(Logger logger, String msg, Object... args) {
		if (logger.isTraceEnabled()) {
			logger.trace(msg, getSupplierValues(args));
		}
	}

	private static Object[] getSupplierValues(Object[] args) {
		Object[] retn = Arrays.copyOf(args, args.length);
		for (int i = 0; i < retn.length; i++) {
			if (retn[i] instanceof Supplier) {
				retn[i] = ((Supplier<?>) retn[i]).get();
			}
		}
		return retn;
	}
}

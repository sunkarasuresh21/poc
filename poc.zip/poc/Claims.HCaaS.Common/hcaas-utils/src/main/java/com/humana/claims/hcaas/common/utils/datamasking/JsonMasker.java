package com.humana.claims.hcaas.common.utils.datamasking;

import java.util.Iterator;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

/** Class the masks JSON documents. Configure once and reuse.  */
public class JsonMasker implements Masker {

	private final JsonMaskerConfiguration[] configs;
	
	public JsonMasker(JsonMaskerConfiguration... jsonMaskerConfig) {
		this.configs = jsonMaskerConfig;
	}

	public String mask(String jsonString) {
		try {
			ObjectNode json = (ObjectNode)new ObjectMapper().readTree(jsonString);
			for (int i = 0; i < configs.length; i++) {
				updateJSON(json, configs[i].getPropertyName(), configs[i].getMasker());
			}
			return json.toString();
		} catch (Exception ex) {
			return "(Error parsing JSON)";
		}
		
	}

	private void updateJSON(ObjectNode json, String propertyName, StringMasker masker) {
		
		Iterator<String> keys = json.fieldNames();
		
		while (keys.hasNext()) {
			
			String key = keys.next();
			
			if(key.equalsIgnoreCase(propertyName)) {
				json.put(key, masker.mask(json.get(key).asText()));
			} else if (json.get(key).isArray()) {
				ArrayNode jsonArray = (ArrayNode) json.get(key);
				
				for (int i = 0; i < jsonArray.size(); i++) {
					ObjectNode arrayElementObj = (ObjectNode)jsonArray.get(i);
					updateJSON(arrayElementObj, propertyName, masker);
				}
			} else if (json.get(key).isContainerNode() ) {
				updateJSON((ObjectNode)json.get(key), propertyName, masker);
			}
		}
	}
}



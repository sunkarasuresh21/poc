package com.humana.claims.hcaas.common.utils.datamasking;

import static org.apache.commons.lang3.StringUtils.leftPad;
import static org.apache.commons.lang3.StringUtils.rightPad;
import static org.apache.commons.lang3.StringUtils.substring;

import org.apache.commons.lang3.StringUtils;

/**
 * Class that masks data.  Configure once and reuse. 
 */
public class StringMasker implements Masker {

	private int leadingUnMaskCharLength;
	private int trailingUnMaskCharLength;
	private int trailingUnMaskCharSubstringIdx;
	
	private StringMasker(int leadingUnMaskCharLength, int trailingUnMaskCharLength) {
		this.leadingUnMaskCharLength = leadingUnMaskCharLength;
		this.trailingUnMaskCharLength = trailingUnMaskCharLength;
		this.trailingUnMaskCharSubstringIdx = -trailingUnMaskCharLength;
	}
	
	private StringMasker() {}

	public static StringMasker stringMasker(int leadingUnMaskCharLength, int trailingUnMaskCharLength) {
		return new StringMasker(leadingUnMaskCharLength, trailingUnMaskCharLength);
	}
	
	@Override
	public String mask(String string) {
		if (string == null) {
			return "null";
		}
		return rightPad(substring(string,0,leadingUnMaskCharLength),leadingUnMaskCharLength) 
				+ "***" 
				+ (trailingUnMaskCharLength == 0 ? "" : leftPad(StringUtils.substring(string, trailingUnMaskCharSubstringIdx), trailingUnMaskCharLength));
	}


	
	private static class NoMasker extends StringMasker {
		@Override
		public String mask(String string) {
			return string;
		}
	}
	
	public static StringMasker nomask() {
		return new NoMasker();
	}

}

package com.humana.claims.hcaas.common.spring.aop.aspect;

import java.util.UUID;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.MDC;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;

@Order(1)
@Aspect
@Configuration
public class ListenerCorrelationIdAspect {
	
    private static final String CORRELATION_ID_LOG_VAR_NAME = "correlationId";
    
    @Pointcut("within(@com.humana.claims.hcaas.common.spring.aop.annotation.Listener *)")
	public void listenerPointCut() { }; //NOSONAR (ignore squid:S1186)(ignore squid:EmptyStatementUsageCheck)
    
    @Before("listenerPointCut()")
    public void before(JoinPoint joinPoint) {
        final String correlationId = generateUniqueCorrelationId();
        MDC.put(CORRELATION_ID_LOG_VAR_NAME, correlationId);
    }
    
    @After("listenerPointCut()")
    public void afterReturning(JoinPoint joinPoint) {
        MDC.remove(CORRELATION_ID_LOG_VAR_NAME);
    }
    
    private String generateUniqueCorrelationId() {
        return UUID.randomUUID().toString();
    }
}

package com.humana.claims.hcaas.common.spring.aop.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;

@Aspect
@Order(3)
@Configuration
public class ApplictaionLoggingAspect implements LoggingAspect{
	
	@Pointcut("listenerPointCut() || daoPointCut() || loggablePointCut()")
	private void pointCutForLogging() { }; //NOSONAR (ignore squid:S1186)(ignore squid:EmptyStatementUsageCheck)
	
	@Around("pointCutForLogging()")
	public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {
		return logMethodExecution(joinPoint);
	}

}

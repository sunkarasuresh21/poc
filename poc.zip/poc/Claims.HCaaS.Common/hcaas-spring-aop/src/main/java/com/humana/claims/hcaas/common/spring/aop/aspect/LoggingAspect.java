package com.humana.claims.hcaas.common.spring.aop.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StopWatch;

interface LoggingAspect {
	
	@Pointcut("within(@com.humana.claims.hcaas.common.spring.aop.annotation.Listener *)")
	public default void listenerPointCut() { 
	};//NOSONAR (ignore squid:S1186)(ignore squid:EmptyStatementUsageCheck)
	
	@Pointcut("within(@com.humana.claims.hcaas.common.spring.aop.annotation.Loggable *) || @annotation(com.humana.claims.hcaas.common.spring.aop.annotation.Loggable)")
	public default void loggablePointCut() { 
	};//NOSONAR (ignore squid:S1186)(ignore squid:EmptyStatementUsageCheck)

	@Pointcut("within(@org.springframework.stereotype.Repository *)")
	public default void daoPointCut() {
	};  //NOSONAR (ignore squid:S1186)(ignore squid:EmptyStatementUsageCheck)
	
	public default Object logMethodExecution(ProceedingJoinPoint joinPoint) throws Throwable {
		Logger log = LoggerFactory.getLogger(joinPoint.getTarget().getClass());
		String className = joinPoint.getTarget().getClass().getSimpleName();
		String methodName = joinPoint.getSignature().getName();
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		log.info("Entering {}:{}() method", className, methodName);
		Object result = joinPoint.proceed();
		stopWatch.stop();
		log.info("Exiting {}:{}() method; Execution time {}ms", className, methodName, stopWatch.getTotalTimeMillis());
		return result;
	}

}

package com.humana.claims.hcaas.common.spring.aop.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.web.bind.annotation.RestController;

@Aspect
@Order(2)
@ConditionalOnClass({RestController.class})
@Configuration
public class ControllerLoggingAspect implements LoggingAspect{

	@Pointcut("within(@org.springframework.web.bind.annotation.RestController *)")
	public void controllerPointCut() { }; // NOSONAR (ignore squid:S1186)(ignore squid:EmptyStatementUsageCheck)
	
	@Around("controllerPointCut()")
	public Object logAround(ProceedingJoinPoint joinPoint) throws Throwable {
		return logMethodExecution(joinPoint);
	}

}

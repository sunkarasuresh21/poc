package com.humana.claims.hcaas.common.spring.aop.interceptor;

import static java.util.UUID.randomUUID;
import static org.apache.commons.lang3.StringUtils.defaultIfBlank;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.MDC;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.AsyncHandlerInterceptor;
import org.springframework.web.util.HtmlUtils;

@ConditionalOnClass(AsyncHandlerInterceptor.class)
@Configuration
public class CorrelationInterceptor implements AsyncHandlerInterceptor {

	private static final String CORRELATION_ID_HEADER_NAME = "X-Correlation-Id";
    private static final String CORRELATION_ID_LOG_VAR_NAME = "correlationId";
	
    @Override
    public boolean preHandle(final HttpServletRequest request, final HttpServletResponse response,
                             final Object handler) throws Exception {
        final String correlationId = getCorrelationId(request);
        MDC.put(CORRELATION_ID_LOG_VAR_NAME, correlationId);
    	response.addHeader(CORRELATION_ID_HEADER_NAME, correlationId);
        return true;
    } 
    
    @Override
    public void afterCompletion(final HttpServletRequest request, final HttpServletResponse response,
                                final Object handler, final Exception ex) throws Exception {
        MDC.remove(CORRELATION_ID_LOG_VAR_NAME);
    }
    
	private String getCorrelationId(final HttpServletRequest request) {
		String rawCorrelationId = defaultIfBlank(
					request.getHeader(CORRELATION_ID_HEADER_NAME), 
					randomUUID().toString());
		return HtmlUtils.htmlEscape(rawCorrelationId);
	}
}

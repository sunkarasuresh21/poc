package com.humana.claims.hcaas.common.spring.aop.interceptor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.AsyncHandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@ConditionalOnClass(AsyncHandlerInterceptor.class)
@Configuration
public class InterceptorRegister implements WebMvcConfigurer  {
	
	 @Autowired
	 CorrelationInterceptor correlationInterceptor;

	 @Override
	 public void addInterceptors(InterceptorRegistry registry) {
	      registry.addInterceptor(correlationInterceptor);
	 }
}

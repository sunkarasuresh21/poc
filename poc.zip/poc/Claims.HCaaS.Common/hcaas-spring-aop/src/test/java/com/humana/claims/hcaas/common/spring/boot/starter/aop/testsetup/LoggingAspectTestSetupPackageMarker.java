package com.humana.claims.hcaas.common.spring.boot.starter.aop.testsetup;

/** Package Marker for the Logging Aspect Test Setup package */
public final class LoggingAspectTestSetupPackageMarker {}

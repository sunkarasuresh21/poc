package com.humana.claims.hcaas.common.spring.aop.interceptor;

import static org.assertj.core.api.Assertions.assertThat;

import javax.servlet.http.HttpServletResponse;

import org.junit.jupiter.api.Test;
import org.slf4j.MDC;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import com.humana.claims.hcaas.common.spring.boot.starter.aop.testsetup.SampleRestController;

class CorrelationInterceptorTest {

	CorrelationInterceptor classUnderTest = new CorrelationInterceptor();
	
	@Test
	void preHandle_should_add_correlation_id_to_response() throws Exception {
		HttpServletResponse response = callClassUnderTestPreHandleWithCorrelationIdHeader("ABCD");

		assertThat(response.getHeader("X-Correlation-Id")).isEqualTo("ABCD");
	}

	@Test
	void preHandle_should_add_correlation_id_to_MDC() throws Exception {
		callClassUnderTestPreHandleWithCorrelationIdHeader("ABCD");

		assertThat(MDC.get("correlationId")).isEqualTo("ABCD");
	}

	@Test
	void if_request_has_no_correlation_id_preHandle_should_create_and_add_to_MDC_and_response_header() throws Exception {
		HttpServletResponse response = callClassUnderTestPreHandle();

		assertThat(MDC.get("correlationId"))
			.isNotBlank()
			.isEqualTo(response.getHeader("X-Correlation-Id"));
	}

	@Test
	void consecutive_calls_without_correlation_id_should_return_different_correlation_ids() throws Exception {
		callClassUnderTestPreHandle();
		String correlationId1 = MDC.get("correlationId");
		
		callClassUnderTestPreHandle();
		String correlationId2 = MDC.get("correlationId");

		assertThat(correlationId1).isNotEqualTo(correlationId2);
	}

	@Test
	void after_completion_should_clear_correlation_from_MDC() throws Exception {
		MDC.put("correlationId", "ABCD");
		
		classUnderTest.afterCompletion(new MockHttpServletRequest(), new MockHttpServletResponse(), new SampleRestController(), null);
		
		assertThat(MDC.get("correlationId")).isNull();
	}

	@Test
	void preHandle_should_handle_xss() throws Exception {
		HttpServletResponse response = callClassUnderTestPreHandleWithCorrelationIdHeader("<b>sneaky</b>");

		assertThat(response.getHeader("X-Correlation-Id")).isEqualTo("&lt;b&gt;sneaky&lt;/b&gt;");
	}

	private HttpServletResponse callClassUnderTestPreHandleWithCorrelationIdHeader(String correlationIdHeader) throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addHeader("X-Correlation-Id", correlationIdHeader);
		return preHandle(request);
	}
	
	private HttpServletResponse callClassUnderTestPreHandle() throws Exception {
		return preHandle(new MockHttpServletRequest());
	}
	
	private HttpServletResponse preHandle(MockHttpServletRequest request) throws Exception {
		MockHttpServletResponse response = new MockHttpServletResponse();
		SampleRestController handler = new SampleRestController();

		CorrelationInterceptor classUnderTest = new CorrelationInterceptor();
		classUnderTest.preHandle(request, response, handler);
		
		return response;
	}
}

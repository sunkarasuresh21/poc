package com.humana.claims.hcaas.common.spring.boot.starter.aop.testsetup;

import com.humana.claims.hcaas.common.spring.aop.annotation.Listener;

@Listener
public class SampleDataCaptureListener {
	
	public void onMessage() {
		// Do nothing
	}
	
	public void badOnMessage() {
		throw new UnsupportedOperationException("oops");
	}

}

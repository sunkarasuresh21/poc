package com.humana.claims.hcaas.common.spring.boot.starter.aop.testsetup;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SampleRestController {
	
	@GetMapping("/")
	public ResponseEntity<String> getId() {
		return ResponseEntity.ok("hi");
	}
	
	@GetMapping("/bad_url")
	public ResponseEntity<String> badEndpoint() {
		throw new UnsupportedOperationException("oops");
	}

}

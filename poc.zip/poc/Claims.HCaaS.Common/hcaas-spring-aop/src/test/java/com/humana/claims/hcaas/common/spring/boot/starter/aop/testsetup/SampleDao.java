package com.humana.claims.hcaas.common.spring.boot.starter.aop.testsetup;

import org.springframework.stereotype.Repository;

@Repository
public class SampleDao {
	
	public String getId() {
		return "1";
	}
	
	public String badGetId() {
		throw new UnsupportedOperationException("oops");
	}

}

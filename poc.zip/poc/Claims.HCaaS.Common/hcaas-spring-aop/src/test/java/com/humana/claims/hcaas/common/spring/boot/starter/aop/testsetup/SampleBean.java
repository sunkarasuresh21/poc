package com.humana.claims.hcaas.common.spring.boot.starter.aop.testsetup;

import org.springframework.stereotype.Component;

import com.humana.claims.hcaas.common.spring.aop.annotation.Loggable;

@Component
public class SampleBean {
		
	@Loggable
	public String loggableMethod() {
		return "1";
	}
	
	@Loggable
	public String badLoggableMethod() {
		throw new UnsupportedOperationException("oops");
	}

	public String nonLoggableMethod() {
		return "1";
	}
}

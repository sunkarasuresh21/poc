package com.humana.claims.hcaas.common.spring.boot.starter.aop.testsetup;

import org.springframework.stereotype.Component;

import com.humana.claims.hcaas.common.spring.aop.annotation.Loggable;

@Loggable
@Component
public class SampleLoggableClass {
	
	public String getId() {
		return "1";
	}
	
	public String badGetId() {
		throw new UnsupportedOperationException("oops");
	}

}

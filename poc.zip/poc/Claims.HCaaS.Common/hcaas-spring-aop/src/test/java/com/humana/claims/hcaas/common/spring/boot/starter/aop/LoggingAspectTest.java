package com.humana.claims.hcaas.common.spring.boot.starter.aop;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.humana.claims.hcaas.common.spring.boot.starter.aop.testsetup.LoggingAspectTestSetupPackageMarker;
import com.humana.claims.hcaas.common.spring.boot.starter.aop.testsetup.SampleBean;
import com.humana.claims.hcaas.common.spring.boot.starter.aop.testsetup.SampleDao;
import com.humana.claims.hcaas.common.spring.boot.starter.aop.testsetup.SampleDataCaptureListener;
import com.humana.claims.hcaas.common.spring.boot.starter.aop.testsetup.SampleLoggableClass;
import com.humana.claims.hcaas.common.spring.boot.starter.aop.testsetup.SampleRestController;

import lombok.RequiredArgsConstructor;

@ExtendWith(OutputCaptureExtension.class)
@RequiredArgsConstructor
class LoggingAspectTest {

	@Configuration
	@EnableAutoConfiguration(exclude={MongoAutoConfiguration.class})
	@ComponentScan(basePackageClasses = LoggingAspectTestSetupPackageMarker.class)
	static class AppConfig { }

	private final CapturedOutput output;

	private ConfigurableApplicationContext context;
	
	@BeforeEach
	public void setup() {
		context = SpringApplication.run(AppConfig.class);
	}
	
	@AfterEach
    public void tearDown() {
		context.close();
	}
	
    @Test
	void rest_controller_calls_should_be_logged() {
		context.getBean(SampleRestController.class).getId();

		assertThat(output)
			.containsPattern(".*Entering.*SampleRestController.*getId.*")
			.containsPattern(".*Exiting.*SampleRestController.*getId.*");
	}

    @Test
	void rest_controller_calls_that_throw_exception_should_be_logged() {
		Throwable t = catchThrowable(() -> context.getBean(SampleRestController.class).badEndpoint());


		assertThat(t).isNotNull();
		assertThat(output)
			.containsPattern(".*Entering.*SampleRestController.*badEndpoint.*")
			.doesNotContainPattern(".*Exiting.*SampleRestController.*badEndpoint.*");
	}

    @Test
	void listener_calls_should_be_logged() {
		context.getBean(SampleDataCaptureListener.class).onMessage();

		assertThat(output)
			.containsPattern(".*Entering.*SampleDataCaptureListener.*onMessage.*")
			.containsPattern(".*Exiting.*SampleDataCaptureListener.*onMessage.*");
	}

    @Test
	void listener_calls_that_throw_exception_should_be_logged() {
		Throwable t = catchThrowable(() -> context.getBean(SampleDataCaptureListener.class).badOnMessage());


		assertThat(t).isNotNull();
		assertThat(output)
			.containsPattern(".*Entering.*SampleDataCaptureListener.*badOnMessage.*")
			.doesNotContainPattern(".*Exiting.*SampleDataCaptureListener.*badOnMessage.*");
	}

    @Test
	void repository_calls_should_be_logged() {
		context.getBean(SampleDao.class).getId();

		assertThat(output)
			.containsPattern(".*Entering.*SampleDao.*getId.*")
			.containsPattern(".*Exiting.*SampleDao.*getId.*");
	}

    @Test
	void repository_calls_that_throw_exception_should_be_logged() {
		Throwable t = catchThrowable(() -> context.getBean(SampleDao.class).badGetId());


		assertThat(t).isNotNull();
		assertThat(output)
			.containsPattern(".*Entering.*SampleDao.*badGetId.*")
			.doesNotContainPattern(".*Exiting.*SampleDao.*badGetId.*");
	}

    @Test
	void loggable_class_calls_should_be_logged() {
		context.getBean(SampleLoggableClass.class).getId();

		assertThat(output)
			.containsPattern(".*Entering.*SampleLoggableClass.*getId.*")
			.containsPattern(".*Exiting.*SampleLoggableClass.*getId.*");
	}

    @Test
	void loggable_class_calls_that_throw_exception_should_be_logged() {
		Throwable t = catchThrowable(() -> context.getBean(SampleLoggableClass.class).badGetId());


		assertThat(t).isNotNull();
		assertThat(output)
			.containsPattern(".*Entering.*SampleLoggableClass.*badGetId.*")
			.doesNotContainPattern(".*Exiting.*SampleLoggableClass.*badGetId.*");
	}

    @Test
	void loggable_method_calls_should_be_logged() {
		context.getBean(SampleBean.class).loggableMethod();

		assertThat(output)
			.containsPattern(".*Entering.*SampleBean.*loggableMethod.*")
			.containsPattern(".*Exiting.*SampleBean.*loggableMethod.*");
	}

    @Test
	void loggable_method_calls_that_throw_exception_should_be_logged() {
		Throwable t = catchThrowable(() -> context.getBean(SampleBean.class).badLoggableMethod());


		assertThat(t).isNotNull();
		assertThat(output)
			.containsPattern(".*Entering.*SampleBean.*badLoggableMethod.*")
			.doesNotContainPattern(".*Exiting.*SampleBean.*badLoggableMethod.*");
	}

    @Test
	void non_loggable_method_calls_should_not_be_logged() {
		context.getBean(SampleBean.class).nonLoggableMethod();

		assertThat(output)
			.doesNotContainPattern(".*Entering.*SampleBean.*nonLoggableMethod.*")
			.doesNotContainPattern(".*Exiting.*SampleBean.*nonLoggableMethod.*");
	}

}

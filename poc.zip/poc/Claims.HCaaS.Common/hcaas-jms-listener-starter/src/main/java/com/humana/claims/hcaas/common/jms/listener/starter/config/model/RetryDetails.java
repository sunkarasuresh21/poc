package com.humana.claims.hcaas.common.jms.listener.starter.config.model;

import static java.time.temporal.ChronoUnit.MINUTES;

import java.time.Duration;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class RetryDetails {
	
    /**
     * Delay to set between retry attempts.  For retry, a new message will be published to the 
     * inbound queue configured with this delay.
     */
    private Duration delay = Duration.of(10, MINUTES);

    /**
     * Maximum number of processing attempts for a message.  After a message has been attempted and failed 
     * the maximum number of attempts, the message will immediately be published to the error queue.
     * 
     * The delivery count will be tracked in the custom AMQP property defined by constant {@link #DELIVERY_COUNT_AMQP_PROP_NAME}
     */
    private int maxAttempts = 3;
}

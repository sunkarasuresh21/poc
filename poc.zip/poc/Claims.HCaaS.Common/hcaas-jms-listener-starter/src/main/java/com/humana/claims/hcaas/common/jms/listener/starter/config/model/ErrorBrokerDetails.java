package com.humana.claims.hcaas.common.jms.listener.starter.config.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ErrorBrokerDetails {

	private AmqpProperties amqp;
	private IbmmqProperties ibmmq;
	private RetryDetails retry=new RetryDetails();
}

package com.humana.claims.hcaas.common.jms.listener.starter.config.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class QueueDetails {

	public enum Brokers { IBMMQ, AMQP, NOOP; }
	
	private Brokers type;
	private QueueProperties amqp;
	private QueueProperties ibmmq;
}

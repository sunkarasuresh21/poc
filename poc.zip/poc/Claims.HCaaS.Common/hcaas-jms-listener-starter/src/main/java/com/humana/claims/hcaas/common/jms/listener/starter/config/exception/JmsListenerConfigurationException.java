package com.humana.claims.hcaas.common.jms.listener.starter.config.exception;

public class JmsListenerConfigurationException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public JmsListenerConfigurationException(String msg) {
		super(msg);
	}
	
}

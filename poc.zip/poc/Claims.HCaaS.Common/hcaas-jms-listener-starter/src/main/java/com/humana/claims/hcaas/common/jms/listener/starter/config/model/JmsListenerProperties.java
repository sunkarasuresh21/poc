package com.humana.claims.hcaas.common.jms.listener.starter.config.model;
import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@ConfigurationProperties(prefix = "jmslistener")
public class JmsListenerProperties {

	private SourceBrokerDetails source;
	private ErrorBrokerDetails error;
	private Map<String, Queues> listeners;

}

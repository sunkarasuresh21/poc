package com.humana.claims.hcaas.common.jms.listener.starter.autoconfig;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.jms.config.JmsListenerEndpointRegistry;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

/**
 * Warn if a potential jms listener misconfiguration is detected.  	
 * 
 * A warning will be logged at startup if no JmsListeners are running.
 */
@Component
@Slf4j
public class ListenerConfigCheck implements ApplicationListener<ContextRefreshedEvent> {

	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {
		ApplicationContext ctx = event.getApplicationContext();
		if (ctx.getBeansOfType(JmsListenerEndpointRegistry.class).isEmpty() || 
				ctx.getBean(JmsListenerEndpointRegistry.class).getListenerContainers().isEmpty()) {
			
			log.warn("No listeners started - this is likely a misconfiguration.  Did you enable any listeners?");
		}
	}

}

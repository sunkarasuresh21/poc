package com.humana.claims.hcaas.common.jms.listener.starter.jms.error;

import org.springframework.util.ErrorHandler;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class JmsListenerErrorHandler implements ErrorHandler {

	@Override
	public void handleError(Throwable t) {
		log.error("Failure processing jms listener message",t);
	}

}

package com.humana.claims.hcaas.common.jms.listener.starter.config.beanfactories;

import javax.jms.ConnectionFactory;
import javax.jms.JMSException;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.boot.actuate.health.HealthContributorRegistry;
import org.springframework.boot.actuate.jms.JmsHealthIndicator;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.util.ErrorHandler;

import com.humana.claims.hcaas.common.jms.listener.starter.config.model.IbmmqProperties;
import com.humana.claims.hcaas.common.jms.listener.starter.config.model.JmsListenerProperties;
import com.humana.claims.hcaas.common.jms.listener.starter.config.model.QueueProperties;
import com.ibm.mq.jms.MQConnectionFactory;
import com.ibm.msg.client.jms.JmsConstants;
import com.ibm.msg.client.wmq.common.CommonConstants;

import lombok.extern.slf4j.Slf4j;

/**
 * When this class is configured as a bean, it will be used as a factory for a JmsListenerContainerFactory
 * to expose, not directly as a bean instance that will be exposed itself.
 * 
 * The JmsListenerContainerFactory will use an MQConnectionFactory.
 * 
 * @see FactoryBean
 */
@Slf4j
public class IbmmqListenerContainerFactoryFactory {


	private static final String HEALTH_CONTRIBUTOR_NAME_SUFFIX = "-IbmmqConnection";
	

	public static JmsListenerContainerFactory<?> createIbmmqConnectionFactory(String listenerName, JmsListenerProperties jmsListenerProps, ErrorHandler jmsErrorHandler, HealthContributorRegistry healthContributorRegistry) throws JMSException {
		log.info("Jms Listener {} enabled using IBM MQ",listenerName);
		IbmmqProperties sourceIbmmqProperties=jmsListenerProps.getSource().getIbmmq();
        QueueProperties sourceQueueProperties= jmsListenerProps.getListeners().get(listenerName).getSource().getIbmmq();
		
		DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
		factory.setConnectionFactory(getIbmMqConnectionFactory(listenerName, sourceIbmmqProperties,sourceQueueProperties, healthContributorRegistry));
		factory.setSessionTransacted(true);
		factory.setErrorHandler(jmsErrorHandler);
		factory.setConcurrency(sourceQueueProperties.getConcurrency());
		return factory;
	}

	private static ConnectionFactory getIbmMqConnectionFactory(String listenerName,IbmmqProperties brokerProperties, QueueProperties queueProperties,  HealthContributorRegistry healthContributorRegistry) throws JMSException {
		
		MQConnectionFactory factory = new MQConnectionFactory();
		factory.setQueueManager(brokerProperties.getQueueManager());
		factory.setConnectionNameList(brokerProperties.getConnName());
		factory.setChannel(brokerProperties.getChannelName());
		factory.setIntProperty(CommonConstants.WMQ_CONNECTION_MODE, CommonConstants.WMQ_CM_CLIENT);
		factory.setStringProperty(JmsConstants.USERID, queueProperties.getUserName());
		healthContributorRegistry.registerContributor(listenerName+HEALTH_CONTRIBUTOR_NAME_SUFFIX, new JmsHealthIndicator(factory));
		return factory;
	}

}

package com.humana.claims.hcaas.common.jms.listener.starter.autoconfig;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.ErrorHandler;

import com.humana.claims.hcaas.common.jms.listener.starter.jms.error.JmsListenerErrorHandler;

/**
 * This autoconfiguration class will automatically configure an bean of type
 * JmsListenerErrorHandler.  This will be used by the JmsListenerContainerFactory to 
 * log any unhandled errors by the MessageListener.
 * 
 * If custom functionality is required to handle or log errors, define a bean 
 * that implements ErrorHandler.  This will prevent this auto configuration class 
 * from being used.
 */
@Configuration
@ConditionalOnMissingBean(ErrorHandler.class)
public class JmsListenerErrorHandlerAutoConfig {

	@Bean
	public ErrorHandler jmsListenerErrorHandler() {
		return new JmsListenerErrorHandler();
	}
}

package com.humana.claims.hcaas.common.jms.listener.starter.config.beanfactories;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.Autowired;

import com.humana.claims.hcaas.common.jms.listener.starter.config.model.JmsListenerProperties;
import com.humana.claims.hcaas.common.jms.listener.starter.config.model.QueueDetails;
import com.humana.claims.hcaas.common.jms.listener.starter.config.model.QueueDetails.Brokers;

import lombok.RequiredArgsConstructor;
import lombok.Setter;

/**
 * When this class is configured as a bean, it will be used as a factory for a String
 * to expose, not directly as a bean instance that will be exposed itself.
 * 
 * The String exposed will be the configured queueName, based on the connectionType and listenerName.
 * 
 * @see FactoryBean
 */
@RequiredArgsConstructor
public class QueueNameFactory implements FactoryBean<String> {

	@Autowired
	private JmsListenerProperties jmsListenerProps;
	
	@Setter
	private String listenerName;
	
	@Override
	public String getObject() throws Exception {
		QueueDetails queueDetails=jmsListenerProps.getListeners().get(listenerName).getSource();
		if(Brokers.AMQP==queueDetails.getType()) {
			return queueDetails.getAmqp().getQueueName();
		}else if(Brokers.IBMMQ==queueDetails.getType()) {
			return queueDetails.getIbmmq().getQueueName();
		}else {
			return "";
		}
	}

	@Override
	public Class<?> getObjectType() {
		return String.class;
	}
}

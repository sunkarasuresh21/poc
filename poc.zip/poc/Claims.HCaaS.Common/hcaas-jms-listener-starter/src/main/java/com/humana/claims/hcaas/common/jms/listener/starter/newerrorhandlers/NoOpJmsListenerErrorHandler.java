package com.humana.claims.hcaas.common.jms.listener.starter.newerrorhandlers;

import javax.jms.Message;

import lombok.extern.slf4j.Slf4j;

/**
 * <b>WARNING: This class should not be used in production!  Doing so WILL result in data loss!!!</b>
 * <p/>
 * This class does nothing to handle a jms listener error.  It only logs the error and returns.
 * The message will be acknowledged off of the queue even though the error happened.
 * <p/>
 * <b>This class is intended only to be used for testing, and should never be configured for use
 * in any deployed environment!!</b>
 */

@Slf4j
public class NoOpJmsListenerErrorHandler implements JmsListenerErrorHandler {
	@Override
    public void handleRetryableMessageProcessingException(Message message, Exception e) {
      log.error("Error Processing Message",e);
    }
	@Override
    public void handleNonretryableMessageProcessingException(Message message, Exception e) {
		  log.error("Error Processing Message",e);
    }

}

package com.humana.claims.hcaas.common.jms.listener.starter.newerrorhandlers;

import static java.text.MessageFormat.format;

import java.util.Optional;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.HealthContributorRegistry;

import com.humana.claims.hcaas.common.jms.listener.starter.config.exception.JmsListenerConfigurationException;
import com.humana.claims.hcaas.common.jms.listener.starter.config.model.JmsListenerProperties;
import com.humana.claims.hcaas.common.jms.listener.starter.config.model.QueueDetails;
import com.humana.claims.hcaas.common.jms.listener.starter.config.model.QueueDetails.Brokers;
import com.humana.claims.hcaas.common.jms.listener.starter.config.model.Queues;

import lombok.Setter;


public class JmsListenerErrorHandlers implements FactoryBean<JmsListenerErrorHandler> {

	@Autowired
	private HealthContributorRegistry healthContributorRegistry;

	@Autowired
	private JmsListenerProperties jmsListenerProps;
	
	@Setter
	private String listenerName;
	
	@Override
	public JmsListenerErrorHandler getObject() throws Exception {
		
		Brokers errorType = Optional.of(jmsListenerProps)
			.map(JmsListenerProperties::getListeners)
			.map(p -> p.get(listenerName))
			.map(Queues::getSource)
			.map(QueueDetails::getType)
			.orElseThrow(() -> new JmsListenerConfigurationException("Error type not configured"));
		
		switch (errorType) {
			case AMQP: return new AmqpJmsListenerErrorHandler(listenerName,jmsListenerProps,healthContributorRegistry);
			case NOOP: return new NoOpJmsListenerErrorHandler();
			default: throw new JmsListenerConfigurationException(format("Error type {0} not supported", errorType));
		}
	}
	
	@Override
	public Class<?> getObjectType() {
		return JmsListenerErrorHandler.class;
	}
}

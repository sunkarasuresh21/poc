package com.humana.claims.hcaas.common.jms.listener.starter.autoconfig;

import org.springframework.boot.actuate.autoconfigure.metrics.MeterRegistryCustomizer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.micrometer.core.aop.TimedAspect;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;

/** 
 * Enable @Timed annotations 
 */
@Configuration
public class TimedAutoConfig {

	@Bean
	@ConditionalOnMissingBean(TimedAspect.class)
	public TimedAspect timedAspect(MeterRegistry registry) {
		return new TimedAspect(registry);
	}

	/**
	 * Initialize messages.processed Timer metric.  Not required
	 * for @Timed to work, but makes the messages.processed metric
	 * show in the actuator even if no messages have yet to be processed
	 * (otherwise, the messages.processed metric is not available until
	 * 1 message as been processed)
	 */
	@Bean
	MeterRegistryCustomizer<MeterRegistry> messagesProcessedTimerInitializer() {
		return registry -> Timer.builder("messages.processed")
				.description("Messages processed by jms listeners")
				.register(registry);
	}

}

package com.humana.claims.hcaas.common.jms.listener.starter.config.model;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class QueueProperties {
	
	private String queueName;
	private String userName;
	private String password;
	
	private int prefetch=0;
	private String concurrency="1-20"; 
}

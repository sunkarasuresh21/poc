package com.humana.claims.hcaas.common.jms.listener.starter.config;

import static org.springframework.beans.factory.support.BeanDefinitionBuilder.genericBeanDefinition;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;

import com.humana.claims.hcaas.common.jms.listener.starter.config.beanfactories.JmsListenerContainerFactoryFactory;
import com.humana.claims.hcaas.common.jms.listener.starter.config.beanfactories.QueueNameFactory;
import com.humana.claims.hcaas.common.jms.listener.starter.newerrorhandlers.JmsListenerErrorHandlers;

public abstract class BaseJmsListenerConnectionConfig {

	public BaseJmsListenerConnectionConfig() {
	} // NOSONAR

	/**
	 * This method will define the following beans:
	 * <ul>
	 * <li>{listenerName}ListenerContainerFactory
	 * <li>{listenerName}QueueName
	 * <li>{listenerName}JmsListenerErrorHandler
	 * </ul>
	 * based on the following properties
	 * <pre>
	 * 
	 * <h2> Broker details / MQ types </h2>
	 * // Connection Factory will generate based on type [amqp OR ibmmq]
	 *   jmslistener.listeners.{listenerName}.source.type=[amqp OR ibmmq]
	 *   jmslistener.listeners.{listenerName}.error.type=[amqp OR ibmmq]
	 * 
	 *   
	 * <h3> IBMMQ MQ properties </h3>
	 * 
	 * <h4>if broker type is IBMMQ then provide as follows</h4>
	 *  //Connection details for source queue and error queue
	 *  
	 *   jmslistener.source.ibmmq.queueManager=
	 *   jmslistener.source.ibmmq.connName=
	 *   jmslistener.source.ibmmq.channelName=
	 *
	 *	 jmslistener.error.ibmmq.queueManager=
	 *   jmslistener.error.ibmmq.connName=
	 *   jmslistener.error.ibmmq.channelName=
	 *   
	 * // Queue Details for source and error queue
	 *  
	 *  //concurrency by default 1-20
	 *  jmslistener.listeners.{listenerName}.error.ibmmq.concurrency= 
	 *  //prefetch value default Zero
	 *	jmslistener.listeners.{listenerName}.error.ibmmq.prefetch=
	 *	jmslistener.listeners.{listenerName}.error.ibmmq.password=
	 *	jmslistener.listeners.{listenerName}.error.ibmmq.queueName=
	 *	jmslistener.listeners.{listenerName}.error.ibmmq.userName=
	 *	
	 *  //concurrency by default 1-20
	 *	jmslistener.listeners.{listenerName}.source.ibmmq.concurrency= 
	 *	//prefetch value default Zero
	 *	jmslistener.listeners.{listenerName}.source.ibmmq.prefetch=
	 *	jmslistener.listeners.{listenerName}.source.ibmmq.password=
	 *	jmslistener.listeners.{listenerName}.source.ibmmq.queueName=
	 *	jmslistener.listeners.{listenerName}.source.ibmmq.userName=
	 *	
	 * 	<h3> AMQP MQ properties </h3>
	 * 
	 * <h4>if broker type is AMQP then provide as follows</h4>
	 *  //Connection details for source queue and error queue
	 *   jmslistener.source.amqp.uri
	 *
	 *	 jmslistener.error.amqp.uri
	 *   
	 * // Queue Details for source and error queue
	 *   
	 *  //concurrency by default 1-20 
	 *  jmslistener.listeners.{listenerName}.error.amqp.concurrency= 
	 *  //prefetch value default Zero
	 *	jmslistener.listeners.{listenerName}.error.amqp.prefetch=
	 *	jmslistener.listeners.{listenerName}.error.amqp.password=
	 *	jmslistener.listeners.{listenerName}.error.amqp.queueName=
	 *	jmslistener.listeners.{listenerName}.error.amqp.userName=
	 *	
	 *  //concurrency by default 1-20 
	 *	jmslistener.listeners.{listenerName}.source.amqp.concurrency=
	 *  //prefetch value default Zero
	 *	jmslistener.listeners.{listenerName}.source.amqp.prefetch=
	 *	jmslistener.listeners.{listenerName}.source.amqp.password=
	 *	jmslistener.listeners.{listenerName}.source.amqp.queueName=
	 *	jmslistener.listeners.{listenerName}.source.amqp.userName=
	 *  
	 * 
	 * // NoOp error handler should <u>only be used for testing purposes</u>. 
	 * //   See {@link com.humana.claims.hcaas.common.jms.listener.starter.errorhandlers.NoOpJmsListenerErrorHandler} for more details
	 * 
	 * // AMQP Retryable Error Handler (optional properties)
	 *   jmslistener.error.retry.delay
	 *   jmslistener.error.retry.max-attempts
	 * </pre>
	 * 
	 * <h2>Requirements</h2>
	 * <ul>
	 * <li>ibmmq requires com.ibm.mq:com.ibm.mq.allclient
	 * <li>amqp requires org.apache.qpid:qpid-jms-client
	 * </ul>
	 * 
	 * <h2>Example</h2>
	 * <pre>
	 * // Configuration Class
	 * &commat;Configuration
	 * &commat;ConditionalOnProperty(name = "jmslistener.{listenerName}.enabled", havingValue = "true")
	 * public class {ListenerName}ListenerConnectionConfig extends BaseJmsListenerConnectionConfig {
	 * 
	 *   &commat;Bean
	 *   public static BeanDefinitionRegistryPostProcessor {listenerName}BeanConfiguration() {
	 *     return jmsListenerDependencyBeanRegisterer("{listenerName}");
	 *   }
	 * }
	 * 
	 * // Listener Class
	 * &commat;Component
	 * &commat;ConditionalOnProperty(name = "jmslistener.{listenerName}.enabled", havingValue = "true")
	 * &commat;Listener
	 * public class {ListenerName}Listener {
	 * 
	 *   &commat;Autowired
	 *   &commat;Qualifier("{listenerName}JmsListenerErrorHandler")
	 *   private JmsListenerErrorHandler errorHandler;
	 * 
	 *   &commat;Timed(value = "messages.processed", extraTags = {"listener","{listenerName}"})
	 *   &commat;JmsListener(containerFactory = "{listenerName}ListenerContainerFactory", destination = "#{@{listenerName}QueueName}")
	 *   public void onMessage(String messageText) {
	 *     // process messageText
	 *   }
	 * }
	 * </pre>
	 * 
	 * <h2>Important Notes</h2>
	 * <ul>
	 * <li>If you define a bean with the same name that this method would create, this method will <i>skip</i>
	 *     creation of that bean
	 * <li>The creation of the ListenerContainerFactory requires the Health Actuator to be enabled
	 * </ul>
	 * 
	 * <h2>Actuators</h2>
	 * <ul>
	 * <li>The health of the listener connections is included as part of the health actuator ( /actuator/health )
	 * <li>The jms listener metrics (count and total processing time) can be found via the /actuator/metrics/messages.processed.
	 *     This will show the metrics for all enabled listeners combined.  To view metrics of a single listener, add the tag to the path 
	 *     ( /actuator/metrics/messages.processed?tag=listener:{listenerName} ) 
	 * </ul>
	 * 
	 * @param listenerName
	 * @return
	 */
	public static BeanDefinitionRegistryPostProcessor jmsListenerDependencyBeanRegisterer(String listenerName) {

		class JmsListenerDependencyBeanRegisterer implements BeanDefinitionRegistryPostProcessor {

			@Override
			public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) {

				registerBeanDef(JmsListenerContainerFactoryFactory.class, "{listenerName}ListenerContainerFactory", listenerName, registry);
				registerBeanDef(QueueNameFactory.class, "{listenerName}QueueName", listenerName, registry);
				registerBeanDef(JmsListenerErrorHandlers.class, "{listenerName}JmsListenerErrorHandler", listenerName, registry);
			}

			@Override
			public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) {
				// Do Nothing (this is called after beans have been created)
			}

		}

		return new JmsListenerDependencyBeanRegisterer();
	}

	private static void registerBeanDef(Class<?> beanClass, String beanNameTemplate, String listenerName, BeanDefinitionRegistry registry) {
		if (beanClass == null) {
			return;
		}

		String beanName = beanNameTemplate.replace("{listenerName}", listenerName);

		if (!registry.containsBeanDefinition(beanName)) {
			BeanDefinition beanDef = genericBeanDefinition(beanClass)
					.addPropertyValue("listenerName", listenerName)
					.getBeanDefinition();

			registry.registerBeanDefinition(beanName, beanDef);
		}

	}
}

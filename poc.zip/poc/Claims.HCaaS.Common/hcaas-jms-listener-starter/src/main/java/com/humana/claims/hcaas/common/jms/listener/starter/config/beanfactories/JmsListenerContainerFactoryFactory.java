package com.humana.claims.hcaas.common.jms.listener.starter.config.beanfactories;

import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.HealthContributorRegistry;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.util.ErrorHandler;

import com.humana.claims.hcaas.common.jms.listener.starter.config.model.JmsListenerProperties;
import com.humana.claims.hcaas.common.jms.listener.starter.config.model.QueueDetails;
import com.humana.claims.hcaas.common.jms.listener.starter.config.model.QueueDetails.Brokers;

import lombok.Setter;

public class JmsListenerContainerFactoryFactory implements FactoryBean<JmsListenerContainerFactory<?>>  {


	@Autowired
	private JmsListenerProperties jmsListenerProps;
	
	@Setter
	private String listenerName;
	
	@Autowired
	private ErrorHandler jmsErrorHandler;

	@Autowired
	private HealthContributorRegistry healthContributorRegistry;

	@Override
	public JmsListenerContainerFactory<?> getObject() throws Exception {
		QueueDetails queueDetails= jmsListenerProps.getListeners().get(listenerName).getSource();
		if(Brokers.AMQP==queueDetails.getType()) {
			return AmqpListenerContainerFactoryFactory.createAmqpConnectionFactory(listenerName,jmsListenerProps, jmsErrorHandler, healthContributorRegistry );
		}else if(Brokers.IBMMQ==queueDetails.getType()){
			return IbmmqListenerContainerFactoryFactory.createIbmmqConnectionFactory(listenerName,jmsListenerProps, jmsErrorHandler, healthContributorRegistry);
		}
		return null;
	}

	@Override
	public Class<?> getObjectType() {
		return JmsListenerContainerFactory.class;
	}

}

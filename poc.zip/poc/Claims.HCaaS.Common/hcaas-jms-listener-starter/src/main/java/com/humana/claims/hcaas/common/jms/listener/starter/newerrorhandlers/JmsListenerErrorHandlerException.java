package com.humana.claims.hcaas.common.jms.listener.starter.newerrorhandlers;

public class JmsListenerErrorHandlerException extends RuntimeException {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public JmsListenerErrorHandlerException(String msg) {
        super(msg);
    }

    public JmsListenerErrorHandlerException(String msg, Throwable cause) {
        super(msg, cause);
    }
    
}

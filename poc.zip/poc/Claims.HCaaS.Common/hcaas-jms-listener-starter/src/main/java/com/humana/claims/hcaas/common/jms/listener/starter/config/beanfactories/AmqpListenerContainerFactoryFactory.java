package com.humana.claims.hcaas.common.jms.listener.starter.config.beanfactories;

import static com.humana.claims.hcaas.common.jms.listener.starter.config.utils.JmsListenerConnectionConfigUtils.createAmqpJmsConnectionFactory;

import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Session;

import org.apache.qpid.jms.JmsConnectionFactory;
import org.apache.qpid.jms.policy.JmsDefaultPrefetchPolicy;
import org.apache.qpid.jms.policy.JmsPrefetchPolicy;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.boot.actuate.health.HealthContributorRegistry;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.util.ErrorHandler;

import com.humana.claims.hcaas.common.jms.listener.starter.config.model.AmqpProperties;
import com.humana.claims.hcaas.common.jms.listener.starter.config.model.JmsListenerProperties;
import com.humana.claims.hcaas.common.jms.listener.starter.config.model.QueueProperties;

import lombok.extern.slf4j.Slf4j;

/**
 * When this class is configured as a bean, it will be used as a factory for a
 * JmsListenerContainerFactory to expose, not directly as a bean instance that
 * will be exposed itself.
 * 
 * The JmsListenerContainerFactory will use an Amqp ConnectionFactory.
 * 
 * @see FactoryBean
 */
@Slf4j
public class AmqpListenerContainerFactoryFactory {
	
	private static final String HEALTH_CONTRIBUTOR_NAME_SUFFIX = "-jmsListener-AmqpConnection";

	public static JmsListenerContainerFactory<?> createAmqpConnectionFactory(String listenerName, JmsListenerProperties jmsListenerProps, ErrorHandler jmsErrorHandler, HealthContributorRegistry healthContributorRegistry) throws JMSException {
		log.info("Jms Listener {} enabled using AMQP", listenerName);
		AmqpProperties sourceAmqpProperties=jmsListenerProps.getSource().getAmqp();
        QueueProperties sourceQueueProperties= jmsListenerProps.getListeners().get(listenerName).getSource().getAmqp();

		DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
		factory.setConnectionFactory(getAmqpConnectionFactory(listenerName, sourceAmqpProperties.getUri(), sourceQueueProperties,healthContributorRegistry));
		factory.setSessionTransacted(true);
		factory.setSessionAcknowledgeMode(Session.CLIENT_ACKNOWLEDGE);
		factory.setErrorHandler(jmsErrorHandler);
		factory.setConcurrency(sourceQueueProperties.getConcurrency());
		return factory;
	}

	private static ConnectionFactory getAmqpConnectionFactory(String listenerName, String uri, QueueProperties queueProperties, HealthContributorRegistry healthContributorRegistry) {

		JmsConnectionFactory amqpConnectionFactory = createAmqpJmsConnectionFactory(uri, queueProperties,listenerName+HEALTH_CONTRIBUTOR_NAME_SUFFIX,
				healthContributorRegistry);

		amqpConnectionFactory.setPrefetchPolicy(prefetchPolicy(queueProperties.getPrefetch()));

		return new CachingConnectionFactory(amqpConnectionFactory);
	}

	private static JmsPrefetchPolicy prefetchPolicy(int prefetch) {
		JmsDefaultPrefetchPolicy prefetchPolicy = new JmsDefaultPrefetchPolicy();
		prefetchPolicy.setAll(0);
		prefetchPolicy.setQueuePrefetch(prefetch);
		return prefetchPolicy;
	}

}

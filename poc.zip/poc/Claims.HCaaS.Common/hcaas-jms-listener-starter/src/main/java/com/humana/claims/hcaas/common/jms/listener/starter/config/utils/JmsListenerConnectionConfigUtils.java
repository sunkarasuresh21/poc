package com.humana.claims.hcaas.common.jms.listener.starter.config.utils;

import org.apache.qpid.jms.JmsConnectionFactory;
import org.springframework.boot.actuate.health.HealthContributorRegistry;
import org.springframework.boot.actuate.jms.JmsHealthIndicator;

import com.humana.claims.hcaas.common.jms.listener.starter.config.model.QueueProperties;

public class JmsListenerConnectionConfigUtils {

	private JmsListenerConnectionConfigUtils() {}
	
	public static JmsConnectionFactory createAmqpJmsConnectionFactory(String urlString, 
			QueueProperties queue, String helthContibutor, HealthContributorRegistry healthContributorRegistry) {
		
		JmsConnectionFactory jmsConnectionFactory = new JmsConnectionFactory(urlString);
		jmsConnectionFactory.setUsername(queue.getUserName());
		jmsConnectionFactory.setPassword(queue.getPassword());
		healthContributorRegistry.registerContributor(helthContibutor, new JmsHealthIndicator(jmsConnectionFactory));
		return jmsConnectionFactory;
	}
	
}

package com.humana.claims.hcaas.common.jms.listener.starter.config.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class IbmmqProperties {

	private String queueManager;
	private String connName;
	private String channelName;
}

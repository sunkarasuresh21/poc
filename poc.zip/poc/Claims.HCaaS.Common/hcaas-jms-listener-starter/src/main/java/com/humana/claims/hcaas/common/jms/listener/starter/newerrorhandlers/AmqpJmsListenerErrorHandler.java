package com.humana.claims.hcaas.common.jms.listener.starter.newerrorhandlers;

import static com.humana.claims.hcaas.common.jms.listener.starter.config.utils.JmsListenerConnectionConfigUtils.createAmqpJmsConnectionFactory;
import static java.time.Instant.now;
import static java.time.format.DateTimeFormatter.ISO_INSTANT;

import java.time.Duration;
import java.time.Instant;
import java.util.Date;

import javax.jms.JMSException;
import javax.jms.Message;

import org.apache.qpid.jms.JmsConnectionFactory;
import org.apache.qpid.jms.message.JmsMessage;
import org.springframework.boot.actuate.health.HealthContributorRegistry;
import org.springframework.jms.JmsException;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessagePostProcessor;

import com.humana.claims.hcaas.common.jms.listener.starter.config.model.AmqpProperties;
import com.humana.claims.hcaas.common.jms.listener.starter.config.model.JmsListenerProperties;
import com.humana.claims.hcaas.common.jms.listener.starter.config.model.QueueProperties;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AmqpJmsListenerErrorHandler implements JmsListenerErrorHandler{
	
	private static final String ERROR_QUEUE_HEALTH_CONTRIBUTOR_NAME_SUFFIX   = "-errorHandler-errorQueue-AmqpConnection";
	private static final String INBOUND_QUEUE_HEALTH_CONTRIBUTOR_NAME_SUFFIX = "-errorHandler-inboundQueue-AmqpConnection";
    public static final String DELIVERY_COUNT_AMQP_PROP_NAME = "DeliveryCount";
	
	private String inboundQueueName = null;

	private JmsTemplate errorQueueJmsTemplate;
    private JmsTemplate inboundQueueJmsTemplate;

    private int maxDeliveryAttempts;
    private Duration retryDelay;

	public AmqpJmsListenerErrorHandler(String listenerName, JmsListenerProperties jmsListenerProps, HealthContributorRegistry healthContributorRegistry) {
        retryDelay = jmsListenerProps.getError().getRetry().getDelay();
        maxDeliveryAttempts = jmsListenerProps.getError().getRetry().getMaxAttempts();

        AmqpProperties sourceAmqpProperties=jmsListenerProps.getSource().getAmqp();
        QueueProperties sourceQueueProperties= jmsListenerProps.getListeners().get(listenerName).getSource().getAmqp();
        
        AmqpProperties errorAmqpProperties=jmsListenerProps.getError().getAmqp();
        QueueProperties errorQueueProperties= jmsListenerProps.getListeners().get(listenerName).getError().getAmqp();


		JmsConnectionFactory connectionFactory = createAmqpJmsConnectionFactory(
				errorAmqpProperties.getUri(), errorQueueProperties,listenerName+ERROR_QUEUE_HEALTH_CONTRIBUTOR_NAME_SUFFIX,
				healthContributorRegistry);
		errorQueueJmsTemplate = new JmsTemplate(new CachingConnectionFactory(connectionFactory));
		errorQueueJmsTemplate.setDefaultDestinationName(errorQueueProperties.getQueueName());

		JmsConnectionFactory inboundConnectionFactory = createAmqpJmsConnectionFactory(
				sourceAmqpProperties.getUri(),  sourceQueueProperties, listenerName+INBOUND_QUEUE_HEALTH_CONTRIBUTOR_NAME_SUFFIX,
				healthContributorRegistry);
        inboundQueueJmsTemplate = new JmsTemplate(new CachingConnectionFactory(inboundConnectionFactory));
        setStandardJmsDeliveryDelay(inboundQueueJmsTemplate);
        inboundQueueJmsTemplate.setDefaultDestinationName(sourceQueueProperties.getQueueName());
        inboundQueueName=sourceQueueProperties.getQueueName();
    }

    /**
     * Retry the message after a delay, or if processed maximum number of attempts send to Error Queue.
     * 
     * @throws JmsListenerErrorHandlerException - if a JmsException/JMSException occurs during processing
     */
	@Override
    public void handleRetryableMessageProcessingException(Message incomingMsg, Exception e) {
        try {
            log.error("Jms Listener Processing Exception", e);
            doHandleRetryableMessageProcessingError(incomingMsg, e);
        } catch (JmsException | JMSException ex) {
            throw new JmsListenerErrorHandlerException("Exception occurred while attempting to process retryable exception", ex);
        }
    }


    public void doHandleRetryableMessageProcessingError(Message incomingMsg, Exception e) throws JMSException {
		final int deliveryCount = determineDeliveryCount(incomingMsg);
		if (deliveryCount >= maxDeliveryAttempts) {
            log.warn("Message Delivery #{}, Sending message to error queue due to exceeding delivery attempt threshold", deliveryCount);
            sendToErrorQueue(incomingMsg, deliveryCount, e);
		} else {
            log.warn("Message Delivery #{}, Retrying message after delay", deliveryCount);
            inboundQueueJmsTemplate.convertAndSend(
                (Object)incomingMsg.getBody(String.class),
                sneakyMessagePostProcessor(m -> {
                    setAzureServiceBusDeliveryDelay(m);
                    m.setIntProperty(DELIVERY_COUNT_AMQP_PROP_NAME, deliveryCount);
                }));
        }
    }

    /**
     * Send message to Error Queue.
     * 
     * @throws JmsListenerErrorHandlerException - if a JmsException/JMSException occurs during processing
     */
    @Override
    public void handleNonretryableMessageProcessingException(Message incomingMsg, Exception e) {
		try {
            log.error("Jms Listener Processing Exception", e);
            doHandleNonretryableMessageProcessingError(incomingMsg, e);
        } catch (JmsException | JMSException ex) {
            throw new JmsListenerErrorHandlerException("Exception occurred while attempting to process non-retryable exception", ex);
        }
    }

    private void doHandleNonretryableMessageProcessingError(Message incomingMsg, Exception e) throws JMSException {
        final int deliveryCount = determineDeliveryCount(incomingMsg);
        log.warn("Message Delivery #{}, Sending message to error queue due to non-retryable exception", deliveryCount);
        sendToErrorQueue(incomingMsg, deliveryCount, e);
    }

    private int determineDeliveryCount(Message incomingMsg) throws JMSException {
		if (incomingMsg.propertyExists(DELIVERY_COUNT_AMQP_PROP_NAME)) {
			return incomingMsg.getIntProperty(DELIVERY_COUNT_AMQP_PROP_NAME) + 1;
		} else {
			return 1;
		}
    }


    private void sendToErrorQueue(Message incomingMsg, int deliveryCount, Exception e) throws JMSException {
        errorQueueJmsTemplate.convertAndSend(
            (Object)incomingMsg.getBody(String.class),
            sneakyMessagePostProcessor(m -> {
                m.setIntProperty(DELIVERY_COUNT_AMQP_PROP_NAME, deliveryCount);
                m.setStringProperty("HcaasInboundQueue", inboundQueueName);
                m.setStringProperty("HcaasFinalAttemptException", e.getClass().getName());
                m.setStringProperty("HcaasFinalAttemptExceptionMsg", e.getMessage());
                m.setStringProperty("HcaasFinalAttemptDateTime", ISO_INSTANT.format(now()));
            }));
    }

    /**
     * Set the delivery delay on jmsTemplate.  Works on brokers that implement the JMS/AMQP standard.
     * This does NOT work on Azure Service Bus - Azure Service Bus will ignore this setting!  
     * 
     * For Azure Service Bus, must use setAzureServiceBusDeliveryDelay(...)
     * to set delivery delay directly on message
     */
    private void setStandardJmsDeliveryDelay(JmsTemplate jmsTemplate) {
        jmsTemplate.setDeliveryDelay(retryDelay.toMillis());
    }

    /**
     * Set the delivery delay for Azure Service Bus.  Other brokers will ignore this setting.
     * @param amqpMessage
     */
    private void setAzureServiceBusDeliveryDelay(org.apache.qpid.jms.message.JmsMessage amqpMessage) {
		Instant deliveryInstant = Instant.now().plus(retryDelay);
		amqpMessage.getFacade().setTracingAnnotation("x-opt-scheduled-enqueue-time", Date.from(deliveryInstant));
	}

	@FunctionalInterface
	public static interface JmsExceptionThrowingFunction<T> {
		void accept(T t) throws JMSException;
	}

    private MessagePostProcessor sneakyMessagePostProcessor(JmsExceptionThrowingFunction<JmsMessage> consumer) {
		return m -> {
            try {
				JmsMessage amqpMessage = (org.apache.qpid.jms.message.JmsMessage)m;
				consumer.accept(amqpMessage);
                return m;
            } catch (Exception e) {
                throw new JmsListenerErrorHandlerException("Exception occurred while preparing message", e);
            }
		};
    }

}

package com.humana.claims.hcaas.common.jms.listener.starter.newerrorhandlers;

import javax.jms.Message;

public interface JmsListenerErrorHandler {
	
	void handleRetryableMessageProcessingException(Message message, Exception e);

	void handleNonretryableMessageProcessingException(Message message, Exception e);
	
}

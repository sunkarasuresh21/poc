package com.humana.claims.hcaas.common.jms.listener.starter.config;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import com.humana.claims.hcaas.common.jms.listener.starter.newerrorhandlers.AmqpJmsListenerErrorHandler;
import com.humana.claims.hcaas.common.jms.listener.starter.newerrorhandlers.JmsListenerErrorHandler;
import com.humana.claims.hcaas.common.jms.listener.starter.newerrorhandlers.NoOpJmsListenerErrorHandler;


class BaseJmsListenerConnectionConfig_JmsErrorHandlerTest {

	@Configuration
	static class TargetConfig extends BaseJmsListenerConnectionConfig {
		@Bean
		public static BeanDefinitionRegistryPostProcessor targetBeanConfiguration() {
			return jmsListenerDependencyBeanRegisterer("teci");
		}
	}
	
	@Component
	static class TargetListener {
		@Autowired
		@Qualifier("teciJmsListenerErrorHandler")
		private JmsListenerErrorHandler teciJmsListenerErrorHandler;
	}

	@EnableAutoConfiguration
	static class EnableAutoConfig {}

	@Test
	void noop_error_handler_created() {
		new ApplicationContextRunner()
			.withUserConfiguration(TargetConfig.class)
			.withUserConfiguration(EnableAutoConfig.class)
			.withPropertyValues(testProperties)
			.withPropertyValues(
					"jmslistener.listeners.teci.error.type=noop",
					"jmslistener.listeners.teci.source.type=noop"
					)
			.run(ctx -> {
				assertThat(ctx).getBean("teciJmsListenerErrorHandler")
						.isNotNull()
						.isInstanceOf(NoOpJmsListenerErrorHandler.class);
			});
	}
	
	@Test
	void amqp_error_handler_created() {
		new ApplicationContextRunner()
			.withUserConfiguration(TargetConfig.class)
			.withUserConfiguration(EnableAutoConfig.class)
			.withPropertyValues(testProperties)
			.withPropertyValues(
					"jmslistener.listeners.teci.error.type=amqp",
					"jmslistener.listeners.teci.source.type=amqp"
					)
			.run(ctx -> {
				assertThat(ctx).getBean("teciJmsListenerErrorHandler")
						.isNotNull()
						.isInstanceOf(AmqpJmsListenerErrorHandler.class);
			});
	}

	@Test
	void unknown_error_handler_faild_to_context_start() {
		new ApplicationContextRunner()
			.withUserConfiguration(TargetConfig.class)
			.withUserConfiguration(EnableAutoConfig.class)
			.withPropertyValues(testProperties)
			.withPropertyValues(
					"jmslistener.listeners.teci.error.type=unknow",
					"jmslistener.listeners.teci.source.type=unknow"
					)
			.run(ctx -> {
				assertThat(ctx).hasFailed();
			});
	}

	@Test
	void null_error_type_fails_when_creating_error_handler() {
		new ApplicationContextRunner()
			.withUserConfiguration(TargetConfig.class)
			.withUserConfiguration(EnableAutoConfig.class)
			.withUserConfiguration(TargetListener.class)
			.withPropertyValues(testProperties)
			.run(ctx -> {
				assertThat(ctx).hasFailed()
					.getFailure().hasMessageContaining("Error type not configured");
			});
	}
	
	@Test
	void ibmmq_error_type_fails_when_creating_error_handler() {
		new ApplicationContextRunner()
			.withUserConfiguration(TargetConfig.class)
			.withUserConfiguration(EnableAutoConfig.class)
			.withUserConfiguration(TargetListener.class)
			.withPropertyValues(testProperties)
			.withPropertyValues(
					"jmslistener.listeners.teci.error.type=ibmmq",
					"jmslistener.listeners.teci.source.type=ibmmq"
					)
			.run(ctx -> {
				assertThat(ctx).hasFailed()
					.getFailure().hasMessageContaining("Error type IBMMQ not supported");
			});
	}

	@Test
	void null_error_type_doesNotFail_when_error_handler_is_not_injected_into_a_bean() {
		new ApplicationContextRunner()
			.withUserConfiguration(TargetConfig.class)
			.withUserConfiguration(EnableAutoConfig.class)
			.withPropertyValues(testProperties)
			.run(ctx -> {
				assertThat(ctx).hasNotFailed();
			});
	}

	
	@Test
	void retryableErrorHandlerFeatureEnabled_ErrorHandlerTypeAmqp_shouldCreateNewAmqpErrorHandler() {
		new ApplicationContextRunner()
			.withUserConfiguration(TargetConfig.class)
			.withUserConfiguration(EnableAutoConfig.class)
			.withPropertyValues(testProperties)
			.withPropertyValues(
					"jmslistener.listeners.teci.error.type=amqp",
					"jmslistener.listeners.teci.source.type=amqp"
					)
			.run(ctx -> {
				assertThat(ctx).getBean("teciJmsListenerErrorHandler")
						.isNotNull()
						.isInstanceOf(com.humana.claims.hcaas.common.jms.listener.starter.newerrorhandlers.AmqpJmsListenerErrorHandler.class);
			});
	}

	@Test
	void retryableErrorHandlerFeatureEnabled_ErrorHandlerTypeNoop_shouldCreateNewNoopErrorHandler() {
		new ApplicationContextRunner()
			.withUserConfiguration(TargetConfig.class)
			.withUserConfiguration(EnableAutoConfig.class)
			.withPropertyValues(testProperties)
			.withPropertyValues(
					"jmslistener.listeners.teci.error.type=noop",
					"jmslistener.listeners.teci.source.type=noop")
			.run(ctx -> {
				assertThat(ctx).getBean("teciJmsListenerErrorHandler")
						.isNotNull()
						.isInstanceOf(com.humana.claims.hcaas.common.jms.listener.starter.newerrorhandlers.NoOpJmsListenerErrorHandler.class);
			});
	}

	@Test
	void retryableErrorHandlerFeatureEnabled_ErrorHandlerTypeUnknown_faild_to_context_start() {
		new ApplicationContextRunner()
			.withUserConfiguration(TargetConfig.class)
			.withUserConfiguration(EnableAutoConfig.class)
			.withPropertyValues(testProperties)
			.withPropertyValues(
					"jmslistener.listeners.teci.error.type=unkonw",
					"jmslistener.listeners.teci.source.type=unkonw"
					)
			.run(ctx -> {
				assertThat(ctx).hasFailed();
			});
	}

	private String[] testProperties = {
			"jmslistener.source.ibmmq.uri=amqps://FAKE_ASB.servicebus.windows.net?amqp.idleTimeout=20000", 
			"jmslistener.error.ibmmq.uri=amqps://FAKE_ASB.servicebus.windows.net?amqp.idleTimeout=20000",
			"jmslistener.listeners.teci.error.ibmmq.prefetch=0",
			"jmslistener.listeners.teci.error.ibmmq.password=222", 
			"jmslistener.listeners.teci.error.ibmmq.queueName=erroribmmq", 
			"jmslistener.listeners.teci.error.ibmmq.userName=111",
			"jmslistener.listeners.teci.source.ibmmq.prefetch=0", 
			"jmslistener.listeners.teci.source.ibmmq.password=222", 
			"jmslistener.listeners.teci.source.ibmmq.queueName=sourceibmmq", 
			"jmslistener.listeners.teci.source.ibmmq.userName=111",
			"jmslistener.source.amqp.uri=amqps://FAKE_ASB.servicebus.windows.net?amqp.idleTimeout=20000", 
			"jmslistener.error.amqp.uri=amqps://FAKE_ASB.servicebus.windows.net?amqp.idleTimeout=20000", 
			"jmslistener.listeners.teci.error.amqp.prefetch=0",
			"jmslistener.listeners.teci.error.amqp.password=222", 
			"jmslistener.listeners.teci.error.amqp.queueName=erroramqp", 
			"jmslistener.listeners.teci.error.amqp.userName=111",
			"jmslistener.listeners.teci.source.amqp.prefetch=0",
			"jmslistener.listeners.teci.source.amqp.password=222", 
			"jmslistener.listeners.teci.source.amqp.queueName=sourceamqp", 
			"jmslistener.listeners.teci.source.amqp.userName=111"
			};

}

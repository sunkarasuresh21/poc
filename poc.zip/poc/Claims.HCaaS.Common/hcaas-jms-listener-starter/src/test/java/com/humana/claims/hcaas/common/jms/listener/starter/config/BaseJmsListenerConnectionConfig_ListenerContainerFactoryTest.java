package com.humana.claims.hcaas.common.jms.listener.starter.config;

import static org.assertj.core.api.Assertions.assertThat;

import org.apache.qpid.jms.JmsConnectionFactory;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.UnsatisfiedDependencyException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.stereotype.Component;

import com.ibm.mq.jms.MQConnectionFactory;

class BaseJmsListenerConnectionConfig_ListenerContainerFactoryTest {

	@Configuration
	static class TargetConfig extends BaseJmsListenerConnectionConfig {
		@Bean
		public static BeanDefinitionRegistryPostProcessor targetBeanConfiguration() {
			return jmsListenerDependencyBeanRegisterer("teci");
		}
	}

	@Component
	static class BeanRequiringJmsListenerContainerFactory {
		@Autowired
		JmsListenerContainerFactory<?> jmsListenerContainerFactory;
	}

	@EnableAutoConfiguration
	static class EnableAutoConfig {}

	@Test
	void amqp_config_creates_caching_connection_factory_bean_with_teci_amqp_connection_factory() {
		new ApplicationContextRunner()
			.withUserConfiguration(TargetConfig.class)
			.withUserConfiguration(EnableAutoConfig.class)
			.withPropertyValues(testProperties)
			.withPropertyValues(
					"jmslistener.listeners.teci.error.type=amqp",
					"jmslistener.listeners.teci.source.type=amqp"
					)
			.run(ctx -> {
				assertThat(ctx).getBean("teciListenerContainerFactory")
						.isNotNull()
						.isInstanceOf(JmsListenerContainerFactory.class);
				assertThat(ctx).getBean("teciListenerContainerFactory",DefaultJmsListenerContainerFactory.class)
					.extracting("connectionFactory")
					.isNotNull()
					.isInstanceOf(CachingConnectionFactory.class)
					.extracting("targetConnectionFactory")
					.isNotNull()
					.isInstanceOf(JmsConnectionFactory.class);
			});
	}
	
	@Test
	void amqp_config_using_default_idleTimeout_creates_caching_connection_factory_bean_with_teci_amqp_connection_factory() {
		new ApplicationContextRunner()
			.withUserConfiguration(TargetConfig.class)
			.withUserConfiguration(EnableAutoConfig.class)
			.withPropertyValues(testProperties)
			.withPropertyValues(
					"jmslistener.listeners.teci.error.type=amqp",
					"jmslistener.listeners.teci.source.type=amqp"
					)
			.run(ctx -> {
				assertThat(ctx).getBean("teciListenerContainerFactory")
						.isNotNull()
						.isInstanceOf(JmsListenerContainerFactory.class);
				assertThat(ctx).getBean("teciListenerContainerFactory",DefaultJmsListenerContainerFactory.class)
					.extracting("connectionFactory")
					.isNotNull()
					.isInstanceOf(CachingConnectionFactory.class)
					.extracting("targetConnectionFactory")
					.isNotNull()
					.isInstanceOf(JmsConnectionFactory.class);
			});
	}

	@Test
	void amqp_connection_factory_fails_when_prefetch_not_set() {
		new ApplicationContextRunner()
			.withUserConfiguration(TargetConfig.class)
			.withUserConfiguration(EnableAutoConfig.class)
			.withBean(BeanRequiringJmsListenerContainerFactory.class)
			.withPropertyValues(testProperties)
			.withPropertyValues(
					"jmslistener.listeners.teci.error.type=amqp",
					"jmslistener.listeners.teci.source.type=amqp",
					"jmslistener.listeners.teci.source.amqp.prefetch="
					)
			.run(ctx -> {
				assertThat(ctx).getFailure()
					.isNotNull()
					.isInstanceOf(UnsatisfiedDependencyException.class);
			});
	}

	@Test
	void amqp_prefetch_config_sets_prefetch_on_teci_amqp_connection_factory() {
		new ApplicationContextRunner()
			.withUserConfiguration(TargetConfig.class)
			.withUserConfiguration(EnableAutoConfig.class)
			.withPropertyValues(testProperties)
			.withPropertyValues(
					"jmslistener.listeners.teci.error.type=amqp",
					"jmslistener.listeners.teci.source.type=amqp",
					"jmslistener.listeners.teci.source.amqp.prefetch=23"
					)
			.run(ctx -> {
				assertThat(ctx).getBean("teciListenerContainerFactory")
						.isNotNull()
						.isInstanceOf(JmsListenerContainerFactory.class);
				assertThat(ctx).getBean("teciListenerContainerFactory",DefaultJmsListenerContainerFactory.class)
					.extracting("connectionFactory")
					.extracting("targetConnectionFactory")
					.extracting("prefetchPolicy")
					.extracting("queuePrefetch")
					.isEqualTo(23);
			});
	}

	
	@Test
	void ibmmq_config_creates_connection_factory_bean() {
		new ApplicationContextRunner()
			.withUserConfiguration(TargetConfig.class)
			.withUserConfiguration(EnableAutoConfig.class)
			.withPropertyValues(testProperties)
			.withPropertyValues(
					"jmslistener.listeners.teci.error.type=ibmmq",
					"jmslistener.listeners.teci.source.type=ibmmq"
					)
			.run(ctx -> {
				assertThat(ctx).getBean("teciListenerContainerFactory")
						.isNotNull()
						.isInstanceOf(JmsListenerContainerFactory.class);
				assertThat(ctx).getBean("teciListenerContainerFactory",DefaultJmsListenerContainerFactory.class)
					.extracting("connectionFactory")
					.isNotNull()
					.isInstanceOf(MQConnectionFactory.class);
			});
	}

	@Test
	void required_property_missing_fails_load() {
		new ApplicationContextRunner()
			.withUserConfiguration(TargetConfig.class)
			.withUserConfiguration(EnableAutoConfig.class)
			.withBean(BeanRequiringJmsListenerContainerFactory.class)
			.withPropertyValues(testProperties)
			.withPropertyValues(
					"jmslistener.listeners.teci.error.type=",
					"jmslistener.listeners.teci.source.type="
					)
			.run(ctx -> {
				assertThat(ctx).getFailure()
					.isNotNull()
					.isInstanceOf(UnsatisfiedDependencyException.class);
			});
	}

	
	@Test
	void unknown_connection_type_fails() {
		new ApplicationContextRunner()
			.withUserConfiguration(TargetConfig.class)
			.withUserConfiguration(EnableAutoConfig.class)
			.withBean(BeanRequiringJmsListenerContainerFactory.class)
			.withPropertyValues(
					"jmslistener.connectionType=unknown")
			.run(ctx -> {
				assertThat(ctx).getFailure()
					.isNotNull()
					.isInstanceOf(UnsatisfiedDependencyException.class);
			});
	}


	@Test
	void null_connection_type_fails() {
		new ApplicationContextRunner()
			.withUserConfiguration(TargetConfig.class)
			.withUserConfiguration(EnableAutoConfig.class)
			.withBean(BeanRequiringJmsListenerContainerFactory.class)
			.run(ctx -> {
				assertThat(ctx).getFailure()
				.isNotNull()
				.isInstanceOf(UnsatisfiedDependencyException.class);
			});
	}
	
	private String[] testProperties = {
			"jmslistener.source.ibmmq.uri=amqps://FAKE_ASB.servicebus.windows.net?amqp.idleTimeout=20000", 
			"jmslistener.source.ibmmq.queueManager=FAKE_QUEUE_MGR",
			"jmslistener.source.ibmmq.connName=FAKE_MQ.humana.com(1437)",
			"jmslistener.source.ibmmq.channelName=FAKE.CHANNEL.NAME",
			"jmslistener.error.ibmmq.uri=amqps://FAKE_ASB.servicebus.windows.net?amqp.idleTimeout=20000",
			"jmslistener.listeners.teci.error.ibmmq.prefetch=0",
			"jmslistener.listeners.teci.error.ibmmq.password=222", 
			"jmslistener.listeners.teci.error.ibmmq.queueName=erroribmmq", 
			"jmslistener.listeners.teci.error.ibmmq.userName=111",
			"jmslistener.listeners.teci.source.ibmmq.prefetch=0", 
			"jmslistener.listeners.teci.source.ibmmq.password=222", 
			"jmslistener.listeners.teci.source.ibmmq.queueName=sourceibmmq", 
			"jmslistener.listeners.teci.source.ibmmq.userName=111",
			
			"jmslistener.source.amqp.uri=amqps://FAKE_ASB.servicebus.windows.net?amqp.idleTimeout=20000", 
			"jmslistener.error.amqp.uri=amqps://FAKE_ASB.servicebus.windows.net?amqp.idleTimeout=20000", 
			"jmslistener.listeners.teci.error.amqp.prefetch=0",
			"jmslistener.listeners.teci.error.amqp.password=222", 
			"jmslistener.listeners.teci.error.amqp.queueName=erroramqp", 
			"jmslistener.listeners.teci.error.amqp.userName=111",
			"jmslistener.listeners.teci.source.amqp.prefetch=0",
			"jmslistener.listeners.teci.source.amqp.password=222", 
			"jmslistener.listeners.teci.source.amqp.queueName=sourceamqp", 
			"jmslistener.listeners.teci.source.amqp.userName=111"
			};
}



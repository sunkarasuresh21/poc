package com.humana.claims.hcaas.common.jms.listener.starter.newerrorhandlers;

import static java.time.Instant.now;
import static java.time.temporal.ChronoUnit.MINUTES;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.InstanceOfAssertFactories.DATE;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.Duration;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.apache.qpid.jms.message.JmsMessage;
import org.apache.qpid.jms.message.JmsTextMessage;
import org.apache.qpid.jms.provider.amqp.message.AmqpJmsTextMessageFacade;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.springframework.boot.actuate.health.HealthContributorRegistry;
import org.springframework.boot.json.JsonParseException;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.test.util.ReflectionTestUtils;

import com.humana.claims.hcaas.common.jms.listener.starter.config.model.AmqpProperties;
import com.humana.claims.hcaas.common.jms.listener.starter.config.model.ErrorBrokerDetails;
import com.humana.claims.hcaas.common.jms.listener.starter.config.model.JmsListenerProperties;
import com.humana.claims.hcaas.common.jms.listener.starter.config.model.QueueDetails;
import com.humana.claims.hcaas.common.jms.listener.starter.config.model.QueueDetails.Brokers;
import com.humana.claims.hcaas.common.jms.listener.starter.config.model.QueueProperties;
import com.humana.claims.hcaas.common.jms.listener.starter.config.model.Queues;
import com.humana.claims.hcaas.common.jms.listener.starter.config.model.SourceBrokerDetails;

import lombok.Getter;
import lombok.SneakyThrows;

class AmqpJmsListenerErrorHandlerTest {

    public static final String DELIVERY_COUNT_AMQP_PROP_NAME = "DeliveryCount";
    private FakeJmsTemplate fakeInboundQueueJmsTemplate;
    private FakeJmsTemplate fakeErrorQueueJmsTemplate;

    private Exception retryableEx = new NumberFormatException("variable");
    private Exception nonRetryableEx = new JsonParseException();

    AmqpJmsListenerErrorHandler classUnderTest =null;
    
    @BeforeEach
    public void setup() {
        fakeInboundQueueJmsTemplate = buildFakeJmsTemplateWithDefaultDestinationName("inbound-queue-name");
        fakeErrorQueueJmsTemplate = buildFakeJmsTemplateWithDefaultDestinationName("inbound-queue-name");

        classUnderTest = new AmqpJmsListenerErrorHandler("teci",prepareJmsProperties(), mock(HealthContributorRegistry.class));
        
		ReflectionTestUtils.setField(classUnderTest, "inboundQueueJmsTemplate", fakeInboundQueueJmsTemplate);
		ReflectionTestUtils.setField(classUnderTest, "errorQueueJmsTemplate", fakeErrorQueueJmsTemplate);
		ReflectionTestUtils.setField(classUnderTest, "maxDeliveryAttempts", Integer.MAX_VALUE);
		ReflectionTestUtils.setField(classUnderTest, "retryDelay", Duration.ofMillis(1));
    }

	@Test
	void should_setup_jmstemplate() {
	
		JmsTemplate errorQueueJmsTemplate = (JmsTemplate)ReflectionTestUtils.getField(classUnderTest, "errorQueueJmsTemplate");
		assertThat(errorQueueJmsTemplate).isNotNull();
		JmsTemplate inboundQueueJmsTemplate = (JmsTemplate)ReflectionTestUtils.getField(classUnderTest, "inboundQueueJmsTemplate");
		assertThat(inboundQueueJmsTemplate).isNotNull();
	}
	
    @SneakyThrows
	@Test
	void handleRetryable_should_send_to_inbound_queue_with_same_message_body() {
		classUnderTest.handleRetryableMessageProcessingException(textMessage("{ number: x }"), retryableEx);
        JmsMessage actualMsgSentToInbound = (JmsMessage)fakeInboundQueueJmsTemplate.getLastMessage();

        assertThat(actualMsgSentToInbound.getBody(String.class)).isEqualTo("{ number: x }");
	}

    @SneakyThrows
	@Test
	void handleRetryable_should_send_to_inbound_queue_with_AzureServiceBus_delay() {
		ReflectionTestUtils.setField(classUnderTest, "retryDelay", Duration.ofMinutes(10));

		classUnderTest.handleRetryableMessageProcessingException(textMessage("{ number: x }"), retryableEx);
        JmsMessage actualMsgSentToInbound = (JmsMessage)fakeInboundQueueJmsTemplate.getLastMessage();

        assertThat(actualMsgSentToInbound.getFacade().getTracingAnnotation("x-opt-scheduled-enqueue-time"))
            .isNotNull()
            .asInstanceOf(DATE)
            .isAfter(Date.from(now().plus(9, MINUTES)))
            .isBefore(Date.from(now().plus(11, MINUTES)));
	}

    @SneakyThrows
	@Test
	void handleRetryable_should_send_to_inbound_queue_with_delivery_count_1_when_no_deliveryCount() {
		classUnderTest.handleRetryableMessageProcessingException(textMessage("{ number: x }"), retryableEx);
        JmsMessage actualMsgSentToInbound = (JmsMessage)fakeInboundQueueJmsTemplate.getLastMessage();

        assertThat(actualMsgSentToInbound).isNotNull();
        assertThat(actualMsgSentToInbound.getIntProperty(DELIVERY_COUNT_AMQP_PROP_NAME)).isEqualTo(1);
	}

    @SneakyThrows
	@Test
	void handleRetryable_should_send_to_inbound_queue_with_incremented_delivery_count() {
		JmsTextMessage incomingMsg = textMessageWithDeliveryCount("{ number: x }",2);

        classUnderTest.handleRetryableMessageProcessingException(incomingMsg, retryableEx);
        JmsMessage actualMsgSentToInbound = (JmsMessage)fakeInboundQueueJmsTemplate.getLastMessage();

        assertThat(actualMsgSentToInbound.getIntProperty(DELIVERY_COUNT_AMQP_PROP_NAME)).isEqualTo(3);
	}

    @SneakyThrows
	@Test
	void handleRetryable_should_send_to_errorQueue_when_total_attempted_deliveries_exceeds_maximum_delivery_attempts() {
		ReflectionTestUtils.setField(classUnderTest, "maxDeliveryAttempts", 10);
        JmsTextMessage incomingMsg = textMessageWithDeliveryCount("{ number: x }",9); // Incoming message had been attempted 9 times before this attempt at processing

        classUnderTest.handleRetryableMessageProcessingException(incomingMsg, retryableEx);
        JmsMessage actualMsgSentToError = (JmsMessage)fakeErrorQueueJmsTemplate.getLastMessage();

        assertThat(actualMsgSentToError.getBody(String.class)).isEqualTo("{ number: x }");
	}

    @SneakyThrows
	@Test
	void handleNonRetryable_should_send_to_errorQueue_with_same_message_body() {
        classUnderTest.handleNonretryableMessageProcessingException(textMessage("{ number: x }"), nonRetryableEx);
        JmsMessage actualMsgSentToError = (JmsMessage)fakeErrorQueueJmsTemplate.getLastMessage();

        assertThat(actualMsgSentToError.getBody(String.class)).isEqualTo("{ number: x }");
	}

    public static class FakeJmsTemplate extends JmsTemplate {
        @Getter
        private Message lastMessage;

        @Getter
        private String lastDestinationName;

        @SneakyThrows
        @Override
        public void send(String destinationName, MessageCreator messageCreator) throws JmsException {
            Session session = mock(Session.class);
            when(session.createTextMessage(ArgumentMatchers.any())).thenAnswer(i -> {
                JmsTextMessage jmsTextMessage = new JmsTextMessage(new AmqpJmsTextMessageFacade());
                jmsTextMessage.setText(i.getArgument(0));
                return jmsTextMessage;
            });
            this.lastDestinationName = destinationName;
            this.lastMessage = messageCreator.createMessage(session);
        }
    }

    private FakeJmsTemplate buildFakeJmsTemplateWithDefaultDestinationName(String destinationName) {
        FakeJmsTemplate fakeJmsTemplate = new FakeJmsTemplate();
        fakeJmsTemplate.setDefaultDestinationName(destinationName);
        return fakeJmsTemplate;
    }
    private JmsTextMessage textMessage(String messageBody) throws JMSException {
        JmsTextMessage message = new JmsTextMessage(new AmqpJmsTextMessageFacade());
        message.setText(messageBody);
        return message;
    }

    private JmsTextMessage textMessageWithDeliveryCount(String messageBody, int deliveryCount) throws JMSException {
        JmsTextMessage jmsTextMessage = textMessage(messageBody);
        jmsTextMessage.setIntProperty(DELIVERY_COUNT_AMQP_PROP_NAME, deliveryCount);
        return jmsTextMessage;        
    }
    
	private JmsListenerProperties prepareJmsProperties() {
		JmsListenerProperties jmsProperties=new JmsListenerProperties();
		
		SourceBrokerDetails source=new SourceBrokerDetails();
		AmqpProperties sourceAmqp=new AmqpProperties();
		sourceAmqp.setUri("amqps://FAKE_ASB.servicebus.windows.net?amqp.idleTimeout=20000");
		source.setAmqp(sourceAmqp);
		jmsProperties.setSource(source);
		
		ErrorBrokerDetails error=new ErrorBrokerDetails();
		AmqpProperties errorAmqp=new AmqpProperties();
		errorAmqp.setUri("amqps://FAKE_ASB.servicebus.windows.net?amqp.idleTimeout=20000");
		error.setAmqp(errorAmqp);
		jmsProperties.setError(error);
		
		Queues queues=new Queues();
		QueueDetails sourceDetails=new QueueDetails();
		sourceDetails.setType(Brokers.AMQP);
		QueueProperties sourceQueueProperties=new QueueProperties();
		sourceQueueProperties.setUserName("111");
		sourceQueueProperties.setPassword("222");
		sourceQueueProperties.setQueueName("sourceAmqp");
		sourceQueueProperties.setPrefetch(0);
		sourceDetails.setAmqp(sourceQueueProperties);
		
		QueueDetails errorDetails=new QueueDetails();
		QueueProperties errorQueueProperties=new QueueProperties();
		errorQueueProperties.setUserName("111");
		errorQueueProperties.setPassword("222");
		errorQueueProperties.setQueueName("errorAmqp");
		errorQueueProperties.setPrefetch(0);
		errorDetails.setAmqp(errorQueueProperties);
		
		queues.setSource(sourceDetails);
		queues.setError(errorDetails);
		Map<String,Queues> listeners=new HashMap<String,Queues>();
		listeners.put("teci", queues);
		jmsProperties.setListeners(listeners);
		
		return jmsProperties;
	}

}

package com.humana.claims.hcaas.common.jms.listener.starter.autoconfig;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.ErrorHandler;

import com.humana.claims.hcaas.common.jms.listener.starter.jms.error.JmsListenerErrorHandler;

class JmsListenerErrorHandlerAutoConfigTest {

	@EnableAutoConfiguration
	static class EnableAutoConfig {}

	@Configuration
	static class ConfigureCustomErrorHandler {
		@Bean
		public CustomErrorHandler customErrorHandler() {
			return new CustomErrorHandler();
		}
	}


	static class CustomErrorHandler implements ErrorHandler {
		@Override
		public void handleError(Throwable t) {
			
		}
	}
	
	@Test
	void jmsListenerErrorHandler_bean_is_created_by_default() {
		new ApplicationContextRunner()
			.withUserConfiguration(EnableAutoConfig.class)
			.run(ctx -> {
				assertThat(ctx).getBean(ErrorHandler.class)
						.isNotNull()
						.isInstanceOf(JmsListenerErrorHandler.class);
			});
	}

	@Test
	void jmsListenerErrorHandler_is_not_created_as_bean_automatically_if_another_error_handler_bean_exists() {
		new ApplicationContextRunner()
			.withUserConfiguration(EnableAutoConfig.class)
			.withUserConfiguration(CustomErrorHandler.class)
			.run(ctx -> {
				assertThat(ctx).getBean(ErrorHandler.class)
						.isNotNull()
						.isInstanceOf(CustomErrorHandler.class);
			});
	}
}

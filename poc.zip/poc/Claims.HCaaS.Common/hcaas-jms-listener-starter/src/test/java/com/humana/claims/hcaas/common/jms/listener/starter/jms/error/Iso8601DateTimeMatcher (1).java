package com.humana.claims.hcaas.common.rest.api.starter.exceptionhandling.testutils;

import static java.time.format.DateTimeFormatter.ISO_OFFSET_DATE_TIME;

import java.time.format.DateTimeParseException;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;

public class Iso8601DateTimeMatcher extends TypeSafeMatcher<String> {

	@Override
	    protected boolean matchesSafely(String s) {
	    	try {
	    		ISO_OFFSET_DATE_TIME.parse(s);
	    		return true;
	    	} catch (DateTimeParseException e) {
	    		return false;
	    	}
	    }

	    @Override
	    public void describeTo(Description description) {
	        description.appendText("a string matching the pattern of ISO8601 Date Time");
	    }

	    public static Matcher<String> isValidIso8601DateTime() {
	        return new Iso8601DateTimeMatcher();
	    }

	}

package com.humana.claims.hcaas.common.jms.listener.starter.newerrorhandlers;

import static org.assertj.core.api.Assertions.assertThat;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;

import org.apache.qpid.jms.message.JmsTextMessage;
import org.apache.qpid.jms.provider.amqp.message.AmqpJmsTextMessageFacade;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import lombok.SneakyThrows;

class NoOpJmsListenerErrorHandlerTest {

	private NoOpJmsListenerErrorHandler classUnderTest = new NoOpJmsListenerErrorHandler();
	
	private ListAppender<ILoggingEvent> logAppender = new ListAppender<>(); 

	@BeforeEach
	public void setup() {
		 getTestLogger().addAppender(logAppender);
		 logAppender.start();
	}
	
	@AfterEach
	public void tearDown() {
		getTestLogger().detachAppender(logAppender);
	}

	private Logger getTestLogger() {
		return (Logger)LoggerFactory.getLogger("com.humana.claims.hcaas");
	}
	
    @SneakyThrows
	@Test
	void handleNonretryableMessageProcessingException_should_log_exception() {
		classUnderTest.handleNonretryableMessageProcessingException(textMessage("{ name: Santa }"), new IllegalStateException("oopsie"));
		
		assertThat(logAppender.list)
			.anySatisfy(l -> {
				assertThat(l.getThrowableProxy().getClassName()).isEqualTo(IllegalStateException.class.getName());
				assertThat(l.getThrowableProxy().getMessage()).isEqualTo("oopsie");
				assertThat(l.getLevel()).isEqualTo(Level.ERROR);
			});
	}

    @SneakyThrows
	@Test
	void handleRetryableMessageProcessingException_should_log_exception() {
		classUnderTest.handleRetryableMessageProcessingException(textMessage("{ name: Santa }"), new IllegalStateException("oopsie"));
		
		assertThat(logAppender.list)
			.anySatisfy(l -> {
				assertThat(l.getThrowableProxy().getClassName()).isEqualTo(IllegalStateException.class.getName());
				assertThat(l.getThrowableProxy().getMessage()).isEqualTo("oopsie");
				assertThat(l.getLevel()).isEqualTo(Level.ERROR);
			});
	}

    private Message textMessage(String messageBody) throws JMSException {
        TextMessage message = new JmsTextMessage(new AmqpJmsTextMessageFacade());
        message.setText(messageBody);
        return message;
    }

}

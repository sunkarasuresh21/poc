package com.humana.claims.hcaas.common.jms.listener.starter.jms.error;

import static org.apache.commons.lang3.StringUtils.isNotBlank;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;

class JmsListenerErrorHandlerTest {

	private JmsListenerErrorHandler classUnderTest = new JmsListenerErrorHandler();
	
	private ListAppender<ILoggingEvent> logAppender = new ListAppender<>(); 

	@BeforeEach
	public void setup() {
		 getTestLogger().addAppender(logAppender);
		 logAppender.start();
	}
	
	@AfterEach
	public void tearDown() {
		getTestLogger().detachAppender(logAppender);
	}

	private Logger getTestLogger() {
		return (Logger)LoggerFactory.getLogger("com.humana.claims.hcaas");
	}
	
	@Test
	void jmsListenerErrorHandler_should_never_throw_exception() {
		assertThatCode(() -> classUnderTest.handleError(new Throwable()))
		
		.doesNotThrowAnyException();
	}
	
	@Test
	void jmsListenerErrorHandler_should_log_once() {
		classUnderTest.handleError(new IllegalStateException("BOO!"));
		
		assertThat(logAppender.list.get(0))
			.matches(l -> l.getThrowableProxy().getMessage().contains("BOO!"))
			.matches(l -> l.getThrowableProxy().getClassName().equals(IllegalStateException.class.getName()));
	}

	@Test
	void jmsListenerErrorHandler_should_add_message_to_log() {
		classUnderTest.handleError(new IllegalStateException("BOO!"));
		
		assertThat(logAppender.list.get(0))
			.matches(l -> isNotBlank(l.getMessage()));
	}

}

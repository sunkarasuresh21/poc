package com.humana.claims.hcaas.common.jms.listener.starter.config;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

class BaseJmsListenerConnectionConfig_QueueNameTest {
	
	@Configuration
	static class TargetConfig extends BaseJmsListenerConnectionConfig {
		@Bean
		public static BeanDefinitionRegistryPostProcessor targetBeanConfiguration() {
			return jmsListenerDependencyBeanRegisterer("teci");
		}
	}
	
	@Component
	static class BeanRequiringQueueName {
		@Qualifier("teciQueueName")
		@Autowired
		String queueName;
	}

	  @EnableAutoConfiguration
	  static class EnableAutoConfig {
	  }
	 

	@Test
	void amqp_config_creates_amqp_queue_name_bean() {
		
		new ApplicationContextRunner()
			.withUserConfiguration(TargetConfig.class)
			.withUserConfiguration(EnableAutoConfig.class)
			.withBean(BeanRequiringQueueName.class)
			.withPropertyValues(testAmqpProperties)
			.withPropertyValues("jmslistener.listeners.teci.source.type=amqp")
			.run(ctx -> {
				assertThat(ctx).getBean("teciQueueName")
					.isNotNull()
					.isEqualTo("sourceamqp");
			});
	}

	@Test
	void ibmmq_config_creates_amqp_queue_name_bean() {
		new ApplicationContextRunner()
			.withUserConfiguration(TargetConfig.class)
			.withUserConfiguration(EnableAutoConfig.class)
			.withBean(BeanRequiringQueueName.class)
			.withPropertyValues(testAmqpProperties)
			.withPropertyValues("jmslistener.listeners.teci.source.type=ibmmq")
			.run(ctx -> {
				assertThat(ctx).getBean("teciQueueName")
					.isNotNull()
					.isEqualTo("sourceibmmq");
			});
	}

	@Test
	void unknown_connection_type_fails_app_ctx_startup() {
		new ApplicationContextRunner()
			.withUserConfiguration(TargetConfig.class)
			.withUserConfiguration(EnableAutoConfig.class)
			.withBean(BeanRequiringQueueName.class)
			.withPropertyValues(testAmqpProperties)
			.withPropertyValues(
					"jmslistener.listeners.teci.source.type=unknown")
			.run(ctx -> {
				assertThat(ctx).hasFailed();
			});
	}
	

	
	private String[] testAmqpProperties = {
			"jmslistener.source.ibmmq.uri=amqps://FAKE_ASB.servicebus.windows.net?amqp.idleTimeout=20000", 
			"jmslistener.error.ibmmq.uri=amqps://FAKE_ASB.servicebus.windows.net?amqp.idleTimeout=20000",
			"jmslistener.listeners.teci.error.ibmmq.prefetch=0",
			"jmslistener.listeners.teci.error.ibmmq.password=222", 
			"jmslistener.listeners.teci.error.ibmmq.queueName=erroribmmq", 
			"jmslistener.listeners.teci.error.ibmmq.userName=111",
			"jmslistener.listeners.teci.source.ibmmq.prefetch=0", 
			"jmslistener.listeners.teci.source.ibmmq.password=222", 
			"jmslistener.listeners.teci.source.ibmmq.queueName=sourceibmmq", 
			"jmslistener.listeners.teci.source.ibmmq.userName=111",
			"jmslistener.listeners.teci.error.type=ibmmq",
			"jmslistener.listeners.teci.source.type=ibmmq", 
			"jmslistener.source.amqp.uri=amqps://FAKE_ASB.servicebus.windows.net?amqp.idleTimeout=20000", 
			"jmslistener.error.amqp.uri=amqps://FAKE_ASB.servicebus.windows.net?amqp.idleTimeout=20000", 
			"jmslistener.listeners.teci.error.amqp.prefetch=0",
			"jmslistener.listeners.teci.error.amqp.password=222", 
			"jmslistener.listeners.teci.error.amqp.queueName=erroramqp", 
			"jmslistener.listeners.teci.error.amqp.userName=111",
			"jmslistener.listeners.teci.source.amqp.prefetch=0",
			"jmslistener.listeners.teci.source.amqp.password=222", 
			"jmslistener.listeners.teci.source.amqp.queueName=sourceamqp", 
			"jmslistener.listeners.teci.source.amqp.userName=111",
			"jmslistener.listeners.teci.error.type=amqp",
			"jmslistener.listeners.teci.source.type=amqp"
			};


}

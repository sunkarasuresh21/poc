package com.humana.claims.hcaas.common.jms.listener.starter.autoconfig;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;

import org.apache.commons.lang3.ArrayUtils;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import com.humana.claims.hcaas.common.jms.listener.starter.config.BaseJmsListenerConnectionConfig;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;

class ListenerConfigCheckTest {
	
	@Configuration
	@EnableAutoConfiguration
	@ComponentScan
	static class TestListenerConfig extends BaseJmsListenerConnectionConfig {
		@Bean
		public static BeanDefinitionRegistryPostProcessor targetBeanConfiguration() {
			return jmsListenerDependencyBeanRegisterer("teci");
		}
	}

	@Component
	@ConditionalOnProperty(name="test.enableTestListener", havingValue="true")
	static class TestListener {
		@JmsListener(containerFactory = "teciListenerContainerFactory", destination = "#{@teciQueueName}")
		public void newMsg(String msg) throws IOException {	}
	}
	
	@EnableJms
	@Configuration
	@ConditionalOnProperty(name="test.enableJmsConfig", havingValue="true")
	static class EnableJmsConfig {};

	
	private static ListAppender<ILoggingEvent> logAppender;
	
	@BeforeAll
	public static void setupLogAppender() {
		// Must load the Application Context before setting up the log appender.  Otherwise
		// log appender is reset and tests cannot access the log appender list.
		SpringApplication.run(TestListenerConfig.class, testProperties());
		
		logAppender = new ListAppender<>();
	    logAppender.start();

	    ((Logger)LoggerFactory.getLogger(ListenerConfigCheck.class)).addAppender(logAppender);
	}

	@AfterAll
	public static void teardownLogAppender() {
		((Logger)LoggerFactory.getLogger(ListenerConfigCheck.class)).detachAndStopAllAppenders();
	}

	@BeforeEach
	public void setup() {
	    logAppender.list.removeIf(e -> true);
	}

	
	@Test
	void jms_not_enabled_should_log_warning() {
		SpringApplication.run(TestListenerConfig.class, 
				testProperties(
						"--test.enableJmsConfig=false",
						"--test.enableTestListener=true"));
		
			assertThat(logAppender.list)
				.extracting(ILoggingEvent::getFormattedMessage)
				.anyMatch(s -> s.contains("No listeners started"));
	}

	@Test
	void listener_started_should_not_log_warning() {
		SpringApplication.run(
				new Class[] {TestListenerConfig.class}, 
				testProperties(
						"--test.enableJmsConfig=true",
						"--test.enableTestListener=true"));
		
			assertThat(logAppender.list)
				.extracting(ILoggingEvent::getFormattedMessage)
				.noneMatch(s -> s.contains("No listeners started"));
	}

	@Test
	void jms_enabled_but_listener_not_enabled_should_log_warning() {
		SpringApplication.run(
				new Class[] {TestListenerConfig.class}, 
				testProperties(
						"--test.enableJmsConfig=true",
						"--test.enableTestListener=false"));
		
			assertThat(logAppender.list)
				.extracting(ILoggingEvent::getFormattedMessage)
				.anyMatch(s -> s.contains("No listeners started"));
	}


	private final static String[] testProperties(String... addlProps) {
		return ArrayUtils.addAll(new String[] {
				"--jmslistener.source.amqp.uri=amqps://FAKE_ASB.servicebus.windows.net?amqp.idleTimeout=20000", 
				"--jmslistener.error.amqp.uri=amqps://FAKE_ASB.servicebus.windows.net?amqp.idleTimeout=20000", 
				"--jmslistener.listeners.teci.error.amqp.prefetch=0", 
				"--jmslistener.listeners.teci.error.amqp.password=222", 
				"--jmslistener.listeners.teci.error.amqp.queueName=error", 
				"--jmslistener.listeners.teci.error.amqp.userName=111", 
				"--jmslistener.jmslistener.teci.error.type=AMQP", 
				"--jmslistener.listeners.teci.source.amqp.prefetch=0", 
				"--jmslistener.listeners.teci.source.amqp.password=222", 
				"--jmslistener.listeners.teci.source.amqp.queueName=source", 
				"--jmslistener.listeners.teci.source.amqp.userName=111", 
				"--jmslistener.listeners.teci.source.type=AMQP"
				},
				addlProps);
	}
}

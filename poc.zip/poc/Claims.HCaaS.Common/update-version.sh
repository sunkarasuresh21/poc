#!/bin/bash

$( dirname $0 )/update-version.bat

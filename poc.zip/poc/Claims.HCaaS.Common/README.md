# HCaaS Common

Common Functionality used by all HCaaS applications.

## Modules

![](diagrams/hcaas-common-modules.png)

## Build

This is a multi-module Maven project.  The root POM can be used to build all the child modules. 

See [CONTRIBUTING.md](./CONTRIBUTING.md) for details on how to contribute.

## Usage

See [CHANGELOG.md](./CHANGELOG.md) for a history of the notable changes to this project

### HCaaS Common Parent

This module be the parent pom for all HCaaS projects.  This pom provides

- Default values for many fields in the POM
- Default versions for most libraries (many from Spring Boot Dependencies)
- Add several libraries (lombok, commons-lang3, etc) as dependencies on all HCaaS projects

### HCaaS Spring Boot Starter

This module should be used as a dependency on all deployable HCaaS modules.  This will include dependencies required for all HCaaS deployments (Spring Boot Starter, Vault, etc), as well as the following functionality:

#### Functionality

* [HcaasSpringBootApplication](hcaas-spring-boot-starter/src/main/java/com/humana/claims/hcaas/common/spring/boot/starter/HcaasSpringBootApplication.java)

#### HCaaS Spring Boot Starter

* [LoggingFormatEnvConfig](hcaas-spring-boot-starter/src/main/java/com/humana/claims/hcaas/common/spring/boot/starter/env/LoggingFormatEnvConfig.java)
* [TrustStoreAutoEnvConfig](hcaas-spring-boot-starter/src/main/java/com/humana/claims/hcaas/common/spring/boot/starter/env/TrustStoreAutoEnvConfig.java)
* [VaultPropertiesAutoEnvConfig](hcaas-spring-boot-starter/src/main/java/com/humana/claims/hcaas/common/spring/boot/starter/env/VaultPropertiesAutoEnvConfig.java)
* [MongoDBAutoConfig](hcaas-spring-boot-starter/src/main/java/com/humana/claims/hcaas/common/spring/boot/starter/autoconfig/MongoDBAutoConfig.java)
* [MongoDBFLEAutoConfig](hcaas-spring-boot-starter/src/main/java/com/humana/claims/hcaas/common/spring/boot/starter/autoconfig/MongoDBFLEAutoConfig.java)
* [MongoDBFieldEncryptor](hcaas-spring-boot-starter/src/main/java/com/humana/claims/hcaas/common/spring/boot/starter/mongodb/MongoDBFieldEncryptor.java)
* [MongoDBUtils](hcaas-spring-boot-starter/src/main/java/com/humana/claims/hcaas/common/spring/boot/starter/autoconfig/MongoDBUtils.java)
* [VersionInfoController](hcaas-spring-boot-starter/src/main/java/com/humana/claims/hcaas/common/spring/boot/starter/restapi/controller/VersionInfoController.java)

### HCaaS Spring Boot AOP Logging

This module is injected as dependency to HCaaS Spring Boot Starter. This includes all the classes designed to be an Aspect needed for logging across HCaaS services.

#### Auto Configurations - HCaaS Spring Boot AOP Logging

Custom annotations @Loggable and @Listener are defined.

Logging will be automatically configured for classes annotated with @RestController, @Repository, @Listener, and @Loggable, as well as methods annotated with @Loggable.  (see  [ControllerLoggingAspect](hcaas-spring-aop-logging/src/main/java/com/humana/claims/hcaas/common/spring/aop/aspect/ControllerLoggingAspect.java) and [ApplictaionLoggingAspect](hcaas-spring-aop-logging/src/main/java/com/humana/claims/hcaas/common/spring/aop/aspect/ApplictaionLoggingAspect.java) for implementation)

Correlation IDs are also added to all log statement via a correlation ID in the Mapped Diagnostic Context (MDC).  

1. The Correlation ID is created in @RestController(rest-api) (via [CorrelationInterceptor](hcaas-spring-aop-logging/src/main/java/com/humana/claims/hcaas/common/spring/aop/interceptor/CorrelationInterceptor.java))
2. The Correlation ID is created in @Listener(data-capture-app) (via [ListenerCorrelationIdAspect](hcaas-spring-aop-logging/src/main/java/com/humana/claims/hcaas/common/spring/aop/aspect/ListenerCorrelationIdAspect.java)).

CorrelationInterceptor is registered with Spring MVC framework via [InterceptorRegister](hcaas-spring-aop-logging/src/main/java/com/humana/claims/hcaas/common/spring/aop/interceptor/InterceptorRegister.java)

### HCaaS Rest API Starter

Module that provides default dependencies and auto-configurations for REST API modules

#### Auto Configurations

* [JacksonAutoConfig](hcaas-rest-api-starter/src/main/java/com/humana/claims/hcaas/common/rest/api/starter/autoconfig/JacksonAutoConfig.java)
* [ContractFirstSwaggerUi](hcaas-rest-api-starter/src/main/java/com/humana/claims/hcaas/common/rest/api/starter/autoconfig/ContractFirstSwaggerUi.java)

#### Common Functionality

* [AbstractSpringControllerExceptionHandler](hcaas-rest-api-starter/src/main/java/com/humana/claims/hcaas/common/rest/api/starter/exceptionhandling/AbstractSpringControllerExceptionHandler.java)

### HCaaS OpenAPI Generator Starter

Common dependencies for modules that use openapi generator plugin

### HCaaS Jms Listener Starter

Module that provides default dependencies and auto-configurations for Jms Listener

#### Auto Configurations

* [JmsListenerErrorHandlerAutoConfig](com/humana/claims/hcaas/common/jms/listener/starter/autoconfig/JmsListenerErrorHandlerAutoConfig.java)
* [TimedAutoConfig](com/humana/claims/hcaas/common/jms/listener/starter/autoconfig/TimedAutoConfig.java)

#### Configuration

Create all the beans needed for most jms listeners with [BaseJmsListenerConnectionConfig](com/humana/claims/hcaas/common/jms/listener/starter/config/BaseJmsListenerConnectionConfig.java)

### HCaaS Spring MongoDB Test

This module can be used to help test DAOs using Spring Data MongoDB.  

#### Usage

See [ConfigureInMemoryMongoTestServer.java](hcaas-spring-mongodb-test/src/main/java/com/humana/claims/hcaas/common/test/spring/mongodb/ConfigureInMemoryMongoTestServer.java) for details on how to easily configure the in-memory MongoDB for testing.

### HCaaS Utils

Utility methods and classes that can be used in any HCaaS module

#### Strings and Dates

* [MainframeDateUtils](hcaas-utils/src/main/java/com/humana/claims/hcaas/common/utils/MainframeDateUtils.java)
* [HcaasStringUtils](hcaas-utils/src/main/java/com/humana/claims/hcaas/common/utils/HcaasStringUtils.java)

#### Data Masking

* [StringMasker](hcaas-utils/src/main/java/com/humana/claims/hcaas/common/utils/datamasking/StringMasker.java)
* [JsonMasker](hcaas-utils/src/main/java/com/humana/claims/hcaas/common/utils/datamasking/JsonMasker.java)

#### Logging

* [LogUtils](hcaas-utils/src/main/java/com/humana/claims/hcaas/common/utils/logging/LogUtils.java)


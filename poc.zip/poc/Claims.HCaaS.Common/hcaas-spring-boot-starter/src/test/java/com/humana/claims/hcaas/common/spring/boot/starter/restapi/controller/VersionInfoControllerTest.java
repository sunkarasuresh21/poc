package com.humana.claims.hcaas.common.spring.boot.starter.restapi.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.function.Consumer;

import org.assertj.core.api.ObjectAssert;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Element;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultMatcher;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = VersionInfoController.class)
@AutoConfigureMockMvc
@TestPropertySource(locations = { "classpath:testGit.properties", "classpath:testApplication.properties" })
@ActiveProfiles("test")
@DirtiesContext(classMode = ClassMode.AFTER_EACH_TEST_METHOD)
public class VersionInfoControllerTest {

	@Autowired
	private MockMvc mockMvc;
	
	@Autowired 
	private VersionInfoController versionInfoController;
	
	@Test
	public void getApplicationNameTest() throws Exception {
		this.mockMvc.perform(get("/version")).andDo(print()).andExpect(status().isOk())
				.andExpect(elementById("appName", el -> el.extracting(Element::text).isEqualTo("testApplicationName")));
	}

	@Test
	public void getProfileTest() throws Exception {
		this.mockMvc.perform(get("/version")).andDo(print()).andExpect(status().isOk())
				.andExpect(elementById("profile", el -> el.extracting(Element::text).isEqualTo("[test]")));
	}

	@Test
	public void getCommitIdTest() throws Exception {
		this.mockMvc.perform(get("/version")).andDo(print()).andExpect(status().isOk())
				.andExpect(elementById("commitID", el -> el.extracting(Element::text).isEqualTo("123")));
	}

	@Test
	public void getBuildIdTest() throws Exception {
		this.mockMvc.perform(get("/version")).andDo(print()).andExpect(status().isOk())
				.andExpect(elementById("buildID", el -> el.extracting(Element::text).isEqualTo("TestBuild.2021109.1")));
	}

	@Test
	public void gitCommitDateTime_should_display_in_UTC_by_default() throws Exception {
		this.mockMvc.perform(get("/version")).andDo(print()).andExpect(status().isOk()).andExpect(
				elementById("CommitDate", el -> el.extracting(Element::text).isEqualTo("2021-09-24T11:01:02Z")));
	}
	
	@Test
	public void gitCommitDateTime_should_display_in_CST() throws Exception {
		this.mockMvc.perform(get("/version?timeZone=America/Chicago")).andDo(print()).andExpect(status().isOk()).andExpect(
				elementById("CommitDate", el -> el.extracting(Element::text).isEqualTo("2021-09-24T06:01:02-05:00")));
	}
	
	@Test
	public void gitCommitDateTime_should_get_exceptioin_return_same_input_date() throws Exception {
		ReflectionTestUtils.setField(versionInfoController, "gitBuildTime", "2012-09-2406:01:02-05:00");
		this.mockMvc.perform(get("/version?timeZone=America/Chicago")).andDo(print()).andExpect(status().isOk()).andExpect(
				elementById("CommitDate", el -> el.extracting(Element::text).isEqualTo("2012-09-2406:01:02-05:00")));
	}

	private ResultMatcher elementById(String id, Consumer<ObjectAssert<Element>> condition) {
		return (r) -> condition
				.accept(assertThat(Jsoup.parse(r.getResponse().getContentAsString()).getElementById(id)));
	}

}

package com.humana.claims.hcaas.common.spring.boot.starter.autoconfig;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import org.springframework.context.annotation.Configuration;

import com.humana.claims.hcaas.common.spring.boot.starter.logging.HeartbeatLogger;

@ExtendWith(OutputCaptureExtension.class)
public class HeartbeatLoggerTest {

	private static final int AT_LEAST_ONE_SEC_IN_MS = 1050;

	@Configuration
	@EnableAutoConfiguration(exclude={MongoDBAutoConfig.class, MongoDBFLEAutoConfig.class})
	static class TestConfig {
	}

	@Test
	public void shouldAutoStartHeartbeatLogger() {
		new ApplicationContextRunner()
			.withUserConfiguration(TestConfig.class)
			.run(ctx -> {
				assertThat(ctx).getBean(HeartbeatLogger.class).isNotNull();
			});
	}

	@Test
	public void shouldLogAtLeastOnceAfterOneInterval(CapturedOutput output) {
		new ApplicationContextRunner()
			.withUserConfiguration(TestConfig.class)
			.withPropertyValues("heartbeat.frequency.secs=1")
			.run(ctx -> {
				sleep(AT_LEAST_ONE_SEC_IN_MS);
				assertThat(output.getOut()).contains("Application is running");
			});
	}

	@Test
	public void shouldNotLogIfNoIntervalHavePassedYet(CapturedOutput output) {
		new ApplicationContextRunner()
			.withUserConfiguration(TestConfig.class)
			.withPropertyValues("heartbeat.frequency.secs=60")
			.run(ctx -> {
				sleep(AT_LEAST_ONE_SEC_IN_MS);
				assertThat(output.getOut()).doesNotContain("Application is running");
			});
	}

	@Test
	public void shouldLogTwiceAfterTwoIntervals(CapturedOutput output) {
		new ApplicationContextRunner()
			.withUserConfiguration(TestConfig.class)
			.withPropertyValues("heartbeat.frequency.secs=1")
			.run(ctx -> {
				sleep(AT_LEAST_ONE_SEC_IN_MS * 2);
				assertThat(output.getOut()).containsSubsequence("Application is running","Application is running");
			});
	}

	private void sleep(long ms) {
		try {
			Thread.sleep(ms); // NOSONAR
		} catch (InterruptedException e) {
			// Ignore...
		}
	}

}

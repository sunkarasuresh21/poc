package com.humana.claims.hcaas.common.spring.boot.starter;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;
import org.springframework.boot.actuate.autoconfigure.health.HealthEndpointAutoConfiguration;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

import com.humana.claims.hcaas.common.spring.boot.starter.autoconfig.MongoDBAutoConfig;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;

class HcaasSpringBootApplicationTest {

	private static final String RANDOM_SERVER_PORT_ARG = "--server.port=0";

	@TestConfiguration
	@EnableAutoConfiguration(exclude={MongoAutoConfiguration.class,MongoDBAutoConfig.class})
	static class ExampleConfig {
		@Bean
		HealthIndicator testHealthIndicator() {
			return () -> appStartupHealth;
		}
	}

	@TestConfiguration
	@EnableAutoConfiguration(exclude={MongoAutoConfiguration.class,MongoDBAutoConfig.class,HealthEndpointAutoConfiguration.class})
	static class ExampleConfigHealthActuatorDisabled { }


	private static Health appStartupHealth = Health.up().build();
	private ListAppender<ILoggingEvent> logAppender;
	private ConfigurableApplicationContext appCtxToEnsureLogAppenderIsNotReset;
	private ConfigurableApplicationContext appCtxUnderTest;

	@BeforeEach
	public void setup() {
		logAppender = new ListAppender<>();
		logAppender.start();

		appStartupHealth = Health.up().build();
	}

	@AfterEach
	public void tearDown() {
		if (appCtxToEnsureLogAppenderIsNotReset != null) {
			appCtxToEnsureLogAppenderIsNotReset.close();
		}
		if (appCtxUnderTest != null) {
			appCtxUnderTest.close();
		}
	}


   	private void run(Class<?> configClass, String... args) {
		// Must load the Application Context before setting up the log appender.  Otherwise
		// log appender is reset and tests cannot access the log appender list.
		appCtxToEnsureLogAppenderIsNotReset = HcaasSpringBootApplication.run(configClass, RANDOM_SERVER_PORT_ARG);

		((Logger)LoggerFactory.getLogger(configClass)).addAppender(logAppender);

		appCtxUnderTest = HcaasSpringBootApplication.run(configClass, args);
	}

	@Test
	void contextShouldBeCreated() {
		run(ExampleConfig.class);

		assertThat(appCtxUnderTest.isActive()).isTrue();
	}

	@Test
	void argsShouldBePassedToContext() {
		run(ExampleConfig.class, "--test.property=123456");

		assertThat(appCtxUnderTest.getEnvironment().getProperty("test.property")).isEqualTo("123456");
	}

	@Test
	void logShouldReportApplicationIsUp() {
		run(ExampleConfig.class);

		assertThat(logAppender.list)
			.extracting(ILoggingEvent::getFormattedMessage)
			.contains("Application started - health status is UP");
	}

	@Test
	void logShouldReportApplicationIsDownWhenDown() {
		appStartupHealth = Health.down().build();
		run(ExampleConfig.class);

		assertThat(logAppender.list)
			.extracting(ILoggingEvent::getFormattedMessage)
			.contains("Application started - health status is DOWN");
	}

	@Test
	void logShouldReportApplicationIsStartedWhenHealthActuatorDisabled() {
		run(ExampleConfigHealthActuatorDisabled.class);

		assertThat(logAppender.list)
			.extracting(ILoggingEvent::getFormattedMessage)
			.contains("Application started");
	}

}

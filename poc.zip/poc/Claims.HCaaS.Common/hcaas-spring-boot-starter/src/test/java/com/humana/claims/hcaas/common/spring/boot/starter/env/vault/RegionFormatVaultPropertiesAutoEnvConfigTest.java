package com.humana.claims.hcaas.common.spring.boot.starter.env.vault;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.vault.core.env.VaultPropertySource;

import com.humana.claims.hcaas.common.spring.boot.starter.HcaasSpringBootApplication;
import com.humana.claims.hcaas.common.spring.boot.starter.autoconfig.MongoDBAutoConfig;
import com.humana.claims.hcaas.common.spring.boot.starter.env.exceptions.HcaasCommonConfigException;

import lombok.Data;

public class RegionFormatVaultPropertiesAutoEnvConfigTest {

	private ConfigurableApplicationContext appCtx;

	@BeforeEach
	public void mockVaultPropertySourceInternalApiCall() {
		VaultPropertySourceFactory.setImpl((name, vaultOperations, path, propertyTransformer) -> {
			return new VaultPropertySource(name, vaultOperations, path, propertyTransformer) {
				@Override
				protected Map<String, Object> doGetProperties(String path) {
					Map<String, Object> props = new HashMap<>();
					if (path.equals("secret/hcaas.17576/unittestenv/default/connectionstrings")) {
						props.put("testapp.mongodb.username","fred");
						props.put("testapp.mongodb.password","#{${boo}}"); // $ => Property Placeholder, # => SpEL
						props.put("anotherapp.providersvc.username","barney");
					} else if (path.equals("secret/hcaas.17576/unittestenv/centralus/connectionstrings")) {
						props.put("testapp.mongodb.username","bambam");
					} else if (path.equals("secret/hcaas.17576/unittestenv/eastus2/connectionstrings")) {
						props.put("testapp.mongodb.username","wilma");
					} else if (path.equals("secret/hcaas.17576/unittest2env/default/connectionstrings")) {
						props.put("testapp.mongodb.username","george");
						props.put("anotherapp.providersvc.username","astro");
					} else if (path.equals("secret/hcaas.17576/unittestenv/connectionstrings")) {
						props.put("testapp.mongodb.username","UNUSED_LEGACY_PATH");
						props.put("anotherapp.providersvc.username","UNUSED_LEGACY_PATH");
					}
					return props;
				}
			};
		});
	}

	@AfterEach
	public void tearDown() {
		VaultPropertySourceFactory.resetImpl();
		if (appCtx != null) {
			appCtx.close();
		}
	}

	@EnableAutoConfiguration(exclude = {MongoDBAutoConfig.class, MongoAutoConfiguration.class})
	@ConfigurationProperties(prefix="mongodb")
	@TestConfiguration
	@Data
	static class MongoConfig {
		private String password;
		
	}	
	@Test
	public void vault_properties_starting_with_vaultSecretsPrefix_should_load_without_prefix() {
		appCtx = HcaasSpringBootApplication.run(MongoConfig.class, "--env=unittestenv", "--vault.secrets.prefix=testapp", "--vault.token=shhhhhhh");

		ConfigurableEnvironment environment = appCtx.getEnvironment();
		assertThat(environment.getProperty("mongodb.username")).isEqualTo("fred");
	}

	@Test
	public void vault_properties_not_starting_with_vaultSecretsPrefix_should_not_load() {
		appCtx = HcaasSpringBootApplication.run(MongoConfig.class, "--env=unittestenv", "--vault.secrets.prefix=testapp", "--vault.token=shhhhhhh");

		ConfigurableEnvironment environment = appCtx.getEnvironment();
		assertThat(environment.getProperty("providersvc.username")).isNull();
		assertThat(environment.getProperty("anotherapp.providersvc.username")).isNull();
	}

	@Test
	public void vaultToken_not_set_should_not_load_vault_property_source() {
		appCtx = HcaasSpringBootApplication.run(MongoConfig.class, "--env=unittestenv", "--vault.secrets.prefix=testapp", "--vault.token=");

		ConfigurableEnvironment environment = appCtx.getEnvironment();
		assertThat(environment.getPropertySources()).doesNotHaveAnyElementsOfTypes(VaultPropertySource.class);
	}

	
	@Test
	public void vaultSecretsPrefix_not_set_should_not_load_vault_property_source() {
		appCtx = HcaasSpringBootApplication.run(MongoConfig.class, "--env=unittestenv",                                    "--vault.token=shhhhhhh");

		ConfigurableEnvironment environment = appCtx.getEnvironment();
		assertThat(environment.getPropertySources()).doesNotHaveAnyElementsOfTypes(VaultPropertySource.class);
	}

	
	@Test
	public void env_not_set_should_not_load_vault_property_source() {
		appCtx = HcaasSpringBootApplication.run(MongoConfig.class,                       "--vault.secrets.prefix=testapp", "--vault.token=shhhhhhh");

		ConfigurableEnvironment environment = appCtx.getEnvironment();
		assertThat(environment.getPropertySources()).doesNotHaveAnyElementsOfTypes(VaultPropertySource.class);
	}
	
	@Test
	public void vault_properties_should_load_for_other_envs() {
		appCtx = HcaasSpringBootApplication.run(MongoConfig.class, "--env=unittest2env", "--vault.secrets.prefix=testapp", "--vault.token=shhhhhhh");

		ConfigurableEnvironment environment = appCtx.getEnvironment();
		assertThat(environment.getProperty("mongodb.username")).isEqualTo("george");
	}
	
	@Test
	public void vault_properties_should_disable_spring_spel() {
		appCtx = HcaasSpringBootApplication.run(MongoConfig.class, "--env=unittestenv", "--vault.secrets.prefix=testapp", "--vault.token=shhhhhhh");
		assertThat(appCtx.getBean(MongoConfig.class).password).isEqualTo("#{${boo}}");
	}

	@Test
	public void vault_properties_config_should_fail_app_startup_if_vault_uri_is_invalid() {
		assertThatExceptionOfType(HcaasCommonConfigException.class)
			.isThrownBy(() -> appCtx = HcaasSpringBootApplication.run(MongoConfig.class, "--env=unittestenv", "--vault.secrets.prefix=testapp", "--vault.token=shhhhhhh", "--vault.endpoint=http://INVALI D_URI"));
	}

	@Test
	public void when_region_is_set_properties_should_load_for_both_region_and_default() {
		appCtx = HcaasSpringBootApplication.run(MongoConfig.class, "--env=unittestenv", "--vault.secrets.prefix=testapp", "--vault.token=shhhhhhh", "--region=eastus2");

		ConfigurableEnvironment environment = appCtx.getEnvironment();
		assertThat(environment.getProperty("mongodb.username")).as("Region vault secret overrides default vault secret").isEqualTo("wilma");
		assertThat(appCtx.getBean(MongoConfig.class).password).as("Default vault secret is used when not defined as region secret").isEqualTo("#{${boo}}");
	}

}

package com.humana.claims.hcaas.common.spring.boot.starter.autoconfig;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.FilteredClassLoader;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.mongodb.ConnectionString;

class MongoDBAutoConfigTest {

	private ConfigurableApplicationContext ctx;

	@Configuration
	@EnableAutoConfiguration(exclude= {MongoDBFLEAutoConfig.class})
	static class AppConfig {
	}
	
	@AfterEach
	public void tearDown() {
		if (ctx != null) {
			ctx.close();
		}
	}

	@Test
    void mongodbUri_property_should_trigger_mongoAutoConfig() {
		ctx = SpringApplication.run(AppConfig.class, "--mongodb.uri=mongodb://testserver/db", "--mongodb.username=fred", "--mongodb.password=dino");
		
		MongoTemplate mongoTemplate = ctx.getBean(MongoTemplate.class);
		
		assertThat(mongoTemplate).isNotNull();
	}
	
	@Test
	void should_correctly_insert_username_password_into_mongo_connectionuri() {
		ctx = SpringApplication.run(AppConfig.class, "--mongodb.uri=mongodb://testserver/db", "--mongodb.username=fred", "--mongodb.password=dino");

		ConnectionString actualConnectionString = ctx.getBean(MongoDBAutoConfig.class).connectionString;
		
		assertThat(actualConnectionString.getCredential().getUserName()).isEqualTo("fred");
		assertThat(new String(actualConnectionString.getCredential().getPassword())).isEqualTo("dino");
		assertThat(actualConnectionString.getHosts()).containsExactly("testserver");
	}
	
 	@Test
	void should_handle_special_chars_in_password() {
 		// # or $ - Breaks Spring value 
 		// : @ or % - break connection string
 		String psWithSpecialChars = "${#}&}[:%->_[!>[+}(&*}>@![#&*:+](@=]%+";
		ctx = SpringApplication.run(AppConfig.class, "--mongodb.uri=mongodb://testserver/db", "--mongodb.username=fred", "--mongodb.password="+psWithSpecialChars);

		ConnectionString actualConnectionString = ctx.getBean(MongoDBAutoConfig.class).connectionString;
		
		assertThat(new String(actualConnectionString.getCredential().getPassword())).isEqualTo(psWithSpecialChars);
	}
	
	@Test
	void uri_not_set_shold_fail_configuration() {
		Throwable t = catchThrowable( () -> ctx = SpringApplication.run(AppConfig.class, /* no_mongodb_uri, */ "--mongodb.username=fred", "--mongodb.password=dino"));
		
		assertThat(t).isNotNull();
	}

	@Test
	void username_not_set_shold_fail_configuration() {
		Throwable t = catchThrowable( () -> ctx = SpringApplication.run(AppConfig.class, "--mongodb.uri=mongodb://testserver/db", /* no_user_name, */ "--mongodb.password=dino"));
		
		assertThat(t).isNotNull();
	}

	@Test
	void password_not_set_should_fail_configuration() {
		Throwable t = catchThrowable( () -> ctx = SpringApplication.run(AppConfig.class, "--mongodb.uri=mongodb://testserver/db", "--mongodb.username=fred" /* no_password */));
		assertThat(t).isNotNull();
	}

	@Test
	void springMongo_on_classpath_should_configure_mongodb() {
		new ApplicationContextRunner()
			.withUserConfiguration(AppConfig.class)
			.withPropertyValues("mongodb.uri=mongodb://testserver/db", "mongodb.username=fred", "mongodb.password=dino")
			.run(ctx -> assertThat(ctx.getBeansOfType(MongoTemplate.class)).hasSize(1) );
	}
	
	@Test
	void springMongo_not_on_classpath_should_not_configure_mongodb() {
		new ApplicationContextRunner()
		.withUserConfiguration(AppConfig.class)
		.withClassLoader(new FilteredClassLoader("org.springframework.data.mongodb."))
		.withPropertyValues("mongodb.uri=mongodb://testserver/db", "mongodb.username=fred", "mongodb.password=dino")
		.run(ctx -> assertThat(ctx.getBeansOfType(MongoTemplate.class)).hasSize(0) );
	}

}

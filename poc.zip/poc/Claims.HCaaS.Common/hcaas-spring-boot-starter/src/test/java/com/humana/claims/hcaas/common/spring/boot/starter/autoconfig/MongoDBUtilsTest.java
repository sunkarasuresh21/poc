package com.humana.claims.hcaas.common.spring.boot.starter.autoconfig;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;

import org.junit.jupiter.api.Test;

import com.mongodb.ConnectionString;

class MongoDBUtilsTest {
	
	@Test
	void should_correctly_insert_username_password_into_mongo_connectionuri() {
		ConnectionString actualConnectionString = MongoDBUtils.buildConnectionString( "mongodb://testserver/TestDB", "test" ,"test123");
		assertThat(actualConnectionString.getCredential().getUserName()).isEqualTo("test");
		assertThat(new String(actualConnectionString.getCredential().getPassword())).isEqualTo("test123");
		assertThat(actualConnectionString.getHosts()).containsExactly("testserver");
	}
	
	@Test
	void password_not_set_should_fail_to_buildConnectionString() {
		Throwable t = catchThrowable( () ->MongoDBUtils.buildConnectionString( "mongodb+srv://testserver/db", "test" ,null));
		assertThat(t).isNotNull();
	}
	
	@Test
	void username_not_set_should_fail_to_buildConnectionString() {
		Throwable t = catchThrowable( () ->MongoDBUtils.buildConnectionString( "mongodb+srv://testserver/db", null  ,"test123"));
		assertThat(t).isNotNull();
	}
	
	
	@Test
	void uri_not_set_should_fail_to_buildConnectionString() {
		Throwable t = catchThrowable( () ->MongoDBUtils.buildConnectionString( null, "test" ,"test123"));
		assertThat(t).isNotNull();
	}
	
	@Test
	void uri_format_not_correct_should_fail_to_buildConnectionString() {
		Throwable t = catchThrowable( () ->MongoDBUtils.buildConnectionString( "mongodb:/testserver/db", "test" ,"test123"));
		assertThat(t).isNotNull();
	}
	
	@Test
	void uri_is_blank_should_fail_to_buildConnectionString() {
		Throwable t = catchThrowable( () ->MongoDBUtils.buildConnectionString( "mongodb:/testserver/db", "test" ,"test123"));
		assertThat(t).isNotNull();
	}
	
	@Test
	void username_is_blank_should_fail_to_buildConnectionString() {
		Throwable t = catchThrowable( () ->MongoDBUtils.buildConnectionString( "mongodb+srv://testserver/db", "" ,"test123"));
		assertThat(t).isNotNull();
	}
	
	@Test
	void password_is_blank_should_fail_to_buildConnectionString() {
		Throwable t = catchThrowable( () ->MongoDBUtils.buildConnectionString( "mongodb+srv://testserver/db", "test" ,""));
		assertThat(t).isNotNull();
	}
	
	
}

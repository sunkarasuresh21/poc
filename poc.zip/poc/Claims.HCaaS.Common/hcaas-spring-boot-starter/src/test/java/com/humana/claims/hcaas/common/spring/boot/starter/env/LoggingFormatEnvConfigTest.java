package com.humana.claims.hcaas.common.spring.boot.starter.env;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Properties;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.Environment;

import com.humana.claims.hcaas.common.spring.boot.starter.HcaasSpringBootApplication;
import com.humana.claims.hcaas.common.spring.boot.starter.autoconfig.MongoDBAutoConfig;

import lombok.SneakyThrows;

class LoggingFormatEnvConfigTest {

	@TestConfiguration
	@EnableAutoConfiguration(exclude = {MongoDBAutoConfig.class, MongoAutoConfiguration.class})
	static class AppConfig { 
		Logger log = LoggerFactory.getLogger(AppConfig.class);
		
		public Logger getLogger() {
			return log;
		}
	}

	private static Properties loggingFormatProps = new Properties();
	
	@SneakyThrows
	@BeforeAll
	public static void setup() {
		loggingFormatProps.load(LoggingFormatEnvConfigTest.class.getClassLoader().getResourceAsStream("hcaas-default-logging-formats.properties"));
	}
	
	private ConfigurableApplicationContext appCtx;

	@AfterEach
	public void tearDown() {
		if (appCtx != null) {
			appCtx.close();
		}
	}

	@Test
	void logging_patterns_should_be_configured() {
		// Note this test does not confirm the logging pattern properties are configured before
		// the log system is setup, which is required in order for these pattern to be used
		
		appCtx = HcaasSpringBootApplication.run(AppConfig.class);
		Environment env = appCtx.getEnvironment();
		
		loggingFormatProps.forEach(
				(k,v) -> assertThat(env.getProperty((String)k)).isEqualTo(v));
	}

}

package com.humana.claims.hcaas.common.spring.boot.starter.env;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Configuration;

import com.humana.claims.hcaas.common.spring.boot.starter.HcaasSpringBootApplication;
import com.humana.claims.hcaas.common.spring.boot.starter.autoconfig.MongoDBAutoConfig;

class TrustStoreAutoEnvConfigTest {

	@Configuration
	@EnableAutoConfiguration(exclude = {MongoDBAutoConfig.class, MongoAutoConfiguration.class})
	static class AppConfig { }

	private ConfigurableApplicationContext ctx;

	@AfterEach
	private void tearDown() {
		if (ctx != null) {
			ctx.close();
		}
	}

	@Test
	void trustStoreAutoConfig_loads_by_default() {
		ctx = HcaasSpringBootApplication.run(AppConfig.class);
		
		assertThat(ctx).isNotNull();
	}
	
	@Test
	void trust_store_fails_when_invalid_truststore() {
		Throwable t = catchThrowable(() -> ctx = HcaasSpringBootApplication.run(AppConfig.class, "--truststore.path=doesnotexist.jks"));
		
		assertThat(t).isNotNull();
	}
	
	
}

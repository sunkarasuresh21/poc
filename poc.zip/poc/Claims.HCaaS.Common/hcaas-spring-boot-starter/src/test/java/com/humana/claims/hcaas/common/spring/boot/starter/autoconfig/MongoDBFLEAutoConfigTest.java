package com.humana.claims.hcaas.common.spring.boot.starter.autoconfig;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Configuration;


class MongoDBFLEAutoConfigTest {
	
	private static final String MONGODB_FLE_ENABLED = "--mongodb.fle.enabled=true";
	private static final String MONGODB_FLE_DEK_URI_PROP = "--mongodb.fle.dek.uri=mongodb://localhost:27017";
	private static final String MONGODB_FLE_DEK_UN_PROP = "--mongodb.fle.dek.username=test";
	private static final String MONGODB_FLE_DEK_PWD_PROP = "--mongodb.fle.dek.password=test";
	private static final String MONGODB_FLE_KEY_ALT_NAME = "--mongodb.fle.dek.keyaltname=user-entitlement";
	private static final String CMK = "--mongodb.fle.masterkey=0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0";
	
	@Configuration
	@EnableAutoConfiguration(exclude= {MongoDBAutoConfig.class})
	static class FLEConfig {
		
	}
	
	@Test
	void uri_not_set_should_fail_configuration() {
		Throwable t = catchThrowable(() -> SpringApplication.run(FLEConfig.class, MONGODB_FLE_ENABLED,MONGODB_FLE_KEY_ALT_NAME,
				/* no_mongodb_uri, */ MONGODB_FLE_DEK_UN_PROP, MONGODB_FLE_DEK_PWD_PROP, CMK));
		assertThat(t).isNotNull();
	}

	@Test
	void username_not_set_should_fail_configuration() {
		Throwable t = catchThrowable(() -> SpringApplication.run(FLEConfig.class, MONGODB_FLE_ENABLED,MONGODB_FLE_KEY_ALT_NAME,
				MONGODB_FLE_DEK_URI_PROP, /* no_user_name, */ MONGODB_FLE_DEK_PWD_PROP, CMK));
		assertThat(t).isNotNull();
	}

	@Test
	void password_not_set_should_fail_configuration() {
		Throwable t = catchThrowable(() -> SpringApplication.run(FLEConfig.class, MONGODB_FLE_ENABLED,MONGODB_FLE_KEY_ALT_NAME,
				MONGODB_FLE_DEK_URI_PROP, MONGODB_FLE_DEK_UN_PROP /* no_password */, CMK));
		assertThat(t).isNotNull();
	}

	@Test
	void cmk_not_set_should_fail_configuration() {
		Throwable t = catchThrowable(() -> SpringApplication.run(FLEConfig.class, MONGODB_FLE_ENABLED,MONGODB_FLE_KEY_ALT_NAME,
				MONGODB_FLE_DEK_URI_PROP, MONGODB_FLE_DEK_UN_PROP, MONGODB_FLE_DEK_PWD_PROP/* no_cmk */));
		assertThat(t).isNotNull();
	}
	
	@Test
	void keyAltName_not_set_should_fail_configuration() {
		Throwable t = catchThrowable(() -> SpringApplication.run(FLEConfig.class, MONGODB_FLE_ENABLED/* no_key_alt_name */,
				MONGODB_FLE_DEK_URI_PROP, MONGODB_FLE_DEK_UN_PROP, MONGODB_FLE_DEK_PWD_PROP,CMK));
		assertThat(t).isNotNull();
	}
}

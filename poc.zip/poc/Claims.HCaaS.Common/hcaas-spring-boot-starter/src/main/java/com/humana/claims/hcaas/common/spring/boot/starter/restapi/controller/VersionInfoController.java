package com.humana.claims.hcaas.common.spring.boot.starter.restapi.controller;

import static java.time.Instant.now;
import static java.time.format.DateTimeFormatter.ISO_OFFSET_DATE_TIME;

import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.DateTimeException;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import org.apache.commons.text.StringEscapeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;

@RestController
@ConditionalOnClass(RestController.class)
@PropertySource(value = { "classpath:/git.properties" }, ignoreResourceNotFound = true)
@Slf4j
public class VersionInfoController {

	@Value("${git.commit.id:}")
	private String gitCommitId;

	@Value("${git.branch:}")
	private String gitBranchName;

	@Value("${git.commit.user.name:}")
	private String gitUserName;

	@Value("${git.commit.author.time:}")
	private String gitCommitTime;

	@Value("${git.build.time:}")
	private String gitBuildTime;

	@Value("${git.commit.message.short:}")
	private String commitMsg;

	@Value("${spring.application.name:}")
	private String applicationName;

	@Value("${build.build-number:}")
	private String buildNumber;

	@Autowired
	private Environment environment;

	private DateTimeFormatter gitPropertyDateTimeParser = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssZ");

	@GetMapping(value = {"/version"}, produces = { "text/html" })
	public ResponseEntity<String> getVersionInfo(@RequestParam(name="timeZone",required = false,defaultValue = "UTC") String timeZone) {
		StringBuilder builder = new StringBuilder();
		prepareVersionInfoResponse(builder,timeZone);
		return ResponseEntity.ok(builder.toString());
	}

	private void prepareVersionInfoResponse(StringBuilder builder,String timeZone) {

		DateTimeFormatter dateTimeOutputFormatter = ISO_OFFSET_DATE_TIME.withZone(parseTimeZone(timeZone));

		String[] activeProfiles = environment.getActiveProfiles();
		RuntimeMXBean runtimeMXBean = ManagementFactory.getRuntimeMXBean();
		buildNumber = buildNumber.trim();
		

		builder.append("<html>	 														");
		builder.append("    <head>	 													");
		builder.append("        <style>	 												");
		builder.append("            th, td {	 										");
		builder.append("                padding: 4px;	 								");
		builder.append("				text-align: left;	 							");
		builder.append("            }	 												");
		builder.append("			.bold{	 											");
		builder.append("				font-weight: bold;	 							");
		builder.append("			}	 												");
		builder.append("        </style>	 											");
		builder.append("    </head>	 													");
		builder.append("    <body>	 													");
		builder.append("        <table style=\"margin-left: 30%; margin-right: auto;\">	");
		builder.append("            <tbody>	 											");
		builder.append("                <tr>	 										");
		builder.append("                    <td class=\"bold\">Application Details</td>	");
		builder.append("                    <td></td>	 								");
		builder.append("                </tr>	 										");
		builder.append("                <tr>	 										");
		builder.append("                    <td>Application Name</td>	 				");
		builder.append("                    <td id=\"appName\">");
		builder.append(applicationName);
		builder.append("</td>															");
		builder.append("                </tr>	 										");
		builder.append("                <tr>	 										");
		builder.append("                    <td>Host Name</td>	 						");
		builder.append("                    <td>										");
		builder.append(getHostName());
		builder.append("					</td>	 									");
		builder.append("                </tr>	 										");
		builder.append("                <tr>	 										");
		builder.append("                    <td>Active Profiles</td>	 				");
		builder.append("                    <td id=\"profile\">");
		builder.append(Arrays.toString(activeProfiles).trim());
		builder.append("</td>  															");
		builder.append("                </tr>	 										");
		builder.append("                <tr>	 										");
		builder.append("                    <td>Current Date/Time</td>	 				");
		builder.append("                    <td>										");
		builder.append(dateTimeOutputFormatter.format(now()));
		builder.append("                    </td>	 									");
		builder.append("                </tr>	 										");
		builder.append("                <tr>	 										");
		builder.append("                    <td>Uptime</td>	 							");
		builder.append("                    <td>										");
		builder.append(convertMillissecondsTodmmss(runtimeMXBean.getUptime()));
		builder.append("                    </td>	 									");
		builder.append("                </tr>	 										");
		builder.append("                <tr>	 										");
		builder.append("                    <td></td>	 								");
		builder.append("                    <td></td>	 								");
		builder.append("                </tr>	 										");

		if (gitCommitId.length() != 0) {
			builder.append("            <tr>	 										");
			builder.append("                <td class=\"bold\">Git Details</td> 		");
			builder.append("                <td></td>	 								");
			builder.append("            </tr>	 										");
			builder.append("            <tr>	 										");
			builder.append("                <td>Git Commit ID</td>	 					");
			builder.append("                <td id=\"commitID\">");
			builder.append(gitCommitId);
			builder.append("</td>	 													");
			builder.append("             </tr>	 										");
			builder.append("             <tr>	 										");
			builder.append("                 <td>Git Branch</td>	 					");
			builder.append("                 <td>				 						");
			builder.append(gitBranchName);
			builder.append("                 </td>	 									");
			builder.append("              </tr>	 										");
			builder.append("              <tr>	 										");
			builder.append("                  <td>Git Commit Message</td>	 			");
			builder.append("                  <td>										");
			builder.append(commitMsg);
			builder.append("                  </td>	 									");
			builder.append("               </tr>	 									");
			builder.append("               <tr>	 										");
			builder.append("                  <td>Git Commit Author</td>	 			");
			builder.append("                  <td>					 					");
			builder.append(gitUserName);
			builder.append("                  </td>	 									");
			builder.append("               </tr>	 									");
			builder.append("               <tr>	 										");
			builder.append("                  <td>Git Commit Date</td>	 				");
			builder.append("                  <td>								 		");
			builder.append(formatGitPropertyDateTime(gitCommitTime,dateTimeOutputFormatter));
			builder.append("                  </td>	 									");
			builder.append("               </tr>	 		   							");
			builder.append("               <tr>	 										");
			builder.append("                  <td></td>	 								");
			builder.append("                  <td></td>	 								");
			builder.append("               </tr>	 									");
		}

		if (buildNumber.length() != 0 && !(buildNumber.startsWith("@") && buildNumber.endsWith("@"))) {
			builder.append("               <tr>	 										");
			builder.append("                  <td class=\"bold\">Build Details</td>	 	");
			builder.append("                  <td></td>	 								");
			builder.append("               </tr>	 									");
			builder.append("               <tr>	 										");
			builder.append("                  <td>Build Number</td>	 					");
			builder.append("                  <td id=\"buildID\">");
			builder.append(buildNumber);
			builder.append("</td>	 													");
			builder.append("               </tr>	 									");
			builder.append("               <tr>	 										");
			builder.append("                  <td>Build Date/Time</td>");
			builder.append("                   <td id=\"CommitDate\">				    ");
			builder.append(formatGitPropertyDateTime(gitBuildTime,dateTimeOutputFormatter));
			builder.append("                  </td>	 									");
			builder.append("               </tr>	 									");
		}
		builder.append("            </tbody>	 										");
		builder.append("        </table>	 											");
		builder.append("    </body>	 													");
		builder.append("</html>	 														");

	}

	private ZoneId parseTimeZone(String timeZone) {
		try {
			return ZoneId.of(timeZone);
		} catch (DateTimeException e) {
			log.info("Error looking up Zone ID '{}'", timeZone, e);
			return ZoneOffset.UTC;
		}
	}

	private String getHostName() {
		try {
			return InetAddress.getLocalHost().getHostName();
		} catch (UnknownHostException e) {
			log.info("Host Name not found {} ", e.getMessage(), e);
			return "[ERROR GETTING HOSTNAME]";
		}
	}

	private String convertMillissecondsTodmmss(long timeInMillis) {
		return String.format("%02d:%02d:%02d:%02d d:hh:mm:ss", TimeUnit.MILLISECONDS.toDays(timeInMillis),
				TimeUnit.MILLISECONDS.toHours(timeInMillis) % 24, TimeUnit.MILLISECONDS.toMinutes(timeInMillis) % 60,
				TimeUnit.MILLISECONDS.toSeconds(timeInMillis) % 60);
	}

	private String formatGitPropertyDateTime(String inputDate, DateTimeFormatter formatter) {
		try {
			String formattedDateTime = formatter.format(gitPropertyDateTimeParser.parse(inputDate));
			return htmlEscape(formattedDateTime); // Resolve false-positive Reflected XSS issue
		} catch (Exception e) {
			log.info("Invalid input date is : {} Exception Cause is : {} ", inputDate, e.getCause());
			return inputDate;
		}
	}

	private String htmlEscape(String potentiallyDangerousString) {
		return StringEscapeUtils.escapeHtml4(potentiallyDangerousString);
	}
	
}

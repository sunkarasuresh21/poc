package com.humana.claims.hcaas.common.spring.boot.starter.security.exception;

public class HcaasTrustStoreException extends RuntimeException {

    public HcaasTrustStoreException(String message) {
        super(message);
    }

    public HcaasTrustStoreException(String message, Throwable cause) {
        super(message, cause);
    }

}

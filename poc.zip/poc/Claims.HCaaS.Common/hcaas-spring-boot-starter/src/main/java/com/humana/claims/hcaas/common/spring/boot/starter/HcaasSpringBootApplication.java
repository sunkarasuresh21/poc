package com.humana.claims.hcaas.common.spring.boot.starter;

import static org.slf4j.LoggerFactory.getLogger;

import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.actuate.health.HealthComponent;
import org.springframework.boot.actuate.health.HealthEndpoint;
import org.springframework.context.ConfigurableApplicationContext;

/**
 * `HCaasSpringBootApplication.run(...)` will start a Spring application, and immediately report the health of the application (if available).
 *
 */
public class HcaasSpringBootApplication {

	private HcaasSpringBootApplication() {}

	/**
	 * Helper function that starts a Spring Application, and immediately logs the health of the application (if available).
	 *
	 * Note this requires using Spring Actuator.
	 * @param primarySource
	 * @param args
	 * @return
	 */
	public static ConfigurableApplicationContext run(Class<?> primarySource, String... args) {
		ConfigurableApplicationContext ctx = SpringApplication.run(primarySource, args);

		try {
			Class.forName("org.springframework.boot.actuate.health.HealthComponent");

			HealthComponent health = ctx.getBean(HealthEndpoint.class).health();

			getLogger(primarySource).info("Application started - health status is {}", health.getStatus().getCode() );

		} catch (ClassNotFoundException | NoSuchBeanDefinitionException noHealthBeanFound) {
			getLogger(primarySource).info("Application started");
		}

		return ctx;
	}

}

package com.humana.claims.hcaas.common.spring.boot.starter.env.vault;

import org.springframework.vault.core.VaultOperations;
import org.springframework.vault.core.env.VaultPropertySource;
import org.springframework.vault.core.util.PropertyTransformer;

class VaultPropertySourceFactory {

    @FunctionalInterface
    static interface Impl {
        VaultPropertySource buildVaultPropertySource(String name, VaultOperations vaultOperations, String path, PropertyTransformer propertyTransformer);
    }

    private static Impl impl = VaultPropertySource::new;

    static void resetImpl() {
        setImpl(VaultPropertySource::new);
    }

    static void setImpl(Impl newImpl) {
        impl = newImpl;
    }

    static VaultPropertySource buildVaultPropertySource(String name, VaultOperations vaultOperations, String path, PropertyTransformer propertyTransformer) {
        return impl.buildVaultPropertySource(name, vaultOperations, path, propertyTransformer);
    }

    private VaultPropertySourceFactory() {}

}

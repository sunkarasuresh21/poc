package com.humana.claims.hcaas.common.spring.boot.starter.env.exceptions;

import org.springframework.core.NestedRuntimeException;

public class HcaasCommonConfigException extends NestedRuntimeException {

	private static final long serialVersionUID = 1L;

	public HcaasCommonConfigException(String message) {
		super(message);
	}

	public HcaasCommonConfigException(String msg, Throwable cause) {
		super(msg, cause);
	}

}

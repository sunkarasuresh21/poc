package com.humana.claims.hcaas.common.spring.boot.starter.autoconfig;

import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;

@ConditionalOnBean(MongoDBAutoConfig.class)
@Configuration
@ConfigurationProperties(prefix="mongodb")
@Data
public class MongoDBAutoConfigProperties {
    /** MongoDB URI (mongodb://server/db?options or mongodb+srv://server/db?options).  Do not include credentials in uri. */
    private String uri;
    /** MongoDB Username. */
    private String username;
    /** MongoDB Password. */
    private String password;

}

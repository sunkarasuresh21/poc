package com.humana.claims.hcaas.common.spring.boot.starter.autoconfig;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.annotation.PostConstruct;

import org.bson.BsonBinary;
import org.bson.Document;
import org.bson.UuidRepresentation;
import org.bson.conversions.Bson;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.humana.claims.hcaas.common.spring.boot.starter.env.exceptions.DataEncryptionConfigException;
import com.humana.claims.hcaas.common.spring.boot.starter.mongodb.MongoDBFieldEncryptor;
import com.mongodb.ClientEncryptionSettings;
import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.vault.DataKeyOptions;
import com.mongodb.client.vault.ClientEncryption;
import com.mongodb.client.vault.ClientEncryptions;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


/**
 * Automatically configures ClientEncryption for Field Level Encryption, and 
 * configures MongoDBFieldEncryptor bean.
 * Classes is loaded only when mongodb.fle.enabled is set to true
 * 
 * Requirements:
 *   - property `mongodb.fle.dek.uri` (must not contain the username and password)
 *   - property `mongodb.fle.dek.username`
 *   - property `mongodb.fle.dek.password`
 *   - property `mongodb.fle.masterkey`
 *   - property `mongodb.fle.enabled`
 *   - `org.springframework.boot:spring-boot-starter-data-mongodb` added as a dependency
 *   - `org.mongodb:mongodb-crypt` added as a dependency
 *   -  UUID stored and retrieved as BSON binary type 4
 *
 */

//Spring AutoConfig setup via src/main/resources/META-INF/spring.factories
@Configuration
@Slf4j
@ConditionalOnProperty("mongodb.fle.enabled")
@RequiredArgsConstructor
public class MongoDBFLEAutoConfig {
	
	private static final String KMS_PROVIDER="local";

	private final MongoDBFLEAutoConfigProperties props;

	private UUID keyId;
	
	private ClientEncryption clientEncryption;

	@PostConstruct
    public void init() {
		this.clientEncryption = buildClientEncryption();
		initializeDEK();
    }
	
	@Bean
    public MongoDBFieldEncryptor encryptor(){
        return new MongoDBFieldEncryptor(clientEncryption, keyId);
    }
	
	private ClientEncryption buildClientEncryption() {
		try {
			String keyVaultNamespace = "encryption" + "." + "__dataKeys";
			ConnectionString connectionString = MongoDBUtils.buildConnectionString(props.getDek().getUri(), props.getDek().getUsername(), props.getDek().getPassword());
			ClientEncryptionSettings clientEncryptionSettings = ClientEncryptionSettings.builder()
					.keyVaultMongoClientSettings(MongoClientSettings.builder()
							.uuidRepresentation(UuidRepresentation.STANDARD)
							.applyConnectionString(connectionString).build())
					.keyVaultNamespace(keyVaultNamespace).kmsProviders(this.getCMKMap()).build();

			return ClientEncryptions.create(clientEncryptionSettings);
		} catch (Exception ex) {
			throw new DataEncryptionConfigException("Unable to configure ClientEncryption",ex);
		}
	}
	
	private Map<String, Map<String, Object>> getCMKMap() {
		
		if(props.getMasterkey().length == 0) {
			throw new DataEncryptionConfigException("Customer Master Key Not loaded");
		}
		log.info("CMK loaded from vault");
		
		Map<String, Object> keyMap = new HashMap<>();
		keyMap.put("key", props.getMasterkey());
		
		Map<String,Map<String, Object>> cmkMap = new HashMap<>();
		cmkMap.put(KMS_PROVIDER, keyMap);

		return cmkMap;
	}

	private void initializeDEK() {
		
		if(loadExistingDEK()){ // NOSONAR (ignore squid:S2589)
			return;
		}
		
		createDEK();
	}

	private void createDEK() {
		DataKeyOptions dataKeyOptions = new DataKeyOptions();
		dataKeyOptions.keyAltNames(Arrays.asList(props.getDek().getKeyaltname()));
		
		BsonBinary dataKeyId = clientEncryption.createDataKey(KMS_PROVIDER, dataKeyOptions);
		keyId = dataKeyId.asUuid();
	}

	private boolean loadExistingDEK(){
		ConnectionString connectionString = MongoDBUtils.buildConnectionString(props.getDek().getUri(), props.getDek().getUsername(), props.getDek().getPassword());
		 MongoClientSettings clientSettings = MongoClientSettings.builder()
	                .uuidRepresentation(UuidRepresentation.STANDARD)
	                .applyConnectionString(connectionString)
	                .build();
		try(MongoClient mongoClient = MongoClients.create(clientSettings);)  {
			MongoCollection<Document> collection = mongoClient.getDatabase("encryption").getCollection("__dataKeys");

			Bson query = Filters.in("keyAltNames", props.getDek().getKeyaltname());
			Document doc = collection.find(query).first();

			if (doc != null) { // NOSONAR (ignore squid:S2589)
				keyId = (UUID) doc.get("_id");
				return true;
			}
			return false;
		}catch(Exception ex) {
			throw new DataEncryptionConfigException("Error Connecting to DataEncryptionKey DB",ex);
		}
	}
	
}

package com.humana.claims.hcaas.common.spring.boot.starter.env;

import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.env.EnvironmentPostProcessor;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.io.support.ResourcePropertySource;

import com.humana.claims.hcaas.common.spring.boot.starter.env.exceptions.HcaasCommonConfigException;

/**
 * Set logging format to HCaaS standard.  
 * 
 * Logging format is defined in hcaas-default-logging-formats.properties.  
 * 
 * If necessary, can be overridden by any other property source (application.properties, 
 * environment variables, command line parameters, etc)
 */

//setup via src/main/resources/META-INF/spring.factories
public class LoggingFormatEnvConfig implements EnvironmentPostProcessor {

	private static final String PROPERTIES_PATH = "hcaas-default-logging-formats.properties";

	@Override
	public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application) {
		try {
			MapPropertySource defaultLoggingFormatsPropSrc = new ResourcePropertySource(PROPERTIES_PATH);
			environment.getPropertySources().addLast(defaultLoggingFormatsPropSrc);
		} catch (IOException e) {
			throw new HcaasCommonConfigException("Error Loading Logging Properties", e);
		}
	}

}

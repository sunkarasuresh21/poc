package com.humana.claims.hcaas.common.spring.boot.starter.autoconfig;

import static java.net.URLEncoder.encode;
import static java.text.MessageFormat.format;

import java.io.UnsupportedEncodingException;

import com.mongodb.ConnectionString;
/**
 *  Builds ConnectionString to connect to Mongo Database.
 *
 * Requirements:
 *   - property `uri` (must not contain the username and password)
 *   - property `username`
 *   - property `password`
 *
 */

class MongoDBUtils {
	
	private MongoDBUtils() {}

	static ConnectionString buildConnectionString(String uri, String username, String pwd) {
		try {
			return new ConnectionString(
					format(uri.replaceFirst("://", "://{0}:{1}@"), encode(username, "UTF-8"), encode(pwd, "UTF-8")));
		} catch (UnsupportedEncodingException ex) {
			throw new IllegalArgumentException("Unable to build ConnectionString", ex);
		}
	}

}

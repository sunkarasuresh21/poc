package com.humana.claims.hcaas.common.spring.boot.starter.security;

import static java.text.MessageFormat.format;

import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.lang3.ArrayUtils;
import org.springframework.core.env.Environment;

import com.humana.claims.hcaas.common.spring.boot.starter.env.TrustStoreAutoEnvConfig;
import com.humana.claims.hcaas.common.spring.boot.starter.env.exceptions.TrustStoreAutoEnvConfigException;
import com.humana.claims.hcaas.common.spring.boot.starter.security.exception.HcaasTrustStoreException;

import lombok.Getter;

public class HcaasTrustStore {
	private static final String PROPERTY_PATH = "truststore.path";
	private static final String PROPERTY_PW = "truststore.password";
	private static final String PROPERTY_TYPE = "truststore.type";

	private static final String DEFAULT_PATH = "custom-truststore.jks";
	private static final String DEFAULT_PW = "humana123";
	private static final String DEFAULT_TYPE = "jks";

    @Getter
    private final X509TrustManager trustManager;

    @Getter
    private final String customTrustStorePath;

    public HcaasTrustStore(Environment environment) {

		customTrustStorePath = environment.getProperty(PROPERTY_PATH, DEFAULT_PATH);
		String customTrustStorePw = environment.getProperty(PROPERTY_PW, DEFAULT_PW);
		String customTrustStoreType = environment.getProperty(PROPERTY_TYPE, DEFAULT_TYPE);


        try {
            trustManager = buildMergedTrustManager(customTrustStorePath, customTrustStorePw, customTrustStoreType);
        } catch (NoSuchAlgorithmException | KeyStoreException | CertificateException | IOException e) {
            throw new HcaasTrustStoreException("Failed Loading Trust Store", e);
        }
    }
	
    public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
        trustManager.checkClientTrusted(chain, authType);
    }

	private X509TrustManager buildMergedTrustManager(String customStorePath, String customStorePass, String customStoreType)
			throws NoSuchAlgorithmException, KeyStoreException, IOException, CertificateException {
		X509TrustManager jreTm = getJreTrustManager();
		X509TrustManager customTm = getCustomTrustManager(customStorePath, customStorePass, customStoreType);

		X509TrustManager mergedTm = mergeTrustManagers(jreTm, customTm);
		return mergedTm;
	}

	private X509TrustManager getCustomTrustManager(String customStorePath, String customStorePass, String customStoreType) throws KeyStoreException, IOException, NoSuchAlgorithmException, CertificateException {
		try (InputStream customTrustStore = TrustStoreAutoEnvConfig.class.getClassLoader().getResourceAsStream(customStorePath)) {
			KeyStore customKeystore = KeyStore.getInstance(customStoreType);
			customKeystore.load(customTrustStore, customStorePass.toCharArray());

			if (!customKeystore.aliases().hasMoreElements()) {
				throw new HcaasTrustStoreException(format("Trust Store ''{0}'' Not Found", customStorePath));
			}

			return getTrustManager(customKeystore);
		}
	}

	private X509TrustManager getJreTrustManager() throws NoSuchAlgorithmException, KeyStoreException {
		// Using null here initialises the TMF with the default trust store.
		return getTrustManager((KeyStore) null);
	}

	private X509TrustManager getTrustManager(KeyStore keyStore) throws NoSuchAlgorithmException, KeyStoreException {
		TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
		tmf.init(keyStore);

		for (TrustManager tm : tmf.getTrustManagers()) {
		    if (tm instanceof X509TrustManager) {
		        return (X509TrustManager) tm;
		    }
		}

		throw new TrustStoreAutoEnvConfigException("KeyStoreNotFound");
	}

	private X509TrustManager mergeTrustManagers(X509TrustManager jreTm, X509TrustManager customTm) {
		return new X509TrustManager() {

			X509Certificate[] acceptedIssuers = ArrayUtils.addAll(jreTm.getAcceptedIssuers(), customTm.getAcceptedIssuers());

		    @Override
		    public X509Certificate[] getAcceptedIssuers() {
				return acceptedIssuers;
		    }

		    @Override
		    public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
		        try {
		            customTm.checkServerTrusted(chain, authType);
		        } catch (CertificateException e) {
		            // This will throw another CertificateException if this fails too.
		            jreTm.checkServerTrusted(chain, authType);
		        }
		    }

		    @Override
		    public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
		        try {
		            customTm.checkClientTrusted(chain, authType);
		        } catch (CertificateException e) {
		            // This will throw another CertificateException if this fails too.
		            jreTm.checkClientTrusted(chain, authType);
		        }
		    }
		 };
	}

}

package com.humana.claims.hcaas.common.spring.boot.starter.autoconfig;

import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;

@ConditionalOnBean(MongoDBFLEAutoConfig.class)
@Configuration
@ConfigurationProperties(prefix="mongodb.fle")
@Data
public class MongoDBFLEAutoConfigProperties {
    /** Controls if Field Level Encryption (FLE) is enabled for MongoDB connection. */
    private boolean enabled; // See MongoDBFLEAutoConfig ConditionalOnProperty annotation
    /** MongoDB FLE Master Key. */
	private byte[] masterkey;
    private DEK dek;

    @Data
    public static class DEK {
        /** MongoDB FLE Data Encryption Key source URI (mongodb://server/db?options or mongodb+srv://server/db?options).  Do not include credentials in uri. */
        private String uri;
        
        /** MongoDB FLE Data Encryption Key source username. */
        private String username;
        
        /** MongoDB FLE Data Encryption Key source password. */
        private String password;
    
        /** MongoDB FLE Data Encryption Key altname. */
        private String keyaltname;
    
    }

}

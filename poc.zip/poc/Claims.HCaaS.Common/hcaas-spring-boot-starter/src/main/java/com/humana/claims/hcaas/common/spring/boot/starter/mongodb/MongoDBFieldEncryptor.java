package com.humana.claims.hcaas.common.spring.boot.starter.mongodb;

import java.util.UUID;

import org.bson.BsonBinary;
import org.bson.BsonString;

import com.mongodb.client.model.vault.EncryptOptions;
import com.mongodb.client.vault.ClientEncryption;

/**
 * MongoDBFieldEncryptor contains clientEncryption and encryptionKeyUUID which can be used to encrypt and decrypt data.
 * Exposes methods that can be used encrypt and decrypt data.
 *
 */

public class MongoDBFieldEncryptor {
	
	private ClientEncryption  clientEncryption;
	
	private  UUID encryptionKeyUUID;
	
	public MongoDBFieldEncryptor(ClientEncryption  clientEncryption,UUID encryptionKeyUUID) {
		this.clientEncryption = clientEncryption;
		this.encryptionKeyUUID = encryptionKeyUUID;
	}
	
	public BsonBinary encrypt(String data, String algorithm) {
		return clientEncryption.encrypt(new BsonString(data),getEncryptOptions(algorithm));
	}

	public String decrypt(BsonBinary ciphertext, String algorithm) { // NOSONAR (ignore squid:S1172)
		return clientEncryption.decrypt(ciphertext).asString().getValue();
	}
	
	private  EncryptOptions getEncryptOptions(String algorithm){
		EncryptOptions encryptOptions = new EncryptOptions(algorithm);
		encryptOptions.keyId(new BsonBinary(encryptionKeyUUID));
		return encryptOptions;
	}

}

package com.humana.claims.hcaas.common.spring.boot.starter.autoconfig;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.Arrays;
import java.util.Date;

import org.bson.BsonBinary;
import org.bson.UuidRepresentation;
import org.bson.types.Binary;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.CustomConversions;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.MongoTransactionManager;
import org.springframework.data.mongodb.core.SimpleMongoClientDatabaseFactory;
import org.springframework.data.mongodb.core.convert.DbRefResolver;
import org.springframework.data.mongodb.core.convert.DefaultDbRefResolver;
import org.springframework.data.mongodb.core.convert.DefaultMongoTypeMapper;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.core.convert.MongoCustomConversions;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;
import org.springframework.lang.NonNull;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;

/**
 * Automatically configures a MongoTemplate and enables Spring Transaction
 * Management if spring-boot-starter-data-mongodb 
 * is included as a dependency.
 *
 * Requirements:
 *   - properties `mongodb.*`
 *   - `org.springframework.boot:spring-boot-starter-data-mongodb` added as a dependency
 *
 */

//Spring AutoConfig setup via src/main/resources/META-INF/spring.factories
@ConditionalOnClass(SimpleMongoClientDatabaseFactory.class)
@EnableTransactionManagement
public class MongoDBAutoConfig {

	final ConnectionString connectionString;

	public MongoDBAutoConfig(MongoDBAutoConfigProperties props) {

		if (props.getUri().matches(".*:.*@.*")) {
			throw new IllegalArgumentException("mongodb.uri cannot contain username and password");
		}

		connectionString = MongoDBUtils.buildConnectionString(props.getUri(), props.getUsername(), props.getPassword());
	}

	@Bean
	public MongoDatabaseFactory mongoDbFactory() {
		return new SimpleMongoClientDatabaseFactory(mongoClient(),connectionString.getDatabase());
	}

	private static final Converter<Date, LocalDate> DateToLocalDateConverter =
			new Converter<Date, LocalDate>() { //NOSONAR (ignore squid:S1604)
				@Override
				public LocalDate convert(@NonNull Date source) {
					return source.toInstant().atZone(ZoneOffset.UTC).toLocalDate();
				}
			};

	private static final Converter<LocalDate, Date> LocalDateToDateConverter =
		new Converter<LocalDate, Date>() { //NOSONAR (ignore squid:S1604)
	         @Override
	         public Date convert(@NonNull LocalDate source) {
	            return new Date(source.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli());
	         }
	      };
	      
	private static final Converter<Binary, BsonBinary> BinaryToBsonBinaryConverter = new Converter<Binary, BsonBinary>() { // NOSONAR
		@Override
		public BsonBinary convert(Binary source) {
			return new BsonBinary(source.getData());
		}
	};

	private static final Converter<BsonBinary, BsonBinary> BsonBinaryToBinaryConverter = new Converter<BsonBinary, BsonBinary>() { // NOSONAR
		@Override
		public BsonBinary convert(BsonBinary source) {
			return source.asBinary();
		}
	};

	@Bean
	public MongoCustomConversions customConversions() {
		// Override Spring Jsr310Converters LocalDateToDateConverter and DateToLocalTimeConverter - which converts LocalDate to midnight System TZ
		// instead, duplicate the logic of LocalDateCodec in the MongoDB Driver - which converts LocalDate to midnight UTC
		// (Spring will use it's own converters rather than the MongoDB Driver Codecs)
		return new MongoCustomConversions(Arrays.asList(
				LocalDateToDateConverter,
				DateToLocalDateConverter,
				BinaryToBsonBinaryConverter,
				BsonBinaryToBinaryConverter));
	}

	@Bean
	public MappingMongoConverter mappingMongoConverter(
				MongoDatabaseFactory mongoDbFactory,
				MongoMappingContext mongoMappingContext,
				CustomConversions customConversions) {
		MappingMongoConverter converter = createDefaultMappingMongoConverter(mongoDbFactory, mongoMappingContext, customConversions);

		// Remove "_class" from being added to each document in database
		// see https://mkyong.com/mongodb/spring-data-mongodb-remove-_class-column/ and https://stackoverflow.com/questions/6810488/spring-data-mongodb-mappingmongoconverter-remove-class/
		converter.setTypeMapper(new DefaultMongoTypeMapper(null));

		return converter;
	}
	
	@Bean
    public MongoTransactionManager mongoDbTransactionManager(MongoDatabaseFactory dbFactory) {
        return new MongoTransactionManager(dbFactory);
    }

	private MappingMongoConverter createDefaultMappingMongoConverter(MongoDatabaseFactory mongoDbFactory,
			MongoMappingContext mongoMappingContext, CustomConversions customConversions) {
		// Create mapping mongo converter identical to AbstractMongoConfiguration class
		DbRefResolver dbRefResolver = new DefaultDbRefResolver(mongoDbFactory);
		MappingMongoConverter converter = new MappingMongoConverter(dbRefResolver, mongoMappingContext);
		converter.setCustomConversions(customConversions);
		return converter;
	}
	
	private MongoClient mongoClient() {
		 MongoClientSettings clientSettings = MongoClientSettings.builder()
	                .uuidRepresentation(UuidRepresentation.STANDARD)
	                .applyConnectionString(connectionString)
	                .build();
		return MongoClients.create(clientSettings);
	}

}

package com.humana.claims.hcaas.common.spring.boot.starter.autoconfig;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.humana.claims.hcaas.common.spring.boot.starter.logging.HeartbeatLogger;

@Configuration
public class HeartbeatLoggerAutoConfig {

    @Bean
    public HeartbeatLogger heartbeatLogger(
        @Value("${heartbeat.frequency.secs:300}") long frequencySecs) { // Default to 5 mins
            return new HeartbeatLogger(frequencySecs);
    }

}

package com.humana.claims.hcaas.common.spring.boot.starter.env.exceptions;

public class DataEncryptionConfigException extends HcaasCommonConfigException {

	private static final long serialVersionUID = 1L;

	public DataEncryptionConfigException(String message) {
		super(message);
	}

	public DataEncryptionConfigException(String msg, Throwable cause) {
		super(msg, cause);
	}

}

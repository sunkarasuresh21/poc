package com.humana.claims.hcaas.common.spring.boot.starter.env.exceptions;

public class TrustStoreAutoEnvConfigException extends HcaasCommonConfigException {

	private static final long serialVersionUID = 1L;

	public TrustStoreAutoEnvConfigException(String message) {
		super(message);
	}

	public TrustStoreAutoEnvConfigException(String msg, Throwable cause) {
		super(msg, cause);
	}

}

package com.humana.claims.hcaas.common.spring.boot.starter.env.vault;

import static com.humana.claims.hcaas.common.spring.boot.starter.env.vault.VaultPropertySourceFactory.buildVaultPropertySource;
import static java.text.MessageFormat.format;
import static java.util.stream.Collectors.toMap;
import static org.apache.commons.lang3.StringUtils.isBlank;

import java.net.URI;
import java.net.URISyntaxException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
import org.springframework.boot.env.RandomValuePropertySource;
import org.springframework.boot.logging.DeferredLog;
import org.springframework.context.ApplicationListener;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.vault.authentication.TokenAuthentication;
import org.springframework.vault.client.VaultEndpoint;
import org.springframework.vault.core.VaultTemplate;
import org.springframework.vault.core.env.VaultPropertySource;
import org.springframework.vault.core.util.PropertyTransformer;

import com.humana.claims.hcaas.common.spring.boot.starter.env.exceptions.HcaasCommonConfigException;

/**
 * Load credentials from vault as a Spring property source.
 *
 * Note that Vault properties will be added as property source between environment variables and properties files. Ex:
 * 	- Test properties
 * 	- env variable
 * 	- ** Vault properties **
 * 	- Property Files
 * 
 * (specifically, the vault property source will be added before the random property source.  See
 *  https://docs.spring.io/spring-boot/docs/2.2.7.RELEASE/reference/html/spring-boot-features.html#boot-features-external-config
 *  for further explanation about property source order)
 * 
 * Required properties for normal usage:
 *   - vault.token
 *      - Should be set at runtime
 *      - If not set, Vault credentials will not be loaded
 *   - vault.secrets.prefix
 *     - The prefix of all secrets to load for this application
 *     - Do not include trailing period - this will be included automatically
 *     - Properties will have the vault.secrets.prefix removed from the key (ex: If the prefix is "my-application",
 *         and the vault property is "my-application.mongodb.username", then the property that will be loaded
 *         will be "mongodb.username").
 *     - Should typically be set in properties file when loaded
 *   - env
 *     - Used for secrets path
 *     - Should be set at runtime
 *   - region
 *     - used for secrets path
 *     - Should be set at runtime
 *     - Will load both region and default as property sources (with region taking precedent)
 *     - If not set, only default will load
 * 
 * IMPORTANT NOTES
 * \@Value annotations will evaluate the property value as a SpEL, which will cause issues if the property contains the chars '$' or '#'.
 * 
 * To avoid this issue, use @ConfigurationProperties (which is the preferred way to load properties)
 * 
 * Ref: https://docs.spring.io/spring-boot/docs/2.4.13/reference/html/spring-boot-features.html#boot-features-external-config-vs-value
 */

public class RegionFormatVaultPropertiesAutoEnvConfig implements ApplicationListener<ApplicationEnvironmentPreparedEvent> {

	private static final String PROPERTY_SOURCE_NAME = RegionFormatVaultPropertiesAutoEnvConfig.class.getName();

	private DeferredLog log = new DeferredLog();
	
    private String env;
    private String region;

	private String vaultEndpointStr;
	private String vaultSecretsDefaultPath;
	private String vaultSecretsRegionPath;
	private String vaultSecretsPrefix;
	private String vaultToken;

	private void initializeProperties(ConfigurableEnvironment environment) {
		this.vaultEndpointStr = environment.getProperty("vault.endpoint", "https://itvault.humana.com");
        env = environment.getProperty("env");
        if (StringUtils.isNotBlank(env)) {
            this.vaultSecretsDefaultPath = buildSecretsPath(env, "default");
            region = environment.getProperty("region");
            if (StringUtils.isNotBlank(region)) {
                this.vaultSecretsRegionPath = buildSecretsPath(env, region);
            }
        }
		this.vaultSecretsPrefix = environment.getProperty("vault.secrets.prefix","") + ".";
		this.vaultToken = environment.getProperty("vault.token");
	}

    private static String buildSecretsPath(String env, String region) {
        return format("secret/hcaas.17576/{0}/{1}/connectionstrings", env, region);
    }
	
	@Override
	public void onApplicationEvent(ApplicationEnvironmentPreparedEvent event) {
		event.getSpringApplication().addInitializers(ctx -> log.replayTo(RegionFormatVaultPropertiesAutoEnvConfig.class));
		ConfigurableEnvironment environment = event.getEnvironment();
		
		initializeProperties(environment);
		if (!isValidToLoadFromVault()) {
			return;
		}
		log.info(format("{0}* properties will be loaded from Vault ({1})", vaultSecretsPrefix, env));

        if (vaultSecretsRegionPath != null) {
            processVaultProperties(environment, region, vaultSecretsRegionPath);
        }
        processVaultProperties(environment, "default", vaultSecretsDefaultPath);
	}

    private void processVaultProperties(ConfigurableEnvironment environment, String propertySourceSuffix, String vaultSecretsPath) {
        VaultPropertySource vaultPropertySource = loadVaultPropertySource(propertySourceSuffix, vaultSecretsPath);

		addAsEnvironmentPropertySource(vaultPropertySource, environment);

		logPropertiesFromVault(vaultPropertySource, propertySourceSuffix);

    }

	private boolean isValidToLoadFromVault() {
		if (isBlank(vaultToken)) {
			log.info("Vault not configured");
			return false;
		}
		if (vaultSecretsPrefix.equals(".")) {
			log.error("Vault Secrets Prefix not configured!  No properties will be loaded from Vault.");
			return false;
		}
		if (vaultSecretsDefaultPath == null) {
			log.error("Env not configured!  No properties will be loaded from Vault.");
			return false;
		}
		return true;
	}

	private VaultPropertySource loadVaultPropertySource(String propertySourceSuffix, String vaultSecretsPath) {
		String propertySourceName = format("{0}(${1})", PROPERTY_SOURCE_NAME, propertySourceSuffix);

		VaultEndpoint vaultEndpoint = VaultEndpoint.from(uri(vaultEndpointStr));
		VaultTemplate vaultTemplate = new VaultTemplate(vaultEndpoint, new TokenAuthentication(vaultToken));
		return buildVaultPropertySource(propertySourceName, vaultTemplate, vaultSecretsPath, vaultPropertyPrefixFilter);
	}

	private URI uri(String s) {
		try {
			return new URI(s);
		} catch (URISyntaxException e) {
			throw new HcaasCommonConfigException("Error Loading Vault Properties", e);
		}
	}

	private PropertyTransformer vaultPropertyPrefixFilter = map ->
		map.entrySet().stream()
			.filter(e -> e.getKey().startsWith(vaultSecretsPrefix))
			.collect(toMap(
					e -> e.getKey().substring(vaultSecretsPrefix.length()), 
					e -> (String)e.getValue()));

	private void addAsEnvironmentPropertySource(VaultPropertySource vaultPropertySource, ConfigurableEnvironment environment) {
		MutablePropertySources environmentPropSources = environment.getPropertySources();

		// Add between OS properties and property files
		// see https://docs.spring.io/spring-boot/docs/current/reference/html/spring-boot-features.html#boot-features-external-config
		// Add before "random" since I am sure that will always be a loaded property source, and it also is between OS and properties files
		environmentPropSources.addBefore(RandomValuePropertySource.RANDOM_PROPERTY_SOURCE_NAME, vaultPropertySource);
	}

	private void logPropertiesFromVault(VaultPropertySource vaultPropertySource, String propertySourceSuffix) {
		for (String propName : vaultPropertySource.getPropertyNames()) {
			log.info(format("Property {0} found in vault ({1})", propName, propertySourceSuffix));
		}
	}
}

package com.humana.claims.hcaas.common.spring.boot.starter.logging;

import static java.util.concurrent.TimeUnit.SECONDS;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

import javax.annotation.PreDestroy;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class HeartbeatLogger {

    private final ScheduledExecutorService execSvc;

    public HeartbeatLogger(long frequencySecs) {
        execSvc = Executors.newSingleThreadScheduledExecutor();
        execSvc.scheduleAtFixedRate(this::pulse, frequencySecs, frequencySecs, SECONDS);
    }


    @PreDestroy
    public void tearDown() {
        execSvc.shutdownNow();
    }

    public void pulse() {
        log.info("Application is running");
    }
}

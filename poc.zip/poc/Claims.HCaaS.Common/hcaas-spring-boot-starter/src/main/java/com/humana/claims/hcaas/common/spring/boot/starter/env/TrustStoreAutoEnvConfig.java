package com.humana.claims.hcaas.common.spring.boot.starter.env;


import static java.text.MessageFormat.format;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.env.EnvironmentPostProcessor;
import org.springframework.boot.logging.DeferredLog;
import org.springframework.core.env.ConfigurableEnvironment;

import com.humana.claims.hcaas.common.spring.boot.starter.env.exceptions.TrustStoreAutoEnvConfigException;
import com.humana.claims.hcaas.common.spring.boot.starter.security.HcaasTrustStore;

/**
 * Automatically configure the runtime truststore, merging the JRE cacerts and a custom Humana truststore.
 *
 * The default custom truststore used is custom-truststore.jks, which includes
 * Humana CAs.  This allows the application to work with other applications that
 * use a Humana signed certificate.
 *
 * This class will be automatically configured by Spring Boot. No configuration is necessary.
*/

// Spring Environment PostProcessor setup via src/main/resources/META-INF/spring.factories
public class TrustStoreAutoEnvConfig implements EnvironmentPostProcessor {

	private DeferredLog log = new DeferredLog();
	
	@Override
	public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication app) {
		app.addInitializers(ctx -> log.replayTo(TrustStoreAutoEnvConfig.class));

		try {
			HcaasTrustStore hcaasTrustStore = new HcaasTrustStore(environment);
			setRuntimeTrustManager(hcaasTrustStore.getTrustManager());
			log.info(format("Trust Store {0} Successfully loaded", hcaasTrustStore.getCustomTrustStorePath()));
		} catch (Exception e) {
			throw new TrustStoreAutoEnvConfigException("Unable to configure truststore", e);
		}
	}

	private void setRuntimeTrustManager(X509TrustManager mergedTm) throws NoSuchAlgorithmException, KeyManagementException {
		SSLContext sslContext = SSLContext.getInstance("TLS"); //NOSONAR
		sslContext.init(null, new TrustManager[] { mergedTm }, null);

		// You don't have to set this as the default context,
		// it depends on the library you're using.
		SSLContext.setDefault(sslContext);
	}

}

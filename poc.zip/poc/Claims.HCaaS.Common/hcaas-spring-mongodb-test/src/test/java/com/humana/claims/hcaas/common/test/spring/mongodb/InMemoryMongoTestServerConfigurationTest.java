package com.humana.claims.hcaas.common.test.spring.mongodb;

import static com.humana.claims.hcaas.common.test.spring.mongodb.testsetup.PersonMongoDbDao.COLLECTION_NAME;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.humana.claims.hcaas.common.test.spring.mongodb.testsetup.Person;
import com.humana.claims.hcaas.common.test.spring.mongodb.testsetup.PersonDao;
import com.humana.claims.hcaas.common.test.spring.mongodb.testsetup.PersonMongoDbDao;

@SpringBootTest(classes = PersonMongoDbDao.class)
@ConfigureInMemoryMongoTestServer
class InMemoryMongoTestServerConfigurationTest {

	@Autowired
	private MongoTemplate mongoTemplate;

	@Autowired
	private PersonDao dao;

	@AfterEach
	public void dropCollection() {
		mongoTemplate.dropCollection(COLLECTION_NAME);
	}

	@Test
	void testMongoServer_and_mongoTemplate_should_be_setup() {
		assertThatCode(() -> mongoTemplate.query(Person.class))
			.doesNotThrowAnyException();
	}

	@Test
	void testMongoServer_should_be_functional_within_application_code() {
		Person fred = new Person();
		fred.setId("fflintstone");
		fred.setName("Fred Flintstone");
		mongoTemplate.insert(fred, COLLECTION_NAME);
		
		Person actual = dao.getPerson("fflintstone");

		assertThat(actual).isEqualTo(fred);
	}
}

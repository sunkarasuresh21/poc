package com.humana.claims.hcaas.common.test.spring.mongodb.testsetup;

import lombok.Data;
import lombok.EqualsAndHashCode;

/** Example of a Production Code model to enable unit testing */
@Data
@EqualsAndHashCode
public class Person {
	private String id;
	private String name;
}

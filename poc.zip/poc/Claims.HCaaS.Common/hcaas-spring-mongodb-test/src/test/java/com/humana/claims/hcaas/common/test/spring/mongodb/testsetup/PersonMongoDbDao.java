package com.humana.claims.hcaas.common.test.spring.mongodb.testsetup;

import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;

/** Example of a Production Code MongoDB DAO implementation to enable unit testing */
@Component
@RequiredArgsConstructor
public class PersonMongoDbDao implements PersonDao {

	public static final String COLLECTION_NAME = "People";
	
	private final MongoTemplate mongoTemplate;
	
	@Override
	public Person getPerson(String id) {
		Query query = new Query();
		query.addCriteria(Criteria.where("id").is(id));
		return mongoTemplate.findOne(query, Person.class, COLLECTION_NAME); // if this was production code, this would throw a PersonNotFoundException if findOne(...) returned null
	}

}

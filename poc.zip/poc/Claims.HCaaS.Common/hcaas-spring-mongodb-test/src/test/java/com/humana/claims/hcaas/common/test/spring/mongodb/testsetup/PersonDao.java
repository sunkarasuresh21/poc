package com.humana.claims.hcaas.common.test.spring.mongodb.testsetup;

/** Example of a Production Code DAO interface to enable unit testing */
public interface PersonDao {

	Person getPerson(String id);

}

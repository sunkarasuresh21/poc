package com.humana.claims.hcaas.common.test.spring.mongodb;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.test.context.ContextConfiguration;

/**
 *  Automatically configure an in-memory MongoDB server that can be used for writing
 *  unit tests for DAOs using Spring Data MongoDB.
 *  <p>
 *  <h4>Usage:</h4> <br/>
 *  Add the following annotations on the test class
 *  <pre>
@SpringBootTest(classes=DaoClassUnderTest.class) // Replace DaoClassUnderTest with actual DAO under test
@ConfigureInMemoryMongoTestServer
 *  </pre>
 *  
 *  <h4>Details</h4>
 *  <ul>
 *  	<li> Uses mongo-java-server library to create in memory mongo database
 *  	<li> Adds {@link com.humana.claims.hcaas.common.test.spring.mongodb.InMemoryMongoTestServerConfiguration InMemoryMongoTestServerConfiguration} 
 *  	to context, which configures and starts the in memory database, and creates the Spring Mongo beans
 *  </ul>
 *
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@ContextConfiguration(classes=InMemoryMongoTestServerConfiguration.class)
public @interface ConfigureInMemoryMongoTestServer {

}

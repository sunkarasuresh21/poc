## Editing Diagrams

To edit diagrams, use draw.io to open the PNG file.  

You can save the edited diagram one of 2 ways:

* If the diagram was opened in draw.io from an existing PNG diagram, just use the save option.  This will automatically save as a PNG that can be edited in draw.io
* If you create a new diagram in draw.io, then export as PNG.  Make sure "Include a copy of my diagram" is enabled - this will allow the PNG to be edited in draw.io

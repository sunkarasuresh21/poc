# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.0.4] - 2022-02-22
### Changed
- Internally use @ConfigurationProperties to inject properties into classes
- Rabbit support has been removed from error handlers
- old error handlers have been removed
- Remove invalid dependency from dependencyManagement section

## [2.0.3] - 2022-02-16
### Updated
- Merged 1.4.1 and 1.4.2 changes in to 2.0.x
- Remove unnecessary version overrides for json-smart, logback, and log4j2

## [2.0.2] - 2022-01-27
### Changed
- Removed Legacy format config code for vault secrets path

## [2.0.1] - 2022-01-21
### Changed
- Spring boot version update to 2.6.2

## [2.0.0] - 2022-01-11
### Important Notes
- Branched from 1.4.0
### Changed
- Refactored module hcaas-data-capture-starter to hcaas-jms-listener-stater
- Refactored properties datacapture.* to jmslistener.*  

## [1.4.2] - 2022-02-16
### Added
- Created ISO_8601_EXTENDED_DATETIME_UTC_FORMAT formatter that can be used for formatting/parsing java.util.Date with ms precision

## [1.4.1] - 2022-02-14
### Added
- Added jacoco profile to hcaas-common-parent, which adds jacoco-maven-plugin to generate code coverage (for each module)
### Fixed
- Remediate dependencies blocked by Xray
  - Force Tomcat to 9.0.58
  - Build plugins: Bump xstream to 1.4.19
  - Build plugin: maven-dependency-plugin and maven-help-plugin (exclude velocity)
  - Build plugin: replacer (force xercesImpl from 2.8.0 to 2.12.2)
### Changed (hcaas-common build)
- Split aggregator module (hcaas-common-build-root) from parent module (hcaas-common-parent) for easier maintainability
- Created code-coverage-merge and modified pipeline to publish merged code coverage to ADO pipeline

## [1.4.0] - 2022-01-10
### Changed
- (Breaking Change) Remove "SpEL Escaping" from VaultPropertiesAutoEnvConfig classes

## [1.3.10] - 2022-01-06
### Fixed
- Force log4j version to 2.17.1

## [1.3.9] - 2021-12-20
### Fixed
- Upgrade Spring Boot to 2.4.13
- Force Logback version to 1.2.9 (CVE-2021-42550)
- Force log4j version to 2.17.0

## [1.3.8] - 2021-12-16
### Added
- Added new data capture error handlers to support retrying messages after delay

## [1.3.7] - 2021-11-30
### Changed
- Refactored functionality to create truststore that merges cacerts and custom-truststore.jks to separate class (no change to functionality)

## [1.3.6] - 2021-11-05
### Fixed
- Return Http 415 Unsupported Media Type status in case of HttpMediaTypeNotSupportedException
- Added new ErrorCode UNSUPPORTED_REQUEST

## [1.3.5] - 2021-10-21
### Added
- Configuration Metadata for all properties used by hcaas-common modules

## [1.3.4] - 2021-10-19
### Fixed
- `*VaultPropertiesAutoEnvConfigTest.vaultToken_not_set_should_not_load_vault_property_source` tests successfully run regardless of environment settings

## [1.3.3] - 2021-10-11
### Update
- /version endpoint date format
- Added timeZone as path variable to display different timeZones. Ex: version?timeZone=America/Chicago (Optional, default is UTC)

## [1.3.2] - 2021-10-05
### Fixed
- /version endpoint UI alignment issues
- Added build number validation.

## [1.3.1] - 2021-10-05
### Updated
- Added Build Number to /version endpoint

## [1.3.0] - 2021-09-28
### Updated
- Added /version endpoint to get build information

## [1.2.4] - 2021-09-17
### Updated
- Added new error code for unauthorized access
  
## [1.2.3] - 2021-09-16
### Updated (Code)
- Fix Sonar issues

## Updated (Build)
- Remove Maven Wrapper
- Move hcaas-common-parent from separate module to root module, replacing hcaas-common-build-root
- Update plugin dependencies to non-vulnerable versions, add depgraph-maven-plugin

## [1.2.2] - 2021-09-01
### Updated
- Refactor JsonMasker to not use classes from Spring ConfigurationProcessor

## [1.2.1] - 2021-08-25
### Updated
- updated property name from vault.path-format to vault.path_format

## [1.2.0] - 2021-08-20
### Added
- Support for using new region-format for vault secrets path (disabled by default)

## [1.1.0] - 2021-08-09
### Updated
- Update Spring Boot version to 2.4.9
- Update version of json-smart to 2.4.1
- Update version of jackson databind nullable dependency to 0.2.1
- Update dependencies used by Maven plugins to non-vulnerable versions

## [1.0.4] - 2021-07-28
### Updated
- Updated build pipeline to use latest HCaaS standards

## [1.0.3] - 2021-07-09
### Added
- Heartbeat Logger
### Changes
- Removed deprecated classes from spring-aop

## [1.0.2] - 2021-07-01
### Changes
- Updated Spring Boot version to 2.4.8

## [1.0.1] - 2021-06-22 
### Fixed
- Removed unused imports
### Added
- Documentation about using maven in CONTRIBUTING.md
- Clearer documentation about Semantic Versioning
- Documentation regarding the SpEL escaping the Vault Auto Config does
- Standard Lombok config
- .vscode/* to .gitignore
### Changed
- Reverted maven wrapper customizations
- Update maven wrapper and maven to the standard across all HCaaS services

## [1.0.0] - 2021-05-21 
### Changed
- hcaas-common-parent - change naming convention to *.openapi.yaml

## [0.9.6] - 2021-05-07
### Changed
- hcaas-common-parent - Update git-commit-id-plugin to 4.0.4

## [0.9.5] - 2021-05-05
### Added
- doc: Added STS/Eclipse option for updating hcaas-common version to CONTRIBUTING.md 

## [0.9.4] - 2021-05-04
### Changed
- hcaas-rest-api-starter library
  - AbstractSpringControllerExceptionHandler - add HttpMessageNotReadableException and modified MethodArgumentNotValidException to handle errors from client API's 

## [0.9.3] - 2021-04-21
### Changed
- hcaas-rest-api-starter library
  - AbstractSpringControllerExceptionHandler - add HttpServerErrorException and HttpClientErrorException to handle errors from client API's 

## [0.9.2] - 2021-04-08
### Changed
- hcaas-rest-api-starter
  - Refactor Contract First Swagger UI
- Build Pipeline
  - Run SecAPI on PR source branch
  - Deploy to Artifactory after GLAPI and SecAPI

## [0.9.1] - 2021-04-06
### Fixed
- hcaas-rest-api-starter
  - Fix Contract First Swagger UI error
- Removed all uses of @SneakyThrows in non-test code

## [0.9.0] - 2021-04-01
### Changed
- hcaas-data-capture-starter (amqp)
	- Add required prefetch property
	- Use CachingConnectionFactory to reuse connections
	- Explicitly set client-acknowledge mode

## [0.8.4] - 2021-03-26
### Fixed
- hcaas-rest-api-starter library
	- AbstractSpringControllerExceptionHandler - fix error if Mongo is not on classpath

## [0.8.3] - 2021-03-19
### Fixed
- doc: Clarified how to change hcaas-common version in CONTRIBUTING.md
- build: Update mvnw download URLs
- build: Update mvnw scripts to prompt for credentials
### Added
- hcaas-rest-api-starter: Add CONFLICT as a REST API Error Code

## [0.8.2] - 2021-03-12
### Changed
- Refactor code in Contract First Swagger UI

## [0.8.1] - 2021-03-11
### Fixed
- Fixed maven deployment
- Fixed check to prevent overwriting versions in Artifactory

## [0.8.0] - 2021-03-05
### Changed
- hcaas-rest-api-starter
  - Created Enum ErrorCode for REST API error response
  - Updated Unit TestCases

## [0.7.1] - 2021-02-18
### Changed
- build
  - Push the sources jar to Artifactory as part of the mvn deploy

## [0.7.0] - 2021-02-15
### Changed
- hcaas-data-capture-parent
  - Replaced datacapture.amqp.host property with datacapture.amqp.uri
  - Replaced datacapture.error.amqp.host property with datacapture.error.amqp.uri
  - Removed datacapture.amqp.idleTimeout and datacapture.error.amqp.idleTimeout properties, since these can be set via the uri properties

## [0.6.0] - 2021-02-01
### Changed
- hcaas-common-parent
  - Update mongodb-crypt managed dependency to 1.1.0, and remove managed JNA dependency
- hcaas-data-capture-starter
  - Removed Timer creation from BaseDataCaptureListenerConnectionConfig
  - Created TimedAutoConfig to enable @Timed annotations and init messages.processed Timer
  - Created AmqpDataCaptureErrorHandler, and modifiy BaseDataCaptureListenerConnectionConfig to use
  - Created ListenerConfigCheck to warn if a potential data capture module misconfiguration is detected

## [0.5.0] - 2020-12-30
### Added
- Created hcaas-data-capture-starter module
  - Added BaseDataCaptureListenerConnectionConfig (and supporting classes), which can be used to create common data capture beans:
    - {listenerName}ListenerContainerFactory
    - {listenerName}QueueName
    - {listenerName}DataCaptureErrorHandler
    - {listenerName}Timer
  - Added auto configuration classes DisableRabbitMqAutoConfiguration and JmsListenerErrorHandlerAutoConfig

## [0.4.5] - 2020-12-23
### Added
- Mongo DB Service Unavialable Response
  - When Mongo DB is down, an ExceptionHandler was added to return 503-ServiceUnvialable response to consumer of the API.
- Add REST API Exception Handler for Constraint Violation Exception (occurs when request parameters are not valid pattern)

## [0.4.4] - 2020-12-10
### Changed
Mongo DB Connection
-  Explicitly specify UUID representation as v4 via uuidRepresentation property of MongoClientSettings for all Mongo Connections. 

## [0.4.3] - 2020-12-09
### Changed
Mongo DB Client Side Field Level Encryption
- mongodb-crypt pulls in JNA 4.5.2 which has a vulnerability as a solution change was done to override the JNA jar version from 4.5.2 to 5.0.0.

## [0.4.2] - 2020-12-08
### Updated
- Clarified documentation to enable Mongo DB auto config (no actual functionality changes)

## [0.4.1] - 2020-11-24
### Changed
Mongo DB Client Side Field Level Encryption
- Explictily specifying UUID representation to be used via the uuidRepresentation property of MongoClientSettings

## [0.4.0] - 2020-11-16
### Changed
- Upgraded Spring Boot to 2.3.6
- Create managed dependency for Spring Boot IBM MQ starter 2.3.5 

## [0.3.5] - 2020-10-22
### Added
Mongo DB Client Side Field Level Encryption.
- Added below 4 classes in hcaas-spring-boot-starter to handle Field Level Encryption, classes are loaded via Spring factories.
1.MongoDBFLEAutoConfig - Creates MongoDB ClientEncryption Object which can be used to create data encryption keys, and to explicitly encrypt and decrypt values.
2.MongoDBFLEAutoKeyIntializer -
	    - If EncryptionKey exists in Data-Encryption-Key DB Loads EncryptionKey from DB 
	    - Else If EncryptionKey doesnt exists in Data-Encryption-Key DB, creates EncryptionKey
	    - Configures MongoDBFieldEncryptor bean.
3.MongoDBFieldEncryptor -
		-This class holds ClientEncryption object and Encryption key. 
		-Contains 2 public methods
			*encrypt -- Encrypts data using ClientEncryption object and Encryption key. 
			*decrypt -- Decrypts data using ClientEncryption object. 
4.MongoDBConfigUtil -- Supplies ConnectionString Object to connect to Mongo DB.

## [0.3.4] - 2020-10-07
### Security
- Fixed vulnerabilities found in Checkmarx in spring-aop and MongoDBAutoConfig

## [0.3.3] - 2020-10-02
### Changed
- Separate hcaas-common-parent as a separate module from the root POM
- Build pipeline deploys unmodified POMs

## [0.3.2] - 2020-10-01
### Fixed
- ContractFirstSwaggerUi not working when not running in IDE

## [0.3.1] - 2020-09-25
### Fixed
- Dependency Management for hcaas-openapi-generator-starter to type pom
### Changed
- ContractFirstSwaggerUI added redirects for "/swagger" and "/" paths

## [0.3.0] - 2020-09-24
### Added
- hcaas-rest-api-starter library
	- common dependencies for rest-api modules
	- JacksonAutoConfig (autoconfigure JsonNullable support in ObjectMapper)
	- ContractFirstSwaggerUi (autoconfigure SwaggerUI built from OpenAPI specs)
	- AbstractSpringControllerExceptionHandler (supports exception handling for Spring generated exception, and builds common error response)
- hcaas-openapi-generator-starter library
	- common dependencies for openapi-generator modules
- hcaas-utils library
	- Data Masking utils
	- Logging utils
### Changed
- Modified how trust store and vault are configured
	- @DependsOn no longer required to ensure Vault properties have been loaded
- Bump Spring Vault Core to 2.2.2
- Rename Logabble to Loggable
- Disable SpEL on all Vault properties (escape $ and # to prevent SpEL execution)
- Moved StringUtils and MainframeDateUtils to hcaas-utils library

## [0.2.7] - 2020-07-24
### Added
- hcaas-spring-mongodb-test module - for testing Spring MongoDB DAOs

## [0.2.6] - 2020-07-17
### Added
- LoggingFormatEnvConfig - to automatically set HCaaS standard logging format

## [0.2.5] - 2020-06-22
### Added
- (MainframeDateUtils) Add function to convert between Mainframe date-only and Instant

## [0.2.4] - 2020-06-22
### Changed
- - MongoDBAutoConfig has been changed to include @EnableTransactionManagement and to register MongoTransactionManager

## [0.2.2] - 2020-06-17
### Added
- MainframeDateUtils
- HcaasStringUtils

## [0.2.1] - 2020-05-29
### Changed
- Spring AOP module for logging
		1. Interceptor bean loading via Spring factories
		2. Interceptor registration with Spring MVC framework

## [0.2.0] - 2020-05-27
### Added
- Spring AOP module to add logging functionality

### Changed
- Update Spring Boot version to 2.2.7 (from 2.2.5)

### Fixed
- Fix error logged from git-commit-id-plugin in ADO build pipeline
- (HcaasSpringBootApplication.run) Fix NoSuchBeanDefinitionException when health actuator endpoint not enabled

## [0.1.0] - 2020-04-20
### Added
- MongoDBAutoConfig
- VaultPropertiesAutoConfig
- TrustStoreAutoConfig
- HcaasSpringBootApplication
- Created hcaas-spring-boot-starter project
- Created hcaas-common-parent project

package com.humana.claims.hcaas.common.rest.api.starter.exceptionhandling.testutils;

import java.util.UUID;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;

public class UUIDMatcher extends TypeSafeMatcher<String> {

	@Override
	    protected boolean matchesSafely(String s) {
	    	try {
	    		UUID.fromString(s);
	    		return true;
	    	} catch (IllegalArgumentException e) {
	    		return false;
	    	}
	    }

	    @Override
	    public void describeTo(Description description) {
	        description.appendText("a string matching the pattern of a UUID");
	    }

	    public static Matcher<String> isUuid() {
	        return new UUIDMatcher();
	    }

	}

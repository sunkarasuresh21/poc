package com.humana.claims.hcaas.common.rest.api.starter.autoconfig;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.InputStream;
import java.io.InputStreamReader;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.web.servlet.MockMvc;

import lombok.SneakyThrows;

class ContractFirstSwaggerUiTest {

	@Configuration
	@EnableAutoConfiguration
	@AutoConfigureMockMvc
	static class AppConfig{ }
	
	private ConfigurableApplicationContext context;
	
	@AfterEach
	public void tearDown() {
		context.close();
	}
	
	@Test
	void when_swaggerui_enabled_swagger_ui_html_should_redirect_to_swagger_ui() throws Exception {
		context = SpringApplication.run(AppConfig.class, "--swaggerui.enabled=true");
		
		context.getBean(MockMvc.class)
			.perform(get("/swagger-ui.html"))
			.andExpect(status().is3xxRedirection())
			.andExpect(header().string("location", containsString("/swagger-ui/index.html")));
	}

	@Test
	void when_swaggerui_enabled_swagger_should_redirect_to_swagger_ui() throws Exception {
		context = SpringApplication.run(AppConfig.class, "--swaggerui.enabled=true");
		
		context.getBean(MockMvc.class)
			.perform(get("/swagger"))
			.andExpect(status().is3xxRedirection())
			.andExpect(header().string("location", containsString("/swagger-ui/index.html")));
	}

	@Test
	void default_root_path_should_should_redirect_to_swagger_ui() throws Exception {
		context = SpringApplication.run(AppConfig.class, "--swaggerui.enabled=true");
		
		context.getBean(MockMvc.class)
			.perform(get("/"))
			.andExpect(status().is3xxRedirection())
			.andExpect(header().string("location", containsString("/swagger-ui/index.html")));
	}

	@Test
	void default_root_path_should_should_not_redirect_to_swagger_ui_if_feature_disabled() throws Exception {
		context = SpringApplication.run(AppConfig.class, "--swaggerui.enabled=true", "--swaggerui.root-redirect.enabled=false");
		
		context.getBean(MockMvc.class)
			.perform(get("/"))
			.andExpect(status().isNotFound());
	}

	@Test
    void when_swaggerui_enabled_swagger_ui_should_be_accessible() throws Exception {
		context = SpringApplication.run(AppConfig.class, "--swaggerui.enabled=true");
		
		context.getBean(MockMvc.class)
			.perform(get("/swagger-ui/index.html"))
			.andExpect(status().isOk());
	}

	@Test
	void when_swaggerui_enabled_swagger_config_should_be_accessible() throws Exception {
		context = SpringApplication.run(AppConfig.class, "--swaggerui.enabled=true");
		
		context.getBean(MockMvc.class)
			.perform(get("/v3/api-docs/swagger-config"))
			.andExpect(status().isOk());
	}

	@Test
	void when_swaggerui_enabled_openapi_spec_should_be_downloadable() throws Exception {
		context = SpringApplication.run(AppConfig.class, "--swaggerui.enabled=true");
		
		context.getBean(MockMvc.class)
			.perform(get("/v3/api-docs/Sample-v1"))
			.andExpect(status().isOk())
			.andExpect(content().contentTypeCompatibleWith("text/yaml"));
	}
	
	@Test
	void when_swaggerui_enabled_openapi_spec_content_should_match_spec() throws Exception {
		String expectedContent = readFileToString("spec/Sample-v1.openapi.yaml");

		context = SpringApplication.run(AppConfig.class, "--swaggerui.enabled=true");
		
		context.getBean(MockMvc.class)
			.perform(get("/v3/api-docs/Sample-v1"))
			.andExpect(status().isOk())
			.andExpect(content().string(expectedContent));
	}

	@Test
	void when_swaggerui_enabled_invalid_openapi_spec_should_return_client_error() throws Exception {
		context = SpringApplication.run(AppConfig.class, "--swaggerui.enabled=true");
		
		context.getBean(MockMvc.class)
			.perform(get("/v3/api-docs/Does-Not-Exist"))
			.andExpect(status().is4xxClientError());
	}

	@Test
	void by_default_swagger_ui_html_should_not_work() throws Exception {
		context = SpringApplication.run(AppConfig.class);
		
		context.getBean(MockMvc.class)
			.perform(get("/swagger-ui.html"))
			.andExpect(status().is4xxClientError());

		context.getBean(MockMvc.class)
			.perform(get("/"))
			.andExpect(status().is4xxClientError());

	}

	@Test
	void by_default_openapi_spec_should_not_be_downloadable() throws Exception {
		context = SpringApplication.run(AppConfig.class);
		
		context.getBean(MockMvc.class)
			.perform(get("/v3/api-docs/Sample-v1"))
			.andExpect(status().is4xxClientError());
	}
	
	
	@SneakyThrows
	private String readFileToString(String filepath) {
		StringBuilder strBuilder = new StringBuilder();

		try (InputStreamReader reader = new InputStreamReader(getResourceAsStream(filepath), UTF_8)) {
			char[] buf = new char[1024];
			int charsRead;
			while ((charsRead = reader.read(buf)) >= 0) {
				strBuilder.append(buf, 0, charsRead);
			}
		}
		return strBuilder.toString();
	}
	
	private InputStream getResourceAsStream(String filepath) {
		return this.getClass().getClassLoader().getResourceAsStream(filepath);
	}
	
}

package com.humana.claims.hcaas.common.rest.api.starter.autoconfig;

import static org.hamcrest.Matchers.matchesRegex;
import static org.hamcrest.Matchers.not;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.web.servlet.MockMvc;

import com.humana.claims.hcaas.common.rest.api.starter.testsetup.SampleRestController;

class JacksonAutoConfigTest {

	@Configuration
	@EnableAutoConfiguration
	@ComponentScan(basePackageClasses = SampleRestController.class)
	@AutoConfigureMockMvc
	static class AppConfig { }
	
	private MockMvc mockMvc;
	private ConfigurableApplicationContext context;
	
	@BeforeEach
	public void setup() {
		context = SpringApplication.run(AppConfig.class);
		mockMvc = context.getBean(MockMvc.class);
	}
	
	@AfterEach
	public void tearDown() {
		context.close();
	}
	
	@Test
	void nullable_property_is_undefined_should_not_be_included_in_response() throws Exception {
		String json = doublifySingleQuotes("{'reqd-field':''}");
		String expectedUnmatchedRegex = "nullable-field";

		mockMvc.perform(
				 post("/reflector")
				.contentType(APPLICATION_JSON)
				.content(json))
			.andExpect(status().isOk())
			.andExpect(content().string(not(matchesRegex(expectedUnmatchedRegex))));
	}
	
	@Test
	void nullable_property_is_null_should_be_null() throws Exception {
		String json = doublifySingleQuotes("{'reqd-field':'', 'nullable-field': null}");
		String expectedJsonSnippet = doublifySingleQuotes("{'nullable-field': null}");

		mockMvc.perform(
				 post("/reflector")
				.contentType(APPLICATION_JSON)
				.content(json))
			.andExpect(status().isOk())
			.andExpect(content().json(expectedJsonSnippet));
	}

	private String doublifySingleQuotes(String orig) {
		return orig.replace("'","\"");
	}
	
}

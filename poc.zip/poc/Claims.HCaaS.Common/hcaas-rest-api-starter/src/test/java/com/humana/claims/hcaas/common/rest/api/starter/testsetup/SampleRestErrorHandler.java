package com.humana.claims.hcaas.common.rest.api.starter.testsetup;

import org.springframework.web.bind.annotation.ControllerAdvice;

import com.humana.claims.hcaas.common.rest.api.starter.exceptionhandling.AbstractSpringControllerExceptionHandler;

@ControllerAdvice(assignableTypes = SampleRestController.class)
public class SampleRestErrorHandler extends AbstractSpringControllerExceptionHandler {

}

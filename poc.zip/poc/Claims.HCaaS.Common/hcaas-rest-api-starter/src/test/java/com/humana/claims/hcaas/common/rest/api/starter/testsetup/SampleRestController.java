package com.humana.claims.hcaas.common.rest.api.starter.testsetup;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Pattern;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import com.mongodb.MongoTimeoutException;

@Validated
@RestController
public class SampleRestController {

	@PostMapping("/reflector")
	public ResponseEntity<ResponseObjectDTO> reflector(@Valid @RequestBody ResponseObjectDTO reqbody) {
		return ResponseEntity.ok(reqbody);
	}

	@GetMapping("/users/{id}")
	public ResponseEntity<String> getUsers(@Valid @Max(100) @PathVariable(value = "id") Integer id) {
		return ResponseEntity.ok("Fred");
	}

	@GetMapping("/reqd-header")
	public ResponseEntity<String> getUsers(@RequestHeader("X-Secret-Header") String headerValue) {
		return ResponseEntity.ok("Fred");
	}
	
	@GetMapping("/hex-query-param")
	public ResponseEntity<String> hexQueryParam(@Pattern(regexp="^[A-Fa-f0-9]*$") @Valid @RequestParam(value = "hexValue", required = false) String hexValue) {
		return ResponseEntity.ok("Fred");
	}

	@GetMapping("/unsupported")
	public ResponseEntity<String> unsupported() {
		throw new UnsupportedOperationException("barf");
	}
	
	@GetMapping("/simulateMongoTimeoutEx")
	public ResponseEntity<String> simulateMongoTimeoutEx() {
		throw new MongoTimeoutException("Connection Lost");
	}
	
	@GetMapping("/ServerErrorException503")
	public ResponseEntity<String> simulateServerErrorException503() {
		throw new HttpServerErrorException(HttpStatus.SERVICE_UNAVAILABLE);
	}
	
	@GetMapping("/ServerErrorException500")
	public ResponseEntity<String> simulateServerErrorException500() {
		throw new HttpServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@GetMapping("/clienterrorException")
	public ResponseEntity<String> simulateClientErrorException401() {
		throw new HttpClientErrorException(HttpStatus.BAD_REQUEST);
	}
}

package com.humana.claims.hcaas.common.rest.api.starter.exceptionhandling;

import static com.humana.claims.hcaas.common.rest.api.starter.exceptionhandling.testutils.Iso8601DateTimeMatcher.isValidIso8601DateTime;
import static com.humana.claims.hcaas.common.rest.api.starter.exceptionhandling.testutils.UUIDMatcher.isUuid;
import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsStringIgnoringCase;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.http.MediaType.APPLICATION_PDF;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.ThrowingConsumer;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.runner.WebApplicationContextRunner;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.web.servlet.MockMvc;

import com.humana.claims.hcaas.common.rest.api.starter.enumerrorcode.ErrorCode;
import com.humana.claims.hcaas.common.rest.api.starter.testsetup.SampleRestController;

class AbstractSpringControllerExceptionHandlerTest {

	@Configuration
	@EnableAutoConfiguration
	@ComponentScan(basePackageClasses = SampleRestController.class)
	@AutoConfigureMockMvc
	static class AppConfig { }
	
	public void runContext(ThrowingConsumer<MockMvc> mockMvcConsumer) {
		runContextWithClassLoader(null, mockMvcConsumer);
	}
	
	public void runContextWithClassLoader(ClassLoader classLoader, ThrowingConsumer<MockMvc> mockMvcConsumer) {
		new WebApplicationContextRunner()
			.withClassLoader(classLoader)
			.withUserConfiguration(AppConfig.class)
			.run(ctx -> mockMvcConsumer.accept(ctx.getBean(MockMvc.class)));
	}

	@Test
	void missing_request_body_should_return_standard_error_message() {
		runContext(mockMvc -> 
			mockMvc.perform(
				 post("/reflector"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.errorId", isUuid()))
				.andExpect(jsonPath("$.timestamp", isValidIso8601DateTime()))
				.andExpect(jsonPath("$.status", is(equalTo(400))))
				.andExpect(jsonPath("$.error", is(equalTo("Bad Request"))))
				.andExpect(jsonPath("$.errorCode", is(equalTo(ErrorCode.BAD_REQUEST.toString()))))
				.andExpect(jsonPath("$.details", contains(containsStringIgnoringCase("Required request body is missing"))))
			
		);
	}

	@Test
	void method_argument_type_mismatch_should_return_standard_error_message() {
		runContext(mockMvc -> 
			mockMvc.perform(
				 get("/users/NOT_AN_INT"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.errorId", isUuid()))
				.andExpect(jsonPath("$.timestamp", isValidIso8601DateTime()))
				.andExpect(jsonPath("$.status", is(equalTo(400))))
				.andExpect(jsonPath("$.error", is(equalTo("Bad Request"))))
				.andExpect(jsonPath("$.errorCode", is(equalTo(ErrorCode.BAD_REQUEST.toString()))))
				.andExpect(jsonPath("$.details", contains(containsStringIgnoringCase("invalid"))))
		);
	}

	@Test
	void method_argument_not_valid_should_return_standard_error_message() {
		runContext(mockMvc -> 
			mockMvc.perform(
				 post("/reflector").contentType(APPLICATION_JSON).content("{}"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.errorId", isUuid()))
				.andExpect(jsonPath("$.timestamp", isValidIso8601DateTime()))
				.andExpect(jsonPath("$.status", is(equalTo(400))))
				.andExpect(jsonPath("$.error", is(equalTo("Bad Request"))))
				.andExpect(jsonPath("$.errorCode", is(equalTo(ErrorCode.BAD_REQUEST.toString()))))
				.andExpect(jsonPath("$.details", contains(containsStringIgnoringCase("invalid"))))
		);
	}
	
	@Test
	void invalid_enum_field_cause_value_instatiation_exception() {
		runContext(mockMvc -> mockMvc
				.perform(post("/reflector").contentType(APPLICATION_JSON)
						.content(doublifySingleQuotes("{ 'reqd-field':' ','opt-field':'optField', 'opt-enum-field':' '}")))
				.andExpect(status().isBadRequest()).andExpect(jsonPath("$.errorId", isUuid()))
				.andExpect(jsonPath("$.timestamp", isValidIso8601DateTime()))
				.andExpect(jsonPath("$.status", is(equalTo(400))))
				.andExpect(jsonPath("$.error", is(equalTo("Bad Request"))))
				.andExpect(jsonPath("$.errorCode", is(equalTo(ErrorCode.BAD_REQUEST.toString()))))
				.andExpect(jsonPath("$.details", contains(containsStringIgnoringCase("Unexpected value ' ' for ResponseObjectDTO.opt-enum-field")))));
	}

	@Test
	void missing_path_param_should_return_standard_error_message() {
		runContext(mockMvc -> 
			mockMvc.perform(
				 post("/reflector").contentType(APPLICATION_JSON).content("{"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.errorId", isUuid()))
				.andExpect(jsonPath("$.timestamp", isValidIso8601DateTime()))
				.andExpect(jsonPath("$.status", is(equalTo(400))))
				.andExpect(jsonPath("$.error", is(equalTo("Bad Request"))))
				.andExpect(jsonPath("$.errorCode", is(equalTo(ErrorCode.BAD_REQUEST.toString()))))
				.andExpect(jsonPath("$.details", contains(containsStringIgnoringCase("JSON Parse Error at line 1 column 2:"))))
		);
	}

	@Test
	void missing_reqd_header_should_return_standard_error_message() {
		runContext(mockMvc -> 
			mockMvc.perform(
				 get("/reqd-header"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.errorId", isUuid()))
				.andExpect(jsonPath("$.timestamp", isValidIso8601DateTime()))
				.andExpect(jsonPath("$.status", is(equalTo(400))))
				.andExpect(jsonPath("$.error", is(equalTo("Bad Request"))))
				.andExpect(jsonPath("$.errorCode", is(equalTo(ErrorCode.BAD_REQUEST.toString()))))
				.andExpect(jsonPath("$.details", contains(containsStringIgnoringCase("header"))))
		);
	}

	@Test
	void unsupported_media_type_should_return_standard_error_message() {
		runContext(mockMvc -> 
			mockMvc.perform(
				 post("/reflector").contentType(APPLICATION_PDF).content("{}"))
				.andExpect(status().isUnsupportedMediaType())
				.andExpect(jsonPath("$.errorId", isUuid()))
				.andExpect(jsonPath("$.timestamp", isValidIso8601DateTime()))
				.andExpect(jsonPath("$.status", is(equalTo(415))))
				.andExpect(jsonPath("$.error", is(equalTo("Unsupported Media Type"))))
				.andExpect(jsonPath("$.errorCode", is(equalTo(ErrorCode.UNSUPPORTED_REQUEST.toString()))))
				.andExpect(jsonPath("$.details", contains(containsStringIgnoringCase("not supported"))))
		);
	}
	
	@Test
	void server_error_exception_should_return_service_unavailable_error_message() {
		runContext(mockMvc -> 
			mockMvc.perform(
				 get("/ServerErrorException503"))
				.andExpect(status().isServiceUnavailable())
				.andExpect(jsonPath("$.errorId", isUuid()))
				.andExpect(jsonPath("$.timestamp", isValidIso8601DateTime()))
				.andExpect(jsonPath("$.status", is(equalTo(503))))
				.andExpect(jsonPath("$.errorCode", is(equalTo(ErrorCode.SERVICE_UNAVAILABLE.toString()))))
		);
	}
	
	@Test
	void server_error_exception_should_return_Internal_server_error_message() {
		runContext(mockMvc -> 
			mockMvc.perform(
				 get("/ServerErrorException500"))
				.andExpect(status().isInternalServerError())
				.andExpect(jsonPath("$.errorId", isUuid()))
				.andExpect(jsonPath("$.timestamp", isValidIso8601DateTime()))
				.andExpect(jsonPath("$.status", is(equalTo(500))))
				.andExpect(jsonPath("$.errorCode", is(equalTo(ErrorCode.INTERNAL_ERROR.toString()))))
		);
	}
	
	
	@Test
	void client_error_exception_should_return_internal_server_error_message() {
		runContext(mockMvc -> 
			mockMvc.perform(
				 get("/clienterrorException"))
				.andExpect(status().isInternalServerError())
				.andExpect(jsonPath("$.errorId", isUuid()))
				.andExpect(jsonPath("$.timestamp", isValidIso8601DateTime()))
				.andExpect(jsonPath("$.status", is(equalTo(500))))
				.andExpect(jsonPath("$.errorCode", is(equalTo(ErrorCode.INTERNAL_ERROR.toString()))))
		);
	}


	@Test
	void invalid_format_should_return_standard_error_message() {
		runContext(mockMvc -> 
			mockMvc.perform(
				 post("/reflector").contentType(APPLICATION_JSON).content(doublifySingleQuotes(
						 "{ 'reqd-field':'', 'nullable-date-time': 'not-a-date'}")))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.errorId", isUuid()))
				.andExpect(jsonPath("$.timestamp", isValidIso8601DateTime()))
				.andExpect(jsonPath("$.status", is(equalTo(400))))
				.andExpect(jsonPath("$.error", is(equalTo("Bad Request"))))
				.andExpect(jsonPath("$.errorCode", is(equalTo(ErrorCode.BAD_REQUEST.toString()))))
				.andExpect(jsonPath("$.details", contains(equalTo("Value 'not-a-date' for nullable-date-time is invalid for type string(date-time)"))))
		);
	}

	@Test
	void constraint_violation_exception_should_return_standard_error_message() {
		runContext(mockMvc -> 
			mockMvc.perform(
				 get("/hex-query-param?hexValue=ZZZZ"))
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.errorId", isUuid()))
				.andExpect(jsonPath("$.timestamp", isValidIso8601DateTime()))
				.andExpect(jsonPath("$.status", is(equalTo(400))))
				.andExpect(jsonPath("$.error", is(equalTo("Bad Request"))))
				.andExpect(jsonPath("$.errorCode", is(equalTo(ErrorCode.BAD_REQUEST.toString()))))
				.andExpect(jsonPath("$.details", contains(containsStringIgnoringCase("must match"))))
		);
	}

	@Test
	void unexpected_exception_should_return_standard_error_message_with_status_code_500_and_no_details() {
		runContext(mockMvc -> 
			mockMvc.perform(
				 get("/unsupported"))
				.andExpect(status().isInternalServerError())
				.andExpect(jsonPath("$.errorId", isUuid()))
				.andExpect(jsonPath("$.timestamp", isValidIso8601DateTime()))
				.andExpect(jsonPath("$.status", is(equalTo(500))))
				.andExpect(jsonPath("$.error", is(equalTo("Internal Server Error"))))
				.andExpect(jsonPath("$.errorCode", is(equalTo(ErrorCode.INTERNAL_ERROR.toString()))))
				.andExpect(content().string(not(containsStringIgnoringCase("details"))))
		);
	}

	@Test
	void MongoTimeoutException_should_return_standard_error_message_with_status_code_503_and_no_details() {
		runContext(mockMvc -> 
			mockMvc.perform(
				 get("/simulateMongoTimeoutEx"))
				.andExpect(status().isServiceUnavailable())
				.andExpect(jsonPath("$.errorId", isUuid()))
				.andExpect(jsonPath("$.timestamp", isValidIso8601DateTime()))
				.andExpect(jsonPath("$.status", is(equalTo(503))))
				.andExpect(jsonPath("$.error", is(equalTo("Service Unavailable"))))
				.andExpect(jsonPath("$.errorCode", is(equalTo(ErrorCode.SERVICE_UNAVAILABLE.toString()))))
				
				.andExpect(jsonPath("$.details", contains(containsStringIgnoringCase("Service Not Available"))))
		);
	}

// Test not properly testing MongoTimeoutException not on ClassPath
//	@Test
//	public void MongoTimeoutException_not_on_classpath_should_not_cause_any_issues() {
//		runContextWithClassLoader(
//			new FilteredClassLoader(MongoTimeoutException.class),
//			mockMvc -> mockMvc.perform(
//				 get("/unsupported"))
//				.andExpect(status().is(500))
//		);
//	}

	private String doublifySingleQuotes(String orig) {
		return orig.replace("'","\"");
	}

	
}

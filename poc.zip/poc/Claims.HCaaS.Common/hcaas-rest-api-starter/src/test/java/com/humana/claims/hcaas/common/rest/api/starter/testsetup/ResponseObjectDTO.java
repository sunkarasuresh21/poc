package com.humana.claims.hcaas.common.rest.api.starter.testsetup;

import java.time.OffsetDateTime;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/* Example open-api generated Model object */

@SuppressWarnings("all")
public class ResponseObjectDTO {
	@JsonProperty("reqd-field")
	private String reqdField;

	@JsonProperty("opt-field")
	private String optField;

	@JsonProperty("nullable-field")
	private JsonNullable<String> nullableField = JsonNullable.undefined();

	@JsonProperty("reqd-nullable-field")
	private JsonNullable<String> reqdNullableField = JsonNullable.undefined();

	@JsonProperty("nullable-date-time")
	private JsonNullable<OffsetDateTime> nullableDateTime = JsonNullable.undefined();

	public enum OptEnumField {
		D("D"),

		H("H");

		private String value;

		OptEnumField(String value) {
			this.value = value;
		}

		@Override
		@JsonValue
		public String toString() {
			return String.valueOf(value);
		}

		@JsonCreator
		public static OptEnumField fromValue(String value) {
			for (OptEnumField b : OptEnumField.values()) {
				if (b.value.equals(value)) {
					return b;
				}
			}
			throw new IllegalArgumentException("Unexpected value '" + value + "'");
		}
	}

	@JsonProperty("opt-enum-field")
	private OptEnumField optEnumField;

	public ResponseObjectDTO optEnumField(OptEnumField optEnumField) {
		this.optEnumField = optEnumField;
		return this;
	}

	/**
	 * Get optEnumField
	 * 
	 * @return optEnumField
	 */
	
	public OptEnumField getOptEnumField() {
		return optEnumField;
	}

	public void setOptEnumField(OptEnumField optEnumField) {
		this.optEnumField = optEnumField;
	}

	public ResponseObjectDTO reqdField(String reqdField) {
		this.reqdField = reqdField;
		return this;
	}

	/**
	 * Get reqdField
	 * 
	 * @return reqdField
	 */
	@NotNull

	public String getReqdField() {
		return reqdField;
	}

	public void setReqdField(String reqdField) {
		this.reqdField = reqdField;
	}

	public ResponseObjectDTO optField(String optField) {
		this.optField = optField;
		return this;
	}

	/**
	 * Get optField
	 * 
	 * @return optField
	 */

	public String getOptField() {
		return optField;
	}

	public void setOptField(String optField) {
		this.optField = optField;
	}

	public ResponseObjectDTO nullableField(String nullableField) {
		this.nullableField = JsonNullable.of(nullableField);
		return this;
	}

	/**
	 * Get nullableField
	 * 
	 * @return nullableField
	 */

	public JsonNullable<String> getNullableField() {
		return nullableField;
	}

	public void setNullableField(JsonNullable<String> nullableField) {
		this.nullableField = nullableField;
	}

	public ResponseObjectDTO reqdNullableField(String reqdNullableField) {
		this.reqdNullableField = JsonNullable.of(reqdNullableField);
		return this;
	}

	/**
	 * Get reqdNullableField
	 * 
	 * @return reqdNullableField
	 */
	@NotNull

	public JsonNullable<String> getReqdNullableField() {
		return reqdNullableField;
	}

	public void setReqdNullableField(JsonNullable<String> reqdNullableField) {
		this.reqdNullableField = reqdNullableField;
	}

	public ResponseObjectDTO nullableDateTime(OffsetDateTime nullableDateTime) {
		this.nullableDateTime = JsonNullable.of(nullableDateTime);
		return this;
	}

	/**
	 * Get nullableField
	 * 
	 * @return nullableField
	 */

	public JsonNullable<OffsetDateTime> getNullableDateTime() {
		return nullableDateTime;
	}

	public void setNullableDateTime(JsonNullable<OffsetDateTime> nullableDateTime) {
		this.nullableDateTime = nullableDateTime;
	}

	@Override
	public boolean equals(java.lang.Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		ResponseObjectDTO testObject = (ResponseObjectDTO) o;
		return Objects.equals(this.reqdField, testObject.reqdField)
				&& Objects.equals(this.optField, testObject.optField)
				&& Objects.equals(this.nullableField, testObject.nullableField)
				&& Objects.equals(this.reqdNullableField, testObject.reqdNullableField);
	}

	@Override
	public int hashCode() {
		return Objects.hash(reqdField, optField, nullableField, reqdNullableField);
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("class TestObjectDTO {\n");

		sb.append("    reqdField: ").append(toIndentedString(reqdField)).append("\n");
		sb.append("    optField: ").append(toIndentedString(optField)).append("\n");
		sb.append("    nullableField: ").append(toIndentedString(nullableField)).append("\n");
		sb.append("    reqdNullableField: ").append(toIndentedString(reqdNullableField)).append("\n");
		sb.append("}");
		return sb.toString();
	}

	/**
	 * Convert the given object to string with each line indented by 4 spaces
	 * (except the first line).
	 */
	private String toIndentedString(java.lang.Object o) {
		if (o == null) {
			return "null";
		}
		return o.toString().replace("\n", "\n    ");
	}
}

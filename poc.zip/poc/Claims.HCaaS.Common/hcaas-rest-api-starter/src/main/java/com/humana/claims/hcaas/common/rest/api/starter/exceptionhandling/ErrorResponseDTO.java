package com.humana.claims.hcaas.common.rest.api.starter.exceptionhandling;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.humana.claims.hcaas.common.rest.api.starter.enumerrorcode.ErrorCode;

import lombok.Builder;
import lombok.Getter;

/**
 * Standard HCaaS Response body that corresponds to the following OpenAPI spec snippet.  Use this schema in
 * the OpenAPI spec
<pre>
components:
  schemas:
    ErrorResponse:
      type: object
      required:
        - timestamp
        - status
      properties:
        errorId:
          type: string
          format: uuid
        timestamp:
          type: string
          format: date-time
        status:
          type: integer
        error:
          type: string
        errorCode:
          type: string
          enum:
            - BAD_REQUEST
            - NOT_FOUND
            - CONFLICT
            - UNAUTHORIZED_ACCESS
            - INTERNAL_ERROR
            - SERVICE_UNAVAILABLE
        details:
          type: array
          nullable: true
          items:
            type: string
  examples:
    Example-400-Error-Response:
      value:
        {
          "errorId": "6dd0e0a1-e804-4993-8647-c566a3dcc675",
          "timestamp": "2020-02-03T15:45:01.285+0000",
          "status": 400,
          "error": "Bad Request",
          "errorCode": "BAD_REQUEST",
          "details": [
              "Value 'abcdefghijklmnop' for Example.alias is invalid: size must be between 0 and 10"
          ]
        }
    Example-401-Error-Response:
      value:
        {
          "errorId": "cf398af4-593e-4472-8441-50754f68172c",
          "timestamp": "2021-09-17T10:44:46.555-04:00",
          "status": 401,
          "error": "Unauthorized",
          "errorCode": "UNAUTHORIZED_ACCESS",
          "details": [
              "Unauthorized Access: Invalid Client Certificate"
          ]
        }
    Example-500-Error-Response:
      value:
        {
          "errorId": "6dd0e0a1-e804-4993-8647-c566a3dcc675",
          "timestamp": "2020-02-03T15:45:01.285+0000",
          "status": 500,
          "error": "Internal Server Error",
          "errorCode": "INTRNAL_ERROR"
        }    
</pre>
 */

@Getter
@Builder
@JsonInclude(JsonInclude.Include.ALWAYS)
public class ErrorResponseDTO {

	@JsonProperty("errorId")
	private UUID errorId;

	@JsonProperty("timestamp")
	private OffsetDateTime timestamp;

	@JsonProperty("status")
	private Integer status;

	@JsonProperty("error")
	private String error;

	@JsonProperty("errorCode")
	private ErrorCode errorCode;

	@JsonProperty("details")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<String> details;

}

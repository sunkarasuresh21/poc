package com.humana.claims.hcaas.common.rest.api.starter.autoconfig;


import org.openapitools.jackson.nullable.JsonNullableModule;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configures REST API modules Jackson Object Mapper for JsonNullable support  
 */
@ConditionalOnClass(JsonNullableModule.class)
@Configuration
public class JacksonAutoConfig {

	/* References:
	 *   https://docs.spring.io/spring-boot/docs/current/reference/html/howto.html#howto-customize-the-jackson-objectmapper
	 *   https://github.com/OpenAPITools/jackson-databind-nullable
	 */
	@Bean
	public Jackson2ObjectMapperBuilderCustomizer registerJsonNullableModule() {
		return objMapperBuilder -> objMapperBuilder
				.modulesToInstall(new JsonNullableModule());
	}
	
}

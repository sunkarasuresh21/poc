package com.humana.claims.hcaas.common.rest.api.starter.exceptionhandling;

import static java.text.MessageFormat.format;
import static java.util.stream.Collectors.toList;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolationException;
import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonMappingException.Reference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.fasterxml.jackson.databind.exc.ValueInstantiationException;
import com.humana.claims.hcaas.common.rest.api.starter.enumerrorcode.ErrorCode;
import com.mongodb.MongoTimeoutException;

import lombok.NoArgsConstructor;

/**
 * Standard HCaaS RestController Exception Handler for Spring Exceptions as well as a catchall ExceptionHandler.
 *
 * Extracts relevant details and returns an ErrorResponseDTO.  See ErrorResponseDTO for
 * the OpenAPI spec schema of ErrorResponseDTO.
 * 
 * To use this handler, you must extend it with the @ControllerAdvice annotation.  You may also 
 * implement ExceptionHandlers specific to your service.
 *
 * <pre>
 * @ControllerAdvice(basePackageClasses = MyRestControllerV1.class) 
 * public class MyRestControllerV1ExceptionHandler extends AbstractSpringControllerExceptionHandler {
 *
 * 	@ExceptionHandler(SomethingConflictException.class) // define your own ExceptionHandlers
 * 	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleSomethingConflictException(SomethingConflictException ex) {
 * 		return respondWith(ex, HttpStatus.CONFLICT, ex.getMessage()); // use respondWith to easily build the response
 * 	}
 * 		
 * 	@ExceptionHandler(SomethingNotFoundException.class)
 * 	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleMyThingNotFoundException(SomethingNotFoundException ex) {
 * 		return respondWith(ex, HttpStatus.BAD_REQUEST, ex.getMessage());
 * 	}
 * 		
 * </pre>
 *
 */

@NoArgsConstructor
public abstract class AbstractSpringControllerExceptionHandler {

	private ObjectMapper jsonMapper = new ObjectMapper()
			.findAndRegisterModules()
			.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
	
	private Logger log = LoggerFactory.getLogger(this.getClass());
	
	private static final Map<Class<?>, String> classToOpenApiTypeMap;
	
	private static final String SERVICE_NOT_AVAILABLE = "Service Not Available";

	private boolean mongoOnClassPath = classExists("com.mongodb.MongoTimeoutException");
	
	private boolean classExists(String className) {
		try {
			Class.forName(className);
			return true;
		} catch (ClassNotFoundException | NoClassDefFoundError cnfe) {
			return false;
		}
	}

	static {
		Map<Class<?>, String> classToOpenApiTypeMapCollector = new HashMap<>();
		classToOpenApiTypeMapCollector.put(BigDecimal.class, "number");
		classToOpenApiTypeMapCollector.put(Float.class, "number(float)");
		classToOpenApiTypeMapCollector.put(Double.class, "number(double)");
		classToOpenApiTypeMapCollector.put(Integer.class, "integer"); // Integer could be integer or integer(int32), but no way to distinguish by class alone
		classToOpenApiTypeMapCollector.put(Long.class, "integer(int64)");
		classToOpenApiTypeMapCollector.put(Boolean.class, "boolean");
		classToOpenApiTypeMapCollector.put(byte[].class, "string(byte)");
		classToOpenApiTypeMapCollector.put(Resource.class, "string(binary)");
		classToOpenApiTypeMapCollector.put(LocalDate.class, "string(date)");
		classToOpenApiTypeMapCollector.put(OffsetDateTime.class, "string(date-time)");
		classToOpenApiTypeMap = Collections.unmodifiableMap(classToOpenApiTypeMapCollector);
	}
	
	private Object mapClassToOpenApiType(Class<?> clazz) {
		if (clazz == null) {
			return "null";
		} else if (classToOpenApiTypeMap.containsKey(clazz)) {
			return classToOpenApiTypeMap.get(clazz);
		} else {
			return clazz.getSimpleName().replaceAll("DTO$","");
		}
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleMethodArgumentNotValidException(MethodArgumentNotValidException ex) {
		List<String> details = ex.getBindingResult().getFieldErrors().stream().map(buildFieldErrorMessage).collect(toList());
		details.addAll(ex.getBindingResult().getGlobalErrors().stream().map(buildGlobalErrorMessage).collect(toList()));
		return respondWith(ex, HttpStatus.BAD_REQUEST, details, ErrorCode.BAD_REQUEST);
	}
	
	private @ResponseBody ResponseEntity<ErrorResponseDTO> handleValueInstantiationException(ValueInstantiationException ex) {        
        return handleValueInstantiationExceptionResponse(ex,
                ex.getPath().stream().map(Reference::getFieldName).collect(Collectors.joining(".")),
                ex.getCause().getMessage(),
                ex.getPath().get(0).getFrom().getClass().getSimpleName());
    }
    
    private @ResponseBody ResponseEntity<ErrorResponseDTO> handleValueInstantiationExceptionResponse(Exception ex, String fieldName, Object invalidValue, String clazz) {
        String message = format("{0} for {2}.{1}",
                invalidValue,
                fieldName,
                clazz);
        return respondWith(ex, HttpStatus.BAD_REQUEST, message, ErrorCode.BAD_REQUEST);
    }

	@ExceptionHandler(MissingRequestHeaderException.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleMissingRequestHeaderException(MissingRequestHeaderException ex) {
		String message = format("Missing required header {0}",ex.getHeaderName());
		return respondWith(ex, HttpStatus.BAD_REQUEST, message, ErrorCode.BAD_REQUEST);
	}

	@ExceptionHandler(ConstraintViolationException.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleConstraintViolationException(ConstraintViolationException ex) {
		List<String> details = ex.getConstraintViolations().stream()
				.map(v -> String.join(":", v.getPropertyPath().toString(), v.getMessage()))
				.collect(Collectors.toList());
		return respondWith(ex, HttpStatus.BAD_REQUEST, details, ErrorCode.BAD_REQUEST);
	}

	@ExceptionHandler(HttpMediaTypeNotSupportedException.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleMediaTypeNotSupportedException(HttpMediaTypeNotSupportedException ex) {
		return respondWith(ex, HttpStatus.UNSUPPORTED_MEDIA_TYPE, ex.getMessage(), ErrorCode.UNSUPPORTED_REQUEST);
	}

	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleMethodArgumentTypeMismatchException(MethodArgumentTypeMismatchException ex) {
		return handleGenericTypeMappingException(ex,
				ex.getName(),
				ex.getValue(),
				ex.getRequiredType());
	}

	@ExceptionHandler(HttpMessageNotReadableException.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleHttpMessageNotReadableException(HttpMessageNotReadableException ex) {
		Throwable cause = ex.getCause();
		if (cause instanceof InvalidFormatException) {
			return handleInvalidFormatException((InvalidFormatException)cause);
		} else if (cause instanceof JsonParseException) {
			return handleJsonParseException((JsonParseException)cause);
		} else if (cause instanceof ValueInstantiationException) {
			return handleValueInstantiationException((ValueInstantiationException)cause);
		} else {
			return respondWith(ex, HttpStatus.BAD_REQUEST, ex.getMessage(), ErrorCode.BAD_REQUEST);
		}
	}

	@ExceptionHandler(JsonParseException.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleJsonParseException(JsonParseException ex) {
		String message = format("JSON Parse Error at line {0} column {1}: {2}",
				ex.getLocation().getLineNr(),
				ex.getLocation().getColumnNr(),
				ex.getOriginalMessage());
		return respondWith(ex, HttpStatus.BAD_REQUEST, message, ErrorCode.BAD_REQUEST);
	}

	private @ResponseBody ResponseEntity<ErrorResponseDTO> handleInvalidFormatException(InvalidFormatException ex) {
		return handleGenericTypeMappingException(ex,
				ex.getPath().stream().map(Reference::getFieldName).collect(Collectors.joining(".")),
				ex.getValue(),
				ex.getTargetType());
	}

	private @ResponseBody ResponseEntity<ErrorResponseDTO> handleGenericTypeMappingException(Exception ex, String fieldName, Object invalidValue, Class<?> clazz) {
		String message = format("Value ''{1}'' for {0} is invalid for type {2}",
				fieldName,
				invalidValue,
				mapClassToOpenApiType(clazz));
		return respondWith(ex, HttpStatus.BAD_REQUEST, message, ErrorCode.BAD_REQUEST);
	}

	@ExceptionHandler(JsonMappingException.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleJsonException(Exception ex) {
		return respondWith(ex, HttpStatus.BAD_REQUEST, "Invalid JSON format: " + ex.getMessage(),
				ErrorCode.BAD_REQUEST);
	}
	
	@ExceptionHandler(HttpClientErrorException.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleClientException(HttpClientErrorException ex) {
		return respondWith(ex, HttpStatus.INTERNAL_SERVER_ERROR, ErrorCode.INTERNAL_ERROR);
	}
	

	@ExceptionHandler(HttpServerErrorException.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleServerException(HttpServerErrorException ex) {
		if (ex.getStatusCode().equals(HttpStatus.SERVICE_UNAVAILABLE)) {
			return respondWith(ex, HttpStatus.SERVICE_UNAVAILABLE, ErrorCode.SERVICE_UNAVAILABLE);
		}
		return respondWith(ex, HttpStatus.INTERNAL_SERVER_ERROR, ErrorCode.INTERNAL_ERROR);
	}

	@ExceptionHandler(Exception.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleException(Exception ex) {
		if (mongoOnClassPath && ex instanceof MongoTimeoutException) {
			return respondWith(ex, HttpStatus.SERVICE_UNAVAILABLE,SERVICE_NOT_AVAILABLE, ErrorCode.SERVICE_UNAVAILABLE);
		}
		return respondWith(ex, HttpStatus.INTERNAL_SERVER_ERROR, ErrorCode.INTERNAL_ERROR);
	}
	
	private static final Function<? super FieldError, ? extends String> buildFieldErrorMessage = e ->
				format("Value ''{2}'' for {0}.{1} is invalid: {3}",
				e.getObjectName(),
				e.getField(),
				e.getRejectedValue(),
				e.getDefaultMessage());

	private static final Function<? super ObjectError, ? extends String> buildGlobalErrorMessage = e ->
				format("ObjectName is ''{0}'' and DefaultMessage is {1} ",
				e.getObjectName(),
				e.getDefaultMessage());

	/** Create ErrorResponseDTO with no details.  (Exception will be logged, but not used for error response) */
	protected ResponseEntity<ErrorResponseDTO> respondWith(Exception e, @NotNull HttpStatus httpStatus, ErrorCode errorCode) {
		return respondWith(e, httpStatus, (List<String>)null, errorCode);
	}

	/** Create ErrorResponseDTO with a single detail entry.  (Exception will be logged, but not used for error response) */
	protected ResponseEntity<ErrorResponseDTO> respondWith(Exception e, @NotNull HttpStatus httpStatus, String details, ErrorCode errorCode) {
		return respondWith(e, httpStatus, Collections.singletonList(details), errorCode);
	}

	/** Create ErrorResponseDTO with a multiple detail entries.  (Exception will be logged, but not used for error response) */
	protected ResponseEntity<ErrorResponseDTO> respondWith(Exception e, @NotNull HttpStatus httpStatus, List<String> details, ErrorCode errorCode) {
		ErrorResponseDTO response = ErrorResponseDTO.builder()
				.errorId(UUID.randomUUID())
				.timestamp(OffsetDateTime.now())
				.error(httpStatus. getReasonPhrase())
				.errorCode(errorCode)
				.status(httpStatus.value())
				.details(details)
				.build();
		if (log.isErrorEnabled()) { log.error(responseForLog(response), e); }
		return new ResponseEntity<>(response, httpStatus);

	}

	private String responseForLog(ErrorResponseDTO response) {
		try {
			return "ErrorId: " + response.getErrorId() + " ErrorResponse: "  + jsonMapper.writeValueAsString(response);
		} catch (JsonProcessingException e) {
			return "ErrorId: " + response.getErrorId();
		}
	}

}

package com.humana.claims.hcaas.common.rest.api.starter.autoconfig;

import static java.nio.charset.StandardCharsets.UTF_8;
import static java.text.MessageFormat.format;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyMap;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toMap;
import static org.springframework.util.AntPathMatcher.DEFAULT_PATH_SEPARATOR;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

import javax.servlet.http.HttpServletResponse;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import lombok.extern.slf4j.Slf4j;

/** Configure Swagger UI endpoints
 * 
 * - Only enabled if property swaggerui.enabled is set to true
 * - Can be access via the following paths:
 *     - /swagger-ui.html
 *     - /swagger
 *     - /  (this path can be disabled by setting the property swaggerui.root-redirect.enabled=false)    
 * - Will enable SwaggerUI (including ability to download API Spec) for all API specs
 *     matching path of `./spec/*.openapi.yml`
 */
@Configuration
@ConditionalOnProperty(value = "swaggerui.enabled", havingValue = "true")
@RestController
@Slf4j
public class ContractFirstSwaggerUi implements WebMvcConfigurer {

	private static final String SWAGGER_UI_VERSION = "3.25.0";
	private static final String SWAGGER_UI_CONTEXT = "/swagger-ui";
	private static final String API_DOCS_CONTEXT = "/v3/api-docs";

	private static final String SWAGGER_UI_INDEX_PATH = "/swagger-ui.html";
	private static final String SWAGGER_UI_PATH_USER_FRIENDLY = "/swagger";
	private static final String SWAGGER_UI_CONFIG_PATH = API_DOCS_CONTEXT + "/swagger-config";
	private static final String SWAGGER_UI_PATH = SWAGGER_UI_CONTEXT + "/index.html?configUrl=" + SWAGGER_UI_CONFIG_PATH;

	private static final String SWAGGER_UI_RESOURCE_LOCATION_URL = ResourceUtils.CLASSPATH_URL_PREFIX + "/META-INF/resources/webjars" + DEFAULT_PATH_SEPARATOR + "swagger-ui" + DEFAULT_PATH_SEPARATOR + SWAGGER_UI_VERSION + DEFAULT_PATH_SEPARATOR;


	private static final String SPEC_EXTENSION = ".openapi.yaml";
	private static final String SPEC_PATTERN = "spec/*" + SPEC_EXTENSION;

	private Map<String, Resource> specs;

	public ContractFirstSwaggerUi() {
		try {
			specs = getResources(SPEC_PATTERN).stream()
					.collect(toMap(
							r -> r.getFilename().replaceFirst(SPEC_EXTENSION + "$",""),
							r -> r));
		} catch (Exception e) {
			log.warn("Error loading Swagger config",e);
			specs = emptyMap();
		}
	}

	private List<Resource> getResources(String pattern) throws IOException {
		PathMatchingResourcePatternResolver resourceResolver = new PathMatchingResourcePatternResolver();
		String resourcePattern = format("classpath*:{0}", pattern);
		return asList(resourceResolver.getResources(resourcePattern));
	}

	@GetMapping(path = {SWAGGER_UI_INDEX_PATH, SWAGGER_UI_PATH_USER_FRIENDLY})
	public void swaggerUiIndex(HttpServletResponse response) throws IOException {
		response.sendRedirect(SWAGGER_UI_PATH);
	}
	
	@ConditionalOnProperty(name = "swaggerui.root-redirect.enabled", havingValue = "true", matchIfMissing = true)
	@RestController
	public static class RootRedirect {
		@GetMapping(path = "/")
		public void getRoot(HttpServletResponse response) throws IOException {
			response.sendRedirect(SWAGGER_UI_PATH);
		}
	}
	
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler(SWAGGER_UI_CONTEXT + "/**").addResourceLocations(SWAGGER_UI_RESOURCE_LOCATION_URL);
	}

	@GetMapping(SWAGGER_UI_CONFIG_PATH)
	public Map<String, Object> swaggerConfig() {
		Map<String, Object> config = new HashMap<>();
		config.put("configUrl", SWAGGER_UI_CONFIG_PATH);
		config.put("urls", specs.entrySet().stream().map(Map.Entry::getKey).map(specNameToSwaggerConfigUrl).collect(toList()));
		return config;
	}

	private static final Function<String, Map<String, String>> specNameToSwaggerConfigUrl = specName -> {
		Map<String, String> urlObject = new HashMap<>();
		urlObject.put("url", API_DOCS_CONTEXT + "/" + specName);
		urlObject.put("name", specName);
		return urlObject;
	};

	@GetMapping(path = API_DOCS_CONTEXT + "/{spec-name}", produces = "text/yaml")
	public String spec(@PathVariable("spec-name") String specName) throws IOException {
		Resource resource = specs.get(specName);
		
		InputStream inputStream = resource.getInputStream();
		return readInputStream(inputStream);
	}

	private String readInputStream(InputStream inputStream) throws IOException {
		StringBuilder strBuilder = new StringBuilder();
		try (Reader reader = new InputStreamReader(inputStream, UTF_8)) {
			char[] buf = new char[1024];
			int charsRead;
			while ( (charsRead = reader.read(buf)) >= 0 ) {
				strBuilder.append(buf, 0, charsRead);
			}
		}
	
		return strBuilder.toString();
	}

	@ExceptionHandler(Throwable.class)
	public ResponseEntity<Void> exceptionHandler(Throwable t) {
		log.error("ContractFirstSwaggerUI Exception!");
		return ResponseEntity.notFound().build();
	}
}

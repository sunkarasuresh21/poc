package com.humana.claims.hcaas.common.rest.api.starter.enumerrorcode;

public enum ErrorCode {

	/** Invalid requests, including validation errors and missing parameters */
	BAD_REQUEST,
	/** Definition varies per service */
	NOT_FOUND,
	/** Definition varies per service */
	CONFLICT,
	/** Invalid client certificate or credentials passed in request */
	UNAUTHORIZED_ACCESS,
	/** Unexpected Exceptions */
	INTERNAL_ERROR,
	/** Downstream services (MongoDB, REST API, etc) are down */
	SERVICE_UNAVAILABLE,
	/** Unsupported requests, including media type not supported validation errors */
	UNSUPPORTED_REQUEST

}

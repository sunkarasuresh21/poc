# TypeEdit (TECI)

The typedit service is used to convert the claims place of treatment to a planload place of treatment which will drive the benefit for the claim.

## Components

![Component Diagram](./diagrams/typeedit-components.png)

## REST API

The OpenAPI spec can be found [here](typeedit-rest-api-spec/src/main/resources)

## Data Capture

  * Mongo DB mapping
	The data capture to Mongo DB mapping can be found on HCaaS Sharepoint at /PlanLoad/DB Schema/Benefit Mapping.xlsx

  * Mainframe message schema
	Mainframe message schema can be found on HCaaS Sharepoint at /PlanLoad/Benefit Selection Service/TECI.xml

  * Mainframe to MongoDB mapping
	Mainframe to MongoDB mapping can be found on HCaaS Sharepoint at /PlanLoad/DB Schema/TECI_NEW.txt

## Build
This is a multi-module Maven project.

### Project Layout
```
typeedit-parent (Root project - modules, dependencies and dependency versions)
    ├ typeedit-core (core business logic and database layer)
    ├ typeedit-data-capture (MQ listener)
    ├ typeedit-rest-api-spec (API specification)
    └ typeedit-rest-api (API layer)
```

Standard dependencies can be found in each pom.xml

Building the root/parent project will build all the modules.
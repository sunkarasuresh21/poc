package com.humana.claims.hcaas.typeedit.restapi;


import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes=TypeEditApplication.class)
@TestPropertySource("classpath:context-test.properties")
public class SpringApplicationContextTest {

	@Autowired
	private ApplicationContext appContext;
	
	/**
	 * This test just confirms the Spring Application Context can be wired up and started
	 *
	 */
	@Test
	public void contextLoads() {
		assertThat(appContext).isNotNull();
	}

}

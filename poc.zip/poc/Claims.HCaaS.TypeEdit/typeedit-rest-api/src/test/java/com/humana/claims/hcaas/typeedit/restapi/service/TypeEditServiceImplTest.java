package com.humana.claims.hcaas.typeedit.restapi.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.Month;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.junit.jupiter.MockitoExtension;

import com.humana.claims.hcaas.typeedit.core.dao.TeciDAO;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditConflictException;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditNotFoundException;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditUpdateException;
import com.humana.claims.hcaas.typeedit.core.model.Teci;
import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.model.InlineObjectDTO;
import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.model.TypeEditDetailsDTO;
import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.model.TypeEditDetailsPlaceOfTreatmentCodesDTO;
import com.humana.claims.hcaas.typeedit.restapi.mapper.TypeEditMapper;
import com.humana.claims.hcaas.typeedit.restapi.service.impl.TypeEditServiceImpl;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
public class TypeEditServiceImplTest {

	private TypeEditServiceImpl classUnderTest;
	private TypeEditMapper typeEditMapper = mock(TypeEditMapper.class);
	private TeciDAO teciDAO = mock(TeciDAO.class);

	@Captor
	private ArgumentCaptor<Teci> teciCaptor;

	@Captor
	private ArgumentCaptor<InlineObjectDTO> inlineObjectCaptor;

	@BeforeEach
	public void init(){
		classUnderTest = new TypeEditServiceImpl(teciDAO,typeEditMapper);
	}

	@SneakyThrows
	@Test
	public void create_type_edit_should_throw_no_exception_when_get_type_edit_is_called() {

		InlineObjectDTO inlineObject = createInlineObjectDTO();
		Teci teci = createTeciForSave();

		when(typeEditMapper.mapInlineObjectDTOToTECI(inlineObject)).thenReturn(teci);
		when(teciDAO.saveTeci(teci)).thenReturn(teci);

		assertDoesNotThrow(() -> classUnderTest.createTypeEdit(inlineObject));
	}

	@SneakyThrows
	@Test
	public void create_type_edit_should_pass_the_correct_argument_to_dao() {

		InlineObjectDTO inlineObject = createInlineObjectDTO();
		Teci teci = createTeciForSave();

		when(typeEditMapper.mapInlineObjectDTOToTECI(inlineObject)).thenReturn(teci);
		when(teciDAO.saveTeci(teci)).thenReturn(teci);

		classUnderTest.createTypeEdit(inlineObject);

		verify(teciDAO,times(1)).saveTeci(teciCaptor.capture());
		assertThat(teciCaptor.getValue()).isEqualTo(teci);
	}

	@SneakyThrows
	@Test
	public void create_type_edit_should_call_dao_and_mapper_methods_only_once() {

		InlineObjectDTO inlineObject = createInlineObjectDTO();
		Teci teci = createTeciForSave();

		when(typeEditMapper.mapInlineObjectDTOToTECI(inlineObject)).thenReturn(teci);
		when(teciDAO.saveTeci(teci)).thenReturn(teci);

		classUnderTest.createTypeEdit(inlineObject);

		verify(teciDAO,times(1)).saveTeci(teciCaptor.capture());
		verify(typeEditMapper,times(1)).mapInlineObjectDTOToTECI(inlineObjectCaptor.capture());
	}

	@SneakyThrows
	@Test
	public void create_type_edit_should_throw_exception_when_dao_throws_conflict_exception() {

		InlineObjectDTO inlineObject = createInlineObjectDTO();
		Teci teci = createTeciForSave();

		when(typeEditMapper.mapInlineObjectDTOToTECI(inlineObject)).thenReturn(teci);
		doThrow(new TypeEditConflictException()).when(teciDAO).saveTeci(teci);

		assertThatExceptionOfType(TypeEditConflictException.class).isThrownBy(() -> 
			classUnderTest.createTypeEdit(inlineObject)
		);
	}

	@SneakyThrows
	@Test
	public void create_type_edit_should_throw_exception_when_dao_throws_runtime_exception() {

		InlineObjectDTO inlineObject = createInlineObjectDTO();
		Teci teci = createTeciForSave();

		when(typeEditMapper.mapInlineObjectDTOToTECI(inlineObject)).thenReturn(teci);
		doThrow(new RuntimeException()).when(teciDAO).saveTeci(teci);

		assertThatExceptionOfType(RuntimeException.class).isThrownBy(() -> 
			classUnderTest.createTypeEdit(inlineObject)
		);
	}

	@SneakyThrows
	@Test
	public void create_type_edit_should_throw_exception_when_mapper_throws_runtime_exception() {

		InlineObjectDTO inlineObject = createInlineObjectDTO();
		Teci teci = createTeciForSave();

		doThrow(new RuntimeException()).when(typeEditMapper).mapInlineObjectDTOToTECI(inlineObject);
		when(teciDAO.saveTeci(teci)).thenReturn(teci);

		assertThatExceptionOfType(RuntimeException.class).isThrownBy(() -> 
			classUnderTest.createTypeEdit(inlineObject)
		);
	}

	@SneakyThrows
	@Test
	public void get_type_edit_by_benefitcategory_benefitnumber_causecode_and_typecode_should_return_type_edit_details_dto() {
		Teci teci = new Teci();
		when(teciDAO.fetchTECI("01", "12345", "XXXXXC", "OBGYN")).thenReturn(teci);

		TypeEditDetailsDTO typeEditDetailsDTO = new TypeEditDetailsDTO();
		when(typeEditMapper.mapTECIToTypeEditDetailsDTO(teci)).thenReturn(typeEditDetailsDTO);

		classUnderTest.getTypeEditByBenefitCategoryBenefitNumberCauseCodeAndTypeCode("01", "12345", "OBGYN", "XXXXXC");

		assertThat(typeEditDetailsDTO).isNotNull();
	}

	@SneakyThrows
	@Test
	public void get_type_edit_by_benefitcategory_benefitnumber_causecode_and_typecode_should_return_null_returned_by_mapper() {
		Teci teci = new Teci();
		when(teciDAO.fetchTECI("01", "12345", "XXXXXC", "OBGYN")).thenReturn(teci);

		TypeEditDetailsDTO typeEditDetailsDTO = null;
		when(typeEditMapper.mapTECIToTypeEditDetailsDTO(teci)).thenReturn(typeEditDetailsDTO);

		TypeEditDetailsDTO typeEditDetailsDTOActual = classUnderTest.getTypeEditByBenefitCategoryBenefitNumberCauseCodeAndTypeCode("01", "12345", "OBGYN", "XXXXXC");

		assertThat(typeEditDetailsDTOActual).isNull();
	}

	@SneakyThrows
	@Test
	public void get_type_edit_by_benefitcategory_benefitnumber_causecode_and_typecode_should_return_type_edit_details_dto_returned_by_mapper() {
		Teci teci = new Teci();
		when(teciDAO.fetchTECI("01", "12345", "XXXXXC", "OBGYN")).thenReturn(teci);

		TypeEditDetailsDTO typeEditDetailsDTO = new TypeEditDetailsDTO();
		when(typeEditMapper.mapTECIToTypeEditDetailsDTO(teci)).thenReturn(typeEditDetailsDTO);

		TypeEditDetailsDTO typeEditDetailsDTOActual = classUnderTest.getTypeEditByBenefitCategoryBenefitNumberCauseCodeAndTypeCode("01", "12345", "OBGYN", "XXXXXC");

		assertThat(typeEditDetailsDTOActual).isEqualTo(typeEditDetailsDTO);
	}

	@SneakyThrows
	@Test
	public void get_type_edit_by_benefitcategory_benefitnumber_causecode_and_typecode_should_throw_type_edit_not_found_exception() {

		when(teciDAO.fetchTECI("01", "12345", "XXXXXC", "OBGYN")).thenThrow(new TypeEditNotFoundException());

		assertThatExceptionOfType(TypeEditNotFoundException.class).isThrownBy(() -> 
			classUnderTest.getTypeEditByBenefitCategoryBenefitNumberCauseCodeAndTypeCode("01", "12345", "OBGYN", "XXXXXC")
		);

	}

	@SneakyThrows
	@Test
	public void get_type_edit_by_benefitcategory_benefitnumber_causecode_and_typecode_should_return_proper_error_msg_when_throw_type_edit_not_found_exception() {

		when(teciDAO.fetchTECI("01", "12345", "XXXXXC", "OBGYN")).thenThrow(new TypeEditNotFoundException());

		assertThatExceptionOfType(TypeEditNotFoundException.class).isThrownBy(() -> 
			classUnderTest.getTypeEditByBenefitCategoryBenefitNumberCauseCodeAndTypeCode("01", "12345", "OBGYN", "XXXXXC")
		).withMessage("No TypeEdit record found matching input criteria");

	}

	@SneakyThrows
	@Test
	public void update_type_edit_should_throw_type_edit_not_found_exception() {
		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDTO();
		Teci teci = createTeciWithDefaultKeyFields();

		when(typeEditMapper.mapTypeEditDetailsDTOToTeci(typeEditDetailsDTO)).thenReturn(teci);
		when(teciDAO.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode("01", "12345", "OBGYN", "XXXXXC", teci)).thenThrow(new TypeEditNotFoundException());

		assertThatExceptionOfType(TypeEditNotFoundException.class).isThrownBy(() -> 
			classUnderTest.updateTypeEdit("01", "12345", "OBGYN", "XXXXXC", typeEditDetailsDTO)
		);

	}

	@SneakyThrows
	@Test
	public void update_type_edit_should_return_proper_error_msg_when_throw_type_edit_not_found_exception() {
		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDTO();
		Teci teci = createTeciWithDefaultKeyFields();

		when(typeEditMapper.mapTypeEditDetailsDTOToTeci(typeEditDetailsDTO)).thenReturn(teci);
		when(teciDAO.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode("01", "12345", "OBGYN", "XXXXXC", teci)).thenThrow(new TypeEditNotFoundException());

		assertThatExceptionOfType(TypeEditNotFoundException.class).isThrownBy(() -> 
			classUnderTest.updateTypeEdit("01", "12345", "OBGYN", "XXXXXC", typeEditDetailsDTO)
		).withMessage("No TypeEdit record found matching input criteria");

	}

	@SneakyThrows
	@Test
	public void update_type_edit_should_throw_type_edit_update_exception() {
		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDTO();
		Teci teci = createTeciWithDefaultKeyFields();

		when(typeEditMapper.mapTypeEditDetailsDTOToTeci(typeEditDetailsDTO)).thenReturn(teci);
		when(teciDAO.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode("01", "12345", "OBGYN", "XXXXXC", teci)).thenThrow(new TypeEditUpdateException("message"));

		assertThatExceptionOfType(TypeEditUpdateException.class).isThrownBy(() -> 
			classUnderTest.updateTypeEdit("01", "12345", "OBGYN", "XXXXXC", typeEditDetailsDTO)
		);
		
	}

	@SneakyThrows
	@Test
	public void update_type_edit_should_return_proper_error_msg_when_throw_type_edit_update_exception() {
		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDTO();
		Teci teci = createTeciWithDefaultKeyFields();

		when(typeEditMapper.mapTypeEditDetailsDTOToTeci(typeEditDetailsDTO)).thenReturn(teci);
		when(teciDAO.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode("01", "12345", "OBGYN", "XXXXXC", teci)).thenThrow(new TypeEditUpdateException("message"));

		assertThatExceptionOfType(TypeEditUpdateException.class).isThrownBy(() -> 
			classUnderTest.updateTypeEdit("01", "12345", "OBGYN", "XXXXXC", typeEditDetailsDTO)
		);
	}

	@SneakyThrows
	@Test
	public void update_type_edit_should_call_teci_dao_to_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code() {
		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDTO();
		Teci teci = createTeciWithDefaultKeyFields();
		teci.setBypassLcd("bypassLcd");

		when(typeEditMapper.mapTypeEditDetailsDTOToTeci(typeEditDetailsDTO)).thenReturn(teci);
		when(teciDAO.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode("01", "12345", "OBGYN", "XXXXXC", teci)).thenReturn(teci);

		classUnderTest.updateTypeEdit("01", "12345", "OBGYN", "XXXXXC", typeEditDetailsDTO);

		verify(teciDAO, times(1)).updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode("01", "12345", "OBGYN", "XXXXXC", teci);
	}

	private Teci createTeciWithDefaultKeyFields() {
		Teci teci = new Teci();
		teci.setBenefitCategory("01");
		teci.setBenefitNumber("12345");
		teci.setCauseCode("OBGYN");
		teci.setTypeCode("XXXXXC");
		return teci;
	}

	private InlineObjectDTO createInlineObjectDTO() {
		InlineObjectDTO inlineObject = new InlineObjectDTO();	
		inlineObject.setBenefitCategory("01");
		inlineObject.setBenefitNumber("12345");
		inlineObject.setCauseCode("CD1");
		inlineObject.setTypeCode("typCd");
		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDTO();
		inlineObject.setTypEditBody(typeEditDetailsDTO);
		return inlineObject;
	}

	private TypeEditDetailsDTO createTypeEditDTO() {
		TypeEditDetailsDTO typEditBody = new TypeEditDetailsDTO();
		typEditBody.setBypassLCD("bypassLCD");
		typEditBody.setHighAge(10);
		typEditBody.setLastModifiedBy("user");
		typEditBody.setLastModifiedDateTime(OffsetDateTime.of(LocalDate.of(2020, Month.AUGUST, 05).atStartOfDay(), ZoneOffset.UTC));
		List<TypeEditDetailsPlaceOfTreatmentCodesDTO> placeOfTreatmentCodes = new  ArrayList<>();
		TypeEditDetailsPlaceOfTreatmentCodesDTO TypeEditDetailspotc = new TypeEditDetailsPlaceOfTreatmentCodesDTO();
		TypeEditDetailspotc.setPlaceOfTreatment("p");
		TypeEditDetailspotc.setPlanloadPlaceOfTreatment("t");
		placeOfTreatmentCodes.add(TypeEditDetailspotc);		
		typEditBody.setPlaceOfTreatmentCodes(placeOfTreatmentCodes);
		List<String> providerTypes = new  ArrayList<>();
		providerTypes.add("abc");
		typEditBody.setProviderTypes(providerTypes);
		typEditBody.setLowAge(10);
		typEditBody.setSex("f");
		return typEditBody;
	}

	private Teci createTeciForSave() {
		Teci teci = new Teci();
		teci.setCauseCode("TestTeciCauseCode");
		teci.setBenefitCategory("TestTeciBenefitCat");
		teci.setBenefitNumber("TestTeciBenefitNumber");
		teci.setTypeCode("99213G");
		return teci;
	}
}

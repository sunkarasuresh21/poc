package com.humana.claims.hcaas.typeedit.restapi.mapper.impl;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.humana.claims.hcaas.typeedit.core.model.PlaceOfTreatmentCodes;
import com.humana.claims.hcaas.typeedit.core.model.Teci;
import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.model.InlineObjectDTO;
import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.model.TypeEditDetailsDTO;
import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.model.TypeEditDetailsPlaceOfTreatmentCodesDTO;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
public class TypeEditMapperImplTest {
	
	@InjectMocks
	private TypeEditMapperImpl classUnderTest;
	
	@Test
	public void test_map_inline_object_to_teci_maps_benefit_category_to_teci_core_from_given_dto() {
		InlineObjectDTO inlineObject = createInlineObjectDTO();
		Teci teci = classUnderTest.mapInlineObjectDTOToTECI(inlineObject);
		
		assertThat(teci.getBenefitCategory()).isEqualTo(inlineObject.getBenefitCategory()); 
		
	}
	
	@Test
	public void test_map_inline_object_to_teci_maps_benefit_number_to_teci_core_from_given_dto() {
		InlineObjectDTO inlineObject = createInlineObjectDTO();
		Teci teci = classUnderTest.mapInlineObjectDTOToTECI(inlineObject);
		
		assertThat(teci.getBenefitNumber()).isEqualTo(inlineObject.getBenefitNumber()); 
		
	}
	
	@Test
	public void test_map_inline_object_to_teci_maps_cause_code_to_teci_core_from_given_dto() {
		InlineObjectDTO inlineObject = createInlineObjectDTO();
		Teci teci = classUnderTest.mapInlineObjectDTOToTECI(inlineObject);
		
		assertThat(teci.getCauseCode()).isEqualTo(inlineObject.getCauseCode());
		
	}
	
	@Test
	public void test_map_inline_object_to_teci_maps_type_code_to_teci_core_from_given_dto() {
		InlineObjectDTO inlineObject = createInlineObjectDTO();
		Teci teci = classUnderTest.mapInlineObjectDTOToTECI(inlineObject);
		
		assertThat(teci.getTypeCode()).isEqualTo(inlineObject.getTypeCode()); 
		
	}
	
	@Test
	public void test_map_inline_object_to_teci_maps_bypasslcd_to_teci_core_from_given_dto() {
		InlineObjectDTO inlineObject = createInlineObjectDTO();
		Teci teci = classUnderTest.mapInlineObjectDTOToTECI(inlineObject);
		
		assertThat(teci.getBypassLcd()).isEqualTo(inlineObject.getTypEditBody().getBypassLCD());
		
	}
	
	@Test
	public void test_map_inline_object_to_teci_maps_highage_to_teci_core_from_given_dto() {
		InlineObjectDTO inlineObject = createInlineObjectDTO();
		Teci teci = classUnderTest.mapInlineObjectDTOToTECI(inlineObject);
		
		assertThat(teci.getHighAge()).isEqualTo(inlineObject.getTypEditBody().getHighAge());
		
	}
	
	@Test
	public void test_map_inline_object_to_teci_maps_lowage_to_teci_core_from_given_dto() {
		InlineObjectDTO inlineObject = createInlineObjectDTO();
		Teci teci = classUnderTest.mapInlineObjectDTOToTECI(inlineObject);
		
		assertThat(teci.getLowAge()).isEqualTo(inlineObject.getTypEditBody().getLowAge());
		
	}
	
	@Test
	public void test_map_inline_object_to_teci_maps_last_modified_by_to_teci_core_from_given_dto() {
		InlineObjectDTO inlineObject = createInlineObjectDTO();
		Teci teci = classUnderTest.mapInlineObjectDTOToTECI(inlineObject);
		
		assertThat(teci.getLastModifiedBy()).isEqualTo(inlineObject.getTypEditBody().getLastModifiedBy());
		
	}
	
	@Test
	public void test_map_inline_object_to_teci_maps_sex_to_teci_core_from_given_dto() {
		InlineObjectDTO inlineObject = createInlineObjectDTO();
		Teci teci = classUnderTest.mapInlineObjectDTOToTECI(inlineObject);
		
		assertThat(teci.getSex()).isEqualTo(inlineObject.getTypEditBody().getSex());
		
	}
	
	@Test
	public void test_map_inline_object_to_teci_maps_provider_types_to_teci_core_from_given_dto() {
		InlineObjectDTO inlineObject = createInlineObjectDTO();
		Teci teci = classUnderTest.mapInlineObjectDTOToTECI(inlineObject);
		
		assertThat(teci.getProviderTypes()).isEqualTo(inlineObject.getTypEditBody().getProviderTypes());
		
	}
	
	@Test
	public void test_map_inline_object_to_teci_maps_place_of_treatment_codes_to_teci_core_from_given_dto() {
		InlineObjectDTO inlineObject = createInlineObjectDTO();
		Teci teci = classUnderTest.mapInlineObjectDTOToTECI(inlineObject);
		
		assertThat(teci.getPlaceOfTreatmentCodes().get(0).getClaimsPot()).isEqualTo(inlineObject.getTypEditBody().getPlaceOfTreatmentCodes().get(0).getPlaceOfTreatment()); 
		assertThat(teci.getPlaceOfTreatmentCodes().get(0).getPlanLoadPot()).isEqualTo(inlineObject.getTypEditBody().getPlaceOfTreatmentCodes().get(0).getPlanloadPlaceOfTreatment());
		
	}
	
	@Test
	public void test_map_teci_to_type_edit_details_dto_returns_non_null_when_teci_is_null() {
		Teci teci = null;
		
		TypeEditDetailsDTO typeEditDetailsDTO = classUnderTest.mapTECIToTypeEditDetailsDTO(teci);
		
		assertThat(typeEditDetailsDTO).isNotNull();
	}
	
	@Test
	public void test_map_teci_to_type_edit_details_dto_returns_non_null_when_teci_is_not_null() {
		Teci teci = new Teci();
		
		TypeEditDetailsDTO typeEditDetailsDTO = classUnderTest.mapTECIToTypeEditDetailsDTO(teci);
		
		assertThat(typeEditDetailsDTO).isNotNull();
	}
	
	@Test
	public void test_map_teci_to_type_edit_details_dto_maps_low_age() {
		Teci teci = new Teci();
		teci.setLowAge(new Integer(10));
		
		TypeEditDetailsDTO typeEditDetailsDTO = classUnderTest.mapTECIToTypeEditDetailsDTO(teci);
		
		assertThat(typeEditDetailsDTO.getLowAge()).isEqualTo(new Integer(10));
	}
	
	@Test
	public void test_map_teci_to_type_edit_details_dto_maps_high_age() {
		Teci teci = new Teci();
		teci.setHighAge(new Integer(100));
		
		TypeEditDetailsDTO typeEditDetailsDTO = classUnderTest.mapTECIToTypeEditDetailsDTO(teci);
		
		assertThat(typeEditDetailsDTO.getHighAge()).isEqualTo(new Integer(100));
	}
	
	@Test
	public void test_map_teci_to_type_edit_details_dto_maps_bypass_lcd() {
		Teci teci = new Teci();
		teci.setBypassLcd("bypassLcd");
		
		TypeEditDetailsDTO typeEditDetailsDTO = classUnderTest.mapTECIToTypeEditDetailsDTO(teci);
		
		assertThat(typeEditDetailsDTO.getBypassLCD()).isEqualTo("bypassLcd");
	}
	
	@Test
	public void test_map_teci_to_type_edit_details_dto_maps_sex() {
		Teci teci = new Teci();
		teci.setSex("M");
		
		TypeEditDetailsDTO typeEditDetailsDTO = classUnderTest.mapTECIToTypeEditDetailsDTO(teci);
		
		assertThat(typeEditDetailsDTO.getSex()).isEqualTo("M");
	}
	
	@Test
	public void test_map_teci_to_type_edit_details_dto_maps_last_modified_by() {
		Teci teci = new Teci();
		teci.setLastModifiedBy("lastModifiedBy");
		
		TypeEditDetailsDTO typeEditDetailsDTO = classUnderTest.mapTECIToTypeEditDetailsDTO(teci);
		
		assertThat(typeEditDetailsDTO.getLastModifiedBy()).isEqualTo("lastModifiedBy");
	}
	
	@Test
	public void test_map_teci_to_type_edit_details_dto_maps_last_modified_date_time_to_null() {
		Teci teci = new Teci();
		
		TypeEditDetailsDTO typeEditDetailsDTO = classUnderTest.mapTECIToTypeEditDetailsDTO(teci);
		
		assertThat(typeEditDetailsDTO.getLastModifiedDateTime()).isNull();
	}
	
	@Test
	public void test_map_teci_to_type_edit_details_dto_maps_last_modified_date_time() {
		Teci teci = new Teci();
		teci.setLastModifiedDateTime(Instant.parse("2020-09-15T10:15:30.59Z"));
		
		TypeEditDetailsDTO typeEditDetailsDTO = classUnderTest.mapTECIToTypeEditDetailsDTO(teci);
		
		assertThat(typeEditDetailsDTO.getLastModifiedDateTime()).isEqualTo(OffsetDateTime.parse("2020-09-15T10:15:30.59Z"));
	}
	
	@Test
	public void test_map_teci_to_type_edit_details_dto_maps_null_provider_types_to_null_type_edit_details_provider_types() {
		Teci teci = new Teci();
		teci.setProviderTypes(null);
		
		TypeEditDetailsDTO typeEditDetailsDTO = classUnderTest.mapTECIToTypeEditDetailsDTO(teci);
		
		assertThat(typeEditDetailsDTO.getProviderTypes()).isNull();
	}

	@Test
	public void test_map_teci_to_type_edit_details_dto_maps_non_empty_provider_types_to_empty_type_edit_details_provider_types() {
		Teci teci = new Teci();
		List<String> providerTypesList = new ArrayList<>();
		teci.setProviderTypes(providerTypesList);
		
		TypeEditDetailsDTO typeEditDetailsDTO = classUnderTest.mapTECIToTypeEditDetailsDTO(teci);
		
		assertThat(typeEditDetailsDTO.getProviderTypes()).isEmpty();
	}
	
	@Test
	public void test_map_teci_to_type_edit_details_dto_maps_provider_types() {
		Teci teci = new Teci();
		List<String> providerTypesList = new ArrayList<>();
		providerTypesList.add("HH");
		providerTypesList.add("RE");
		teci.setProviderTypes(providerTypesList);
		
		TypeEditDetailsDTO typeEditDetailsDTO = classUnderTest.mapTECIToTypeEditDetailsDTO(teci);
		
		assertThat(typeEditDetailsDTO.getProviderTypes()).isEqualTo(providerTypesList);
	}
	
	@Test
	public void test_map_teci_to_type_edit_details_dto_maps_null_place_of_treatment_codes_to_null_type_edit_details_place_of_treatment_codes() {
		Teci teci = new Teci();
		teci.setPlaceOfTreatmentCodes(null);
		
		TypeEditDetailsDTO typeEditDetailsDTO = classUnderTest.mapTECIToTypeEditDetailsDTO(teci);
		
		assertThat(typeEditDetailsDTO.getPlaceOfTreatmentCodes()).isNull();
	}
	
	@Test
	public void test_map_teci_to_type_edit_details_dto_maps_non_empty_place_of_treatment_codes_to_empty_type_edit_details_place_of_treatment_codes() {
		Teci teci = new Teci();
		List<PlaceOfTreatmentCodes> potcList = new ArrayList<>();
		teci.setPlaceOfTreatmentCodes(potcList);
		
		TypeEditDetailsDTO typeEditDetailsDTO = classUnderTest.mapTECIToTypeEditDetailsDTO(teci);
		
		assertThat(typeEditDetailsDTO.getPlaceOfTreatmentCodes()).isEmpty();
	}
	
	@Test
	public void test_map_teci_to_type_edit_details_dto_maps_all_null_place_of_treatment_codes_to_empty_type_edit_details_place_of_treatment_codes() {
		Teci teci = new Teci();
		List<PlaceOfTreatmentCodes> potcList = new ArrayList<>();
		potcList.add(null);
		teci.setPlaceOfTreatmentCodes(potcList);
		
		TypeEditDetailsDTO typeEditDetailsDTO = classUnderTest.mapTECIToTypeEditDetailsDTO(teci);
		
		assertThat(typeEditDetailsDTO.getPlaceOfTreatmentCodes()).isEmpty();
	}
	
	@Test
	public void test_map_teci_to_type_edit_details_dto_maps_place_of_treatment_codes_to_non_empty_type_edit_details_place_of_treatment_codes_ignoring_nulls() {
		Teci teci = new Teci();
		List<PlaceOfTreatmentCodes> potcList = new ArrayList<>();
		PlaceOfTreatmentCodes placeOfTreatmentCodes = new PlaceOfTreatmentCodes();
		potcList.add(null);
		potcList.add(placeOfTreatmentCodes);
		teci.setPlaceOfTreatmentCodes(potcList);
		
		TypeEditDetailsDTO typeEditDetailsDTO = classUnderTest.mapTECIToTypeEditDetailsDTO(teci);
		
		assertThat(typeEditDetailsDTO.getPlaceOfTreatmentCodes()).hasSize(1);
	}
	
	@Test
	public void test_map_teci_to_type_edit_details_dto_maps_place_of_treatment_codes_claimspot() {
		Teci teci = new Teci();
		List<PlaceOfTreatmentCodes> potcList = new ArrayList<>();
		PlaceOfTreatmentCodes placeOfTreatmentCodes = new PlaceOfTreatmentCodes();
		placeOfTreatmentCodes.setClaimsPot("1");
		potcList.add(placeOfTreatmentCodes);
		teci.setPlaceOfTreatmentCodes(potcList);
		
		TypeEditDetailsDTO typeEditDetailsDTO = classUnderTest.mapTECIToTypeEditDetailsDTO(teci);
		
		assertThat(typeEditDetailsDTO.getPlaceOfTreatmentCodes().get(0).getPlaceOfTreatment()).isEqualTo("1");
	}
	
	@Test
	public void test_map_teci_to_type_edit_details_dto_maps_place_of_treatment_codes_planloadpot() {
		Teci teci = new Teci();
		List<PlaceOfTreatmentCodes> potcList = new ArrayList<>();
		PlaceOfTreatmentCodes placeOfTreatmentCodes = new PlaceOfTreatmentCodes();
		placeOfTreatmentCodes.setPlanLoadPot("2");
		potcList.add(placeOfTreatmentCodes);
		teci.setPlaceOfTreatmentCodes(potcList);
		
		TypeEditDetailsDTO typeEditDetailsDTO = classUnderTest.mapTECIToTypeEditDetailsDTO(teci);
		
		assertThat( typeEditDetailsDTO.getPlaceOfTreatmentCodes().get(0).getPlanloadPlaceOfTreatment()).isEqualTo("2");
	}
	
	@Test
	public void test_map_type_edit_details_dto_to_teci_maps_lowage() {
		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTO();
		Teci teci = classUnderTest.mapTypeEditDetailsDTOToTeci(typeEditDetailsDTO);
		
		assertThat(teci.getLowAge()).isEqualTo(typeEditDetailsDTO.getLowAge());
	}
	
	@Test
	public void test_map_type_edit_details_dto_to_teci_maps_highage() {
		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTO();
		Teci teci = classUnderTest.mapTypeEditDetailsDTOToTeci(typeEditDetailsDTO);
		
		assertThat(teci.getHighAge()).isEqualTo(typeEditDetailsDTO.getHighAge());
	}
	
	@Test
	public void test_map_type_edit_details_dto_to_teci_maps_sex() {
		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTO();
		Teci teci = classUnderTest.mapTypeEditDetailsDTOToTeci(typeEditDetailsDTO);
		
		assertThat(teci.getSex()).isEqualTo(typeEditDetailsDTO.getSex());
	}
	
	@Test
	public void test_map_type_edit_details_dto_to_teci_maps_bypass_lcd() {
		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTO();
		Teci teci = classUnderTest.mapTypeEditDetailsDTOToTeci(typeEditDetailsDTO);
		
		assertThat(teci.getBypassLcd()).isEqualTo(typeEditDetailsDTO.getBypassLCD());
	}
	
	@Test
	public void test_map_type_edit_details_dto_to_teci_maps_last_modified_by() {
		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTO();
		Teci teci = classUnderTest.mapTypeEditDetailsDTOToTeci(typeEditDetailsDTO);
		
		assertThat(teci.getLastModifiedBy()).isEqualTo(typeEditDetailsDTO.getLastModifiedBy());
	}
	
	@SneakyThrows
	@Test
	public void test_map_type_edit_details_dto_to_teci_generates_last_modified_date_time() {
		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTO();
		typeEditDetailsDTO.setLastModifiedDateTime(OffsetDateTime.parse("2015-09-07T00:00:00.000Z"));
		Instant beforeMapping = LocalDateTime.now().toInstant(ZoneOffset.UTC);
		
		Teci teci = classUnderTest.mapTypeEditDetailsDTOToTeci(typeEditDetailsDTO);

		Instant afterMapping = LocalDateTime.now().toInstant(ZoneOffset.UTC);
		
		Instant lastModifiedDateTimeActual = teci.getLastModifiedDateTime();
		assertThat(lastModifiedDateTimeActual.equals(Instant.parse("2015-09-07T00:00:00.000Z"))).isFalse();
		assertThat(lastModifiedDateTimeActual.isAfter(beforeMapping) || lastModifiedDateTimeActual.equals(beforeMapping)).isTrue();
		assertThat(lastModifiedDateTimeActual.isBefore(afterMapping) || lastModifiedDateTimeActual.equals(afterMapping)).isTrue();
	}

	@Test
	public void test_map_type_edit_details_dto_to_teci_maps_provider_types_null() {
		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTO();
		typeEditDetailsDTO.setProviderTypes(null);
		
		Teci teci = classUnderTest.mapTypeEditDetailsDTOToTeci(typeEditDetailsDTO);
		
		assertThat(teci.getProviderTypes()).isEqualTo(null);
	}
	
	@Test
	public void test_map_type_edit_details_dto_to_teci_maps_provider_types_empty() {
		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTO();
		typeEditDetailsDTO.setProviderTypes(new ArrayList<>());
		
		Teci teci = classUnderTest.mapTypeEditDetailsDTOToTeci(typeEditDetailsDTO);
		
		assertThat(teci.getProviderTypes()).isEqualTo(new ArrayList<>());
	}
	
	@Test
	public void test_map_type_edit_details_dto_to_teci_maps_provider_types_non_empty() {
		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTO();
		List<String> providerTypes = new ArrayList<>();
		providerTypes.add("providerType1");
		typeEditDetailsDTO.setProviderTypes(providerTypes);
		
		Teci teci = classUnderTest.mapTypeEditDetailsDTOToTeci(typeEditDetailsDTO);
		
		assertThat(teci.getProviderTypes().get(0)).isEqualTo("providerType1");
	}
	
	@Test
	public void test_map_type_edit_details_dto_to_teci_maps_provider_types_non_empty_and_ignores_empty() {
		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTO();
		List<String> providerTypes = new ArrayList<>();
		providerTypes.add(null);
		providerTypes.add("providerType1");
		typeEditDetailsDTO.setProviderTypes(providerTypes);
		
		Teci teci = classUnderTest.mapTypeEditDetailsDTOToTeci(typeEditDetailsDTO);
		
		assertThat(teci.getProviderTypes().get(0)).isEqualTo("providerType1");
	}
	
	@Test
	public void test_map_type_edit_details_dto_to_teci_maps_place_of_treatment_codes_null() {
		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTO();
		typeEditDetailsDTO.setPlaceOfTreatmentCodes(null);
		
		Teci teci = classUnderTest.mapTypeEditDetailsDTOToTeci(typeEditDetailsDTO);
		
		assertThat(teci.getPlaceOfTreatmentCodes()).isNull();
	}

	@Test
	public void test_map_type_edit_details_dto_to_teci_maps_place_of_treatment_codes_empty() {
		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTO();
		typeEditDetailsDTO.setPlaceOfTreatmentCodes(new ArrayList<>());
		
		Teci teci = classUnderTest.mapTypeEditDetailsDTOToTeci(typeEditDetailsDTO);
		
		assertThat(teci.getPlaceOfTreatmentCodes()).isEqualTo(new ArrayList<>());
	}
	
	@Test
	public void test_map_type_edit_details_dto_to_teci_maps_place_of_treatment_codes_ignoring_nulls() {
		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTO();
		List<TypeEditDetailsPlaceOfTreatmentCodesDTO> placeOfTreatmentCodes = new ArrayList<>();
		TypeEditDetailsPlaceOfTreatmentCodesDTO typeEditDetailsPlaceOfTreatmentCodesDTO = new TypeEditDetailsPlaceOfTreatmentCodesDTO();
		placeOfTreatmentCodes.add(null);
		placeOfTreatmentCodes.add(typeEditDetailsPlaceOfTreatmentCodesDTO);
		typeEditDetailsDTO.setPlaceOfTreatmentCodes(placeOfTreatmentCodes);
		
		Teci teci = classUnderTest.mapTypeEditDetailsDTOToTeci(typeEditDetailsDTO);
		
		assertThat(teci.getPlaceOfTreatmentCodes()).hasSize(1);
	}
	
	@Test
	public void test_map_type_edit_details_dto_to_teci_maps_place_of_treatment() {
		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTO();
		List<TypeEditDetailsPlaceOfTreatmentCodesDTO> placeOfTreatmentCodes = new ArrayList<>();
		TypeEditDetailsPlaceOfTreatmentCodesDTO typeEditDetailsPlaceOfTreatmentCodesDTO = new TypeEditDetailsPlaceOfTreatmentCodesDTO();
		typeEditDetailsPlaceOfTreatmentCodesDTO.setPlaceOfTreatment("placeOfTreatment");
		placeOfTreatmentCodes.add(typeEditDetailsPlaceOfTreatmentCodesDTO);
		
		typeEditDetailsDTO.setPlaceOfTreatmentCodes(placeOfTreatmentCodes);
		
		Teci teci = classUnderTest.mapTypeEditDetailsDTOToTeci(typeEditDetailsDTO);
		
		assertThat(teci.getPlaceOfTreatmentCodes().get(0).getClaimsPot()).isEqualTo("placeOfTreatment");
	}
	
	@Test
	public void test_map_type_edit_details_dto_to_teci_maps_planload_place_of_treatment() {
		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTO();
		List<TypeEditDetailsPlaceOfTreatmentCodesDTO> placeOfTreatmentCodes = new ArrayList<>();
		TypeEditDetailsPlaceOfTreatmentCodesDTO typeEditDetailsPlaceOfTreatmentCodesDTO = new TypeEditDetailsPlaceOfTreatmentCodesDTO();
		typeEditDetailsPlaceOfTreatmentCodesDTO.setPlanloadPlaceOfTreatment("planloadPlaceOfTreatment");
		placeOfTreatmentCodes.add(typeEditDetailsPlaceOfTreatmentCodesDTO);
		
		typeEditDetailsDTO.setPlaceOfTreatmentCodes(placeOfTreatmentCodes);
		
		Teci teci = classUnderTest.mapTypeEditDetailsDTOToTeci(typeEditDetailsDTO);
		
		assertThat(teci.getPlaceOfTreatmentCodes().get(0).getPlanLoadPot()).isEqualTo("planloadPlaceOfTreatment");
	}
	
	private InlineObjectDTO createInlineObjectDTO() {
		InlineObjectDTO inlineObject = new InlineObjectDTO();	
		inlineObject.setBenefitCategory("01");
		inlineObject.setBenefitNumber("12345");
		inlineObject.setCauseCode("CD1");
		inlineObject.setTypeCode("typCd");
		
		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTO();
		inlineObject.setTypEditBody(typeEditDetailsDTO);
		return inlineObject;
	}

	private TypeEditDetailsDTO createTypeEditDetailsDTO() {
		TypeEditDetailsDTO typEditBody = new TypeEditDetailsDTO();
		typEditBody.setBypassLCD("bypassLCD");
		typEditBody.setHighAge(100);
		typEditBody.setLastModifiedBy("ABC1234");
		typEditBody.setLowAge(1);
		typEditBody.setSex("F");
		List<String> providerTypes = new  ArrayList<>();
		providerTypes.add("AF");
		typEditBody.setProviderTypes(providerTypes);
		
		List<TypeEditDetailsPlaceOfTreatmentCodesDTO> placeOfTreatmentCodes = new  ArrayList<>();
		TypeEditDetailsPlaceOfTreatmentCodesDTO TypeEditDetailspotc = new TypeEditDetailsPlaceOfTreatmentCodesDTO();
		TypeEditDetailspotc.setPlaceOfTreatment("1");
		TypeEditDetailspotc.setPlanloadPlaceOfTreatment("2");
		placeOfTreatmentCodes.add(TypeEditDetailspotc);		
		typEditBody.setPlaceOfTreatmentCodes(placeOfTreatmentCodes);
		return typEditBody;
	}
	
}

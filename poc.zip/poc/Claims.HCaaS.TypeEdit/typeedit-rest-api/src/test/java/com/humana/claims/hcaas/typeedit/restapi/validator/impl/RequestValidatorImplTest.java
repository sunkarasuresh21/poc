package com.humana.claims.hcaas.typeedit.restapi.validator.impl;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.humana.claims.hcaas.typeedit.restapi.exception.TypeEditConstraintViolationException;
import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.model.TypeEditDetailsDTO;

@ExtendWith(MockitoExtension.class)
public class RequestValidatorImplTest {

	@InjectMocks
	private RequestValidatorImpl classUnderTest;

	@Test
	public void test_validate_type_edit_details_dto_does_not_throws_type_edit_constraint_violation_exception_when_provider_types_is_valid() {
		TypeEditDetailsDTO typeEditDetailsDTO = new TypeEditDetailsDTO();
		List<String> providerTypes = new ArrayList<>();
		providerTypes.add("aa");

		assertDoesNotThrow(() -> classUnderTest.validateTypeEditDetailsDTO(typeEditDetailsDTO));
		
	}

	@Test
	public void test_validate_type_edit_details_dto_throws_type_edit_constraint_violation_exception_when_provider_types_is_invalid() {
		TypeEditDetailsDTO typeEditDetailsDTO = new TypeEditDetailsDTO();
		List<String> providerTypes = new ArrayList<>();
		providerTypes.add("abcd");

		typeEditDetailsDTO.setProviderTypes(providerTypes);

		assertThatExceptionOfType(TypeEditConstraintViolationException.class).isThrownBy(() -> 
			classUnderTest.validateTypeEditDetailsDTO(typeEditDetailsDTO)
		).withMessage("Value 'abcd' for typeEditDetailsDTO.providerTypes[0] is invalid: size must be between 2 and 2");
		
	}

}

package com.humana.claims.hcaas.typeedit.restapi.controller;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.time.Month;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditConflictException;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditNotFoundException;
import com.humana.claims.hcaas.typeedit.restapi.exception.TypeEditConstraintViolationException;
import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.model.InlineObjectDTO;
import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.model.TypeEditDetailsDTO;
import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.model.TypeEditDetailsPlaceOfTreatmentCodesDTO;
import com.humana.claims.hcaas.typeedit.restapi.service.TypeEditService;
import com.humana.claims.hcaas.typeedit.restapi.validator.RequestValidator;

import lombok.SneakyThrows;

@ExtendWith(SpringExtension.class)
@WebMvcTest(TypeEditControllerV1.class)
public class TypeEditControllerV1Test {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private TypeEditService typeEditService;
	
	@MockBean
	private RequestValidator requestValidator;

	@SneakyThrows
	@Test
	public void create_type_edit_should_return_status_created_and_returns_proper_message_when_valid_post_data() {
		InlineObjectDTO inlineObject = createValidInlineObjectDTOWithAllMandatoryFields();

		String inlineObjectJson = convertDTOObjectToJsonString(inlineObject);

		this.mockMvc.perform(post("/v1/typedit").contentType(MediaType.APPLICATION_JSON).content(inlineObjectJson))
		.andDo(print())
		.andExpect(status().isCreated());
	}

	@SneakyThrows
	@Test
	public void create_type_edit_should_return_created_even_when_null_benefit_category() {
		InlineObjectDTO inlineObject = createValidInlineObjectDTOWithAllMandatoryFields();
		inlineObject.setBenefitCategory(null);

		String inlineObjectJson = convertDTOObjectToJsonString(inlineObject);

		this.mockMvc.perform(post("/v1/typedit").contentType(MediaType.APPLICATION_JSON).content(inlineObjectJson))
		.andDo(print())
		.andExpect(status().isCreated());
	}

	@SneakyThrows
	@Test
	public void create_type_edit_should_return_created_even_when_null_benefit_number() {
		InlineObjectDTO inlineObject = createValidInlineObjectDTOWithAllMandatoryFields();
		inlineObject.setBenefitNumber(null);

		String inlineObjectJson = convertDTOObjectToJsonString(inlineObject);

		this.mockMvc.perform(post("/v1/typedit").contentType(MediaType.APPLICATION_JSON).content(inlineObjectJson))
		.andDo(print())
		.andExpect(status().isCreated());
	}

	@SneakyThrows
	@Test
	public void create_type_edit_should_return_created_even_request_when_null_type_code() {
		InlineObjectDTO inlineObject = createValidInlineObjectDTOWithAllMandatoryFields();
		inlineObject.setTypeCode(null);

		String inlineObjectJson = convertDTOObjectToJsonString(inlineObject);

		this.mockMvc.perform(post("/v1/typedit").contentType(MediaType.APPLICATION_JSON).content(inlineObjectJson))
		.andDo(print())
		.andExpect(status().isCreated());
	}

	@SneakyThrows
	@Test
	public void create_type_edit_should_return_created_even_when_null_cause_code() {
		InlineObjectDTO inlineObject = createValidInlineObjectDTOWithAllMandatoryFields();
		inlineObject.setCauseCode(null);
		
		String inlineObjectJson = convertDTOObjectToJsonString(inlineObject);

		this.mockMvc.perform(post("/v1/typedit").contentType(MediaType.APPLICATION_JSON).content(inlineObjectJson))
		.andDo(print())
		.andExpect(status().isCreated());
	}

	@SneakyThrows
	@Test
	public void create_type_edit_should_return_status_bad_request_when_invalid_benefit_number() {
		InlineObjectDTO inlineObject = createValidInlineObjectDTOWithAllMandatoryFields();
		inlineObject.setBenefitNumber("123B");

		String inlineObjectJson = convertDTOObjectToJsonString(inlineObject);

		this.mockMvc.perform(post("/v1/typedit").contentType(MediaType.APPLICATION_JSON).content(inlineObjectJson))
		.andDo(print())
		.andExpect(status().isBadRequest())
		.andExpect(jsonPath("$['errorId']").isNotEmpty())
		.andExpect(jsonPath("$['timestamp']").isNotEmpty())
		.andExpect(jsonPath("$['error']").value("Bad Request"))
		.andExpect(jsonPath("$['errorCode']").value("BAD_REQUEST"))
		.andExpect(jsonPath("$['details'][0]").value("Value '123B' for inlineObjectDTO.benefitNumber is invalid: must match \"^[0-9]{5}$\""));
	}

	@SneakyThrows
	@Test
	public void create_type_edit_should_return_status_bad_request_when_invalid_benefit_category() {
		InlineObjectDTO inlineObject = createValidInlineObjectDTOWithAllMandatoryFields();
		inlineObject.setBenefitCategory("123");

		String inlineObjectJson = convertDTOObjectToJsonString(inlineObject);

		this.mockMvc.perform(post("/v1/typedit").contentType(MediaType.APPLICATION_JSON).content(inlineObjectJson))
		.andDo(print())
		.andExpect(status().isBadRequest())
		.andExpect(jsonPath("$['errorId']").isNotEmpty())
		.andExpect(jsonPath("$['timestamp']").isNotEmpty())
		.andExpect(jsonPath("$['error']").value("Bad Request"))
		.andExpect(jsonPath("$['errorCode']").value("BAD_REQUEST"))
		.andExpect(jsonPath("$['details'][0]").value("Value '123' for inlineObjectDTO.benefitCategory is invalid: must match \"^[0-9]{2}$\""));
	}

	@SneakyThrows
	@Test
	public void create_type_edit_should_return_status_bad_request_when_invalid_type_code() {
		InlineObjectDTO inlineObject = createValidInlineObjectDTOWithAllMandatoryFields();
		inlineObject.setTypeCode("a");;

		String inlineObjectJson = convertDTOObjectToJsonString(inlineObject);

		this.mockMvc.perform(post("/v1/typedit").contentType(MediaType.APPLICATION_JSON).content(inlineObjectJson))
		.andDo(print())
		.andExpect(status().isBadRequest())
		.andExpect(jsonPath("$['errorId']").isNotEmpty())
		.andExpect(jsonPath("$['timestamp']").isNotEmpty())
		.andExpect(jsonPath("$['error']").value("Bad Request"))
		.andExpect(jsonPath("$['errorCode']").value("BAD_REQUEST"))
		.andExpect(jsonPath("$['details'][0]").value("Value 'a' for inlineObjectDTO.typeCode is invalid: size must be between 2 and 6"));
	}

	@SneakyThrows
	@Test
	public void create_type_edit_should_return_status_bad_request_when_invalid_cause_code_with_bigger_length() {
		InlineObjectDTO inlineObject = createValidInlineObjectDTOWithAllMandatoryFields();
		inlineObject.setCauseCode("ABCDE1");;

		String inlineObjectJson = convertDTOObjectToJsonString(inlineObject);

		this.mockMvc.perform(post("/v1/typedit").contentType(MediaType.APPLICATION_JSON).content(inlineObjectJson))
		.andDo(print())
		.andExpect(status().isBadRequest())
		.andExpect(jsonPath("$['errorId']").isNotEmpty())
		.andExpect(jsonPath("$['timestamp']").isNotEmpty())
		.andExpect(jsonPath("$['error']").value("Bad Request"))
		.andExpect(jsonPath("$['errorCode']").value("BAD_REQUEST"))
		.andExpect(jsonPath("$['details'][0]").value("Value 'ABCDE1' for inlineObjectDTO.causeCode is invalid: size must be between 2 and 5"));
	}

	@SneakyThrows
	@Test
	public void create_type_edit_should_return_status_bad_request_when_invalid_cause_code_with_wrong_value() {
		InlineObjectDTO inlineObject = createValidInlineObjectDTOWithAllMandatoryFields();
		inlineObject.setCauseCode("abcd");;

		String inlineObjectJson = convertDTOObjectToJsonString(inlineObject);

		this.mockMvc.perform(post("/v1/typedit").contentType(MediaType.APPLICATION_JSON).content(inlineObjectJson))
		.andDo(print())
		.andExpect(status().isBadRequest())
		.andExpect(jsonPath("$['errorId']").isNotEmpty())
		.andExpect(jsonPath("$['timestamp']").isNotEmpty())
		.andExpect(jsonPath("$['error']").value("Bad Request"))
		.andExpect(jsonPath("$['errorCode']").value("BAD_REQUEST"))
		.andExpect(jsonPath("$['details'][0]").value("Value 'abcd' for inlineObjectDTO.causeCode is invalid: must match \"^[0-9A-Z]+$\""));
	}

	@SneakyThrows
	@Test
	public void create_type_edit_should_return_created_if_null_type_edit_body_and_no_exception_from_service() {
		InlineObjectDTO inlineObject = createValidInlineObjectDTOWithAllMandatoryFields();
		inlineObject.setTypEditBody(null);

		String inlineObjectJson = convertDTOObjectToJsonString(inlineObject);

		this.mockMvc.perform(post("/v1/typedit").contentType(MediaType.APPLICATION_JSON).content(inlineObjectJson))
		.andDo(print())
		.andExpect(status().isCreated());
	}

	@SneakyThrows
	@Test
	public void create_type_edit_should_return_status_conflict_when_already_present() {
		InlineObjectDTO inlineObject = createValidInlineObjectDTOWithAllMandatoryFields();

		String inlineObjectJson = convertDTOObjectToJsonString(inlineObject);

		doThrow(new TypeEditConflictException()).when(typeEditService).createTypeEdit(inlineObject);

		this.mockMvc.perform(post("/v1/typedit").contentType(MediaType.APPLICATION_JSON).content(inlineObjectJson))
		.andDo(print())
		.andExpect(status().isConflict())
		.andExpect(jsonPath("$['errorId']").isNotEmpty())
		.andExpect(jsonPath("$['timestamp']").isNotEmpty())
		.andExpect(jsonPath("$['error']").value("Conflict"))
		.andExpect(jsonPath("$['errorCode']").value("CONFLICT"))
		.andExpect(jsonPath("$['details'][0]").value("A TypeEdit record already exists for this key"));
	}

	@SneakyThrows
	@Test
	public void create_type_edit_should_return_status_internal_server_error_when_type_edit_service_throws_unknown_exception() {
		InlineObjectDTO inlineObject = createValidInlineObjectDTOWithAllMandatoryFields();
		String inlineObjectJson = convertDTOObjectToJsonString(inlineObject);

		doThrow(new RuntimeException()).when(typeEditService).createTypeEdit(inlineObject);

		this.mockMvc.perform(post("/v1/typedit").contentType(MediaType.APPLICATION_JSON).content(inlineObjectJson))
		.andExpect(status().isInternalServerError())
		.andExpect(jsonPath("$['errorId']").isNotEmpty())
		.andExpect(jsonPath("$['timestamp']").isNotEmpty())
		.andExpect(jsonPath("$['error']").value("Internal Server Error"))
		.andExpect(jsonPath("$['errorCode']").value("INTERNAL_ERROR"))
		.andExpect(jsonPath("$['details']").doesNotExist());
	}

	@SneakyThrows
	@Test
	public void create_type_edit_should_return_status_bad_request_error_when_type_edit_service_pattern_is_wrong_throws_exception() {
		InlineObjectDTO inlineObject = createValidInlineObjectDTOWithAllMandatoryFields();
		TypeEditDetailsPlaceOfTreatmentCodesDTO typeEditDetailsPlaceOfTreatmentCodes = new TypeEditDetailsPlaceOfTreatmentCodesDTO();
		typeEditDetailsPlaceOfTreatmentCodes.setPlaceOfTreatment("abc");
		inlineObject.getTypEditBody().getPlaceOfTreatmentCodes().set(0, typeEditDetailsPlaceOfTreatmentCodes);
		String inlineObjectJson = convertDTOObjectToJsonString(inlineObject);

		this.mockMvc.perform(post("/v1/typedit").contentType(MediaType.APPLICATION_JSON).content(inlineObjectJson))
		.andExpect(status().isBadRequest())
		.andExpect(jsonPath("$['errorId']").isNotEmpty())
		.andExpect(jsonPath("$['timestamp']").isNotEmpty())
		.andExpect(jsonPath("$['error']").value("Bad Request"))
		.andExpect(jsonPath("$['errorCode']").value("BAD_REQUEST"));
	}
	
	@SneakyThrows
	@Test
	public void get_type_edit_should_return_status_ok_when_valid_benefit_category_benefit_number_cause_code_type_code() {
		TypeEditDetailsDTO typeEditDetails = createTypeEditDetailsDTOWithAllMandatoryFields();
		List<TypeEditDetailsPlaceOfTreatmentCodesDTO> typeEditDetailsPlaceOfTreatmentCodesList = new ArrayList<>();
		typeEditDetails.setPlaceOfTreatmentCodes(typeEditDetailsPlaceOfTreatmentCodesList);
		typeEditDetails.setProviderTypes(new ArrayList<>());
		
		when(typeEditService.getTypeEditByBenefitCategoryBenefitNumberCauseCodeAndTypeCode("02", "12345", "OBGYN", "XXXXXC")).thenReturn(typeEditDetails);

		this.mockMvc.perform(get("/v1/typedit/benefitCategory/02/benefitNumber/12345/causeCode/OBGYN/typeCode/XXXXXC")).andDo(print())
		.andExpect(status().isOk())
		.andExpect(jsonPath("$['placeOfTreatmentCodes']").isArray())
        .andExpect(jsonPath("$['providerTypes']").isArray());
	}
	
	@SneakyThrows
	@Test
	public void get_type_edit_should_return_status_bad_request_when_invalid_benefit_category() {
		this.mockMvc.perform(get("/v1/typedit/benefitCategory/AB1/benefitNumber/12345/causeCode/OBGYN/typeCode/XXXXXC")).andDo(print())
		.andExpect(status().isBadRequest())
		.andExpect(jsonPath("$['errorId']").isNotEmpty())
		.andExpect(jsonPath("$['timestamp']").isNotEmpty())
		.andExpect(jsonPath("$['error']").value("Bad Request"))
		.andExpect(jsonPath("$['details'][0]").value("getTypeEdit.benefitCategory:must match \"^[0-9]{2}$\""));
	}
	
	@SneakyThrows
	@Test
	public void get_type_edit_should_return_status_bad_request_when_invalid_benefit_number() {
		this.mockMvc.perform(get("/v1/typedit/benefitCategory/01/benefitNumber/AB345/causeCode/OBGYN/typeCode/XXXXXC")).andDo(print())
		.andExpect(status().isBadRequest())
		.andExpect(jsonPath("$['errorId']").isNotEmpty())
		.andExpect(jsonPath("$['timestamp']").isNotEmpty())
		.andExpect(jsonPath("$['error']").value("Bad Request"))
		.andExpect(jsonPath("$['errorCode']").value("BAD_REQUEST"))
		.andExpect(jsonPath("$['details'][0]").value("getTypeEdit.benefitNumber:must match \"^[0-9]{5}$\""));
	}
	
	@SneakyThrows
	@Test
	public void get_type_edit_should_return_status_bad_request_when_invalid_cause_code() {
		this.mockMvc.perform(get("/v1/typedit/benefitCategory/01/benefitNumber/12345/causeCode/abcd/typeCode/XXXXXC")).andDo(print())
		.andExpect(status().isBadRequest())
		.andExpect(jsonPath("$['errorId']").isNotEmpty())
		.andExpect(jsonPath("$['timestamp']").isNotEmpty())
		.andExpect(jsonPath("$['error']").value("Bad Request"))
		.andExpect(jsonPath("$['errorCode']").value("BAD_REQUEST"))
		.andExpect(jsonPath("$['details'][0]").value("getTypeEdit.causeCode:must match \"^[0-9A-Z]+$\""));
	}
	
	@SneakyThrows
	@Test
	public void get_type_edit_should_return_status_bad_request_when_invalid_type_code() {
		this.mockMvc.perform(get("/v1/typedit/benefitCategory/01/benefitNumber/12345/causeCode/OBGYN/typeCode/5432100")).andDo(print())
		.andExpect(status().isBadRequest())
		.andExpect(jsonPath("$['errorId']").isNotEmpty())
		.andExpect(jsonPath("$['timestamp']").isNotEmpty())
		.andExpect(jsonPath("$['error']").value("Bad Request"))
		.andExpect(jsonPath("$['details'][0]").value("getTypeEdit.typeCode:size must be between 2 and 6"));
	}
	
	@SneakyThrows
	@Test
	public void get_type_edit_should_return_status_bad_request_when_type_edit_service_throws_type_edit_not_found_exception() {
		
		doThrow(new TypeEditNotFoundException()).when(typeEditService).getTypeEditByBenefitCategoryBenefitNumberCauseCodeAndTypeCode("02", "12345", "OBGYN", "XXXXXC");
		
		this.mockMvc.perform(get("/v1/typedit/benefitCategory/02/benefitNumber/12345/causeCode/OBGYN/typeCode/XXXXXC")).andDo(print())
		.andExpect(status().isBadRequest())
		.andExpect(jsonPath("$['errorId']").isNotEmpty())
		.andExpect(jsonPath("$['timestamp']").isNotEmpty())
		.andExpect(jsonPath("$['error']").value("Bad Request"))
		.andExpect(jsonPath("$['errorCode']").value("NOT_FOUND"))
		.andExpect(jsonPath("$['details'][0]").value("No TypeEdit record found matching input criteria"));
	}
	
	@SneakyThrows
	@Test
	public void get_type_edit_should_throw_internal_server_error_when_type_edit_service_throws_unknown_exception() {
		
		doThrow(new RuntimeException()).when(typeEditService).getTypeEditByBenefitCategoryBenefitNumberCauseCodeAndTypeCode("02", "12345", "OBGYN", "XXXXXC");
		
		this.mockMvc.perform(get("/v1/typedit/benefitCategory/02/benefitNumber/12345/causeCode/OBGYN/typeCode/XXXXXC")).andDo(print())
		.andExpect(status().isInternalServerError())
		.andExpect(jsonPath("$['errorId']").isNotEmpty())
		.andExpect(jsonPath("$['timestamp']").isNotEmpty())
		.andExpect(jsonPath("$['error']").value("Internal Server Error"))
		.andExpect(jsonPath("$['errorCode']").value("INTERNAL_ERROR"))
		.andExpect(jsonPath("$['details']").doesNotExist());
	}

	@SneakyThrows
	@Test
	public void update_type_edit_should_return_status_ok_and_returns_proper_message_when_valid_input_data() {
		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTOWithAllMandatoryFields();
		String typeEditDetailsJSON = convertTypeEditDetailsDTOObjectToJsonString(typeEditDetailsDTO);

		doNothing().when(typeEditService).updateTypeEdit("12", "12345", "12ABC", "TECI", typeEditDetailsDTO);
		doNothing().when(requestValidator).validateTypeEditDetailsDTO(typeEditDetailsDTO);
		
		this.mockMvc.perform(patch("/v1/typedit/benefitCategory/12/benefitNumber/12345/causeCode/12ABC/typeCode/TECI")
				.contentType(MediaType.APPLICATION_JSON)
				.content(typeEditDetailsJSON))
				.andDo(print())
				.andExpect(status().isOk());
	}
	
	@SneakyThrows
	@Test
	public void update_type_edit_should_return_status_bad_request_and_returns_proper_message_when_type_edit_service_throws_type_edit_not_found_exception() {

		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTOWithAllMandatoryFields();
		String typeEditDetailsJSON = convertTypeEditDetailsDTOObjectToJsonString(typeEditDetailsDTO);

		doThrow(new TypeEditNotFoundException()).when(typeEditService).updateTypeEdit("12", "12345", "12ABC", "TECI", typeEditDetailsDTO);
		doNothing().when(requestValidator).validateTypeEditDetailsDTO(typeEditDetailsDTO);
		
		this.mockMvc.perform(patch("/v1/typedit/benefitCategory/12/benefitNumber/12345/causeCode/12ABC/typeCode/TECI")
				.contentType(MediaType.APPLICATION_JSON)
				.content(typeEditDetailsJSON))
				.andDo(print())
				.andExpect(jsonPath("$['errorId']").isNotEmpty())
				.andExpect(jsonPath("$['timestamp']").isNotEmpty())
				.andExpect(jsonPath("$['error']").value("Bad Request"))
				.andExpect(jsonPath("$['errorCode']").value("NOT_FOUND"))
				.andExpect(jsonPath("$['details'][0]").value("No TypeEdit record found matching input criteria"))
				.andExpect(status().isBadRequest());
	}
	
	@SneakyThrows
	@Test
	public void update_type_edit_should_return_status_bad_request_and_returns_proper_message_when_valid_input_data_when_invalid_benefitcategory() {

		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTOWithAllMandatoryFields();
		String typeEditDetailsJSON = convertTypeEditDetailsDTOObjectToJsonString(typeEditDetailsDTO);

		doNothing().when(requestValidator).validateTypeEditDetailsDTO(typeEditDetailsDTO);
		
		this.mockMvc.perform(patch("/v1/typedit/benefitCategory/abc/benefitNumber/12345/causeCode/12ABC/typeCode/TECI")
				.contentType(MediaType.APPLICATION_JSON)
				.content(typeEditDetailsJSON))
				.andDo(print())
				.andExpect(jsonPath("$['errorId']").isNotEmpty())
				.andExpect(jsonPath("$['timestamp']").isNotEmpty())
				.andExpect(jsonPath("$['error']").value("Bad Request"))
				.andExpect(jsonPath("$['errorCode']").value("BAD_REQUEST"))
				.andExpect(jsonPath("$['details'][0]").value("updateTypeEdit.benefitCategory:must match \"^[0-9]{2}$\""))
				.andExpect(status().isBadRequest());
	}
	
	@SneakyThrows
	@Test
	public void update_type_edit_should_return_status_bad_request_and_returns_proper_message_when_valid_input_data_when_invalid_benefitnumber() {

		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTOWithAllMandatoryFields();
		String typeEditDetailsJSON = convertTypeEditDetailsDTOObjectToJsonString(typeEditDetailsDTO);

		doNothing().when(requestValidator).validateTypeEditDetailsDTO(typeEditDetailsDTO);
		
		this.mockMvc.perform(patch("/v1/typedit/benefitCategory/12/benefitNumber/abc/causeCode/12ABC/typeCode/TECI")
				.contentType(MediaType.APPLICATION_JSON)
				.content(typeEditDetailsJSON))
				.andDo(print())
				.andExpect(jsonPath("$['errorId']").isNotEmpty())
				.andExpect(jsonPath("$['timestamp']").isNotEmpty())
				.andExpect(jsonPath("$['error']").value("Bad Request"))
				.andExpect(jsonPath("$['errorCode']").value("BAD_REQUEST"))
				.andExpect(jsonPath("$['details'][0]").value("updateTypeEdit.benefitNumber:must match \"^[0-9]{5}$\""))
				.andExpect(status().isBadRequest());

	}
	
	@SneakyThrows
	@Test
	public void update_type_edit_should_return_status_bad_request_and_returns_proper_message_when_valid_input_data_when_invalid_causecode_min_value() {

		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTOWithAllMandatoryFields();
		String typeEditDetailsJSON = convertTypeEditDetailsDTOObjectToJsonString(typeEditDetailsDTO);

		doNothing().when(requestValidator).validateTypeEditDetailsDTO(typeEditDetailsDTO);
		
		this.mockMvc.perform(patch("/v1/typedit/benefitCategory/12/benefitNumber/12345/causeCode/A/typeCode/TECI")
				.contentType(MediaType.APPLICATION_JSON)
				.content(typeEditDetailsJSON))
				.andDo(print())
				.andExpect(jsonPath("$['errorId']").isNotEmpty())
				.andExpect(jsonPath("$['timestamp']").isNotEmpty())
				.andExpect(jsonPath("$['error']").value("Bad Request"))
				.andExpect(jsonPath("$['errorCode']").value("BAD_REQUEST"))
				.andExpect(jsonPath("$['details'][0]").value("updateTypeEdit.causeCode:size must be between 2 and 5"))
				.andExpect(status().isBadRequest());
	}
	
	@SneakyThrows
	@Test
	public void update_type_edit_should_return_status_bad_request_and_returns_proper_message_when_valid_input_data_when_invalid_causecode_max_value() {

		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTOWithAllMandatoryFields();
		String typeEditDetailsJSON = convertTypeEditDetailsDTOObjectToJsonString(typeEditDetailsDTO);

		doNothing().when(requestValidator).validateTypeEditDetailsDTO(typeEditDetailsDTO);
		
		this.mockMvc.perform(patch("/v1/typedit/benefitCategory/12/benefitNumber/12345/causeCode/ABCDEF/typeCode/TECI")
				.contentType(MediaType.APPLICATION_JSON)
				.content(typeEditDetailsJSON))
				.andDo(print())
				.andExpect(jsonPath("$['errorId']").isNotEmpty())
				.andExpect(jsonPath("$['timestamp']").isNotEmpty())
				.andExpect(jsonPath("$['error']").value("Bad Request"))
				.andExpect(jsonPath("$['errorCode']").value("BAD_REQUEST"))
				.andExpect(jsonPath("$['details'][0]").value("updateTypeEdit.causeCode:size must be between 2 and 5"))
				.andExpect(status().isBadRequest());
	}

	@SneakyThrows
	@Test
	public void update_type_edit_should_return_status_bad_request_and_returns_proper_message_when_valid_input_data_when_invalid_typecode_min_value() {

		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTOWithAllMandatoryFields();
		String typeEditDetailsJSON = convertTypeEditDetailsDTOObjectToJsonString(typeEditDetailsDTO);

		doNothing().when(requestValidator).validateTypeEditDetailsDTO(typeEditDetailsDTO);
		
		this.mockMvc.perform(patch("/v1/typedit/benefitCategory/12/benefitNumber/12345/causeCode/A/typeCode/TECI")
				.contentType(MediaType.APPLICATION_JSON)
				.content(typeEditDetailsJSON))
				.andDo(print())
				.andExpect(jsonPath("$['errorId']").isNotEmpty())
				.andExpect(jsonPath("$['timestamp']").isNotEmpty())
				.andExpect(jsonPath("$['error']").value("Bad Request"))
				.andExpect(jsonPath("$['errorCode']").value("BAD_REQUEST"))
				.andExpect(jsonPath("$['details'][0]").value("updateTypeEdit.causeCode:size must be between 2 and 5"))
				.andExpect(status().isBadRequest());
	}
	
	@SneakyThrows
	@Test
	public void update_type_edit_should_return_status_bad_request_and_returns_proper_message_when_valid_input_data_when_invalid_typecode_max_value() {

		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTOWithAllMandatoryFields();
		String typeEditDetailsJSON = convertTypeEditDetailsDTOObjectToJsonString(typeEditDetailsDTO);

		doNothing().when(requestValidator).validateTypeEditDetailsDTO(typeEditDetailsDTO);
		
		this.mockMvc.perform(patch("/v1/typedit/benefitCategory/12/benefitNumber/12345/causeCode/ABCDEFG/typeCode/TECI")
				.contentType(MediaType.APPLICATION_JSON)
				.content(typeEditDetailsJSON))
				.andDo(print())
				.andExpect(jsonPath("$['errorId']").isNotEmpty())
				.andExpect(jsonPath("$['timestamp']").isNotEmpty())
				.andExpect(jsonPath("$['error']").value("Bad Request"))
				.andExpect(jsonPath("$['errorCode']").value("BAD_REQUEST"))
				.andExpect(jsonPath("$['details'][0]").value("updateTypeEdit.causeCode:size must be between 2 and 5"))
				.andExpect(status().isBadRequest());
	}
	
	@SneakyThrows
	@Test
	public void update_type_edit_should_return_status_bad_request_and_returns_proper_message_when_valid_input_data_when_invalid_lowage_min_value() {

		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTOWithAllMandatoryFields();
		typeEditDetailsDTO.setLowAge(-1);
		
		String typeEditDetailsJSON = convertTypeEditDetailsDTOObjectToJsonString(typeEditDetailsDTO);

		doNothing().when(requestValidator).validateTypeEditDetailsDTO(typeEditDetailsDTO);
		
		this.mockMvc.perform(patch("/v1/typedit/benefitCategory/12/benefitNumber/12345/causeCode/AA/typeCode/TECI")
				.contentType(MediaType.APPLICATION_JSON)
				.content(typeEditDetailsJSON))
				.andDo(print())
				.andExpect(jsonPath("$['errorId']").isNotEmpty())
				.andExpect(jsonPath("$['timestamp']").isNotEmpty())
				.andExpect(jsonPath("$['error']").value("Bad Request"))
				.andExpect(jsonPath("$['errorCode']").value("BAD_REQUEST"))
				.andExpect(jsonPath("$['details'][0]").value("Value '-1' for typeEditDetailsDTO.lowAge is invalid: must be greater than or equal to 0"))
				.andExpect(status().isBadRequest());
	}
	
	@SneakyThrows
	@Test
	public void update_type_edit_should_return_status_bad_request_and_returns_proper_message_when_valid_input_data_when_invalid_lowage_max_value() {

		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTOWithAllMandatoryFields();
		typeEditDetailsDTO.setLowAge(9999);
		
		String typeEditDetailsJSON = convertTypeEditDetailsDTOObjectToJsonString(typeEditDetailsDTO);

		doNothing().when(requestValidator).validateTypeEditDetailsDTO(typeEditDetailsDTO);
		
		this.mockMvc.perform(patch("/v1/typedit/benefitCategory/12/benefitNumber/12345/causeCode/AA/typeCode/TECI")
				.contentType(MediaType.APPLICATION_JSON)
				.content(typeEditDetailsJSON))
				.andDo(print())
				.andExpect(jsonPath("$['errorId']").isNotEmpty())
				.andExpect(jsonPath("$['timestamp']").isNotEmpty())
				.andExpect(jsonPath("$['error']").value("Bad Request"))
				.andExpect(jsonPath("$['errorCode']").value("BAD_REQUEST"))
				.andExpect(jsonPath("$['details'][0]").value("Value '9,999' for typeEditDetailsDTO.lowAge is invalid: must be less than or equal to 999"))
				.andExpect(status().isBadRequest());
	}
	
	@SneakyThrows
	@Test
	public void update_type_edit_should_return_status_bad_request_and_returns_proper_message_when_valid_input_data_when_invalid_highage_min_value() {

		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTOWithAllMandatoryFields();
		typeEditDetailsDTO.setHighAge(-1);
		
		String typeEditDetailsJSON = convertTypeEditDetailsDTOObjectToJsonString(typeEditDetailsDTO);

		doNothing().when(requestValidator).validateTypeEditDetailsDTO(typeEditDetailsDTO);
		
		this.mockMvc.perform(patch("/v1/typedit/benefitCategory/12/benefitNumber/12345/causeCode/AA/typeCode/TECI")
				.contentType(MediaType.APPLICATION_JSON)
				.content(typeEditDetailsJSON))
				.andDo(print())
				.andExpect(jsonPath("$['errorId']").isNotEmpty())
				.andExpect(jsonPath("$['timestamp']").isNotEmpty())
				.andExpect(jsonPath("$['error']").value("Bad Request"))
				.andExpect(jsonPath("$['errorCode']").value("BAD_REQUEST"))
				.andExpect(jsonPath("$['details'][0]").value("Value '-1' for typeEditDetailsDTO.highAge is invalid: must be greater than or equal to 0"))
				.andExpect(status().isBadRequest());
	}
	
	@SneakyThrows
	@Test
	public void update_type_edit_should_return_status_bad_request_and_returns_proper_message_when_valid_input_data_when_invalid_highage_max_value() {

		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTOWithAllMandatoryFields();
		typeEditDetailsDTO.setHighAge(9999);
		
		String typeEditDetailsJSON = convertTypeEditDetailsDTOObjectToJsonString(typeEditDetailsDTO);

		doNothing().when(requestValidator).validateTypeEditDetailsDTO(typeEditDetailsDTO);
		
		this.mockMvc.perform(patch("/v1/typedit/benefitCategory/12/benefitNumber/12345/causeCode/AA/typeCode/TECI")
				.contentType(MediaType.APPLICATION_JSON)
				.content(typeEditDetailsJSON))
				.andDo(print())
				.andExpect(jsonPath("$['errorId']").isNotEmpty())
				.andExpect(jsonPath("$['timestamp']").isNotEmpty())
				.andExpect(jsonPath("$['error']").value("Bad Request"))
				.andExpect(jsonPath("$['errorCode']").value("BAD_REQUEST"))
				.andExpect(jsonPath("$['details'][0]").value("Value '9,999' for typeEditDetailsDTO.highAge is invalid: must be less than or equal to 999"))
				.andExpect(status().isBadRequest());
	}
	
	@SneakyThrows
	@Test
	public void update_type_edit_should_return_status_bad_request_and_returns_proper_message_when_valid_input_data_when_invalid_placeoftreatment_length() {

		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTOWithAllMandatoryFields();
		
		TypeEditDetailsPlaceOfTreatmentCodesDTO typeEditDetailsPlaceOfTreatmentCodesDTO = new TypeEditDetailsPlaceOfTreatmentCodesDTO();
		typeEditDetailsPlaceOfTreatmentCodesDTO.setPlaceOfTreatment("placeOfTreatment");
		
		List<TypeEditDetailsPlaceOfTreatmentCodesDTO> placeOfTreatmentCodes = new ArrayList<>();
		placeOfTreatmentCodes.add(typeEditDetailsPlaceOfTreatmentCodesDTO);
		typeEditDetailsDTO.setPlaceOfTreatmentCodes(placeOfTreatmentCodes);
		
		String typeEditDetailsJSON = convertTypeEditDetailsDTOObjectToJsonString(typeEditDetailsDTO);

		doNothing().when(requestValidator).validateTypeEditDetailsDTO(typeEditDetailsDTO);
		
		this.mockMvc.perform(patch("/v1/typedit/benefitCategory/12/benefitNumber/12345/causeCode/AA/typeCode/TECI")
				.contentType(MediaType.APPLICATION_JSON)
				.content(typeEditDetailsJSON))
				.andDo(print())
				.andExpect(jsonPath("$['errorId']").isNotEmpty())
				.andExpect(jsonPath("$['timestamp']").isNotEmpty())
				.andExpect(jsonPath("$['error']").value("Bad Request"))
				.andExpect(jsonPath("$['errorCode']").value("BAD_REQUEST"))
				.andExpect(jsonPath("$['details'][0]").value("Value 'placeOfTreatment' for typeEditDetailsDTO.placeOfTreatmentCodes[0].placeOfTreatment is invalid: size must be between 1 and 1"))
				.andExpect(status().isBadRequest());
	}
	
	@SneakyThrows
	@Test
	public void update_type_edit_should_return_status_bad_request_and_returns_proper_message_when_valid_input_data_when_invalid_providertypes_length() {

		TypeEditDetailsDTO typeEditDetailsDTO = createTypeEditDetailsDTOWithAllMandatoryFields();
		List<String> providerTypes = new ArrayList<>();
		providerTypes.add("abcd");
		typeEditDetailsDTO.setProviderTypes(providerTypes);
		
		String typeEditDetailsJSON = convertTypeEditDetailsDTOObjectToJsonString(typeEditDetailsDTO);

		doThrow(new TypeEditConstraintViolationException("Value 'abcd' for typeEditDetailsDTO.providerTypes[0] is invalid: size must be between 2 and 2")).when(requestValidator).validateTypeEditDetailsDTO(typeEditDetailsDTO);
		
		this.mockMvc.perform(patch("/v1/typedit/benefitCategory/12/benefitNumber/12345/causeCode/AA/typeCode/TECI")
				.contentType(MediaType.APPLICATION_JSON)
				.content(typeEditDetailsJSON))
				.andDo(print())
				.andExpect(jsonPath("$['errorId']").isNotEmpty())
				.andExpect(jsonPath("$['timestamp']").isNotEmpty())
				.andExpect(jsonPath("$['error']").value("Bad Request"))
				.andExpect(jsonPath("$['errorCode']").value("BAD_REQUEST"))
				.andExpect(jsonPath("$['details'][0]").value("Value 'abcd' for typeEditDetailsDTO.providerTypes[0] is invalid: size must be between 2 and 2"))
				.andExpect(status().isBadRequest());
	}
	
	private InlineObjectDTO createValidInlineObjectDTOWithAllMandatoryFields() {
		InlineObjectDTO inlineObject = new InlineObjectDTO();	
		inlineObject.setBenefitCategory("01");
		inlineObject.setBenefitNumber("12345");
		inlineObject.setCauseCode("CD1");
		inlineObject.setTypeCode("typCd");
		TypeEditDetailsDTO typeEditDetails = createTypeEditDetailsDTOWithAllMandatoryFields();
		inlineObject.setTypEditBody(typeEditDetails);
		return inlineObject;
	}

	private TypeEditDetailsDTO createTypeEditDetailsDTOWithAllMandatoryFields() {
		TypeEditDetailsDTO typeEditDetails = new TypeEditDetailsDTO();
		typeEditDetails.setBypassLCD("bypassLCD");
		typeEditDetails.setHighAge(10);
		typeEditDetails.setLastModifiedBy("user");
		typeEditDetails.setLastModifiedDateTime(OffsetDateTime.of(LocalDate.of(2020, Month.AUGUST, 05).atStartOfDay(), ZoneOffset.UTC));
		List<TypeEditDetailsPlaceOfTreatmentCodesDTO> placeOfTreatmentCodes = new  ArrayList<>();
		TypeEditDetailsPlaceOfTreatmentCodesDTO TypeEditDetailsDTOpotc = new TypeEditDetailsPlaceOfTreatmentCodesDTO();
		TypeEditDetailsDTOpotc.setPlaceOfTreatment("p");
		TypeEditDetailsDTOpotc.setPlanloadPlaceOfTreatment("t");
		placeOfTreatmentCodes.add(TypeEditDetailsDTOpotc);		
		typeEditDetails.setPlaceOfTreatmentCodes(placeOfTreatmentCodes);
		List<String> providerTypes = new  ArrayList<>();
		providerTypes.add("abc");
		typeEditDetails.setProviderTypes(providerTypes);
		typeEditDetails.setLowAge(10);
		typeEditDetails.setSex("f");
		return typeEditDetails;
	}

	@SneakyThrows
	private String convertTypeEditDetailsDTOObjectToJsonString(TypeEditDetailsDTO typeEditDetails) {
		ObjectMapper objectMapper = createObjectMapper();
		return objectMapper.writeValueAsString(typeEditDetails);
	}
	
	@SneakyThrows
	private String convertDTOObjectToJsonString(InlineObjectDTO inlineObject) {
		ObjectMapper objectMapper = createObjectMapper();
		String inlineObjectJson = objectMapper.writeValueAsString(inlineObject);
		return inlineObjectJson;
	}

	@SneakyThrows
	private final ObjectMapper createObjectMapper() {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
		objectMapper.registerModule(new JavaTimeModule());
		return objectMapper;
	}	
}
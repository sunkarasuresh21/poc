package com.humana.claims.hcaas.typeedit.restapi.exception;

public class TypeEditConstraintViolationException extends Exception {

	private static final long serialVersionUID = -7931938202020685347L;

	public TypeEditConstraintViolationException(String message) {
		super(message);
	}
}

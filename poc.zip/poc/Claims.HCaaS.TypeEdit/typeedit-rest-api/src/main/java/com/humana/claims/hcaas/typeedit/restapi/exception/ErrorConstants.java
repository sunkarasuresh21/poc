package com.humana.claims.hcaas.typeedit.restapi.exception;

public class ErrorConstants {

	private ErrorConstants() {

	}
	
	public static final String ERROR_ID = "ErrorId: ";
	 
}
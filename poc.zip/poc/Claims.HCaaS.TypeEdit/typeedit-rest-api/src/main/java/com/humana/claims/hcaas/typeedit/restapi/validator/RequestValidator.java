package com.humana.claims.hcaas.typeedit.restapi.validator;

import com.humana.claims.hcaas.typeedit.restapi.exception.TypeEditConstraintViolationException;
import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.model.TypeEditDetailsDTO;

public interface RequestValidator {

	void validateTypeEditDetailsDTO(TypeEditDetailsDTO typeEditDetailsDTO) throws TypeEditConstraintViolationException;
}

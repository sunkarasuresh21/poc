package com.humana.claims.hcaas.typeedit.restapi.mapper.impl;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.stereotype.Component;

import com.humana.claims.hcaas.typeedit.core.model.PlaceOfTreatmentCodes;
import com.humana.claims.hcaas.typeedit.core.model.Teci;
import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.model.InlineObjectDTO;
import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.model.TypeEditDetailsDTO;
import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.model.TypeEditDetailsPlaceOfTreatmentCodesDTO;
import com.humana.claims.hcaas.typeedit.restapi.mapper.TypeEditMapper;

@Component
public class TypeEditMapperImpl implements TypeEditMapper {

	@Override
	public Teci mapInlineObjectDTOToTECI(InlineObjectDTO inlineObject) {
		Teci teci = new Teci();
		teci.setLastModifiedDateTime(LocalDateTime.now().toInstant(ZoneOffset.UTC));
		mapTeciFromInlineObject(teci, inlineObject);
		return teci;
	}

	private void mapTeciFromInlineObject(Teci teci, InlineObjectDTO inlineObject) {
		if(null != inlineObject) {
			teci.setBenefitCategory(inlineObject.getBenefitCategory());
			teci.setBenefitNumber(inlineObject.getBenefitNumber());
			teci.setTypeCode(inlineObject.getTypeCode());
			teci.setCauseCode(inlineObject.getCauseCode());
			
			mapTeciDataFromInlineObjectTypEditBody(teci, inlineObject.getTypEditBody());
		}
	}
	
	@Override
	public Teci mapTypeEditDetailsDTOToTeci(TypeEditDetailsDTO typeEditDetailsDTO) {
		Teci teci = new Teci();
		mapTeciDataFromInlineObjectTypEditBody(teci , typeEditDetailsDTO);
		teci.setLastModifiedDateTime(LocalDateTime.now().toInstant(ZoneOffset.UTC));
		return teci;
	}

	private void mapTeciDataFromInlineObjectTypEditBody(Teci teci, TypeEditDetailsDTO typeEditDetailsDTO) {
		if(null != typeEditDetailsDTO) {
			teci.setLowAge(typeEditDetailsDTO.getLowAge());
			teci.setHighAge(typeEditDetailsDTO.getHighAge());
			teci.setSex(typeEditDetailsDTO.getSex());
			teci.setBypassLcd(typeEditDetailsDTO.getBypassLCD());
			teci.setLastModifiedBy(typeEditDetailsDTO.getLastModifiedBy());
			
			if(null != typeEditDetailsDTO.getProviderTypes()) {
				List<String> providerTypes = typeEditDetailsDTO.getProviderTypes().stream()
							.filter(Objects::nonNull)
							.collect(Collectors.toList());
				teci.setProviderTypes(providerTypes);
			}	
			if(null != typeEditDetailsDTO.getPlaceOfTreatmentCodes()) {
				teci.setPlaceOfTreatmentCodes(mapTypeEditDetailsPlaceOfTreatmentCodesToTeciPlaceOfTreatmentCodes(typeEditDetailsDTO.getPlaceOfTreatmentCodes()));
			}
		}
	}

	private List<PlaceOfTreatmentCodes> mapTypeEditDetailsPlaceOfTreatmentCodesToTeciPlaceOfTreatmentCodes(
				List<TypeEditDetailsPlaceOfTreatmentCodesDTO> typeEditDetailsPlaceOfTreatmentCodes) {
		return Optional.ofNullable(typeEditDetailsPlaceOfTreatmentCodes)
				.map(Collection::stream)
				.orElseGet(Stream::empty)
				.filter(Objects::nonNull)
				.map(this::mapTypeEditDetailsPlaceOfTreatmentCodesToPlaceOfTreatmentCodes)
				.collect(Collectors.toList());
	}

	private PlaceOfTreatmentCodes mapTypeEditDetailsPlaceOfTreatmentCodesToPlaceOfTreatmentCodes(TypeEditDetailsPlaceOfTreatmentCodesDTO typeEditPlaceOfTreatmentCodes) {
		PlaceOfTreatmentCodes placeOfTreatmentCodes = new PlaceOfTreatmentCodes();
		placeOfTreatmentCodes.setClaimsPot(typeEditPlaceOfTreatmentCodes.getPlaceOfTreatment());
		placeOfTreatmentCodes.setPlanLoadPot(typeEditPlaceOfTreatmentCodes.getPlanloadPlaceOfTreatment());
		return placeOfTreatmentCodes;
	}
	
	@Override
	public TypeEditDetailsDTO mapTECIToTypeEditDetailsDTO(Teci teci) {
		TypeEditDetailsDTO typeEditDetailsDTO = new TypeEditDetailsDTO();
		if(null != teci) {
			typeEditDetailsDTO.setBypassLCD(teci.getBypassLcd());
			typeEditDetailsDTO.setHighAge(teci.getHighAge());
			typeEditDetailsDTO.setLowAge(teci.getLowAge());
			typeEditDetailsDTO.setLastModifiedBy(teci.getLastModifiedBy());
			typeEditDetailsDTO.setLastModifiedDateTime(null == teci.getLastModifiedDateTime() ? null : teci.getLastModifiedDateTime().atOffset(ZoneOffset.UTC));
			typeEditDetailsDTO.setSex(teci.getSex());
			typeEditDetailsDTO.setProviderTypes(teci.getProviderTypes());
			typeEditDetailsDTO.setPlaceOfTreatmentCodes(null == teci.getPlaceOfTreatmentCodes() ? null : mapPlaceOfTreatmentCodes(teci.getPlaceOfTreatmentCodes()));
		}

		return typeEditDetailsDTO;
	}
	
	private List<TypeEditDetailsPlaceOfTreatmentCodesDTO> mapPlaceOfTreatmentCodes(List<PlaceOfTreatmentCodes> placeOfTreatmentCodes) {
		return Optional.ofNullable(placeOfTreatmentCodes)
				.map(Collection::stream)
				.orElseGet(Stream::empty)
				.filter(Objects::nonNull)
				.map(this::mapPlaceOfTreatmentCode)
				.collect(Collectors.toList());
	}

	private TypeEditDetailsPlaceOfTreatmentCodesDTO mapPlaceOfTreatmentCode(PlaceOfTreatmentCodes placeOfTreatmentCodes) {
		TypeEditDetailsPlaceOfTreatmentCodesDTO placeOfTreatmentCodesDTO = new TypeEditDetailsPlaceOfTreatmentCodesDTO();
		placeOfTreatmentCodesDTO.setPlaceOfTreatment(placeOfTreatmentCodes.getClaimsPot());
		placeOfTreatmentCodesDTO.setPlanloadPlaceOfTreatment(placeOfTreatmentCodes.getPlanLoadPot());
		return placeOfTreatmentCodesDTO;
	}
}
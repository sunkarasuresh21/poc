package com.humana.claims.hcaas.typeedit.restapi.service;


import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditConflictException;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditNotFoundException;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditUpdateException;
import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.model.InlineObjectDTO;
import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.model.TypeEditDetailsDTO;

public interface TypeEditService {

	void createTypeEdit(InlineObjectDTO inlineObject) throws TypeEditConflictException;

	TypeEditDetailsDTO getTypeEditByBenefitCategoryBenefitNumberCauseCodeAndTypeCode(String benefitCategory, String benefitNumber, String causeCode, String typeCode) throws TypeEditNotFoundException;
	
	void updateTypeEdit(String benefitCategory, String benefitNumber, String causeCode, String typeCode, TypeEditDetailsDTO typeEditDetails) throws TypeEditUpdateException, TypeEditNotFoundException;
}

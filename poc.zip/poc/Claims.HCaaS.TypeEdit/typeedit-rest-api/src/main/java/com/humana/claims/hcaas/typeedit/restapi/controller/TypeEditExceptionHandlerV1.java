/*
* Copyright (C) Humana - All Rights Reserved
*
* Unauthorized copying of this file, via any medium is strictly prohibited
* Proprietary and confidential
*
* Written by Shridutt Kothari <skothari1@humana.com>, November 2021
*/
package com.humana.claims.hcaas.typeedit.restapi.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.humana.claims.hcaas.common.rest.api.starter.enumerrorcode.ErrorCode;
import com.humana.claims.hcaas.common.rest.api.starter.exceptionhandling.AbstractSpringControllerExceptionHandler;
import com.humana.claims.hcaas.common.rest.api.starter.exceptionhandling.ErrorResponseDTO;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditConflictException;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditNotFoundException;
import com.humana.claims.hcaas.typeedit.restapi.exception.TypeEditConstraintViolationException;

@ControllerAdvice
public class TypeEditExceptionHandlerV1 extends AbstractSpringControllerExceptionHandler {
	
	@ExceptionHandler(TypeEditConflictException.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleTypeEditConflictException(TypeEditConflictException ex) {
		return respondWith(ex, HttpStatus.CONFLICT, ex.getMessage(), ErrorCode.CONFLICT);
	}
	
	@ExceptionHandler(TypeEditNotFoundException.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleTypeEditNotFoundException(TypeEditNotFoundException ex) {
		return respondWith(ex, HttpStatus.BAD_REQUEST, ex.getMessage(), ErrorCode.NOT_FOUND);
	}
	
	@ExceptionHandler(TypeEditConstraintViolationException.class)
	public @ResponseBody ResponseEntity<ErrorResponseDTO> handleTypeEditConstraintViolationException(TypeEditConstraintViolationException ex) {
		return respondWith(ex, HttpStatus.BAD_REQUEST, ex.getMessage(), ErrorCode.BAD_REQUEST);
	}
}
package com.humana.claims.hcaas.typeedit.restapi;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.humana.claims.hcaas.common.spring.boot.starter.HcaasSpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.humana.claims.hcaas.typeedit")
@EnableAutoConfiguration
public class TypeEditApplication {

	public static void main(String[] args) {
		HcaasSpringBootApplication.run(TypeEditApplication.class, args);
	}

}
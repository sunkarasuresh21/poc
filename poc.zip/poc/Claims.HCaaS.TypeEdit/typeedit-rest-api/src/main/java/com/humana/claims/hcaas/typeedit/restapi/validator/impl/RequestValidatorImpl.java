package com.humana.claims.hcaas.typeedit.restapi.validator.impl;

import java.util.List;

import org.springframework.stereotype.Component;

import com.humana.claims.hcaas.typeedit.restapi.exception.TypeEditConstraintViolationException;
import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.model.TypeEditDetailsDTO;
import com.humana.claims.hcaas.typeedit.restapi.validator.RequestValidator;

@Component
public class RequestValidatorImpl implements RequestValidator {

	private static final int PROVIDER_TYPE_LENGTH = 2;
	
	@Override
	public void validateTypeEditDetailsDTO(TypeEditDetailsDTO typeEditDetailsDTO)
			throws TypeEditConstraintViolationException {
		validateProviderTypes(typeEditDetailsDTO);
	}

	private void validateProviderTypes(TypeEditDetailsDTO typeEditDetailsDTO) throws TypeEditConstraintViolationException {
		List<String> providerTypes = typeEditDetailsDTO.getProviderTypes();
		if (null != providerTypes) {
			for (int index = 0; index < providerTypes.size(); index++) {
				String providerType = providerTypes.get(index);
				if (null != providerType && providerType.length() != PROVIDER_TYPE_LENGTH) {
					throw new TypeEditConstraintViolationException("Value '" + providerType + "' for typeEditDetailsDTO.providerTypes[" + index + "] is invalid: size must be between "+ PROVIDER_TYPE_LENGTH+" and " + PROVIDER_TYPE_LENGTH);
				}
			}
		}
	}
}
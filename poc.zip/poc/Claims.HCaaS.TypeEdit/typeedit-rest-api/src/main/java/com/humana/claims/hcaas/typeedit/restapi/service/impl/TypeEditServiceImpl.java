package com.humana.claims.hcaas.typeedit.restapi.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.humana.claims.hcaas.typeedit.core.dao.TeciDAO;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditConflictException;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditNotFoundException;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditUpdateException;
import com.humana.claims.hcaas.typeedit.core.model.Teci;
import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.model.InlineObjectDTO;
import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.model.TypeEditDetailsDTO;
import com.humana.claims.hcaas.typeedit.restapi.mapper.TypeEditMapper;
import com.humana.claims.hcaas.typeedit.restapi.service.TypeEditService;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@Service
public class TypeEditServiceImpl implements TypeEditService {

	@Autowired
	private TeciDAO teciDAO;

	@Autowired
	private TypeEditMapper typeEditMapper;

	@Override
	public void createTypeEdit(InlineObjectDTO inlineObject) throws TypeEditConflictException {
		Teci teci = typeEditMapper.mapInlineObjectDTOToTECI(inlineObject);		
		teciDAO.saveTeci(teci);
	}

	@Override
	public TypeEditDetailsDTO getTypeEditByBenefitCategoryBenefitNumberCauseCodeAndTypeCode(String benefitCategory,
			String benefitNumber, String causeCode, String typeCode) throws TypeEditNotFoundException {
		Teci teci = teciDAO.fetchTECI(benefitCategory, benefitNumber, typeCode, causeCode);
		return typeEditMapper.mapTECIToTypeEditDetailsDTO(teci);
	}

	@Override
	public void updateTypeEdit(String benefitCategory, String benefitNumber, String causeCode, String typeCode,
			TypeEditDetailsDTO typeEditDetails) throws TypeEditUpdateException, TypeEditNotFoundException {
		Teci teci = typeEditMapper.mapTypeEditDetailsDTOToTeci(typeEditDetails);
		teci.setBenefitCategory(benefitCategory);
		teci.setBenefitNumber(benefitNumber);
		teci.setCauseCode(causeCode);
		teci.setTypeCode(typeCode);
		
		teciDAO.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode(benefitCategory, benefitNumber, causeCode, typeCode, teci);
	}
}
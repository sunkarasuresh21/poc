package com.humana.claims.hcaas.typeedit.restapi.controller;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.V1Api;
import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.model.InlineObjectDTO;
import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.model.TypeEditDetailsDTO;
import com.humana.claims.hcaas.typeedit.restapi.service.TypeEditService;
import com.humana.claims.hcaas.typeedit.restapi.validator.RequestValidator;

@RestController
public class TypeEditControllerV1 implements V1Api {
	
	@Autowired
	private TypeEditService typeEditService;
	
	@Autowired
	private RequestValidator requestValidator;

	@Override
	public ResponseEntity<Void> createTypeEdit(@Valid InlineObjectDTO inlineObject) throws Exception {
		typeEditService.createTypeEdit(inlineObject);
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}
	
	@Override
	public ResponseEntity<TypeEditDetailsDTO> getTypeEdit(@Pattern(regexp="^[0-9]{2}$") @PathVariable("benefitCategory") String benefitCategory,
			@Pattern(regexp="^[0-9]{5}$") @PathVariable("benefitNumber") String benefitNumber,
			@Pattern(regexp="^[0-9A-Z]+$") @Size(min=2,max=5) @PathVariable("causeCode") String causeCode,	
			@Size(min=2,max=6) @PathVariable("typeCode") String typeCode) throws Exception {
		TypeEditDetailsDTO typeEditDetails = typeEditService.getTypeEditByBenefitCategoryBenefitNumberCauseCodeAndTypeCode(benefitCategory, benefitNumber, causeCode, typeCode);
		return ResponseEntity.ok(typeEditDetails);
    }
	
	@Override
	public ResponseEntity<Void> updateTypeEdit(@Pattern(regexp = "^[0-9]{2}$") String benefitCategory,
			@Pattern(regexp = "^[0-9]{5}$") String benefitNumber,
			@Pattern(regexp = "^[0-9A-Z]+$") @Size(min = 2, max = 5) String causeCode,
			@Size(min = 2, max = 6) String typeCode, @Valid TypeEditDetailsDTO typeEditDetailsDTO) throws Exception {
		requestValidator.validateTypeEditDetailsDTO(typeEditDetailsDTO);
		typeEditService.updateTypeEdit(benefitCategory, benefitNumber, causeCode, typeCode, typeEditDetailsDTO);
		return ResponseEntity.status(HttpStatus.OK).build(); 		
	}
}
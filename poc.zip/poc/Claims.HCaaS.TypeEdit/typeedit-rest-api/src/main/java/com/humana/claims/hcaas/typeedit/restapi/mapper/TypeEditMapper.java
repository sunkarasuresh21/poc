package com.humana.claims.hcaas.typeedit.restapi.mapper;

import com.humana.claims.hcaas.typeedit.core.model.Teci;
import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.model.InlineObjectDTO;
import com.humana.claims.hcaas.typeedit.restapi.gen.api.v1.model.TypeEditDetailsDTO;

public interface TypeEditMapper {
	
	Teci mapInlineObjectDTOToTECI(InlineObjectDTO inlineObject);
	
	TypeEditDetailsDTO mapTECIToTypeEditDetailsDTO(Teci teci);

	Teci mapTypeEditDetailsDTOToTeci(TypeEditDetailsDTO typeEditDetailsDTO);
}

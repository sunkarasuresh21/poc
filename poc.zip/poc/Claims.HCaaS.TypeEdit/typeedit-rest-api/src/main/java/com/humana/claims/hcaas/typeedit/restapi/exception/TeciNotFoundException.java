package com.humana.claims.hcaas.typeedit.restapi.exception;

public class TeciNotFoundException extends Exception{
	
	private static final long serialVersionUID = -8254777870227632511L;
	private static final String TECI_RECORD_NOT_FOUND = "Teci record not found";

	public TeciNotFoundException(){
		super(TECI_RECORD_NOT_FOUND);
	}

}

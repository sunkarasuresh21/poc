package com.humana.claims.hcaas.typeedit.core.dao.impl;

import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.humana.claims.hcaas.typeedit.core.constants.TypeEditCommonConstants;
import com.humana.claims.hcaas.typeedit.core.constants.TypeEditDBConstants;
import com.humana.claims.hcaas.typeedit.core.dao.TeciDAO;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditConflictException;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditNotFoundException;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditUpdateException;
import com.humana.claims.hcaas.typeedit.core.model.Teci;
import com.mongodb.client.result.UpdateResult;

@Repository
public class TeciDAOImpl implements TeciDAO {
	
	private MongoTemplate mongoTemplate;

	@Autowired
	public TeciDAOImpl(MongoTemplate mongoTemplate) {
		this.mongoTemplate = mongoTemplate;
	}

	@Override
	public Teci fetchTECI(String benefitCategory, String benefitNumber, String typeCode, String causeCode) throws TypeEditNotFoundException {
		Query query = new Query();
		query.addCriteria(Criteria.where(TypeEditDBConstants.BENEFIT_CATEGORY).is(benefitCategory));
		query.addCriteria(Criteria.where(TypeEditDBConstants.BENEFIT_NUMBER).is(benefitNumber));
		query.addCriteria(Criteria.where(TypeEditDBConstants.TYPE_CODE).is(typeCode));
		query.addCriteria(Criteria.where(TypeEditDBConstants.CAUSE_CODE).is(causeCode));

		Teci teciFromDB = mongoTemplate.findOne(query, Teci.class, TypeEditDBConstants.COLLECTION_TECI);
		if(null == teciFromDB) throw new TypeEditNotFoundException();
		return teciFromDB;
	}

	@Override
	public Teci saveTeci(Teci teci) throws TypeEditConflictException {
		try {
			fetchTECI(teci.getBenefitCategory(), teci.getBenefitNumber(), teci.getTypeCode(), teci.getCauseCode());
			throw new TypeEditConflictException();
		} catch (TypeEditNotFoundException typeEditNotFoundException) {
			return mongoTemplate.save(teci, TypeEditDBConstants.COLLECTION_TECI);
		}
	}

	@Override
	public boolean upsertTeci(Teci teci) {
		Document doc = new Document();
		mongoTemplate.getConverter().write(teci, doc);
		Query query = new Query();
		query.addCriteria(Criteria.where(TypeEditDBConstants.BENEFIT_CATEGORY).is(teci.getBenefitCategory()));
		query.addCriteria(Criteria.where(TypeEditDBConstants.BENEFIT_NUMBER).is(teci.getBenefitNumber()));
		query.addCriteria(Criteria.where(TypeEditDBConstants.TYPE_CODE).is(teci.getTypeCode()));
		query.addCriteria(Criteria.where(TypeEditDBConstants.CAUSE_CODE).is(teci.getCauseCode()));
		UpdateResult updateResult = mongoTemplate.upsert(query, Update.fromDocument(doc), TypeEditDBConstants.COLLECTION_TECI);
		return updateResult.wasAcknowledged();
	}
	
	@Override
	public boolean updateTECIByKey(Teci teciDetails) {
		Document doc = new Document();
		mongoTemplate.getConverter().write(teciDetails, doc);
		Query query = new Query(
				Criteria.where(TypeEditDBConstants.BENEFIT_CATEGORY).is(teciDetails.getBenefitCategory()));
		query.addCriteria(Criteria.where(TypeEditDBConstants.BENEFIT_NUMBER).is(teciDetails.getBenefitNumber()));
		query.addCriteria(
				Criteria.where(TypeEditDBConstants.TYPE_CODE).is(teciDetails.getTypeCode()));
		query.addCriteria(Criteria.where(TypeEditDBConstants.CAUSE_CODE).is(teciDetails.getCauseCode()));
		UpdateResult updateResult = mongoTemplate.upsert(query, Update.fromDocument(doc),
				TypeEditDBConstants.COLLECTION_TECI);
		return updateResult.getUpsertedId() != null;
	}

	@Override
	public Teci updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode(String benefitCategory,
			String benefitNumber, String causeCode, String typeCode, Teci teci)
			throws TypeEditUpdateException, TypeEditNotFoundException {
		if(null == teci.getBenefitCategory() || !teci.getBenefitCategory().equals(benefitCategory)) {
			throw new TypeEditUpdateException(TypeEditCommonConstants.BENEFIT_CATEGORY_NOT_ALLOWED_TO_BE_MODIFIED);
		}
		if(null == teci.getBenefitNumber() || !teci.getBenefitNumber().equals(benefitNumber)) {
			throw new TypeEditUpdateException(TypeEditCommonConstants.BENEFIT_NUMBER_NOT_ALLOWED_TO_BE_MODIFIED);
		}
		if(null == teci.getCauseCode() || !teci.getCauseCode().equals(causeCode)) {
			throw new TypeEditUpdateException(TypeEditCommonConstants.CAUSE_CODE_NOT_ALLOWED_TO_BE_MODIFIED);
		}
		if(null == teci.getTypeCode() || !teci.getTypeCode().equals(typeCode)) {
			throw new TypeEditUpdateException(TypeEditCommonConstants.TYPE_CODE_NOT_ALLOWED_TO_BE_MODIFIED);
		}
		
		Query query = new Query();
		Criteria groupSubgroupCriteria = new Criteria()
				.andOperator(
					Criteria.where(TypeEditDBConstants.BENEFIT_CATEGORY).is(benefitCategory),
					Criteria.where(TypeEditDBConstants.BENEFIT_NUMBER).is(benefitNumber),
					Criteria.where(TypeEditDBConstants.CAUSE_CODE).is(causeCode),
					Criteria.where(TypeEditDBConstants.TYPE_CODE).is(typeCode)
				);
		query.addCriteria(groupSubgroupCriteria);
		Update updateObj = TeciDAOHelper.getMongoUpdateObjForTeci(teci);
		Teci teciUpdated = mongoTemplate.findAndModify(query, updateObj, new FindAndModifyOptions().returnNew(true).upsert(false), Teci.class, TypeEditDBConstants.COLLECTION_TECI);
		if(null == teciUpdated) {
			throw new TypeEditNotFoundException();
		}
		return teciUpdated;
	}
}

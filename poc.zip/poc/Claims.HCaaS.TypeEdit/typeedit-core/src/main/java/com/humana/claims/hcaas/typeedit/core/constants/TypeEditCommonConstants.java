package com.humana.claims.hcaas.typeedit.core.constants;

public class TypeEditCommonConstants {
	
	private TypeEditCommonConstants() {

	}
	
	public static final String NO_TYPE_EDIT_FOUND_MATCHING_INPUT_CRITERIA = "No TypeEdit record found matching input criteria";
	public static final String CONFLICT_MATCHING_INPUT_CRITERIA = "A TypeEdit record already exists for this key";
	public static final String INVALID_REQUEST = "Invalid request code";
	public static final String BENEFIT_CATEGORY_NOT_ALLOWED_TO_BE_MODIFIED = "BenefitCategory not allowed to be modified";
	public static final String BENEFIT_NUMBER_NOT_ALLOWED_TO_BE_MODIFIED = "BenefitNumber not allowed to be modified";
	public static final String CAUSE_CODE_NOT_ALLOWED_TO_BE_MODIFIED = "CauseCode not allowed to be modified";
	public static final String TYPE_CODE_NOT_ALLOWED_TO_BE_MODIFIED = "TypeCode not allowed to be modified";
	
}

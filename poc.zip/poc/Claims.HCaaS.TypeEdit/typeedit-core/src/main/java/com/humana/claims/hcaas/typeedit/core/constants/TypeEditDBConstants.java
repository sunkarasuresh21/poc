package com.humana.claims.hcaas.typeedit.core.constants;

public class TypeEditDBConstants {
	
	private TypeEditDBConstants() {
		
	}
	
	public static final String COLLECTION_TECI = "TypeEdit";
	
	public static final String CAUSE_CODE = "causeCode";
	public static final String TYPE_CODE = "typeCode";
	public static final String BENEFIT_NUMBER = "benefitNumber";
	public static final String BENEFIT_CATEGORY = "benefitCategory";
	public static final String BYPASS_LCD = "bypassLcd";
	public static final String LAST_MODIFIED_BY = "lastModifiedBy";
	public static final String LAST_MODIFIED_DATE_TIME = "lastModifiedDateTime";
	public static final String HIGH_AGE = "highAge";
	public static final String LOW_AGE = "lowAge";
	public static final String SEX = "sex";
	public static final String PROVIDER_TYPES = "providerTypes";
	public static final String PLACE_OF_TREATMENT_CODES = "placeOfTreatmentCodes";
}
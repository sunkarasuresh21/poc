package com.humana.claims.hcaas.typeedit.core.dao;

import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditConflictException;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditNotFoundException;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditUpdateException;
import com.humana.claims.hcaas.typeedit.core.model.Teci;

public interface TeciDAO {
	
	Teci fetchTECI(String benefitCategory, String benefitNumber, String typeCode, String causeCode) throws TypeEditNotFoundException;

	Teci saveTeci(Teci teci) throws TypeEditConflictException;

	boolean updateTECIByKey(Teci teciDetails);

	Teci updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode(String benefitCategory, String benefitNumber, String causeCode, String typeCode, Teci teci) throws TypeEditUpdateException, TypeEditNotFoundException;

	boolean upsertTeci(Teci teci);
}

package com.humana.claims.hcaas.typeedit.core.exceptions;

import com.humana.claims.hcaas.typeedit.core.constants.TypeEditCommonConstants;

public class TypeEditConflictException extends Exception {
	
	private static final long serialVersionUID = -9197714350046420845L;
	
	public TypeEditConflictException() {
		super(TypeEditCommonConstants.CONFLICT_MATCHING_INPUT_CRITERIA);
	}
	
}

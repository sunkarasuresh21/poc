package com.humana.claims.hcaas.typeedit.core.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class PlaceOfTreatmentCodes {
	
	@JsonProperty("claimsPot")
	private String claimsPot = null;

	@JsonProperty("planLoadPot")
	private String planLoadPot = null;

}

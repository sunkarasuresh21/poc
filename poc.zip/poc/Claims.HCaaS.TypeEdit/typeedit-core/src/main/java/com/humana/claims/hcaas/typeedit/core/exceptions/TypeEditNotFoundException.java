package com.humana.claims.hcaas.typeedit.core.exceptions;

import com.humana.claims.hcaas.typeedit.core.constants.TypeEditCommonConstants;

public class TypeEditNotFoundException extends Exception {
	
private static final long serialVersionUID = -7692849257719870411L;
	
	public TypeEditNotFoundException() {
		super(TypeEditCommonConstants.NO_TYPE_EDIT_FOUND_MATCHING_INPUT_CRITERIA);
	}

}

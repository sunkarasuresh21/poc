package com.humana.claims.hcaas.typeedit.core.exceptions;

public class TypeEditUpdateException extends Exception {

	private static final long serialVersionUID = 6438903580209683550L;

	public TypeEditUpdateException(String message) {
		super(message);
	}
}
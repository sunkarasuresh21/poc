package com.humana.claims.hcaas.typeedit.core.model;

import java.time.Instant;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class Teci {

	@JsonProperty("benefitCategory")
	private String benefitCategory = null;

	@JsonProperty("benefitNumber")
	private String benefitNumber = null;

	@JsonProperty("typeCode")
	private String typeCode = null;

	@JsonProperty("causeCode")
	private String causeCode = null;

	@JsonProperty("providerTypes")
	private List<String> providerTypes;

	@JsonProperty("placeOfTreatmentCodes")
	private List<PlaceOfTreatmentCodes> placeOfTreatmentCodes;

	@JsonProperty("lowAge")
	private Integer lowAge = null;

	@JsonProperty("highAge")
	private Integer highAge = null;

	@JsonProperty("sex")
	private String sex = null;

	@JsonProperty("bypassLcd")
	private String bypassLcd = null;

	@JsonProperty("lastModifiedBy")
	private String lastModifiedBy = null;
	
	@JsonProperty("lastModifiedDateTime")
	private Instant lastModifiedDateTime = null;

}
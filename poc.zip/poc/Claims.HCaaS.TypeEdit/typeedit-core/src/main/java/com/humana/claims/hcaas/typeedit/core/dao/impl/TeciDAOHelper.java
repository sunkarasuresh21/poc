package com.humana.claims.hcaas.typeedit.core.dao.impl;

import java.util.Collection;

import org.springframework.data.mongodb.core.query.Update;

import com.humana.claims.hcaas.typeedit.core.constants.TypeEditDBConstants;
import com.humana.claims.hcaas.typeedit.core.model.Teci;

public class TeciDAOHelper {

	private TeciDAOHelper() {

	}

	public static Update getMongoUpdateObjForTeci(Teci teci) {
		Update update = new Update();
		setIfNotNull(TypeEditDBConstants.SEX, teci.getSex(), update);
		setIfNotNull(TypeEditDBConstants.LOW_AGE, teci.getLowAge(), update);
		setIfNotNull(TypeEditDBConstants.HIGH_AGE, teci.getHighAge(), update);
		setIfNotNull(TypeEditDBConstants.LAST_MODIFIED_DATE_TIME, teci.getLastModifiedDateTime(), update);
		setIfNotNull(TypeEditDBConstants.LAST_MODIFIED_BY, teci.getLastModifiedBy(), update);
		setIfNotNull(TypeEditDBConstants.BYPASS_LCD, teci.getBypassLcd(), update);
		setIfNotNull(TypeEditDBConstants.TYPE_CODE, teci.getTypeCode(), update);
		setIfNotNull(TypeEditDBConstants.CAUSE_CODE, teci.getCauseCode(), update);
		setIfNotNull(TypeEditDBConstants.BENEFIT_NUMBER, teci.getBenefitNumber(), update);
		setIfNotNull(TypeEditDBConstants.BENEFIT_CATEGORY, teci.getBenefitCategory(), update);
		setIfNotNullAndNotEmpty(TypeEditDBConstants.PROVIDER_TYPES, teci.getProviderTypes(), update);
		setIfNotNullAndNotEmpty(TypeEditDBConstants.PLACE_OF_TREATMENT_CODES, teci.getPlaceOfTreatmentCodes(), update);

		return update;
	}

	private static void setIfNotNullAndNotEmpty(String key, Collection<?> collectionValue, Update update) {
		if (null != collectionValue && !collectionValue.isEmpty()) {
			update.set(key, collectionValue);
		}
	}

	private static void setIfNotNull(String key, Object value, Update update) {
		if (null != value) {
			update.set(key, value);
		}
	}
}

package com.humana.claims.hcaas.typeedit.core.dao;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import com.humana.claims.hcaas.typeedit.core.dao.impl.TeciDAOImpl;
import com.humana.claims.hcaas.typeedit.core.model.Teci;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
public class TeciDaoTest {

	@InjectMocks
	TeciDAOImpl teciDAOImpl;

	@Mock
	MongoTemplate mongoTemplate;

	@SneakyThrows
	@Test
	public void fetchTECITest() {
		String benefitCategory = "AC006";
		String benefitGroup = "group10";
		String causeCode = "CC1007";
		String planLoadTypeCode = "AHCD";
		Teci expected = createTeci();

		when(mongoTemplate.findOne(ArgumentMatchers.any(Query.class), ArgumentMatchers.<Class<Teci>>any(),
				ArgumentMatchers.any(String.class))).thenReturn(expected);
		
		Teci actual = teciDAOImpl.fetchTECI(benefitCategory, benefitGroup, planLoadTypeCode, causeCode);
		
		assertThat(actual).isNotNull();
		assertThat(actual.getBenefitCategory()).isEqualTo("AC006");
	}

	@SneakyThrows
	@Test
	public void saveTECITest() {
		Teci teciObj = createTeci();
		
		when(mongoTemplate.save(ArgumentMatchers.any(Teci.class), ArgumentMatchers.any(String.class))).thenReturn(teciObj);
		
		Teci teciActual = teciDAOImpl.saveTeci(teciObj);
		
		assertEquals("AC006", teciActual.getBenefitCategory());
	}
	
	private Teci createTeci() {
		Teci teci = new Teci();
		teci.setBenefitCategory("AC006");
		teci.setBenefitNumber("group10");
		teci.setCauseCode("CC1007");
		teci.setTypeCode("AHCD");
		
		return teci;
	}
}

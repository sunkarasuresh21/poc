package com.humana.claims.hcaas.typeedit.core.dao.impl;

import static com.humana.claims.hcaas.typeedit.core.constants.TypeEditDBConstants.COLLECTION_TECI;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;

import com.humana.claims.hcaas.common.test.spring.mongodb.ConfigureInMemoryMongoTestServer;
import com.humana.claims.hcaas.typeedit.core.constants.TypeEditDBConstants;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditConflictException;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditNotFoundException;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditUpdateException;
import com.humana.claims.hcaas.typeedit.core.model.PlaceOfTreatmentCodes;
import com.humana.claims.hcaas.typeedit.core.model.Teci;

import lombok.SneakyThrows;

@SpringBootTest(classes = TeciDAOImpl.class)
@ConfigureInMemoryMongoTestServer
public class TeciDaoImplIntTest {

	@Autowired
	private MongoTemplate mongoTemplate;

	@Autowired
	private TeciDAOImpl classUnderTest;

	@AfterEach
	public void dropCollection() {
		mongoTemplate.dropCollection(COLLECTION_TECI);
	}

	@SneakyThrows
	@Test
	public void fetch_teci_should_returns_record_if_record_in_database() {
		Teci original = createTeciObjectWithKeyFieldsOnly();
		mongoTemplate.save(original, COLLECTION_TECI);

		Teci actual = classUnderTest.fetchTECI(original.getBenefitCategory(), original.getBenefitNumber(), original.getTypeCode(), original.getCauseCode());

		assertThat(actual).isNotNull();
		assertThat(actual).usingRecursiveComparison().ignoringFields("id").isEqualTo(original);
	}

	@SneakyThrows
	@Test
	public void fetch_teci_should_returns_record_valid_record_if_all_criteria_mached() {
		Teci original = createTeciObjectWithKeyFieldsOnly();
		mongoTemplate.save(original, COLLECTION_TECI);

		Teci actual = classUnderTest.fetchTECI(original.getBenefitCategory(), original.getBenefitNumber(), original.getTypeCode(), original.getCauseCode());

		assertThat(actual).usingRecursiveComparison().ignoringFields("id").isEqualTo(original);
	}

	@Test
	public void fetch_teci_should_throw_type_edit_not_found_exception_if_no_record_in_database() {

		assertThatExceptionOfType(TypeEditNotFoundException.class).isThrownBy(() -> 
			classUnderTest.fetchTECI("benefitCategory", "benefitNumber", "typeCode", "causeCode")
		);
	}

	@Test
	public void fetch_teci_should_throw_type_edit_not_found_exception_if_benefit_category_does_not_match() {
		Teci teci = createTeciObjectWithKeyFieldsOnly();
		mongoTemplate.save(teci, COLLECTION_TECI);

		assertThatExceptionOfType(TypeEditNotFoundException.class).isThrownBy(() -> 
			classUnderTest.fetchTECI("123", teci.getBenefitNumber(), teci.getTypeCode(), teci.getCauseCode())
		);
	}

	@Test
	public void fetch_teci_should_throw_type_edit_not_found_exception_if_benefit_number_does_not_match() {
		Teci teci = createTeciObjectWithKeyFieldsOnly();
		mongoTemplate.save(teci, COLLECTION_TECI);

		assertThatExceptionOfType(TypeEditNotFoundException.class).isThrownBy(() -> 
			classUnderTest.fetchTECI(teci.getBenefitCategory(), "321", teci.getTypeCode(), teci.getCauseCode())
		);
	}

	@Test
	public void fetch_teci_should_throw_type_edit_not_found_exception_if_type_code_does_not_match() {
		Teci teci = createTeciObjectWithKeyFieldsOnly();
		mongoTemplate.save(teci, COLLECTION_TECI);

		assertThatExceptionOfType(TypeEditNotFoundException.class).isThrownBy(() -> 
			classUnderTest.fetchTECI(teci.getBenefitCategory(), teci.getBenefitNumber(), "typeCode01", teci.getCauseCode())
		);
	}

	@Test
	public void fetch_teci_should_throw_type_edit_not_found_exception_if_cause_code_does_not_match() {
		Teci teci = createTeciObjectWithKeyFieldsOnly();
		mongoTemplate.save(teci, COLLECTION_TECI);

		assertThatExceptionOfType(TypeEditNotFoundException.class).isThrownBy(() -> 
			classUnderTest.fetchTECI(teci.getBenefitCategory(), teci.getBenefitNumber(), teci.getTypeCode(), "AB12")
		);
	}

	@SneakyThrows
	@Test
	public void saveteci_creates_record_in_database() {
		Teci teciToCreate = createTeciObjectWithKeyFieldsOnly();

		Teci actual = classUnderTest.saveTeci(teciToCreate);

		Query query = prepareTeciQuery(teciToCreate.getBenefitCategory(), teciToCreate.getBenefitNumber(), teciToCreate.getTypeCode(), teciToCreate.getCauseCode());
		Collection<Teci> teciFetchedFromDB = mongoTemplate.find(query, Teci.class, TypeEditDBConstants.COLLECTION_TECI);

		assertThat(actual).isNotNull();
		assertThat(actual).usingRecursiveComparison().ignoringFields("id").isEqualTo(teciFetchedFromDB.stream().findFirst().get());
	}

	@SneakyThrows
	@Test
	public void saveteci_throw_type_edit_conflict_exception() {
		Teci teciToCreate = createTeciObjectWithKeyFieldsOnly();
		mongoTemplate.save(teciToCreate, COLLECTION_TECI);

		assertThatExceptionOfType(TypeEditConflictException.class).isThrownBy(() -> 
			classUnderTest.saveTeci(teciToCreate)
		);
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_throws_type_edit_update_exception_when_benefit_category_is_null() {
		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setBenefitCategory(null);

		assertThatExceptionOfType(TypeEditUpdateException.class).isThrownBy(() -> 
			classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode("Existing_BenefitCategory", 
				"Existing_BenefitNumber", "Existing_CalCode", "Existing_TypeCode", teciToUpdate)
		).withMessage("BenefitCategory not allowed to be modified");
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_throws_type_edit_update_exception_when_benefit_category_in_teci_is_not_equal_to_existing_benefit_category() {
		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setBenefitCategory("BenefitCategory_To_Modify");

		assertThatExceptionOfType(TypeEditUpdateException.class).isThrownBy(() -> 
			classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode("Existing_BenefitCategory", "Existing_BenefitNumber", 
				"Existing_CalCode", "Existing_TypeCode", teciToUpdate)
		).withMessage("BenefitCategory not allowed to be modified");
	
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_throws_type_edit_update_exception_when_benefit_number_is_null() {
		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setBenefitCategory("Existing_BenefitCategory");
		teciToUpdate.setBenefitNumber(null);

		assertThatExceptionOfType(TypeEditUpdateException.class).isThrownBy(() -> 
			classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode("Existing_BenefitCategory", "Existing_BenefitNumber", 
					"Existing_CalCode", "Existing_TypeCode", teciToUpdate)
		).withMessage("BenefitNumber not allowed to be modified");
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_throws_type_edit_update_exception_when_benefit_number_in_teci_is_not_equal_to_existing_benefit_number() {
		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setBenefitCategory("Existing_BenefitCategory");
		teciToUpdate.setBenefitNumber("BenefitNumber_To_Modify");

		assertThatExceptionOfType(TypeEditUpdateException.class).isThrownBy(() -> 
			classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode("Existing_BenefitCategory", "Existing_BenefitNumber", 
					"Existing_CalCode", "Existing_TypeCode", teciToUpdate)
		).withMessage("BenefitNumber not allowed to be modified");
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_throws_type_edit_update_exception_when_cause_code_is_null() {
		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setBenefitCategory("Existing_BenefitCategory");
		teciToUpdate.setBenefitNumber("Existing_BenefitNumber");
		teciToUpdate.setCauseCode(null);

		assertThatExceptionOfType(TypeEditUpdateException.class).isThrownBy(() -> 
			classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode("Existing_BenefitCategory", "Existing_BenefitNumber", 
					"Existing_CalCode", "Existing_TypeCode", teciToUpdate)
		).withMessage("CauseCode not allowed to be modified");
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_throws_type_edit_update_exception_when_cause_code_in_teci_is_not_equal_to_existing_cause_code() {
		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setBenefitCategory("Existing_BenefitCategory");
		teciToUpdate.setBenefitNumber("Existing_BenefitNumber");
		teciToUpdate.setCauseCode("CauseCode_To_Modify");

		
		assertThatExceptionOfType(TypeEditUpdateException.class).isThrownBy(() -> 
			classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode("Existing_BenefitCategory", "Existing_BenefitNumber", 
					"Existing_CalCode", "Existing_TypeCode", teciToUpdate)
		).withMessage("CauseCode not allowed to be modified");
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_throws_type_edit_update_exception_when_type_code_is_null() {
		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setBenefitCategory("Existing_BenefitCategory");
		teciToUpdate.setBenefitNumber("Existing_BenefitNumber");
		teciToUpdate.setCauseCode("Existing_CauseCode");
		teciToUpdate.setTypeCode(null);

		assertThatExceptionOfType(TypeEditUpdateException.class).isThrownBy(() -> 
			classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode("Existing_BenefitCategory", "Existing_BenefitNumber", 
					"Existing_CauseCode", "Existing_TypeCode", teciToUpdate)
		).withMessage("TypeCode not allowed to be modified");
		
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_throws_type_edit_update_exception_when_type_code_in_teci_is_not_equal_to_existing_type_code() {
		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setBenefitCategory("Existing_BenefitCategory");
		teciToUpdate.setBenefitNumber("Existing_BenefitNumber");
		teciToUpdate.setCauseCode("Existing_CauseCode");
		teciToUpdate.setTypeCode("TypeCode_Modified");

		assertThatExceptionOfType(TypeEditUpdateException.class).isThrownBy(() -> 
			classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode("Existing_BenefitCategory", "Existing_BenefitNumber", 
					"Existing_CauseCode", "Existing_TypeCode", teciToUpdate)
		).withMessage("TypeCode not allowed to be modified");
		
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_ignores_null_bypass_lcd() {
		Teci teciBeforeUpdate = createTeciObjectWithKeyFieldsOnly();
		teciBeforeUpdate.setBypassLcd("BypassLcd");
		mongoTemplate.save(teciBeforeUpdate, TypeEditDBConstants.COLLECTION_TECI);

		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setBypassLcd(null);

		Teci teciUpdated = classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode(teciToUpdate.getBenefitCategory(), teciToUpdate.getBenefitNumber(), teciToUpdate.getCauseCode(), teciToUpdate.getTypeCode(), teciToUpdate); 

		assertThat(teciUpdated).isEqualTo(teciBeforeUpdate);
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_ignores_null_high_age() {
		Teci teciBeforeUpdate = createTeciObjectWithKeyFieldsOnly();
		teciBeforeUpdate.setHighAge(100);

		mongoTemplate.save(teciBeforeUpdate, TypeEditDBConstants.COLLECTION_TECI);

		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setHighAge(null);

		Teci teciUpdated = classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode(teciToUpdate.getBenefitCategory(), teciToUpdate.getBenefitNumber(), teciToUpdate.getCauseCode(), teciToUpdate.getTypeCode(), teciToUpdate); 

		assertThat(teciUpdated).isEqualTo(teciBeforeUpdate);
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_ignores_null_last_modified_by() {
		Teci teciBeforeUpdate = createTeciObjectWithKeyFieldsOnly();
		teciBeforeUpdate.setLastModifiedBy("lastModifiedBy");

		mongoTemplate.save(teciBeforeUpdate, TypeEditDBConstants.COLLECTION_TECI);

		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setLastModifiedBy(null);

		Teci teciUpdated = classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode(teciToUpdate.getBenefitCategory(), teciToUpdate.getBenefitNumber(), teciToUpdate.getCauseCode(), teciToUpdate.getTypeCode(), teciToUpdate); 

		assertThat(teciUpdated).isEqualTo(teciBeforeUpdate);
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_ignores_null_last_modified_date_time() {
		Teci teciBeforeUpdate = createTeciObjectWithKeyFieldsOnly();
		teciBeforeUpdate.setLastModifiedDateTime(LocalDateTime.now().toInstant(ZoneOffset.UTC));

		mongoTemplate.save(teciBeforeUpdate, TypeEditDBConstants.COLLECTION_TECI);

		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setLastModifiedDateTime(null);

		Teci teciUpdated = classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode(teciToUpdate.getBenefitCategory(), teciToUpdate.getBenefitNumber(), teciToUpdate.getCauseCode(), teciToUpdate.getTypeCode(), teciToUpdate); 

		assertThat(teciUpdated).usingRecursiveComparison().
			withComparatorForType(instantComparatorWithSecondsPrecision , Instant.class)
		   .isEqualTo(teciBeforeUpdate);
		
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_ignores_null_low_age() {
		Teci teciBeforeUpdate = createTeciObjectWithKeyFieldsOnly();
		teciBeforeUpdate.setLowAge(18);

		mongoTemplate.save(teciBeforeUpdate, TypeEditDBConstants.COLLECTION_TECI);

		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setLowAge(null);

		Teci teciUpdated = classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode(teciToUpdate.getBenefitCategory(), teciToUpdate.getBenefitNumber(), teciToUpdate.getCauseCode(), teciToUpdate.getTypeCode(), teciToUpdate); 

		assertThat(teciUpdated).isEqualTo(teciBeforeUpdate);
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_ignores_null_sex() {
		Teci teciBeforeUpdate = createTeciObjectWithKeyFieldsOnly();
		teciBeforeUpdate.setSex("sex");

		mongoTemplate.save(teciBeforeUpdate, TypeEditDBConstants.COLLECTION_TECI);

		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setSex(null);

		Teci teciUpdated = classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode(teciToUpdate.getBenefitCategory(), teciToUpdate.getBenefitNumber(), teciToUpdate.getCauseCode(), teciToUpdate.getTypeCode(), teciToUpdate); 

		assertThat(teciUpdated).isEqualTo(teciBeforeUpdate);
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_ignores_null_place_of_treatment_codes() {
		List<PlaceOfTreatmentCodes> placeOfTreatmentCodesList = new ArrayList<>();
		PlaceOfTreatmentCodes placeOfTreatmentCode = new PlaceOfTreatmentCodes();
		placeOfTreatmentCode.setClaimsPot("claimsPot");
		placeOfTreatmentCode.setPlanLoadPot("planLoadPot");
		placeOfTreatmentCodesList.add(placeOfTreatmentCode);
		Teci teciBeforeUpdate = createTeciObjectWithKeyFieldsOnly();

		teciBeforeUpdate.setPlaceOfTreatmentCodes(placeOfTreatmentCodesList);

		mongoTemplate.save(teciBeforeUpdate, TypeEditDBConstants.COLLECTION_TECI);

		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setPlaceOfTreatmentCodes(null);

		Teci teciUpdated = classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode(teciToUpdate.getBenefitCategory(), teciToUpdate.getBenefitNumber(), teciToUpdate.getCauseCode(), teciToUpdate.getTypeCode(), teciToUpdate); 

		assertThat(teciUpdated).isEqualTo(teciBeforeUpdate);
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_ignores_empty_place_of_treatment_codes() {
		List<PlaceOfTreatmentCodes> placeOfTreatmentCodesList = new ArrayList<>();
		PlaceOfTreatmentCodes placeOfTreatmentCode = new PlaceOfTreatmentCodes();
		placeOfTreatmentCode.setClaimsPot("claimsPot");
		placeOfTreatmentCode.setPlanLoadPot("planLoadPot");
		placeOfTreatmentCodesList.add(placeOfTreatmentCode);
		Teci teciBeforeUpdate = createTeciObjectWithKeyFieldsOnly();

		teciBeforeUpdate.setPlaceOfTreatmentCodes(placeOfTreatmentCodesList);

		mongoTemplate.save(teciBeforeUpdate, TypeEditDBConstants.COLLECTION_TECI);

		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setPlaceOfTreatmentCodes(new ArrayList<>());

		Teci teciUpdated = classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode(teciToUpdate.getBenefitCategory(), teciToUpdate.getBenefitNumber(), teciToUpdate.getCauseCode(), teciToUpdate.getTypeCode(), teciToUpdate); 

		assertThat(teciUpdated).isEqualTo(teciBeforeUpdate);
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_ignores_null_provider_type() {
		List<String> providerTypes = new ArrayList<>();
		providerTypes.add("providerType1");
		Teci teciBeforeUpdate = createTeciObjectWithKeyFieldsOnly();

		teciBeforeUpdate.setProviderTypes(providerTypes);

		mongoTemplate.save(teciBeforeUpdate, TypeEditDBConstants.COLLECTION_TECI);

		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setProviderTypes(null);

		Teci teciUpdated = classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode(teciToUpdate.getBenefitCategory(), teciToUpdate.getBenefitNumber(), teciToUpdate.getCauseCode(), teciToUpdate.getTypeCode(), teciToUpdate); 

		assertThat(teciUpdated).isEqualTo(teciBeforeUpdate);
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_ignores_empty_provider_type() {
		List<String> providerTypes = new ArrayList<>();
		providerTypes.add("providerType1");
		Teci teciBeforeUpdate = createTeciObjectWithKeyFieldsOnly();

		teciBeforeUpdate.setProviderTypes(providerTypes);

		mongoTemplate.save(teciBeforeUpdate, TypeEditDBConstants.COLLECTION_TECI);

		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setProviderTypes(new ArrayList<>());

		Teci teciUpdated = classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode(teciToUpdate.getBenefitCategory(), teciToUpdate.getBenefitNumber(), teciToUpdate.getCauseCode(), teciToUpdate.getTypeCode(), teciToUpdate); 

		assertThat(teciUpdated).isEqualTo(teciBeforeUpdate);
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_updates_bypass_lcd() {
		Teci teciBeforeUpdate = createTeciObjectWithKeyFieldsOnly();
		teciBeforeUpdate.setBypassLcd("BypassLcd");
		mongoTemplate.save(teciBeforeUpdate, TypeEditDBConstants.COLLECTION_TECI);

		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setBypassLcd("BypassLcd_Modified");

		Teci teciUpdated = classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode(teciToUpdate.getBenefitCategory(), teciToUpdate.getBenefitNumber(), teciToUpdate.getCauseCode(), teciToUpdate.getTypeCode(), teciToUpdate); 

		assertThat(teciUpdated).isEqualTo(teciToUpdate);

		Query query = prepareTeciQuery(teciBeforeUpdate.getBenefitCategory(), teciBeforeUpdate.getBenefitNumber(), teciBeforeUpdate.getTypeCode(), teciBeforeUpdate.getCauseCode());
		Teci teciFetchedFromDB = mongoTemplate.findOne(query, Teci.class, TypeEditDBConstants.COLLECTION_TECI);

		assertThat(teciFetchedFromDB).isNotNull();
		assertThat(teciUpdated).usingRecursiveComparison().ignoringFields("id").isEqualTo(teciFetchedFromDB);
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_updates_high_age() {
		Teci teciBeforeUpdate = createTeciObjectWithKeyFieldsOnly();
		teciBeforeUpdate.setHighAge(100);

		mongoTemplate.save(teciBeforeUpdate, TypeEditDBConstants.COLLECTION_TECI);

		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setHighAge(202);

		Teci teciUpdated = classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode(teciToUpdate.getBenefitCategory(), teciToUpdate.getBenefitNumber(), teciToUpdate.getCauseCode(), teciToUpdate.getTypeCode(), teciToUpdate); 

		assertThat(teciUpdated).isEqualTo(teciToUpdate);

		Query query = prepareTeciQuery(teciBeforeUpdate.getBenefitCategory(), teciBeforeUpdate.getBenefitNumber(), teciBeforeUpdate.getTypeCode(), teciBeforeUpdate.getCauseCode());
		Teci teciFetchedFromDB = mongoTemplate.findOne(query, Teci.class, TypeEditDBConstants.COLLECTION_TECI);

		assertThat(teciFetchedFromDB).isNotNull();
		assertThat(teciUpdated).usingRecursiveComparison().ignoringFields("id").isEqualTo(teciFetchedFromDB);
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_updates_last_modified_by() {
		Teci teciBeforeUpdate = createTeciObjectWithKeyFieldsOnly();
		teciBeforeUpdate.setLastModifiedBy("lastModifiedBy");

		mongoTemplate.save(teciBeforeUpdate, TypeEditDBConstants.COLLECTION_TECI);

		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setLastModifiedBy("lastModifiedBy_new");

		Teci teciUpdated = classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode(teciToUpdate.getBenefitCategory(), teciToUpdate.getBenefitNumber(), teciToUpdate.getCauseCode(), teciToUpdate.getTypeCode(), teciToUpdate); 

		assertThat(teciUpdated).isEqualTo(teciToUpdate);

		Query query = prepareTeciQuery(teciBeforeUpdate.getBenefitCategory(), teciBeforeUpdate.getBenefitNumber(), teciBeforeUpdate.getTypeCode(), teciBeforeUpdate.getCauseCode());
		Teci teciFetchedFromDB = mongoTemplate.findOne(query, Teci.class, TypeEditDBConstants.COLLECTION_TECI);

		assertThat(teciFetchedFromDB).isNotNull();
		assertThat(teciUpdated).usingRecursiveComparison().ignoringFields("id").isEqualTo(teciFetchedFromDB);
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_updates_last_modified_date_time() {
		Teci teciBeforeUpdate = createTeciObjectWithKeyFieldsOnly();
		teciBeforeUpdate.setLastModifiedDateTime(LocalDateTime.now().toInstant(ZoneOffset.UTC));

		mongoTemplate.save(teciBeforeUpdate, TypeEditDBConstants.COLLECTION_TECI);

		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setLastModifiedDateTime(Instant.parse("2007-12-03T10:15:30.00Z"));

		Teci teciUpdated = classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode(teciToUpdate.getBenefitCategory(), teciToUpdate.getBenefitNumber(), teciToUpdate.getCauseCode(), teciToUpdate.getTypeCode(), teciToUpdate); 

		assertThat(teciUpdated).isEqualTo(teciToUpdate);

		Query query = prepareTeciQuery(teciBeforeUpdate.getBenefitCategory(), teciBeforeUpdate.getBenefitNumber(), teciBeforeUpdate.getTypeCode(), teciBeforeUpdate.getCauseCode());
		Teci teciFetchedFromDB = mongoTemplate.findOne(query, Teci.class, TypeEditDBConstants.COLLECTION_TECI);

		assertThat(teciFetchedFromDB).isNotNull();
		assertThat(teciUpdated).usingRecursiveComparison().ignoringFields("id").isEqualTo(teciFetchedFromDB);
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_updates_low_age() {
		Teci teciBeforeUpdate = createTeciObjectWithKeyFieldsOnly();
		teciBeforeUpdate.setLowAge(18);

		mongoTemplate.save(teciBeforeUpdate, TypeEditDBConstants.COLLECTION_TECI);

		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setLowAge(25);

		Teci teciUpdated = classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode(teciToUpdate.getBenefitCategory(), teciToUpdate.getBenefitNumber(), teciToUpdate.getCauseCode(), teciToUpdate.getTypeCode(), teciToUpdate); 

		assertThat(teciUpdated).isEqualTo(teciToUpdate);

		Query query = prepareTeciQuery(teciBeforeUpdate.getBenefitCategory(), teciBeforeUpdate.getBenefitNumber(), teciBeforeUpdate.getTypeCode(), teciBeforeUpdate.getCauseCode());
		Teci teciFetchedFromDB = mongoTemplate.findOne(query, Teci.class, TypeEditDBConstants.COLLECTION_TECI);

		assertThat(teciFetchedFromDB).isNotNull();
		assertThat(teciUpdated).usingRecursiveComparison().ignoringFields("id").isEqualTo(teciFetchedFromDB);
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_updates_sex() {
		Teci teciBeforeUpdate = createTeciObjectWithKeyFieldsOnly();
		teciBeforeUpdate.setSex("sex");

		mongoTemplate.save(teciBeforeUpdate, TypeEditDBConstants.COLLECTION_TECI);

		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		teciToUpdate.setSex("sex_Modified");

		Teci teciUpdated = classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode(teciToUpdate.getBenefitCategory(), teciToUpdate.getBenefitNumber(), teciToUpdate.getCauseCode(), teciToUpdate.getTypeCode(), teciToUpdate); 

		assertThat(teciUpdated).isEqualTo(teciToUpdate);

		Query query = prepareTeciQuery(teciBeforeUpdate.getBenefitCategory(), teciBeforeUpdate.getBenefitNumber(), teciBeforeUpdate.getTypeCode(), teciBeforeUpdate.getCauseCode());
		Teci teciFetchedFromDB = mongoTemplate.findOne(query, Teci.class, TypeEditDBConstants.COLLECTION_TECI);

		assertThat(teciFetchedFromDB).isNotNull();
		assertThat(teciUpdated).usingRecursiveComparison().ignoringFields("id").isEqualTo(teciFetchedFromDB);
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_updates_place_of_treatment_codes() {
		List<PlaceOfTreatmentCodes> placeOfTreatmentCodesList = new ArrayList<>();
		PlaceOfTreatmentCodes placeOfTreatmentCode = new PlaceOfTreatmentCodes();
		placeOfTreatmentCode.setClaimsPot("claimsPot");
		placeOfTreatmentCode.setPlanLoadPot("planLoadPot");
		placeOfTreatmentCodesList.add(placeOfTreatmentCode);

		PlaceOfTreatmentCodes placeOfTreatmentCode2 = new PlaceOfTreatmentCodes();
		placeOfTreatmentCode2.setClaimsPot("claimsPot2");
		placeOfTreatmentCode2.setPlanLoadPot("planLoadPot2");
		placeOfTreatmentCodesList.add(placeOfTreatmentCode2);

		Teci teciBeforeUpdate = createTeciObjectWithKeyFieldsOnly();

		teciBeforeUpdate.setPlaceOfTreatmentCodes(placeOfTreatmentCodesList);

		mongoTemplate.save(teciBeforeUpdate, TypeEditDBConstants.COLLECTION_TECI);

		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		List<PlaceOfTreatmentCodes> placeOfTreatmentCodesListToUpdate = new ArrayList<>();
		PlaceOfTreatmentCodes placeOfTreatmentCodeToUpdate = new PlaceOfTreatmentCodes();
		placeOfTreatmentCodeToUpdate.setClaimsPot("claimsPot_Modified");
		placeOfTreatmentCodeToUpdate.setPlanLoadPot("planLoadPot_Modified");
		placeOfTreatmentCodesListToUpdate.add(placeOfTreatmentCodeToUpdate);

		teciToUpdate.setPlaceOfTreatmentCodes(placeOfTreatmentCodesListToUpdate);

		Teci teciUpdated = classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode(teciToUpdate.getBenefitCategory(), teciToUpdate.getBenefitNumber(), teciToUpdate.getCauseCode(), teciToUpdate.getTypeCode(), teciToUpdate); 

		assertThat(teciUpdated).isEqualTo(teciToUpdate);

		Query query =prepareTeciQuery(teciBeforeUpdate.getBenefitCategory(), teciBeforeUpdate.getBenefitNumber(), teciBeforeUpdate.getTypeCode(), teciBeforeUpdate.getCauseCode());
		Teci teciFetchedFromDB = mongoTemplate.findOne(query, Teci.class, TypeEditDBConstants.COLLECTION_TECI);

		assertThat(teciFetchedFromDB).isNotNull();
		assertThat(teciUpdated).usingRecursiveComparison().ignoringFields("id").isEqualTo(teciFetchedFromDB);
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_updates_provider_type() {
		List<String> providerTypes = new ArrayList<>();
		providerTypes.add("providerType1");
		Teci teciBeforeUpdate = createTeciObjectWithKeyFieldsOnly();

		teciBeforeUpdate.setProviderTypes(providerTypes);

		mongoTemplate.save(teciBeforeUpdate, TypeEditDBConstants.COLLECTION_TECI);

		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();
		List<String> providerTypesToUpdate = new ArrayList<>();
		providerTypesToUpdate.add("providerType1_Modified");
		teciToUpdate.setProviderTypes(providerTypesToUpdate);

		Teci teciUpdated = classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode(teciToUpdate.getBenefitCategory(), teciToUpdate.getBenefitNumber(), teciToUpdate.getCauseCode(), teciToUpdate.getTypeCode(), teciToUpdate); 

		assertThat(teciUpdated).isEqualTo(teciToUpdate);

		Query query = prepareTeciQuery(teciBeforeUpdate.getBenefitCategory(), teciBeforeUpdate.getBenefitNumber(), teciBeforeUpdate.getTypeCode(), teciBeforeUpdate.getCauseCode());
		Teci teciFetchedFromDB = mongoTemplate.findOne(query, Teci.class, TypeEditDBConstants.COLLECTION_TECI);

		assertThat(teciFetchedFromDB).isNotNull();
		assertThat(teciUpdated).usingRecursiveComparison().ignoringFields("id").isEqualTo(teciFetchedFromDB);
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_benefit_category_and_benefit_number_and_cause_code_and_type_code_should_throw_type_edit_not_found_exception() {
		Teci teciToUpdate = createTeciObjectWithKeyFieldsOnly();

		TypeEditNotFoundException exceptionThrown = Assertions.assertThrows(TypeEditNotFoundException.class, () -> { 
			classUnderTest.updateTeciByBenefitCategoryAndBenefitNumberAndCauseCodeAndTypeCode(teciToUpdate.getBenefitCategory(), teciToUpdate.getBenefitNumber(), teciToUpdate.getCauseCode(), teciToUpdate.getTypeCode(), teciToUpdate); 
		});

		assertThat(exceptionThrown.getMessage()).isEqualTo("No TypeEdit record found matching input criteria");
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_key_adds_new_record_when_not_present_in_database() {
		Teci teciToCreate = createTeciObjectWithKeyFieldsOnly();

		classUnderTest.updateTECIByKey(teciToCreate);

		Collection<Teci> collectionAfterUpdate = mongoTemplate.findAll(Teci.class, TypeEditDBConstants.COLLECTION_TECI);
		assertThat(collectionAfterUpdate.stream().findFirst().get()).usingRecursiveComparison().isEqualTo(teciToCreate);
		assertThat(collectionAfterUpdate).hasSize(1);
	}

	@SneakyThrows
	@Test
	public void test_update_teci_by_key_updates_record_correctly_when_its_present_in_database() {
		Teci teciToCreate = createTeciObjectWithKeyFieldsOnly();

		mongoTemplate.save(teciToCreate, TypeEditDBConstants.COLLECTION_TECI);
		Collection<Teci> collectionBeforeUpsert = mongoTemplate.findAll(Teci.class, TypeEditDBConstants.COLLECTION_TECI);

		Teci inputTeci = createTeciObjectWithKeyFieldsOnly();
		inputTeci.setLowAge(10);
		inputTeci.setHighAge(20);

		classUnderTest.updateTECIByKey(inputTeci);
		Collection<Teci> collectionAfterUpsert = mongoTemplate.findAll(Teci.class, TypeEditDBConstants.COLLECTION_TECI);
		assertThat(collectionAfterUpsert.stream().findFirst().get()).usingRecursiveComparison().isEqualTo(inputTeci);
		assertThat(collectionAfterUpsert.stream().findFirst().get()).isNotEqualTo(collectionBeforeUpsert.stream().findFirst().get());
		assertThat(collectionAfterUpsert).hasSize(1);
	}

	@SneakyThrows
	@Test
	public void test_upsert_teci_should_save_record_if_no_record_in_database() {
		Teci original = createTeciObjectWithKeyFieldsOnly();

		boolean isSaved = classUnderTest.upsertTeci(original);

		assertThat(isSaved).isTrue();

		Collection<Teci> collectionAfterUpdate = mongoTemplate.findAll(Teci.class, TypeEditDBConstants.COLLECTION_TECI);
		assertThat(collectionAfterUpdate.stream().findFirst().get()).usingRecursiveComparison().isEqualTo(original);
	}

	@SneakyThrows
	@Test
	public void test_upsert_teci_should_update_record_if_record_exists_in_database() {
		Teci original = createTeciObjectWithKeyFieldsOnly();
		original.setLastModifiedBy("lastModifiedBy_test");
		mongoTemplate.save(original, COLLECTION_TECI);

		original.setLastModifiedBy("lastModifiedBy_test_123");
		boolean isSaved = classUnderTest.upsertTeci(original);

		assertThat(isSaved).isTrue();

		Collection<Teci> collectionAfterUpdate = mongoTemplate.findAll(Teci.class, TypeEditDBConstants.COLLECTION_TECI);
		assertThat(collectionAfterUpdate.stream().findFirst().get()).usingRecursiveComparison().isEqualTo(original);
	}

	public Teci createTeciObjectWithKeyFieldsOnly() {
		Teci originalTeci = new Teci();
		originalTeci.setBenefitCategory("benefitCategory");
		originalTeci.setBenefitNumber("benefitNumber");
		originalTeci.setTypeCode("typeCode");
		originalTeci.setCauseCode("causeCode");
		return originalTeci;
	}
	
	private Query prepareTeciQuery(String benefitCategory, String benefitNumber, String typeCode, String causeCode) {		
		Query query = new Query();
		query.addCriteria(Criteria.where(TypeEditDBConstants.BENEFIT_CATEGORY).is(benefitCategory));
		query.addCriteria(Criteria.where(TypeEditDBConstants.BENEFIT_NUMBER).is(benefitNumber));
		query.addCriteria(Criteria.where(TypeEditDBConstants.TYPE_CODE).is(typeCode));
		query.addCriteria(Criteria.where(TypeEditDBConstants.CAUSE_CODE).is(causeCode));
		
		return query;
	}
	
	private Comparator<? super Instant> instantComparatorWithSecondsPrecision = (a,b) -> a.truncatedTo(ChronoUnit.SECONDS).compareTo(b.truncatedTo(ChronoUnit.SECONDS));
}
package com.humana.claims.hcaas.typeedit.datacapture.service.impl;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.humana.claims.hcaas.typeedit.core.dao.TeciDAO;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditConflictException;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditNotFoundException;
import com.humana.claims.hcaas.typeedit.core.model.Teci;
import com.humana.claims.hcaas.typeedit.datacapture.mapper.TECIMapper;
import com.humana.claims.hcaas.typeedit.datacapture.mapper.TypeEditJSONDataMapper;
import com.humana.claims.hcaas.typeedit.datacapture.service.TypeEditDataCaptureService;
import com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto.TypeEditDTO;

@Service
public class TypeEditDataCaptureServiceImpl implements TypeEditDataCaptureService {

	@Autowired
	private TeciDAO teciDAO;

	@Autowired
	private TypeEditJSONDataMapper typeEditJsonDataMapper;

	@Autowired
	private TECIMapper teciMapper;

	@Override
	public Teci getTeciByKey(String benefitCategory, String benefitGroup, String typeCode, String causeCode)
			throws TypeEditNotFoundException {
		return teciDAO.fetchTECI(benefitCategory, benefitGroup, typeCode, causeCode);
	}

	@Override
	public boolean updateTECI(Teci teciObject) {
		return teciDAO.updateTECIByKey(teciObject);
	}

	@Override
	public boolean upsertTECI(Teci teciObject) {
		return teciDAO.upsertTeci(teciObject);
	}
	
	@Override
	public void saveTeci(Teci teciObject) throws TypeEditConflictException {
		teciDAO.saveTeci(teciObject);
	}

	@Override
	public void processTECI(String teciData) throws IOException {
		TypeEditDTO typeEditDTO = typeEditJsonDataMapper.mapTeci(teciData);
		Teci teciObject = teciMapper.mapToTECI(typeEditDTO);
		upsertTECI(teciObject);
	}
}

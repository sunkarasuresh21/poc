package com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class SeTeKeyDTO {

    @JsonProperty("SE-TE-CLIENT")
    private String seTeClient;

    @JsonProperty("SE-TE-BEN-CATEGORY")
    private String seTeBenCategory;

    @JsonProperty("SE-TE-BEN-GROUP-NO")
    private String seTeBenGroupNo;

    @JsonProperty("SE-TE-CAUSE-CD")
    private String seTeCauseCd;

    @JsonProperty("SE-TE-TYPE-OF-SER-CD")
    private String seTeTypeOfSerCd;

}

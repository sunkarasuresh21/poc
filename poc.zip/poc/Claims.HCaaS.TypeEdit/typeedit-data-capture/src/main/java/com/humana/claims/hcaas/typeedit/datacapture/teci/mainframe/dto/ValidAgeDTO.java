package com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ValidAgeDTO {

    @JsonProperty("SE-TE-LOW-AGE")
    private String seTeLowAge;

    @JsonProperty("SE-TE-HIGH-AGE")
    private String seTeHighAge;

    @JsonProperty("SE-TE-VALID-SEX")
    private String seTeValidSex;

    @JsonProperty("SE-TE-PAR-NONPAR-APPL")
    private String seTeParNonparAppl;

}

package com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class SeTeHighDiagCdDTO {

    @JsonProperty("SE-TE-HIGH-PVTP-CD")
    private String seTeHighPvtpCd;

    @JsonProperty("SE-TE-HIGH-PVTP-1")
    private String seTeHighPvtp1;

    @JsonProperty("SE-TE-HIGH-PVTP-2")
    private String seTeHighPvtp2;

}

package com.humana.claims.hcaas.typeedit.datacapture.config;

import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.humana.claims.hcaas.common.jms.listener.starter.config.BaseJmsListenerConnectionConfig;


@Configuration
@ConditionalOnProperty(name = "jmslistener.teci.enabled", havingValue = "true")
public class TECIListenerConnectionConfig extends BaseJmsListenerConnectionConfig {
	
	@Bean
	public static BeanDefinitionRegistryPostProcessor teciBeanConfiguration() {
		return jmsListenerDependencyBeanRegisterer("teci");
	}
}

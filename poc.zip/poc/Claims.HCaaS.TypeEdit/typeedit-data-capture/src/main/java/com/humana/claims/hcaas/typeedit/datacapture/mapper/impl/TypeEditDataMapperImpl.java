package com.humana.claims.hcaas.typeedit.datacapture.mapper.impl;

import java.io.IOException;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.humana.claims.hcaas.typeedit.datacapture.mapper.TypeEditJSONDataMapper;
import com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto.TypeEditDTO;

@Component
public class TypeEditDataMapperImpl implements TypeEditJSONDataMapper {

	private static final ObjectMapper mapper = new ObjectMapper()
			.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
			.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);

	@Override
	public TypeEditDTO mapTeci(String teciData) throws IOException {
		return mapper.readValue(teciData, TypeEditDTO.class);
	}

	
}

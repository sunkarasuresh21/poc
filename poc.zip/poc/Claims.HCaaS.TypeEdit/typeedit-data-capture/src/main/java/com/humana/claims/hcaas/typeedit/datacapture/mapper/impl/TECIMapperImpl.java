package com.humana.claims.hcaas.typeedit.datacapture.mapper.impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.humana.claims.hcaas.common.utils.MainframeDateUtils;
import com.humana.claims.hcaas.typeedit.core.model.PlaceOfTreatmentCodes;
import com.humana.claims.hcaas.typeedit.core.model.Teci;
import com.humana.claims.hcaas.typeedit.datacapture.mapper.TECIMapper;
import com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto.TypeEditDTO;
import com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto.ValidDiagCdDTO;
import com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto.ValidPotCdDTO;
import com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto.ValidProviderTypeDTO;

@Component
public class TECIMapperImpl implements TECIMapper {

	public static final String EMPTY_SPACE = " ";
	public static final String ZEROS = "00";

	@Override
	public Teci mapToTECI(TypeEditDTO typeEditDTO) {
		Teci teciObject = new Teci();
		teciObject
				.setBenefitNumber(typeEditDTO.getTypeEditRecordDTO().getTypeOfServiceRecDTO().getSeTeKeyDTO().getSeTeBenGroupNo());
		teciObject.setBenefitCategory(
				typeEditDTO.getTypeEditRecordDTO().getTypeOfServiceRecDTO().getSeTeKeyDTO().getSeTeBenCategory());
		teciObject.setCauseCode(typeEditDTO.getTypeEditRecordDTO().getTypeOfServiceRecDTO().getSeTeKeyDTO().getSeTeCauseCd());
		teciObject.setTypeCode(typeEditDTO.getTypeEditRecordDTO().getTypeOfServiceRecDTO().getSeTeKeyDTO().getSeTeTypeOfSerCd());
		List<PlaceOfTreatmentCodes> placeOfTreatmentCodes = new ArrayList<>();
		List<ValidPotCdDTO> validPotCdDTO = typeEditDTO.getTypeEditRecordDTO().getTypeOfServiceRecDTO().getValidPotCdDTO();

		for (ValidPotCdDTO potObjDTO : validPotCdDTO) {
			PlaceOfTreatmentCodes schemaObj = new PlaceOfTreatmentCodes();
			if (!StringUtils.isEmpty(potObjDTO.getSeTePot().trim())
					|| !StringUtils.isEmpty(potObjDTO.getSeTePotCalcKey().trim())) {
				schemaObj.setClaimsPot(potObjDTO.getSeTePot());
				schemaObj.setPlanLoadPot(potObjDTO.getSeTePotCalcKey());
				placeOfTreatmentCodes.add(schemaObj);
			}
		}

		List<String> providerTypesList = new ArrayList<>();
		List<ValidProviderTypeDTO> validProviderTypeDTO = typeEditDTO.getTypeEditRecordDTO().getTypeOfServiceRecDTO()
				.getValidProviderTypeDTO();
		List<ValidDiagCdDTO> validDiagCdDTOList = typeEditDTO.getTypeEditRecordDTO().getTypeOfServiceRecDTO().getValidDiagCdDTO();

		providerTypesList.addAll(IntStream.range(0, validProviderTypeDTO.size())
				.mapToObj(index -> validProviderTypeDTO.get(index).getSeTeProvType()).collect(Collectors.toList()));
		providerTypesList.addAll(IntStream.range(0, validDiagCdDTOList.size())
				.mapToObj(index -> validDiagCdDTOList.get(index).getSeTeLowDiagCdDTO().getSeTeLowPvtp1())
				.collect(Collectors.toList()));
		providerTypesList.addAll(IntStream.range(0, validDiagCdDTOList.size())
				.mapToObj(index -> validDiagCdDTOList.get(index).getSeTeLowDiagCdDTO().getSeTeLowPvtp2())
				.collect(Collectors.toList()));
		providerTypesList.addAll(IntStream.range(0, validDiagCdDTOList.size())
				.mapToObj(index -> validDiagCdDTOList.get(index).getSeTeHighDiagCdDTO().getSeTeHighPvtp1())
				.collect(Collectors.toList()));
		providerTypesList.addAll(IntStream.range(0, validDiagCdDTOList.size())
				.mapToObj(index -> validDiagCdDTOList.get(index).getSeTeHighDiagCdDTO().getSeTeHighPvtp2())
				.collect(Collectors.toList()));
		providerTypesList.removeIf(n -> Objects.equals(n, EMPTY_SPACE));
		providerTypesList.removeIf(n -> Objects.equals(n, ZEROS));
		teciObject.setPlaceOfTreatmentCodes(placeOfTreatmentCodes);
		teciObject.setProviderTypes(providerTypesList);
		teciObject.setHighAge(
				Integer.parseInt(typeEditDTO.getTypeEditRecordDTO().getTypeOfServiceRecDTO().getValidAgeDTO().getSeTeHighAge()));
		teciObject.setLowAge(
				Integer.parseInt(typeEditDTO.getTypeEditRecordDTO().getTypeOfServiceRecDTO().getValidAgeDTO().getSeTeLowAge()));
		teciObject.setSex(typeEditDTO.getTypeEditRecordDTO().getTypeOfServiceRecDTO().getValidAgeDTO().getSeTeValidSex());
		teciObject
				.setBypassLcd(typeEditDTO.getTypeEditRecordDTO().getTypeOfServiceRecDTO().getValidAgeDTO().getSeTeParNonparAppl());
		LocalDate changeDate = MainframeDateUtils
				.convertYYMMDDStringToLocalDate(typeEditDTO.getTypeEditRecordDTO().getTypeOfServiceRecDTO().getSeTeChgDate());
		if (changeDate != null) {
			teciObject.setLastModifiedDateTime(MainframeDateUtils.toInstant(changeDate));
		}
		teciObject.setLastModifiedBy(typeEditDTO.getTypeEditRecordDTO().getTypeOfServiceRecDTO().getSeTeAdjNo());
		return teciObject;
	}

}

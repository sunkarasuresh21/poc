package com.humana.claims.hcaas.typeedit.datacapture;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.retry.annotation.EnableRetry;

import com.humana.claims.hcaas.common.spring.boot.starter.HcaasSpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.humana.claims.hcaas.typeedit")
@EnableJms
@EnableRetry
public class TypeEditDataCaptureApplication{

	public static void main(String[] args) {
		HcaasSpringBootApplication.run(TypeEditDataCaptureApplication.class, args);
	}
}

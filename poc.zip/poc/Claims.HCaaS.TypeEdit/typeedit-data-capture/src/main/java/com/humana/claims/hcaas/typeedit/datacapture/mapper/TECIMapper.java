package com.humana.claims.hcaas.typeedit.datacapture.mapper;

import com.humana.claims.hcaas.typeedit.core.model.Teci;
import com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto.TypeEditDTO;

public interface TECIMapper {

	Teci mapToTECI(TypeEditDTO typeEditDTO);
}

package com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ValidDiagCdDTO {

    @JsonProperty("SE-TE-LOW-DIAG-CD")
    private SeTeLowDiagCdDTO seTeLowDiagCdDTO;

    @JsonProperty("SE-TE-HIGH-DIAG-CD")
    private SeTeHighDiagCdDTO seTeHighDiagCdDTO;

}

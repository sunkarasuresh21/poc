package com.humana.claims.hcaas.typeedit.datacapture.mapper;

import java.io.IOException;

import com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto.TypeEditDTO;

public interface TypeEditJSONDataMapper {

	TypeEditDTO mapTeci(String teciData) throws IOException;
}

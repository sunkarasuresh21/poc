package com.humana.claims.hcaas.typeedit.datacapture.service;

import java.io.IOException;

import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditConflictException;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditNotFoundException;
import com.humana.claims.hcaas.typeedit.core.model.Teci;

public interface TypeEditDataCaptureService {
	
	Teci getTeciByKey(String benefitCategory, String benefitGroup, String typeCode, String causeCode) throws TypeEditNotFoundException;

	boolean updateTECI(Teci teciObject);

	void saveTeci(Teci teciObject) throws TypeEditConflictException;

	boolean upsertTECI(Teci teciObject);

	void processTECI(String teciData) throws IOException;
}

package com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class TypeOfServiceRecDTO {

    @JsonProperty("SE-TE-KEY")
    private SeTeKeyDTO seTeKeyDTO;

    @JsonProperty("VALID-DIAG-CD")
    private List<ValidDiagCdDTO> validDiagCdDTO = new ArrayList<>();

    @JsonProperty("VALID-POT-CD")
    private List<ValidPotCdDTO> validPotCdDTO = new ArrayList<>();

    @JsonProperty("VALID-PROVIDER-TYPE")
    private List<ValidProviderTypeDTO> validProviderTypeDTO = new ArrayList<>();

    @JsonProperty("VALID-AGE")
    private ValidAgeDTO validAgeDTO;

    @JsonProperty("REL-AGE-EDIT")
    private List<RelAgeEditDTO> relAgeEditDTO = new ArrayList<>();

    @JsonProperty("SE-TE-ADJ-NO")
    private String seTeAdjNo;

    @JsonProperty("SE-TE-CHG-DATE")
    private String seTeChgDate;

}

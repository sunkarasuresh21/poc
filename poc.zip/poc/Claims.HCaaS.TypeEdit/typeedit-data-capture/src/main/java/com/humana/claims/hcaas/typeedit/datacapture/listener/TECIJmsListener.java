package com.humana.claims.hcaas.typeedit.datacapture.listener;

import java.io.IOException;

import javax.jms.JMSException;
import javax.jms.Message;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import com.humana.claims.hcaas.common.jms.listener.starter.newerrorhandlers.JmsListenerErrorHandler;
import com.humana.claims.hcaas.common.spring.aop.annotation.Listener;
import com.humana.claims.hcaas.typeedit.datacapture.service.TypeEditDataCaptureService;
import com.mongodb.MongoException;

import io.micrometer.core.annotation.Timed;
import lombok.AllArgsConstructor;

@Component
@ConditionalOnProperty(name = "jmslistener.teci.enabled", havingValue = "true")
@AllArgsConstructor
@Listener
public class TECIJmsListener {

	@Qualifier("teciJmsListenerErrorHandler")
	@Autowired
	private JmsListenerErrorHandler errorHandler;

	@Autowired
	private TypeEditDataCaptureService typeEditDataCaptureService;

	@Timed(value = "messages.processed", extraTags = {"listener", "teci"})
	@JmsListener(containerFactory = "teciListenerContainerFactory", destination = "#{@teciQueueName}")
	@Retryable(value = { MongoException.class }, maxAttemptsExpression = "#{${jmslistener.retry.attempts}}", backoff = @Backoff(delayExpression = "#{${jmslistener.retry.backoff}}"))
	public void processTECIData(Message message) throws IOException, JMSException {
		String teciData = message.getBody(String.class);
		typeEditDataCaptureService.processTECI(teciData);
	}

	@Recover
	public void handleMongoException(MongoException e, Message message) {
		errorHandler.handleRetryableMessageProcessingException(message, e);
	}

	@Recover
	public void handleException(Exception e, Message message) {
		errorHandler.handleNonretryableMessageProcessingException(message, e);
	}
	
}

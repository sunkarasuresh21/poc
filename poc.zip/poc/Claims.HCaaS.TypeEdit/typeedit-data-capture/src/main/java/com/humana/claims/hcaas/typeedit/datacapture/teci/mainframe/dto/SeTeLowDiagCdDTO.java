package com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class SeTeLowDiagCdDTO {

    @JsonProperty("SE-TE-LOW-PVTP-CD")
    private String seTeLowPvtpCd;

    @JsonProperty("SE-TE-LOW-PVTP-1")
    private String seTeLowPvtp1;

    @JsonProperty("SE-TE-LOW-PVTP-2")
    private String seTeLowPvtp2;

}

package com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ValidPotCdDTO {

    @JsonProperty("SE-TE-POT")
    private String seTePot;

    @JsonProperty("SE-TE-POT-CALC-KEY")
    private String seTePotCalcKey;

}

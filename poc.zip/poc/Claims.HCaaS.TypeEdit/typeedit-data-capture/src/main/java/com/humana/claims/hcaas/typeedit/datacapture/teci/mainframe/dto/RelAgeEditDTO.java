package com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class RelAgeEditDTO {

    @JsonProperty("SE-TE-REL-LOW-AGE")
    private String seTeRelLowAge;

    @JsonProperty("SE-TE-REL-HIGH-AGE")
    private String seTeRelHighAge;

    @JsonProperty("SE-TE-NUMBER-OF-OCCUR")
    private String seTeNumberOfOccur;

    @JsonProperty("SE-TE-PERIOD")
    private String seTePeriod;

}

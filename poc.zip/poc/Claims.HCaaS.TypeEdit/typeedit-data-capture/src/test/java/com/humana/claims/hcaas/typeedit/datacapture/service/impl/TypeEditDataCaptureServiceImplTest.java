package com.humana.claims.hcaas.typeedit.datacapture.service.impl;

import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.humana.claims.hcaas.typeedit.core.dao.TeciDAO;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditConflictException;
import com.humana.claims.hcaas.typeedit.core.exceptions.TypeEditNotFoundException;
import com.humana.claims.hcaas.typeedit.core.model.Teci;
import com.humana.claims.hcaas.typeedit.datacapture.mapper.TECIMapper;
import com.humana.claims.hcaas.typeedit.datacapture.mapper.TypeEditJSONDataMapper;
import com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto.SeTeHighDiagCdDTO;
import com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto.SeTeKeyDTO;
import com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto.SeTeLowDiagCdDTO;
import com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto.TypeEditDTO;
import com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto.TypeEditRecordDTO;
import com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto.TypeOfServiceRecDTO;
import com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto.ValidDiagCdDTO;

import lombok.SneakyThrows;

@ExtendWith(MockitoExtension.class)
public class TypeEditDataCaptureServiceImplTest {
	
	@InjectMocks
	private TypeEditDataCaptureServiceImpl classUnderTest;

	@Mock
	private TeciDAO teciDAO;
	
	@Mock
	TypeEditJSONDataMapper typeEditDTOJsonDataMapper;

	@Mock
	TECIMapper teciMapper;
	
	@SneakyThrows
	@Test
	public void test_save_teci_does_not_throw_exceptoin_and_dao_is_called_once() {
		
		Teci teci = getTeci();
		
		when(teciDAO.saveTeci(teci)).thenReturn(teci);
		
		assertDoesNotThrow(() -> classUnderTest.saveTeci(teci));
		
		verify(teciDAO).saveTeci(teci);
	}
	
	@SneakyThrows
	@Test
	public void test_save_teci_should_throw_exception_when_dao_throws_conflict_exception() {
		
		Teci teci = getTeci();
		
		doThrow(new TypeEditConflictException()).when(teciDAO).saveTeci(teci);

		assertThatExceptionOfType(TypeEditConflictException.class).isThrownBy(() -> 
			classUnderTest.saveTeci(teci)
		);
	}
	
	@SneakyThrows
	@Test
	public void test_save_teci_should_throw_exception_when_dao_throws_runtime_exception() {
		
		Teci teci = getTeci();
		
		doThrow(new RuntimeException()).when(teciDAO).saveTeci(teci);

		assertThatExceptionOfType(RuntimeException.class).isThrownBy(() -> 
			classUnderTest.saveTeci(teci)
		);
	}
	
	@SneakyThrows
	@Test
	public void test_get_teci_by_key_does_not_throw_exceptoin_and_dao_is_called_once() {
		
		Teci teci = getTeci();
		
		when(teciDAO.fetchTECI(teci.getBenefitCategory(), teci.getBenefitNumber(), teci.getTypeCode(), teci.getCauseCode())).thenReturn(teci);
		
		assertDoesNotThrow(() -> classUnderTest.getTeciByKey(teci.getBenefitCategory(), teci.getBenefitNumber(), teci.getTypeCode(), teci.getCauseCode()));
		
		verify(teciDAO).fetchTECI(teci.getBenefitCategory(), teci.getBenefitNumber(), teci.getTypeCode(), teci.getCauseCode());
	}
	
	@SneakyThrows
	@Test
	public void test_get_teci_by_key_should_throw_type_edit_not_found_exception() {
		
		doThrow(new TypeEditNotFoundException()).when(teciDAO).fetchTECI("01", "12345", "XXXXXC", "OBGYN");

		assertThatExceptionOfType(TypeEditNotFoundException.class).isThrownBy(() -> 
			classUnderTest.getTeciByKey("01", "12345", "XXXXXC", "OBGYN")
		);
	}
	
	@SneakyThrows
	@Test
	public void test_update_teci_does_not_throw_exceptoin_and_dao_is_called_once() {
		
		Teci teci = getTeci();
		
		when(teciDAO.updateTECIByKey(teci)).thenReturn(true);
		
		assertDoesNotThrow(() -> classUnderTest.updateTECI(teci));
		
		verify(teciDAO).updateTECIByKey(teci);
	}
	
	@SneakyThrows
	@Test
	public void test_update_teci_should_throw_exception_when_dao_throws_runtime_exception() {
		
		Teci teci = getTeci();
		
		doThrow(new RuntimeException()).when(teciDAO).updateTECIByKey(teci);

		assertThatExceptionOfType(RuntimeException.class).isThrownBy(() -> 
			classUnderTest.updateTECI(teci)
		);
	}
	
	@SneakyThrows
	@Test
	public void test_process_teci_to_create_a_new_teci_record() {
		
		String teciRecordJSONData = "testJSONMessage";
		TypeEditDTO typeEditDTO = getTypeEditDTO();
		Teci teci = getTeci();
		
		when(typeEditDTOJsonDataMapper.mapTeci(teciRecordJSONData)).thenReturn(typeEditDTO);
		
		when(teciMapper.mapToTECI(typeEditDTO)).thenReturn(teci);
		
		classUnderTest.processTECI(teciRecordJSONData);
		
		verify(teciDAO,times(1)).upsertTeci(teci);
	}
	
	@SneakyThrows
	@Test
	public void test_process_teci_to_update_a_existing_teci_record() {
		
		String teciRecordJSONData = "testJSONMessage";
		TypeEditDTO typeEditDTO = getTypeEditDTO();
		Teci teci = getTeci();
		teci.setLowAge(10);
		teci.setHighAge(20);
		
		when(typeEditDTOJsonDataMapper.mapTeci(teciRecordJSONData)).thenReturn(typeEditDTO);
		when(teciMapper.mapToTECI(typeEditDTO)).thenReturn(teci);
		
		classUnderTest.processTECI(teciRecordJSONData);
		
		verify(teciDAO,times(1)).upsertTeci(teci);
	}
	
	@SneakyThrows
	@Test
	public void test_process_teci_throws_io_exception_if_mapper_throws_io_excetion() {
		
		String teciRecordJSONData = "testJSONMessage";
		
		when(typeEditDTOJsonDataMapper.mapTeci(teciRecordJSONData)).thenThrow(new IOException());
		
		assertThatExceptionOfType(IOException.class).isThrownBy(() -> 
			classUnderTest.processTECI(teciRecordJSONData)
		);
	}

	private Teci getTeci() {
		Teci originalTeci = new Teci();
		originalTeci.setBenefitCategory("benefitCategory");
		originalTeci.setBenefitNumber("benefitNumber");
		originalTeci.setTypeCode("typeCode");
		originalTeci.setCauseCode("causeCode");
		return originalTeci;
	}
	
	private TypeEditDTO getTypeEditDTO() {
		TypeEditDTO typeEditDTO = new TypeEditDTO();
		TypeEditRecordDTO typeEditRecordDTO = new TypeEditRecordDTO();
		TypeOfServiceRecDTO typeOfServiceRecDTO = new TypeOfServiceRecDTO();
		typeOfServiceRecDTO.setSeTeAdjNo("seTeAdjNo");
		typeOfServiceRecDTO.setSeTeChgDate("seTeChgDate");
		
		List<ValidDiagCdDTO> validDiagCdDTOList = new ArrayList<>();
		ValidDiagCdDTO validDiagCdDTO = new ValidDiagCdDTO();
		SeTeLowDiagCdDTO seTeLowDiagCdDTO = new SeTeLowDiagCdDTO();
		SeTeHighDiagCdDTO seTeHighDiagCdDTO = new SeTeHighDiagCdDTO();
		validDiagCdDTO.setSeTeLowDiagCdDTO(seTeLowDiagCdDTO);
		validDiagCdDTO.setSeTeHighDiagCdDTO(seTeHighDiagCdDTO);
		validDiagCdDTOList.add(validDiagCdDTO);
		typeOfServiceRecDTO.setValidDiagCdDTO(validDiagCdDTOList);
		
		SeTeKeyDTO seTeKeyDTO = new SeTeKeyDTO();
		seTeKeyDTO.setSeTeBenCategory("seTeBenCategory");
		seTeKeyDTO.setSeTeBenGroupNo("seTeBenGroupNo");
		seTeKeyDTO.setSeTeCauseCd("seTeCauseCd");
		seTeKeyDTO.setSeTeTypeOfSerCd("seTeTypeOfSerCd");
		typeOfServiceRecDTO.setSeTeKeyDTO(seTeKeyDTO);
		
		typeEditRecordDTO.setTypeOfServiceRecDTO(typeOfServiceRecDTO);
		typeEditDTO.setTypeEditRecordDTO(typeEditRecordDTO);
		
		return typeEditDTO;
	}

}

package com.humana.claims.hcaas.typeedit.datacapture;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.humana.claims.hcaas.typeedit.datacapture.listener.TECIJmsListener;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = TypeEditDataCaptureApplication.class)
@TestPropertySource("classpath:test-application-teci.properties")
public class TypeEditDataCaptureApplicationTest {

	@Autowired
	private ApplicationContext appContext;

	/**
	 * This test just confirms the Listener Initialization
	 *
	 */
	@Test
	public void contextLoads() {
		assertThat(appContext).isNotNull();
		assertThat(appContext.getBean(TECIJmsListener.class)).isNotNull();
	}
	
}
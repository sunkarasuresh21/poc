package com.humana.claims.hcaas.typeedit.datacapture.mapper.impl;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.nio.charset.Charset;
import java.time.Instant;

import org.apache.commons.io.FileUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.humana.claims.hcaas.typeedit.core.model.Teci;
import com.humana.claims.hcaas.typeedit.datacapture.teci.mainframe.dto.TypeEditDTO;

import lombok.SneakyThrows;

public class TECIMapperImplTest {

	TypeEditDataMapperImpl classUnderTest;

	TECIMapperImpl teciDataMapper;

	private static final String teciFilePath = "TypeEditJSONFiles/TECI.json";
	private static String teciInputData;
	private TypeEditDTO typeEditDTO;

	@SneakyThrows
	@BeforeEach
	public void setUp() throws IOException {
		classUnderTest = new TypeEditDataMapperImpl();

		teciInputData = readFileToString(teciFilePath);

		typeEditDTO = classUnderTest.mapTeci(teciInputData);

		teciDataMapper = new TECIMapperImpl();
	}

	@SneakyThrows
	private static String readFileToString(String filepath) {
		URI filePathUri = TECIMapperImplTest.class.getClassLoader().getResource(filepath).toURI();
		File file = new File(filePathUri);
		return FileUtils.readFileToString(file, Charset.forName("UTF-8"));
	}
	
	@Test
	public void typeCode_Key_Fields_BenefitCategory_BenefitGroupNumber_PlanLoadTypeCode_CauseCode_Test() {
		typeEditDTO.getTypeEditRecordDTO().getTypeOfServiceRecDTO().getSeTeKeyDTO().setSeTeBenCategory("TestBenefitCategory");
		typeEditDTO.getTypeEditRecordDTO().getTypeOfServiceRecDTO().getSeTeKeyDTO().setSeTeBenGroupNo("00000");
		typeEditDTO.getTypeEditRecordDTO().getTypeOfServiceRecDTO().getSeTeKeyDTO().setSeTeTypeOfSerCd("TestTypeCode");
		typeEditDTO.getTypeEditRecordDTO().getTypeOfServiceRecDTO().getSeTeKeyDTO().setSeTeCauseCd("TestCauseCode");

		Teci typeEdit = teciDataMapper.mapToTECI(typeEditDTO);

		assertThat(typeEdit.getBenefitCategory()).isEqualTo("TestBenefitCategory");
		assertThat(typeEdit.getBenefitNumber()).isEqualTo("00000");
		assertThat(typeEdit.getTypeCode()).isEqualTo("TestTypeCode");
		assertThat(typeEdit.getCauseCode()).isEqualTo("TestCauseCode");
	}

	@Test
	public void check_TECIObjectPlaceOfTreatmentCodes_Test() throws IOException {
		typeEditDTO.getTypeEditRecordDTO().getTypeOfServiceRecDTO().getValidPotCdDTO().get(0).setSeTePot("POT12");
		typeEditDTO.getTypeEditRecordDTO().getTypeOfServiceRecDTO().getValidPotCdDTO().get(0).setSeTePotCalcKey("POTKey24");

		Teci typeEdit = teciDataMapper.mapToTECI(typeEditDTO);

		assertThat(typeEdit.getPlaceOfTreatmentCodes().get(0).getClaimsPot()).isEqualTo("POT12");
		assertThat(typeEdit.getPlaceOfTreatmentCodes().get(0).getPlanLoadPot()).isEqualTo("POTKey24");
	}

	@Test
	public void teci_providerTypesList_Test() {
		typeEditDTO.getTypeEditRecordDTO().getTypeOfServiceRecDTO().getValidProviderTypeDTO().get(0).setSeTeProvType("Prov12");
		typeEditDTO.getTypeEditRecordDTO().getTypeOfServiceRecDTO().getValidProviderTypeDTO().get(1).setSeTeProvType("Prov24");

		Teci typeEdit = teciDataMapper.mapToTECI(typeEditDTO);

		assertThat(typeEdit.getProviderTypes().get(0)).isEqualTo("Prov12");
		assertThat(typeEdit.getProviderTypes().get(1)).isEqualTo("Prov24");
	}
	
	@Test
	public void teci_LastModifiedByAndLastModified_Test() {
		Teci typeEdit = teciDataMapper.mapToTECI(typeEditDTO);

		assertThat(typeEdit.getLastModifiedBy()).isEqualTo("CLG2335");
		assertThat(typeEdit.getLastModifiedDateTime()).isEqualTo(Instant.parse("2005-09-21T04:00:00Z"));
	}
}

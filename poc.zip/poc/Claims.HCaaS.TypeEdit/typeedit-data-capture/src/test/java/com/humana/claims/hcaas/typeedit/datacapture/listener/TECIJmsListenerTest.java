package com.humana.claims.hcaas.typeedit.datacapture.listener;


import static org.assertj.core.api.Assertions.assertThatCode;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.io.IOException;

import javax.jms.Message;

import org.apache.qpid.jms.message.JmsTextMessage;
import org.apache.qpid.jms.provider.amqp.message.AmqpJmsTextMessageFacade;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.fasterxml.jackson.core.JsonParseException;
import com.humana.claims.hcaas.common.jms.listener.starter.newerrorhandlers.JmsListenerErrorHandler;
import com.humana.claims.hcaas.typeedit.datacapture.service.TypeEditDataCaptureService;
import com.mongodb.MongoException;

import io.micrometer.core.instrument.Metrics;
import io.micrometer.core.instrument.Timer;
import lombok.SneakyThrows;

@ExtendWith(SpringExtension.class)
@TestPropertySource("classpath:test-application-teci.properties")
public class TECIJmsListenerTest {
	
	@Autowired
	private TECIJmsListener classUnderTest;
	
	@MockBean
	private JmsListenerErrorHandler errorHandler;
	
	@MockBean
	private TypeEditDataCaptureService typeEditDataCaptureService;
	
	private static final String providerData = "testProviderData";
	
	@SneakyThrows
	@Test
	public void test_send_error_invokes_handle_message_processing_error_in_error_handler_() {
		Exception exception = new Exception("test_exception");
		Message message=textMessage(providerData);
		doNothing().when(errorHandler).handleNonretryableMessageProcessingException(message, exception);
		
		classUnderTest.handleException(exception, message);
		
		verify(errorHandler, times(1)).handleNonretryableMessageProcessingException(message, exception);
	}
	
	@SneakyThrows
	@Test
	public void test_process_teci_data_data_does_not_throw_error() {
		Message message=textMessage(providerData);
		assertThatCode(() -> classUnderTest.processTECIData(message)).doesNotThrowAnyException();
		verify(errorHandler, times(0)).handleRetryableMessageProcessingException(message, new Exception());
		verify(errorHandler, times(0)).handleNonretryableMessageProcessingException(message, new Exception());
	}	

	@SneakyThrows
	@Test
	public void test_process_teci_data_data_whether_update_medPolicy_method_of_methods_is_invoked_correctly() {
		Message message=textMessage(providerData);
		doNothing().when(typeEditDataCaptureService).processTECI(providerData);
		
		classUnderTest.processTECIData(message);		
		
		verify(errorHandler, times(0)).handleRetryableMessageProcessingException(message, new Exception());
		verify(errorHandler, times(0)).handleNonretryableMessageProcessingException(message, new Exception());
	}

	@Test
	public void test_send_error_invokes_handle_message_processing_error_in_error_handler() {
		Exception exception = new Exception("test_exception");
		Message message=textMessage(providerData);
		doNothing().when(errorHandler).handleNonretryableMessageProcessingException(message, exception);

		classUnderTest.handleException(exception, message);

		verify(errorHandler, times(1)).handleNonretryableMessageProcessingException(message, exception);
	}
	
	@SneakyThrows
	@Test
	public void test_process_teci_data_whether_process_teci_method_of_type_edit_data_capture_service_is_invoked_correctly() {	
		Message message=textMessage(providerData);
		doNothing().when(typeEditDataCaptureService).processTECI(providerData);
		
		classUnderTest.processTECIData(message);		
		
		verify(typeEditDataCaptureService, times(1)).processTECI(providerData);
	}
	
	@SneakyThrows
	@Test
	public void test_process_teci_data_does_not_throw_exception_when_type_edit_data_capture_service_throws_io_exception_and_invokes_error_handler() {
		Message message=textMessage(providerData);
		doThrow(IOException.class).when(typeEditDataCaptureService).processTECI(providerData);
		
		assertThatCode(() -> classUnderTest.processTECIData(message)).doesNotThrowAnyException();
		
		verify(typeEditDataCaptureService, times(1)).processTECI(providerData);
		verify(errorHandler, times(1)).handleNonretryableMessageProcessingException(any(), any());
		verify(errorHandler, times(0)).handleRetryableMessageProcessingException(message, new Exception());
	}
	
	@SneakyThrows
	@Test
	public void test_process_teci_data_does_not_throw_exception_when_type_edit_data_capture_service_throws_null_pointer_exception_and_invokes_error_handler() {
		Message message=textMessage(providerData);
		doThrow(NullPointerException.class).when(typeEditDataCaptureService).processTECI(providerData);

		assertThatCode(() -> classUnderTest.processTECIData(message)).doesNotThrowAnyException();
		
		verify(typeEditDataCaptureService, times(1)).processTECI(providerData);
		verify(errorHandler, times(1)).handleNonretryableMessageProcessingException(any(), any());
		verify(errorHandler, times(0)).handleRetryableMessageProcessingException(message, new Exception());
	}
	
	@SneakyThrows
	@Test
	public void test_process_teci_data_does_not_throw_exception_when_type_edit_data_capture_service_throws_json_parse_exception_and_invokes_error_handler() {
		doThrow(JsonParseException.class).when(typeEditDataCaptureService).processTECI(providerData);
		Message message=textMessage(providerData);
		
		assertThatCode(() -> classUnderTest.processTECIData(message)).doesNotThrowAnyException();
		
		verify(typeEditDataCaptureService, times(1)).processTECI(providerData);
		verify(errorHandler, times(1)).handleNonretryableMessageProcessingException(any(), any());
		verify(errorHandler, times(0)).handleRetryableMessageProcessingException(message, new Exception());
	}
	
	@SneakyThrows	  
	@Test 
	public void test_process_teci_data_retry_functionality_when_mongo_db_exception_is_thrown_all_the_three_times_and_calling_recover_method() {
		MongoException exception = new MongoException("mongo_exception");
		doThrow(exception).when(typeEditDataCaptureService).processTECI(providerData);
		Message message=textMessage(providerData);
		
		assertThatCode(() -> classUnderTest.processTECIData(message)).doesNotThrowAnyException();

		verify(typeEditDataCaptureService, times(3)).processTECI(providerData);
		verify(errorHandler, times(0)).handleNonretryableMessageProcessingException(any(), any());
		verify(errorHandler, times(1)).handleRetryableMessageProcessingException(message, exception);
	}	
	
	@SneakyThrows	  
	@Test 
	public void test_process_teci_data_retry_functionality_when_mongo_db_exception_is_thrown_twice_and_runs_successfully_in_third_time() {
		MongoException exception = new MongoException("mongo_exception");
		doThrow(exception).doThrow(MongoException.class).doNothing().when(typeEditDataCaptureService).processTECI(providerData);
		Message message=textMessage(providerData);
		
		assertThatCode(() -> classUnderTest.processTECIData(message)).doesNotThrowAnyException();

		verify(typeEditDataCaptureService, times(3)).processTECI(providerData);
		verify(errorHandler, times(0)).handleNonretryableMessageProcessingException(any(), any());
		verify(errorHandler, times(0)).handleRetryableMessageProcessingException(message, exception);
	}
	
	@Configuration
	@EnableRetry
	public static class TECIRetryConfig {

		@Qualifier("teciTimer")
		@Bean
		public Timer teciDataCaptureQueueMetric() {
			Timer timer = Metrics.timer("test");
			return timer;
		}

		@Bean
		public JmsListenerErrorHandler teciJmsListenerErrorHandler() {
			return mock(JmsListenerErrorHandler.class);
		}
		
		@Bean
		public TypeEditDataCaptureService typeEditDataCaptureService() throws Exception {
			return mock(TypeEditDataCaptureService.class);
		}		

		@Bean
		public TECIJmsListener classUnderTest() throws Exception {
			TECIJmsListener exceptionListener = new TECIJmsListener(teciJmsListenerErrorHandler(), typeEditDataCaptureService());

			ReflectionTestUtils.setField(exceptionListener, "errorHandler", teciJmsListenerErrorHandler());
			ReflectionTestUtils.setField(exceptionListener, "typeEditDataCaptureService",
					typeEditDataCaptureService());
			return exceptionListener;
		}
	}
	
	@SneakyThrows
	public Message textMessage(String text) {
		JmsTextMessage jmsTextMessage = new JmsTextMessage(new AmqpJmsTextMessageFacade());
		jmsTextMessage.setText(text);
		return jmsTextMessage;
	}
}
